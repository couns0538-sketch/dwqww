from pathlib import Path
import json,re
HERE=Path(__file__).resolve().parent
PARENT='ff2e269c6058be84456e3b98344826d17b0056eb'
SOURCE_COMMIT='1d3ed25bea2c8b781f7ee5a178af0f66061b3984' # Root-declared frozen23 SHA; full native clearance remains required.
def load_freeze(stage='build'):
    assert stage in ('source','build')
    path=HERE/'WINDOWS-BUILD-CLEAR.json'
    if not path.is_file():raise RuntimeError('23 Windows OFFLINE PREPARATION ONLY: explicit root full-native42/8 clearance is required before exports/build/runtime/package/audit')
    data=json.loads(path.read_text())
    assert isinstance(SOURCE_COMMIT,str) and re.fullmatch(r'[0-9a-f]{40}',SOURCE_COMMIT),'Exact root23 source SHA not bound'
    assert data.get('authorization')=='23 WINDOWS BUILD CLEAR','Root23 execution authorization missing'
    assert data.get('source_commit')==SOURCE_COMMIT and data.get('parent_source_commit')==PARENT,'Incorrect frozen source/parent identity'
    for field,value in [('runtime_summary_checks',347),('correction_checks',54),('pawn_span_checks',37320),('nearest_pawn_checks',791680),('nearest_pawn_sets',395840),('pv_metadata_assertions',56),('source_files',74),('tt_groups',12)]:
        assert type(data.get(field)) is int and data[field]==value,'Root23 count mismatch: '+field
    assert data.get('bench_expected_nodes') is None,'Search-changing Windows23 signature must start unknown'
    assert data.get('bench_signature_policy')=='FIRST_NORMAL_CANDIDATE_CAPTURE_ONLY','Candidate first-capture signature policy required'
    assert data.get('root_proof_namespace')=='validation/tt-refresh-20261021','Incorrect root23 proof namespace'
    assert data.get('root_source_gates_path')=='/workspace/dwqww/validation/tt-refresh-20261021/ROOT-FROZEN23-SOURCE-GATES.json','Incorrect reviewed23 source-gate path'
    assert data.get('root_source_gates_sha256')=='f029228717c97678b124722efdba0ed7c9b356d90e4e79236597674ba82b7294','Incorrect reviewed23 source-gate bytes'
    assert data.get('tt_test_sha256')=='cc2fe3e9fb0059f409876345e8cfb3c008ede401751a4dad76b022f743238fd5','Incorrect reviewed23 TT test'
    return data
