#!/usr/bin/env python3
"""Post-closure identity check and exact tested Windows trial package."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import shutil
import sys
import zipfile

OUT = Path(__file__).resolve().parent
H = OUT.parent
BUILD = Path('/workspace/.cloud-setup/nnue-final-windows-attempt1/build')
SOURCE = BUILD.parent / 'source'
FROZEN = H / 'full-trained-net-freeze-attempt1'
TOOLS = Path('/workspace/.cloud-setup/toolchains/llvm-mingw-20261006-ucrt-ubuntu-22.04-x86_64')
NAME = 'forge-6.4.24-nnue-a52efa5f7864-trial-windows-zen5'
PACKAGE = OUT / NAME
COMMIT = '6e9622fd5be18e0155fc3ed5fcf6c4586705cca6'
NET_SHA = 'a52efa5f7864b04d0e8fceb3b14af4fc4970e0bb0a0a8706be0959b0bbb98df7'


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1048576), b''):
            h.update(chunk)
    return h.hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def copy(source, target):
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
    if sha(source) != sha(target):
        raise ValueError('Copied bytes differ: ' + str(target))


def main():
    if PACKAGE.exists() or (H / (NAME + '.zip')).exists():
        raise ValueError('Fresh package path required; no overwrite')
    result = read(OUT / 'RESULT.json')
    closed = read(OUT / 'controller.receipt.json')
    freeze = read(OUT / 'BENCH-SIGNATURE-FREEZE.json')
    source = read(OUT / 'SOURCE-FREEZE.json')
    protocol = read(OUT / 'PROTOCOL.json')
    if closed['returncode'] != 0 or result['tests_passed'] != 14 or not result['status'].startswith('PASS_WINDOWS_ZEN5_TRIAL_'):
        raise ValueError('Actual Windows qualification has not closed PASS')
    if result['source_commit'] != COMMIT or source['source_commit'] != COMMIT or result['net_sha256'] != NET_SHA:
        raise ValueError('Frozen candidate identity differs')
    for path, expected in protocol['protected_sha256'].items():
        if sha(path) != expected:
            raise ValueError('Protected runtime input changed: ' + path)
    current_source = {p.relative_to(SOURCE).as_posix(): sha(p) for p in SOURCE.rglob('*') if p.is_file()}
    if current_source != source['source_sha256'] or len(current_source) != 74:
        raise ValueError('Source bytes/file set changed after qualification')
    engine_sha = sha(BUILD / 'forge.exe')
    if engine_sha != result['binaries']['forge.exe']['sha256'] or engine_sha != freeze['engine_sha256']:
        raise ValueError('Actual final engine differs from first genuine bench freeze')
    for name, record in result['binaries'].items():
        if sha(BUILD / name) != record['sha256']:
            raise ValueError('Actual tested binary changed: ' + name)
    for name in result['checks']:
        if read(OUT / ('test-' + name + '.receipt.json'))['returncode'] != 0:
            raise ValueError('An original test receipt is not PASS')
    for stem in ('bench-first', 'bench-repeat', 'windows-parity'):
        if read(OUT / (stem + '.receipt.json'))['returncode'] != 0:
            raise ValueError('Actual qualification receipt differs: ' + stem)
    parity = read(OUT / 'parity/RESULT.json')
    if parity['status'] != 'PASS' or parity['weights_sha256'] != NET_SHA:
        raise ValueError('Chosen Windows network parity differs')
    proof = {'status': 'PASS_POST_CLOSURE_WINDOWS_TRIAL_IDENTITY',
        'utc': datetime.now(timezone.utc).isoformat(), 'source_commit': COMMIT,
        'engine_sha256': engine_sha, 'net_sha256': NET_SHA, 'first_bench_engine_sha256': freeze['engine_sha256'],
        'final_engine_equals_first_bench_freeze': True, 'result_sha256': sha(OUT / 'RESULT.json'),
        'controller_receipt_sha256': sha(OUT / 'controller.receipt.json'),
        'windows_parity_result_sha256': sha(OUT / 'parity/RESULT.json'), 'checks_passed': 14,
        'source_files': len(current_source), 'selected_inc_matches_source': sha(SOURCE / 'src/nnue_weights.inc') == NET_SHA,
        'scope': 'Actual delivered/tested byte identity and Wine qualification only; no native Ryzen/Windows, speed or Elo claim'}
    (OUT / 'POST-CLOSURE-IDENTITY.json').write_text(json.dumps(proof, indent=2) + '\n')
    PACKAGE.mkdir()
    exe_name = 'forge-6.4.24-nnue-a52efa5f7864-trial-zen5.exe'
    copy(BUILD / 'forge.exe', PACKAGE / exe_name)
    for name in ('nnue_weights.inc', 'nnue_weights.bin', 'checkpoint.pt', 'original-export.json', 'FREEZE.json'):
        copy(FROZEN / name, PACKAGE / 'weights' / name)
    copy(SOURCE / 'LICENSE', PACKAGE / 'LICENSE')
    copy(TOOLS / 'LICENSE.TXT', PACKAGE / 'licenses/LLVM-MinGW-LICENSE.TXT')
    for name in ('COPYING', 'COPYING.MinGW-w64.txt', 'COPYING.MinGW-w64-runtime.txt', 'COPYING.winpthreads.txt', 'COPYING.winstorecompat.txt'):
        copy(TOOLS / 'x86_64-w64-mingw32/share/mingw32' / name, PACKAGE / 'licenses' / name)
    for name in current_source:
        copy(SOURCE / name, PACKAGE / 'source' / name)
    evidence_files = [p for p in OUT.rglob('*') if p.is_file() and PACKAGE not in p.parents
        and p.name not in ('PACKAGE-RESULT.json', 'PACKAGE-FILES-SHA256.json')
        and not p.name.startswith('packaging.')]
    for path in evidence_files:
        copy(path, PACKAGE / 'evidence' / path.relative_to(OUT))
    for name in result['binaries']:
        if name != 'forge.exe':
            copy(BUILD / name, PACKAGE / 'evidence/tested-binaries' / name)
    copy(BUILD / 'libforge_core.a', PACKAGE / 'evidence/tested-binaries/libforge_core.a')
    for path in sorted((BUILD / 'CMakeFiles').rglob('*.obj')):
        copy(path, PACKAGE / 'evidence/objects' / path.relative_to(BUILD))
    provenance = {**proof, 'engine_filename': exe_name, 'compiler_flags': protocol['flags'],
        'source_url': 'https://github.com/couns0538-sketch/dwqww/tree/' + COMMIT,
        'bench11_nodes': result['first_bench_nodes'], 'bench_repeat_identical_nodes': True,
        'qualification': '9 actual C++ Windows tests under Wine plus5 original Python tool/UCI/ponder/OwnBook checks; actual2048-position Windows inference parity',
        'windows_parity': result['windows_native_inference_parity'], 'trial_not_elo_accepted': True}
    (PACKAGE / 'PROVENANCE.json').write_text(json.dumps(provenance, indent=2) + '\n')
    (PACKAGE / 'README.txt').write_text(f'''Forge 6.4.24 NNUE trial - Windows x64 Zen5 / Ryzen 7 9850X3D

Engine: {exe_name}
Engine SHA256: {engine_sha}
Source: {COMMIT}
Network SHA256: {NET_SHA}

This is a TRIAL, NOT ELO ACCEPTED. The clean source commit changes only the
selected residual H128 network from baseline 1ab. Search, evaluation code and
tests are unchanged. The network is compiled in; no EvalFile/DLL download is
required. Keep LICENSE and bundled runtime notices when redistributing.

Build: LLVM-MinGW 23.1.3, C++20, Release/O3, -march=znver5 -mtune=znver5,
-fno-fast-math -ffp-contract=off -fno-lto, static linking. Target compatible
Zen5 Windows x64 hardware. The executable identifies as 6.4.24 candidate in UCI;
the distinct filename/network SHA identifies this trained-network trial.

Actual qualification: all 14 original checks passed through Wine/host-Python
adapters; selected network passed 2048-position actual Windows C++ versus shared
Python inference parity. First actual bench11 signature was {result['first_bench_nodes']}
nodes and repeated exactly. These are correctness/repeatability results, not
speed or Elo evidence. No timed Wine matches were run. Native Windows on your
physical Ryzen and the external crew's strength acceptance remain separate.

Load the executable as a UCI engine in your chess GUI. For comparable testing,
use the documented match protocol, same clocks/hash/thread settings and paired
openings. This package makes no Stockfish-superiority claim.

Exact selected weights/checkpoint, clean source, original commands/streams/
receipts, PE/import/disassembly checks, all tested helper PEs/core/objects and
SHA256 manifests are included for recovery and independent inspection.
''')
    files = {p.relative_to(PACKAGE).as_posix(): {'sha256': sha(p), 'bytes': p.stat().st_size}
        for p in sorted(PACKAGE.rglob('*')) if p.is_file()}
    (PACKAGE / 'FILES-SHA256.json').write_text(json.dumps(files, indent=2) + '\n')
    archive = H / (NAME + '.zip')
    with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for path in sorted(PACKAGE.rglob('*')):
            if path.is_file():
                z.write(path, str(Path(NAME) / path.relative_to(PACKAGE)))
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None:
            raise ValueError('Archive CRC failure')
        for name, info in files.items():
            with z.open(NAME + '/' + name) as f:
                h = hashlib.sha256()
                for chunk in iter(lambda: f.read(1048576), b''):
                    h.update(chunk)
            if h.hexdigest() != info['sha256']:
                raise ValueError('Archived bytes differ: ' + name)
    if sha(BUILD / 'forge.exe') != engine_sha or sha(PACKAGE / exe_name) != engine_sha:
        raise ValueError('Final tested/delivered engine differs')
    record = {'status': 'PASS_EXACT_TESTED_WINDOWS_ZEN5_TRIAL_PACKAGE', 'path': str(archive),
        'bytes': archive.stat().st_size, 'sha256': sha(archive), 'engine_sha256': engine_sha,
        'source_commit': COMMIT, 'net_sha256': NET_SHA, 'entries_sha256_verified': len(files),
        'source_files': len(current_source), 'scope': proof['scope']}
    (OUT / 'PACKAGE-RESULT.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record, indent=2), flush=True)


if __name__ == '__main__':
    main()
