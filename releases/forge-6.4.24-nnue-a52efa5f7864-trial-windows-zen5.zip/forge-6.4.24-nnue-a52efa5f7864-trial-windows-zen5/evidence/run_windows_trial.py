#!/usr/bin/env python3
"""Frozen net-only Windows trial; preserve each actual process and failure."""
from pathlib import Path
from datetime import datetime, timezone
import difflib
import hashlib
import json
import os
import re
import shlex
import shutil
import signal
import subprocess
import sys
import time
import zipfile

R = Path('/workspace/dwqww')
H = Path('/workspace/forge-nnue-handoff-20261023')
OUT = Path(__file__).resolve().parent
PRIVATE = Path('/workspace/.cloud-setup/nnue-final-windows-attempt1')
SOURCE, BUILD = PRIVATE / 'source', PRIVATE / 'build'
BASE = '1ab50b2dd64d9b2f752f7f1285f6968cad2fd792'
COMMIT = '6e9622fd5be18e0155fc3ed5fcf6c4586705cca6'
FROZEN = H / 'full-trained-net-freeze-attempt1'
INC = FROZEN / 'nnue_weights.inc'
NET_SHA = 'a52efa5f7864b04d0e8fceb3b14af4fc4970e0bb0a0a8706be0959b0bbb98df7'
FREEZE_SHA = '3d945dc1f0e20d3469791eeb36b9ad5b23a1e70c87f6615703d0fda3442e211c'
PY = Path('/workspace/.cloud-setup/nnue-pipeline-20261023-venv/bin/python')
TOOLS = Path('/workspace/.cloud-setup/toolchains/llvm-mingw-20261006-ucrt-ubuntu-22.04-x86_64')
CMAKE = Path('/workspace/.cloud-setup/venv/bin/cmake')
WINE = Path('/workspace/.cloud-setup/wine/usr/lib/wine/wine64')
PROBE_SOURCE = R / 'tools/nnue/engine_probe.cpp'
PARITY_SOURCE = R / 'tools/nnue/tests/test_engine_parity.py'
FLAGS = ['-std=gnu++20', '-O3', '-DNDEBUG', '-march=znver5', '-mtune=znver5',
         '-fno-fast-math', '-ffp-contract=off', '-fno-lto']
ENV = dict(os.environ, LLVM_MINGW_ROOT=str(TOOLS), PYTHONDONTWRITEBYTECODE='1',
           OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1',
           WINEPREFIX='/workspace/.cloud-setup/wine-prefix-ready', WINEDEBUG='-all',
           XDG_CACHE_HOME='/workspace/.cloud-setup/font-cache')
ENV['PATH'] = str(TOOLS / 'bin') + ':/usr/bin:/bin:' + ENV.get('PATH', '')
SOURCE_HASHES = {}
SOURCE_MODES = {}
PROTECTED = {}
CHILD = None


def utc():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    d = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1048576), b''):
            d.update(chunk)
    return d.hexdigest()


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def stable():
    for path, expected in PROTECTED.items():
        if sha(path) != expected:
            raise ValueError('Protected input changed: ' + path)
    if SOURCE_HASHES:
        current = {p.relative_to(SOURCE).as_posix(): sha(p) for p in SOURCE.rglob('*') if p.is_file()}
        if current != SOURCE_HASHES:
            raise ValueError('Frozen clean source bytes/file set changed')
        modes = {name: oct((SOURCE / name).stat().st_mode & 0o777) for name in SOURCE_HASHES}
        if modes != SOURCE_MODES:
            raise ValueError('Frozen clean source modes changed')


def run(stem, command, *, payload=None, timeout=300, cwd=None):
    global CHILD
    stable()
    record = {'command': list(map(str, command)), 'cwd': str(cwd or OUT), 'utc_started': utc(),
        'environment': {key: ENV[key] for key in ('LLVM_MINGW_ROOT', 'PYTHONDONTWRITEBYTECODE',
        'OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'WINEPREFIX', 'WINEDEBUG', 'XDG_CACHE_HOME')},
        'timeout_seconds': timeout, 'stdin_sha256': hashlib.sha256(payload).hexdigest() if payload is not None else None}
    write(stem + '.command.json', record)
    if payload is not None:
        with (OUT / (stem + '.stdin')).open('xb') as f:
            f.write(payload)
    timed_out = False
    started = time.monotonic()
    with (OUT / (stem + '.stdout')).open('xb') as stdout, (OUT / (stem + '.stderr')).open('xb') as stderr:
        CHILD = subprocess.Popen(record['command'], cwd=cwd or OUT, env=ENV,
            stdin=subprocess.PIPE if payload is not None else subprocess.DEVNULL,
            stdout=stdout, stderr=stderr, start_new_session=True)
        record['pid'] = CHILD.pid
        record['pgid'] = CHILD.pid
        write(stem + '.START.json', record)
        try:
            CHILD.communicate(input=payload, timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(CHILD.pid, signal.SIGTERM)
            try:
                CHILD.communicate(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(CHILD.pid, signal.SIGKILL)
                CHILD.communicate()
        rc = CHILD.returncode
        CHILD = None
    record.update(returncode=rc, timed_out=timed_out, owned_process_reaped=True,
        utc_closed=utc(), elapsed_seconds_diagnostic_only=time.monotonic() - started,
        stdout_sha256=sha(OUT / (stem + '.stdout')), stderr_sha256=sha(OUT / (stem + '.stderr')))
    write(stem + '.receipt.json', record)
    stable()
    print(json.dumps({'stage': stem, 'returncode': rc, 'timed_out': timed_out}), flush=True)
    if rc or timed_out:
        raise RuntimeError('Stage failed, original evidence retained: ' + stem)
    return (OUT / (stem + '.stdout')).read_text(errors='replace')


def export_source():
    global SOURCE_HASHES, SOURCE_MODES
    if PRIVATE.exists():
        raise ValueError('Fresh private path required')
    names = subprocess.check_output(['git', '-C', str(R), 'diff', '--name-only', BASE, COMMIT], text=True).splitlines()
    if names != ['src/nnue_weights.inc']:
        raise ValueError('Clean commit has more than the selected network change')
    rows = subprocess.check_output(['git', '-C', str(R), 'ls-tree', '-r', '-z', COMMIT, '--',
        'CMakeLists.txt', 'LICENSE', 'bench', 'include', 'src', 'tests', 'tools']).split(b'\0')
    omitted = []
    for row in rows:
        if not row:
            continue
        metadata, name = row.split(b'\t', 1)
        mode, kind, object_id = metadata.decode().split()
        name = name.decode()
        if name.endswith('.pyc'):
            omitted.append(name)
            continue
        if kind != 'blob' or mode not in ('100644', '100755'):
            raise ValueError('Unsupported clean tree member')
        data = subprocess.check_output(['git', '-C', str(R), 'cat-file', 'blob', object_id])
        target = SOURCE / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        target.chmod(0o755 if mode == '100755' else 0o644)
        SOURCE_HASHES[name] = hashlib.sha256(data).hexdigest()
        SOURCE_MODES[name] = oct(target.stat().st_mode & 0o777)
    if len(SOURCE_HASHES) != 74 or SOURCE_HASHES['src/nnue_weights.inc'] != NET_SHA or (SOURCE / 'src/nnue_weights.inc').read_bytes() != INC.read_bytes():
        raise ValueError('Actual clean source export/net binding differs')
    write('SOURCE-FREEZE.json', {'source_commit': COMMIT, 'baseline': BASE, 'source': str(SOURCE),
        'build': str(BUILD), 'source_files': len(SOURCE_HASHES), 'source_sha256': SOURCE_HASHES,
        'source_modes': SOURCE_MODES, 'omitted_historical_pyc': omitted,
        'only_delta_from_base': names, 'frozen_include_sha256': NET_SHA,
        'freeze_json_sha256': FREEZE_SHA, 'source_exported_from_actual_clean_commit': True})
    stable()


def launcher(path, exe):
    path.write_text('#!/bin/bash\n' + ''.join('export ' + key + '=' + shlex.quote(ENV[key]) + '\n'
        for key in ('WINEPREFIX', 'WINEDEBUG', 'XDG_CACHE_HOME'))
        + 'exec ' + shlex.quote(str(WINE)) + ' ' + shlex.quote(str(exe)) + ' "$@"\n')
    path.chmod(0o755)


def main():
    if (OUT / 'PROTOCOL.json').exists():
        raise ValueError('Do not overwrite an existing execution attempt')
    if sha(INC) != NET_SHA or sha(FROZEN / 'FREEZE.json') != FREEZE_SHA:
        raise ValueError('Root-authorized immutable network binding differs')
    frozen = json.loads((FROZEN / 'FREEZE.json').read_text())
    if frozen['chosen']['inc_sha256'] != NET_SHA:
        raise ValueError('Chosen selector receipt differs')
    pins = json.loads((R / 'validation/see-proof-reuse-windows-20261021/PINNED-TOOLS.json').read_text())['tools']
    for record in pins.values():
        if sha(record['path']) != record['sha256']:
            raise ValueError('Verified Windows tool changed: ' + record['path'])
        PROTECTED[record['path']] = record['sha256']
    PROTECTED.update({str(INC): NET_SHA, str(FROZEN / 'FREEZE.json'): FREEZE_SHA,
        str(PROBE_SOURCE): 'a4d584955d9cdf1185b6bec6efe884d90babf1a7bbcb79de1b0c40f69b647629',
        str(PARITY_SOURCE): 'e2107a375c39dfd83ef276b3018f5f5665dfdb7b7835b772ca820d7dd3510d3a',
        str(R / 'src/nnue_weights.inc'): '41487f328ff51f27417564df45b6f3139d038b7e940dedb121340bd61be9a4d3',
        str(Path(__file__)): sha(Path(__file__))})
    for path in (R / 'tools/nnue/train_nnue.py', R / 'tools/nnue/include_parser.py', R / 'tools/nnue/examples/forge_sample.txt'):
        PROTECTED[str(path)] = sha(path)
    write('PROTOCOL.json', {'utc': utc(), 'source_commit': COMMIT, 'base_commit': BASE,
        'chosen_inc': str(INC), 'chosen_sha256': NET_SHA, 'freeze_sha256': FREEZE_SHA,
        'protected_sha256': PROTECTED, 'flags': FLAGS, 'parallel_build_jobs': 1,
        'expected_new_bench_nodes': None, 'bench_policy': 'First genuine new-net signature then one same-binary repeat; no old-network signature requirement',
        'scope': 'Wine functional correctness, chosen-network parity and trial packaging; no timed matches, NPS, Elo or native Ryzen/Windows claim'})
    export_source()
    run('compiler-version', [TOOLS / 'bin/x86_64-w64-mingw32-clang++', '--version'])
    run('wine-version', [WINE, '--version'])
    run('cmake-configure', [CMAKE, '-S', SOURCE, '-B', BUILD, '-DCMAKE_BUILD_TYPE=Release',
        '-DCMAKE_TOOLCHAIN_FILE=' + str(SOURCE / 'tools/windows-zen5.cmake'), '-DCMAKE_MAKE_PROGRAM=/usr/bin/gmake',
        '-DPython3_EXECUTABLE=' + str(PY), '-DCMAKE_CXX_FLAGS=' + ' '.join(FLAGS[3:]),
        '-DCMAKE_EXE_LINKER_FLAGS=-static -fno-lto', '-DFORGE_NATIVE=OFF',
        '-DCMAKE_INTERPROCEDURAL_OPTIMIZATION=OFF', '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON'], timeout=180)
    run('cmake-build', [CMAKE, '--build', BUILD, '--parallel', '1'], timeout=900)
    for name in ('CMakeCache.txt', 'compile_commands.json'):
        shutil.copyfile(BUILD / name, OUT / name)
    for path in sorted((BUILD / 'CMakeFiles').glob('*.dir/flags.make')) + sorted((BUILD / 'CMakeFiles').glob('*.dir/link.txt')):
        shutil.copyfile(path, OUT / path.relative_to(BUILD).as_posix().replace('/', '_'))
    pe = run('engine-pe-imports', [TOOLS / 'bin/llvm-readobj', '--file-headers', '--coff-imports', BUILD / 'forge.exe'])
    if 'IMAGE_FILE_MACHINE_AMD64' not in pe:
        raise ValueError('Built engine is not AMD64 PE')
    imports = re.findall(r'^\s*Name: (\S+\.dll)\s*$', pe, re.M | re.I)
    if any(name.lower() not in ('kernel32.dll', 'advapi32.dll', 'user32.dll', 'shell32.dll', 'ws2_32.dll', 'ntdll.dll', 'msvcrt.dll', 'ucrtbase.dll', 'bcrypt.dll', 'ole32.dll') and not name.lower().startswith('api-ms-win-') for name in imports):
        raise ValueError('Unexpected non-system runtime import: ' + repr(imports))
    assembly = run('engine-disassembly', [TOOLS / 'bin/llvm-objdump', '-d', '--no-show-raw-insn', BUILD / 'forge.exe'])
    simd = {'avx2_minmax_ymm': bool(re.search(r'v(?:max|min)ps[^\n]*ymm', assembly)),
        'avx2_multiply_ymm': bool(re.search(r'vmulps[^\n]*ymm', assembly)),
        'avx2_add_ymm': bool(re.search(r'vaddps[^\n]*ymm', assembly)),
        'fused_operations': sorted(set(re.findall(r'\bv(?:fmadd|fmsub|fnmadd|fnmsub)\w*\b', assembly)))}
    write('SIMD.json', simd)
    if not all(simd[key] for key in ('avx2_minmax_ymm', 'avx2_multiply_ymm', 'avx2_add_ymm')) or simd['fused_operations']:
        raise ValueError('Expected strict vector arithmetic/no-FMA check failed')
    wrapper = OUT / 'forge-wine'
    launcher(wrapper, BUILD / 'forge.exe')
    original = SOURCE / 'tools/ownbook_regression.py'
    adapted = OUT / 'ownbook-wine-regression.py'
    text = original.read_text()
    if text.count('str(book)') != 2 or text.count('{book} with 1 entries') != 2:
        raise ValueError('Original OwnBook adapter shape changed')
    new = text.replace('ROOT = Path(__file__).resolve().parents[1]', 'ROOT = Path(' + repr(str(SOURCE)) + ')')
    new = new.replace('            e.send("setoption name Book File value " + str(book))',
        '            book_sent = "Z:" + str(book).replace("/", chr(92))\n            e.send("setoption name Book File value " + book_sent)', 1)
    new = new.replace(' + str(book))', ' + book_sent)').replace('{book} with 1 entries', '{book_sent} with 1 entries')
    compile(new, str(adapted), 'exec')
    adapted.write_text(new)
    (OUT / 'ownbook-path-only.diff').write_text(''.join(difflib.unified_diff(text.splitlines(True), new.splitlines(True), fromfile='pristine/tools/ownbook_regression.py', tofile='evidence/ownbook-wine-regression.py')))
    win = lambda path: 'Z:' + str(path).replace('/', chr(92))
    checks = []
    tests = [('core', 'forge_tests'), ('correction-history', 'forge_correction_history_tests'),
        ('runtime-psqt', 'forge_runtime_psqt_tests'), ('pawn-span', 'forge_pawn_span_tests'),
        ('nearest-pawn', 'forge_nearest_pawn_tests'), ('pv-metadata', 'forge_pv_metadata_tests'),
        ('coherent-tt', 'forge_tt_tests'), ('rule50', 'forge_rule50_tests'), ('legal-witness', 'forge_legal_witness_tests')]
    for name, binary in tests:
        command = [WINE, BUILD / (binary + '.exe')]
        if name == 'legal-witness':
            command += [win(SOURCE / 'tests/legal_witness_fixtures.tsv'), win(SOURCE / 'tools/openings/forge-10000.epd')]
        run('test-' + name, command, cwd=BUILD)
        checks.append(name)
    for name, command in [
        ('match-tools', [PY, '-B', SOURCE / 'tools/match/test_match_tools.py']),
        ('windows-validation-tools', [PY, '-B', SOURCE / 'tools/match/tests/test_windows_validate.py']),
        ('uci', [PY, '-B', SOURCE / 'tools/uci_regression.py', wrapper, '--log', OUT / 'uci-transcript.log']),
        ('ponder', [PY, '-B', SOURCE / 'tools/ponder_regression.py', wrapper]),
        ('ownbook', [PY, '-B', adapted, wrapper, OUT / 'ownbook-transcript.json'])]:
        run('test-' + name, command, cwd=BUILD)
        checks.append(name)
    if len(checks) != 14:
        raise ValueError('Not all original tests executed')
    first = run('bench-first', [WINE, BUILD / 'forge.exe'], payload=b'bench 11\nquit\n', cwd=BUILD)
    parse = lambda text: re.findall(r'^info string bench depth 11 nodes (\d+) time \d+ nps \d+\s*$', text, re.M)
    signature = parse(first)
    if len(signature) != 1 or int(signature[0]) <= 0:
        raise ValueError('First new-network bench signature invalid')
    nodes = int(signature[0])
    write('BENCH-SIGNATURE-FREEZE.json', {'utc': utc(), 'source_commit': COMMIT, 'net_sha256': NET_SHA,
        'engine_sha256': sha(BUILD / 'forge.exe'), 'first_actual_nodes': nodes,
        'first_original_stdout_sha256': sha(OUT / 'bench-first.stdout'),
        'expected_before_first_execution': None, 'hash_mib': 16, 'threads': 1,
        'scope': 'Logical-work repeatability only; no speed or Elo'})
    second = run('bench-repeat', [WINE, BUILD / 'forge.exe'], payload=b'bench 11\nquit\n', cwd=BUILD)
    if parse(second) != [str(nodes)]:
        raise ValueError('Same-binary new-network bench repeat differs; first capture remains preserved')
    shutil.copyfile(PROBE_SOURCE, OUT / 'engine_probe.cpp')
    run('compile-windows-probe', [TOOLS / 'bin/x86_64-w64-mingw32-clang++', *FLAGS,
        '-DFORGE_NNUE_HIDDEN=128', '-I', SOURCE / 'include', OUT / 'engine_probe.cpp', BUILD / 'libforge_core.a',
        '-pthread', '-static', '-o', BUILD / 'forge_nnue_probe.exe'], timeout=180)
    probe_wrapper = OUT / 'forge-probe-wine'
    launcher(probe_wrapper, BUILD / 'forge_nnue_probe.exe')
    run('windows-parity', [PY, '-B', PARITY_SOURCE, '--probe', probe_wrapper, '--weights', INC,
        '--positions', '2048', '--seed', '20261023', '--out', OUT / 'parity'], timeout=180, cwd=BUILD)
    parity = json.loads((OUT / 'parity/RESULT.json').read_text())
    if parity['status'] != 'PASS' or parity['weights_sha256'] != NET_SHA:
        raise ValueError('Actual Windows chosen-network parity failed')
    stable()
    binaries = {p.name: {'path': str(p), 'sha256': sha(p), 'bytes': p.stat().st_size} for p in sorted(BUILD.glob('*.exe'))}
    result = {'status': 'PASS_WINDOWS_ZEN5_TRIAL_14_TESTS_PARITY_AND_REPEATABLE_BENCH_NOT_ELO_ACCEPTED',
        'utc': utc(), 'source_commit': COMMIT, 'base_commit': BASE, 'net_sha256': NET_SHA,
        'freeze_json_sha256': FREEZE_SHA, 'checks': checks, 'tests_passed': len(checks),
        'first_bench_nodes': nodes, 'repeat_nodes_equal': True, 'simd': simd, 'imports': imports,
        'windows_native_inference_parity': {key: parity[key] for key in ('positions', 'exact_integer_matches', 'maximum_integer_cp_error', 'feature_mismatch_count')},
        'binaries': binaries, 'windows_core_sha256': sha(BUILD / 'libforge_core.a'),
        'source_inputs_unchanged': True, 'default_net_unchanged': True,
        'scope': 'Wine functional correctness/inference parity/logical-work repeatability only. Not native Windows/Ryzen validation, speed/NPS, strength or Elo acceptance.'}
    write('RESULT.json', result)
    print(json.dumps(result, indent=2), flush=True)


if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        if CHILD is not None:
            if CHILD.poll() is None:
                os.killpg(CHILD.pid, signal.SIGKILL)
            CHILD.wait()
        write('FAILED.json', {'status': 'FAILED_PRESERVE_ORIGINALS_NO_RETRY', 'utc': utc(), 'error': repr(error)})
        raise
