from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,sys
out=Path(__file__).resolve().parent
command=[sys.executable,'-B',str(out/'package_windows_trial.py')]
(out/'packaging.command.json').write_text(json.dumps({'command':command,'script_sha256':hashlib.sha256((out/'package_windows_trial.py').read_bytes()).hexdigest()},indent=2)+'\n')
with (out/'packaging.stdout').open('xb') as stdout,(out/'packaging.stderr').open('xb') as stderr:
    p=subprocess.run(command,stdout=stdout,stderr=stderr,timeout=300,check=False)
record={'command':command,'returncode':p.returncode,'utc_closed':datetime.now(timezone.utc).isoformat(),'stdout_sha256':hashlib.sha256((out/'packaging.stdout').read_bytes()).hexdigest(),'stderr_sha256':hashlib.sha256((out/'packaging.stderr').read_bytes()).hexdigest()}
(out/'packaging.receipt.json').write_text(json.dumps(record,indent=2)+'\n')
print((out/'packaging.stdout').read_text(),end='')
if p.returncode:print((out/'packaging.stderr').read_text(),file=sys.stderr,end='')
print(json.dumps({'packaging_returncode':p.returncode,'stderr_bytes':(out/'packaging.stderr').stat().st_size}),flush=True)
raise SystemExit(p.returncode)
