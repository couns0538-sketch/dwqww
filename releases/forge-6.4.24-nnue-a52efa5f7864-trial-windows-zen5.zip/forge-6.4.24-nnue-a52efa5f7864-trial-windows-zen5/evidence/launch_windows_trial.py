from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,sys
out=Path(__file__).resolve().parent
command=[sys.executable,'-B',str(out/'run_windows_trial.py')]
(out/'controller.command.json').write_text(json.dumps({'command':command,'driver_sha256':hashlib.sha256((out/'run_windows_trial.py').read_bytes()).hexdigest()},indent=2)+'\n')
with (out/'controller.stdout').open('xb') as log,(out/'controller.stderr').open('xb') as stderr:
    p=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=stderr)
    for line in p.stdout:
        log.write(line);log.flush();sys.stdout.buffer.write(line);sys.stdout.buffer.flush()
    rc=p.wait()
record={'command':command,'returncode':rc,'utc_closed':datetime.now(timezone.utc).isoformat(),'stdout_sha256':hashlib.sha256((out/'controller.stdout').read_bytes()).hexdigest(),'stderr_sha256':hashlib.sha256((out/'controller.stderr').read_bytes()).hexdigest()}
(out/'controller.receipt.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'controller_returncode':rc,'stderr_bytes':(out/'controller.stderr').stat().st_size}),flush=True)
raise SystemExit(rc)
