Forge 6.4.24 NNUE trial - Windows x64 Zen5 / Ryzen 7 9850X3D

Engine: forge-6.4.24-nnue-a52efa5f7864-trial-zen5.exe
Engine SHA256: 2adc0429d238208ae9ae1a7788d6c570d9eb649b58c737bd8358d6004703518e
Source: 6e9622fd5be18e0155fc3ed5fcf6c4586705cca6
Network SHA256: a52efa5f7864b04d0e8fceb3b14af4fc4970e0bb0a0a8706be0959b0bbb98df7

This is a TRIAL, NOT ELO ACCEPTED. The clean source commit changes only the
selected residual H128 network from baseline 1ab. Search, evaluation code and
tests are unchanged. The network is compiled in; no EvalFile/DLL download is
required. Keep LICENSE and bundled runtime notices when redistributing.

Build: LLVM-MinGW 23.1.3, C++20, Release/O3, -march=znver5 -mtune=znver5,
-fno-fast-math -ffp-contract=off -fno-lto, static linking. Target compatible
Zen5 Windows x64 hardware. The executable identifies as 6.4.24 candidate in UCI;
the distinct filename/network SHA identifies this trained-network trial.

Actual qualification: all 14 original checks passed through Wine/host-Python
adapters; selected network passed 2048-position actual Windows C++ versus shared
Python inference parity. First actual bench11 signature was 378596
nodes and repeated exactly. These are correctness/repeatability results, not
speed or Elo evidence. No timed Wine matches were run. Native Windows on your
physical Ryzen and the external crew's strength acceptance remain separate.

Load the executable as a UCI engine in your chess GUI. For comparable testing,
use the documented match protocol, same clocks/hash/thread settings and paired
openings. This package makes no Stockfish-superiority claim.

Exact selected weights/checkpoint, clean source, original commands/streams/
receipts, PE/import/disassembly checks, all tested helper PEs/core/objects and
SHA256 manifests are included for recovery and independent inspection.
