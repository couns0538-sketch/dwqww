# LLVM-MinGW Clang 23/libc++ requires explicit malloc/free declarations in
# bundled fmt's format.cc. Force the standard header for this unit only.
# Fastchess and third-party source files remain unchanged.
$(BUILDDIR)/third_party/fmt/src/format.o: CXXFLAGS += -include cstdlib
