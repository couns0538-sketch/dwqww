@echo off
setlocal
cd /d "%~dp0"
"%~dp0runtime\python.exe" -I -B "%~dp0windows_validate.py" --aa-only --zip-results %*
set "FORGE_VALIDATION_EXIT=%ERRORLEVEL%"
echo.
echo Readiness ended with exit code %FORGE_VALIDATION_EXIT%. Evidence is under results.
exit /b %FORGE_VALIDATION_EXIT%
