Forge 6.4.2 candidate: offline Windows validation bundle
Target engine: Ryzen 7 9850X3D / Zen 5, Windows x64

Extract the complete bundle into an ASCII-only path, for example
C:\Forge Validation. Spaces are supported. Keep every bundled file together.
No installation, credentials, network access or administrator rights are needed.

RUN

Double-click run-readiness.cmd for the four-pair deterministic readiness check.
Double-click run-validation.cmd for one complete fresh attempt:

  1. A/A readiness: exact original release versus itself, 4 color-swapped pairs,
     10,000 nodes per move, unlimited clock, concurrency 2.
  2. Timed pilot: candidate versus original, 8 new color-swapped pairs,
     10 seconds plus 0.1 second per move, concurrency 1.
  3. Timed paired logistic SPRT: H0=0, H1=5 Elo, alpha=beta=0.05,
     same 10+0.1 control, concurrency 1, at most 5,000 pairs / 10,000 games.

All phases use Threads=1, Hash=32 MiB, OwnBook=false, Ponder=false,
Move Overhead=100 ms, a fresh engine process per game, strict error handling,
and no score/move-cap/tablebase adjudication. Pilot and SPRT start only after
the preceding gates pass. The full run is for native Windows. Wine is allowed
only with --aa-only for transport/readiness; it cannot establish native Elo.

Equivalent terminal commands, from this directory:

  runtime\python.exe -I -B windows_validate.py --aa-only --zip-results
  runtime\python.exe -I -B windows_validate.py --zip-results

Use both -I and -B. The first isolates Python; the second prevents bytecode
writes into the frozen runtime. This is a complete portable Python runtime.

RESULTS AND TIME

Each launch creates a new results\TIMESTAMP-ID directory and, on completion,
a matching ZIP containing all evidence. result.json records overall outcome;
aa\result.json, pilot\result.json and sprt\result.json hold phase details.
The console and active phase status update every 10 seconds. Leave the machine
and console running; there is no unattended service or remote hourly reporter.

A SPRT may stop at a native boundary, or reach its cap inconclusively. The cap
is 10,000 serial timed games and can take several days. Full deferred UCI traces
are retained, including failures, and can occupy multiple gigabytes. Allow
ample free disk space (20 GB is a practical starting allowance). The final ZIP
also needs free space. Avoid other heavy CPU jobs during a timed comparison.

Ctrl+C stops the owned Fastchess child and preserves the interrupted attempt
as invalid. The runner never resumes, retries, discards games or pools attempts.
Do not restart repeatedly to obtain H1. Keep a failed attempt and investigate
it before designing a different experiment. Do not modify bundle files after
freezing: every listed input is hashed before play and checked after each phase.

WHAT THIS COMPARES

Candidate: engine\candidate.exe, Forge 6.4.2 candidate, source commit
f6f0a00b2f98a7a9f117790e2c8f19a340b6769f, LLVM-MinGW Clang 23.1.3,
Release -march=znver5 -mtune=znver5 -fno-fast-math -ffp-contract=off -static.
It adds TT-tag/clock/stalemate fixes, AVX2 evaluation and complete promotion
generation relative to the original release. No accepted Elo gain exists yet.

Reference: engine\original-6.4.exe is the unmodified znver4 Windows release PE
from the user's exact Forge 6.4.0 ZIP (archive SHA-256 starts 98d2ff2c523a2593).
Its original build flags/source-to-binary relationship were not independently
authenticated. The comparison is between these complete Windows releases,
including compiler and architecture-flag differences. It does not isolate any
single source change. Both bundled sources and source/build evidence are kept
under sources\ and provenance\. The original shipped PE was not rebuilt.

An accepted H1 requires every retained game to belong to a complete, normal,
unique, color-swapped pair; exact opening-prefix and native outcome agreement;
unchanged inputs; exactly one finite native acceptance; and an independently
recomputed paired likelihood agreeing with native rounded LLR and crossing
the proper boundary. H1 is evidence of gain for this opponent and 10+0.1
protocol. It does not prove a gain of at least 5 Elo. H0 does not prove exact
equality. A positive estimate without a boundary is inconclusive.

There is no Stockfish opponent or strength limiter in this bundle. Nothing in
these results establishes Stockfish superiority, other controls/thread counts,
or Ryzen strength unless the actual machine and protocol support that claim.
CPU identity, OS and runtime are recorded when the run starts. Current bundle
readiness checks under Wine are not native Windows or physical Ryzen testing.

REPRODUCIBILITY AND LICENSES

manifest.json schema_version=1 freezes all files except itself; its own checksum
is captured separately in each run protocol. provenance\openings-selection.json
documents seed 20261019, unchanged corpus positions with EP target '-', all
excluded prior registries (including the unused 500-position Linux SPRT tail),
and fresh disjoint selections of 4/8/5,000 pairs. openings\selected.epd registers
the whole planned schedule for exclusion from future experiments.

Fastchess source pin: 60d7a7a26c6b0582a15c112fb29a1829bef2adb3.
Its version label and file hash are checked against the frozen bundle. Build
source, commands, licenses and provenance are under fastchess\. The Python
3.14.8 portable runtime is from python-build-standalone release 20261013; its
archive checksum matched the retained upstream SHA256SUMS. All bundled runtime
files and upstream licenses are preserved under runtime\.

Forge/runner license: LICENSE.txt. Additional component licenses accompany
their respective sources and runtime. This bundle performs no uploads.
