# pc_speed_ci box-only synthetic 5% slowdown (GitHub runner) (box-only; metric cpu NPS; core 3; Idle)

| depth | test pairs | median B/A | 95% CI | CI excludes 1 | A/A pairs | A/A median | A/A 95% CI | A/A contains 1 | nodes A = B |
|---|---:|---:|---|---|---:|---:|---|---|---|
| d13 | 40 | 0.9551 | 0.9388-0.9579 | True | 10 | 1.0000 | 0.9574-1.0116 | True | True |
| d16 | 40 | 0.9576 | 0.9501-0.9659 | True | 10 | 1.0000 | 0.9789-1.0268 | True | True |

Speed rule (CI lower bound >= 1.02 at every depth): not met
