# pc_speed_ci box-only A/A (GitHub runner) (box-only; metric cpu NPS; core 3; Idle)

| depth | test pairs | median B/A | 95% CI | CI excludes 1 | A/A pairs | A/A median | A/A 95% CI | A/A contains 1 | nodes A = B |
|---|---:|---:|---|---|---:|---:|---|---|---|
| d13 | 40 | 1.0000 | 0.9767-1.0230 | False | 10 | 1.0119 | 0.9884-1.0360 | True | True |
| d16 | 40 | 1.0069 | 1.0000-1.0077 | False | 10 | 0.9962 | 0.9716-1.0214 | True | True |

Speed rule (CI lower bound >= 1.02 at every depth): not met
