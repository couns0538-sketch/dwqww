# pc_speed_ci box-only synthetic 5% slowdown (GitHub Windows runner) (box-only; metric cpu NPS; core 3; Idle)

| depth | test pairs | median B/A | 95% CI | CI excludes 1 | A/A pairs | A/A median | A/A 95% CI | A/A contains 1 | nodes A = B |
|---|---:|---:|---|---|---:|---:|---|---|---|
| d13 | 40 | 0.9722 | 0.9487-0.9733 | True | 10 | 0.9865 | 0.9608-1.0294 | True | True |
| d16 | 40 | 0.9576 | 0.9498-0.9602 | True | 10 | 0.9957 | 0.9871-1.0090 | True | True |

Speed rule (CI lower bound >= 1.02 at every depth): not met
