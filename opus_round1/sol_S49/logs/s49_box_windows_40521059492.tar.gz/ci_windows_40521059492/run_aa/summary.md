# pc_speed_ci box-only A/A (GitHub Windows runner) (box-only; metric cpu NPS; core 3; Idle)

| depth | test pairs | median B/A | 95% CI | CI excludes 1 | A/A pairs | A/A median | A/A 95% CI | A/A contains 1 | nodes A = B |
|---|---:|---:|---|---|---:|---:|---|---|---|
| d13 | 40 | 1.0000 | 1.0000-1.0000 | False | 10 | 1.0000 | 0.9714-1.0147 | True | True |
| d16 | 40 | 1.0000 | 0.9868-1.0000 | False | 10 | 1.0135 | 0.9914-1.0270 | True | True |

Speed rule (CI lower bound >= 1.02 at every depth): not met
