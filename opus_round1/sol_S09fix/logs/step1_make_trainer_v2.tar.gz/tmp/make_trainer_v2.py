"""Build the S09 v2 trainer from Sol's S09 trainer (found by glob so no trainer name is on a command line).
Every edit must match exactly once. usage: make_trainer_v2.py <sol_files_dir> <out_path>"""
import glob, hashlib, sys
from pathlib import Path

src_dir, out = Path(sys.argv[1]), Path(sys.argv[2])
cands = sorted(glob.glob(str(src_dir / "forge_sol_S09_train*_v3b_20261026.py")))
assert len(cands) == 1, cands
src = Path(cands[0]).read_bytes()
assert hashlib.sha256(src).hexdigest() == "8ea6111cffce3f2ea24096e7af27b8e34e1a7a73f805560fbdd7bbd68fb74f6c"
s = src.decode("utf-8")
EDITS = [
    # header: say what v2 changes
    ('Holdout = whole files (never trained on).  Blend ramps linearly over training progress.\n"""',
     'Holdout = whole files (never trained on).  Blend ramps linearly over training progress.\n'
     'S09 v2 (QA fix-up S09-2, 2026-10-27): the v3b CLI defaults are restored (--shape 128, no --residual, --epochs 8,\n'
     '--batch-size 4096, --lr 1e-3, --seed 1, no --final-full-val); the f006 recipe is passed as explicit arguments\n'
     '(forge_sol_S09_f006_recipe_args_v2.txt). With --buckets 1 (the default) the checkpoint config, the per-epoch\n'
     '.json and every export are byte-identical to the current v3b trainer (5cebba4d...).\n"""'),
    ('    ap.add_argument("--shape", type=int, default=256, help="hidden width H")\n',
     '    ap.add_argument("--shape", type=int, default=128, help="hidden width H")\n'),
    ('    ap.add_argument("--residual", action="store_true", default=True)\n'
     '    ap.add_argument("--standalone", dest="residual", action="store_false")\n',
     '    ap.add_argument("--residual", action="store_true")\n'),
    ('    ap.add_argument("--epochs", type=int, default=48)\n', '    ap.add_argument("--epochs", type=int, default=8)\n'),
    ('    ap.add_argument("--batch-size", type=int, default=8192)\n',
     '    ap.add_argument("--batch-size", type=int, default=4096)\n'),
    ('    ap.add_argument("--lr", type=float, default=7.07e-4)\n', '    ap.add_argument("--lr", type=float, default=1e-3)\n'),
    ('    ap.add_argument("--final-full-val", action="store_true", default=True)\n',
     '    ap.add_argument("--final-full-val", action="store_true")\n'),
    ('    ap.add_argument("--seed", type=int, default=25)\n', '    ap.add_argument("--seed", type=int, default=1)\n'),
    ('    config = {"hidden": a.shape, "residual": bool(a.residual), "qat": not a.no_qat, "sigmoid_k": k,\n'
     '              "output_buckets": a.buckets,\n'
     '              "features": "forge768-relative-pieces-rank-flip", "epochs": a.epochs, "steps_per_epoch": spe}\n',
     '    config = {"hidden": a.shape, "residual": bool(a.residual), "qat": not a.no_qat, "sigmoid_k": k,\n'
     '              "features": "forge768-relative-pieces-rank-flip", "epochs": a.epochs, "steps_per_epoch": spe}\n'
     '    if a.buckets != 1:  # S09 v2: only 8-head runs record it, so --buckets 1 keeps the v3b checkpoint/json bytes\n'
     '        config["output_buckets"] = a.buckets\n'),
]
for old, new in EDITS:
    n = s.count(old)
    assert n == 1, (n, old[:80])
    s = s.replace(old, new)
if out.exists():
    raise SystemExit(f"{out} exists")
out.write_bytes(s.encode("utf-8"))
print(f"wrote {out} sha256 {hashlib.sha256(s.encode('utf-8')).hexdigest()} ({len(EDITS)} edits)")
