"""Read-only structural diff of two trainer .pt payloads (tensors compared exactly, plus dtype/device/shape)."""
import sys, torch
def walk(a, b, path, out):
    if torch.is_tensor(a) or torch.is_tensor(b):
        if not (torch.is_tensor(a) and torch.is_tensor(b)):
            out.append(f"{path}: tensor vs {type(b).__name__}"); return
        if a.dtype != b.dtype or a.shape != b.shape or a.device != b.device:
            out.append(f"{path}: dtype/shape/device {a.dtype}/{tuple(a.shape)}/{a.device} vs {b.dtype}/{tuple(b.shape)}/{b.device}")
        elif not torch.equal(a, b):
            out.append(f"{path}: values differ (max abs {float((a.double()-b.double()).abs().max())})")
        if a.dtype == b.dtype and a.shape == b.shape and a.dim() == 0:
            out.append(f"  {path} = {a.item()} / {b.item()} (strides {a.stride()} {b.stride()})")
        return
    if isinstance(a, dict) and isinstance(b, dict):
        if list(a.keys()) != list(b.keys()):
            out.append(f"{path}: keys {list(a.keys())} vs {list(b.keys())}")
        for k in a:
            if k in b: walk(a[k], b[k], f"{path}/{k}", out)
        return
    if isinstance(a, (list, tuple)) and isinstance(b, (list, tuple)):
        if len(a) != len(b): out.append(f"{path}: len {len(a)} vs {len(b)}")
        for i, (x, y) in enumerate(zip(a, b)): walk(x, y, f"{path}[{i}]", out)
        return
    if type(a) != type(b) or a != b:
        out.append(f"{path}: {a!r} ({type(a).__name__}) vs {b!r} ({type(b).__name__})")
A = torch.load(sys.argv[1], map_location="cpu", weights_only=True)
B = torch.load(sys.argv[2], map_location="cpu", weights_only=True)
out = []
walk(A, B, "", out)
print("\n".join(out) if out else "IDENTICAL CONTENT")
