"""List the members of two zip-format .pt files and show which differ (read-only)."""
import sys, zipfile, hashlib
za, zb = zipfile.ZipFile(sys.argv[1]), zipfile.ZipFile(sys.argv[2])
na, nb = za.namelist(), zb.namelist()
print("members equal order:", na == nb, len(na), len(nb))
for n in sorted(set(na) | set(nb)):
    a = za.read(n) if n in na else None
    b = zb.read(n) if n in nb else None
    if a != b:
        print("DIFF", n, len(a) if a is not None else None, len(b) if b is not None else None)
        if n.endswith(".pkl") and a and b:
            import pickletools, io
            da, db = io.StringIO(), io.StringIO()
            pickletools.dis(a, out=da); pickletools.dis(b, out=db)
            la, lb = da.getvalue().splitlines(), db.getvalue().splitlines()
            shown = 0
            for x, y in zip(la, lb):
                if x.split(":", 1)[-1] != y.split(":", 1)[-1]:
                    print("  A", x); print("  B", y); shown += 1
                    if shown > 12: break
        elif a is not None and b is not None and len(a) < 200:
            print("  A", a); print("  B", b)
print("order A:", na[:8], "...")
print("order B:", nb[:8], "...")
