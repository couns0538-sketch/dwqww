fixture lock pins note
