from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from html import unescape
from html.parser import HTMLParser
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import time
import urllib.error
import urllib.request

BASE = Path('/workspace/.cloud-setup/hosted-strength-observation')
RUN = 'https://github.com/couns0538-sketch/dwqww/actions/runs/39325939081'
JOB = RUN + '/job/118311679380'
STOP = datetime(2026, 10, 19, 21, 40, tzinfo=timezone.utc).timestamp()
INTERVAL = 45.0
LAST_INITIAL_REQUEST = datetime.fromisoformat('2026-10-19T21:16:27.728906+00:00').timestamp()


class JobParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.job_status = None
        self.steps = []

    def handle_starttag(self, tag, attrs):
        values = dict(attrs)
        if tag == 'check-steps':
            self.job_status = values.get('data-job-status')
        if tag == 'check-step':
            self.steps.append({key.removeprefix('data-'): values.get(key) for key in (
                'data-number', 'data-name', 'data-conclusion', 'data-started-at', 'data-completed-at'
            )})


def fetch(kind, url, stamp):
    record = {'url': url}
    try:
        request = urllib.request.Request(url, headers={
            'User-Agent': 'Forge-public-run-observer', 'Accept': 'text/html'
        })
        try:
            response = urllib.request.urlopen(request, timeout=20)
        except urllib.error.HTTPError as error:
            response = error
        with response:
            data = response.read()
            record.update(http_status=response.code, final_url=response.url,
                          response_date=response.headers.get('date'), etag=response.headers.get('etag'))
        path = BASE / (stamp + '-' + kind + '.html')
        path.write_bytes(data)
        record.update(html_path=str(path), html_sha256=hashlib.sha256(data).hexdigest(), html_bytes=len(data))
        return record, data.decode('utf-8', 'replace')
    except Exception as error:
        record['error'] = repr(error)
        return record, ''


def refs(stamp):
    command = ['git', '-c', 'credential.helper=', '-c', 'core.askPass=', '-c', 'http.extraHeader=',
               'ls-remote', 'https://github.com/couns0538-sketch/dwqww.git',
               'refs/heads/results/hosted-strength-*']
    environment = os.environ.copy()
    environment.update(GIT_TERMINAL_PROMPT='0', GIT_CONFIG_NOSYSTEM='1',
                       GIT_CONFIG_GLOBAL='/dev/null', GIT_CONFIG_COUNT='0', GIT_ASKPASS='/bin/false')
    record = {'command': command, 'authentication': 'disabled credential helpers and prompts; public HTTPS'}
    try:
        completed = subprocess.run(command, cwd='/workspace', env=environment,
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=20)
        (BASE / (stamp + '-refs.txt')).write_bytes(completed.stdout)
        (BASE / (stamp + '-refs-stderr.txt')).write_bytes(completed.stderr)
        record.update(exit_code=completed.returncode, stdout=completed.stdout.decode('utf8', 'replace'),
                      stderr=completed.stderr.decode('utf8', 'replace'))
    except Exception as error:
        record['error'] = repr(error)
    return record


last_start = LAST_INITIAL_REQUEST
previous_visible = None
while time.time() < STOP:
    delay = max(0.0, last_start + INTERVAL - time.time())
    if time.time() + delay >= STOP:
        break
    if delay:
        time.sleep(delay)
    last_start = time.time()
    observed = datetime.now(timezone.utc)
    stamp = observed.strftime('%Y%m%dT%H%M%S.%fZ')
    with ThreadPoolExecutor(max_workers=3) as pool:
        main_future = pool.submit(fetch, 'run', RUN, stamp)
        job_future = pool.submit(fetch, 'job', JOB, stamp)
        refs_future = pool.submit(refs, stamp)
        main_record, main_html = main_future.result()
        job_record, job_html = job_future.result()
        refs_record = refs_future.result()
    status = re.search(r'>Status</span>\s*<span[^>]*>(.*?)</span>', main_html, re.S)
    head = re.search(r'/couns0538-sketch/dwqww/commit/([0-9a-f]{40})', main_html)
    branch = re.search(r'class="[^"]*branch-name[^"\n]*"[^>]*title="([^"]+)"', main_html)
    parser = JobParser()
    parser.feed(job_html)
    visible = {'run_status': unescape(re.sub('<[^>]+>', '', status[1])).strip() if status else None,
               'run_head_sha': head[1] if head else None, 'run_branch': unescape(branch[1]) if branch else None,
               'job_status': parser.job_status, 'steps': parser.steps,
               'results_refs': refs_record.get('stdout', '')}
    record = {'observed_utc': observed.isoformat(), 'run_id': 39325939081, 'job_id': 118311679380,
              'scope': 'Public read-only HTML and unauthenticated ls-remote; no workflow/API writes or engine execution',
              'run_request': main_record, 'job_request': job_record, 'refs_request': refs_record,
              'visible': visible, 'visible_state_changed': visible != previous_visible}
    (BASE / (stamp + '.json')).write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'observed_utc': record['observed_utc'],
                      'changed': record['visible_state_changed'],
                      'http_status': [main_record.get('http_status'), job_record.get('http_status')],
                      'visible': visible}), flush=True)
    previous_visible = visible
    if parser.job_status == 'completed' or visible['run_status'] in ('Success', 'Failure', 'Cancelled', 'Timed out'):
        print('Observer stopped after visible completion; no game or strength outcome inferred.', flush=True)
        break
else:
    print('Observer reached bounded stop time21:40UTC.', flush=True)
