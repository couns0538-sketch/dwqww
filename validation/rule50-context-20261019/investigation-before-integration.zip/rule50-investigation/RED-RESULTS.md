# Actual unchanged 6.4.3 RED regression

Executed with owner authorization, against
`/workspace/.cloud-setup/forge-tt-coherent-release/libforge_core.a` and current headers.
Recorded HEAD: `77ee53bdae40fbffee42be406b73f245f4434993`.
Exact input hashes/compiler/commands are in `regression-red-protocol.json` and
`regression-red-result.json`. Compilation succeeded; runtime about0.63s; exit1,
five expected regression failures; stderr empty. No checkout source was modified.

## Observed outcomes

| Actual Worker call | Warm | Cold | Meaning |
|---|---:|---:|---|
| qsearch clock89, null window | -426 | -426 | Warm visits one node; eligible TT direct cutoff remains active. |
| qsearch clock90/98, null window | -426 | -426 | Existing TT cutoff visits one node; proposed near50 guard would traverse evasions. |
| qsearch clock99, null window | -426 | 0 | Exact one-ply draw oracle violated by naturally learned lowclock bound. |
| qsearch clock100 | 0 | 0 | Current-position terminal check precedes TT. |
| qsearch low0 after actual high99 q draw cached | 0 | -426 | Reverse context contaminates direct null-window cutoff. |
| qsearch low0 full window after actual high99 main draw cached | 0 | 453 | PV direct cutoff is disabled: actual TT-score-as-eval substitution changes the result. |

The latter entry was naturally produced by high99 depth1 main search:
`score=0, raw_eval=453, depth=1, BoundExact`. Thus the raw position evaluation
remains453 while the history-dependent searched draw replaces it with0. No invented
TT scores or mocked Worker implementation were used.

Legal resetting capture and pawn controls passed: clocks reset0, material remains,
and child qsearch evaluates the material position rather than forcing a rule50 draw.
Mate100 and actual rule50 draw100 precedence also passed.

The original clock99 failure has an independently confirmed exact one-ply terminal
draw oracle. The reverse lowclock differences demonstrate actual conditional score
reuse and a different bounded search result; they are not independently measured
tablebase WDL/DTZ or a claimed exact centipawn value for the complete chess game.

## Assessment of the one-line candidate

The prepared `<90` qsearch direct-cutoff guard addresses the observed low->high99
cutoff. It **cannot** address either newly demonstrated reverse direction: low0
passes `<90`, and full-window qsearch uses score-as-eval despite bypassing direct
cutoff. It is not a complete context policy and has not been applied/built here.

## Evidence-led next isolated option, not implemented

TTEntry currently has a two-byte `padding` member. A future isolated experiment
could replace it with the stored halfmove clock (Board's counter is uint16), preserving
entry/cluster size, and treat search scores as unavailable on counter mismatch.
Keep the hit/TT move and raw static eval reusable. Central gating at both qsearch
and main-search `tt_score` extraction would also cover score-as-eval and secondary
score consumers (null-move veto, ProbCut and singular extension), rather than only
the first direct-cutoff expression. Review every consumer and store call explicitly.

Require current-clock metadata to be supplied at every real store and coherently
published/copied with the entry; tests/probes need explicit valid context too.
Keep existing conservative policies until separately justified. Exact clock equality
is conservative, may cost useful TT bounds, and is **not** a full repetition/history
key solution. The present evidence does not authorize combining root-effort changes,
new pruning policy or a strength claim with this isolated investigation.

Before implementation, freeze a new branch/experiment and promote reverse direct
and PV-eval cases to explicit red assertions for the broader context hypothesis.
The current regression intentionally prints them as LIMITATION diagnostics so a
passing near50-only patch could not be mistaken for solving them. Compare exact
clock match/mismatch, pawn/capture resets, mate score normalization, TT moves/raw
eval reuse, replacement, coherent snapshot lifecycle and appropriate strength costs.
