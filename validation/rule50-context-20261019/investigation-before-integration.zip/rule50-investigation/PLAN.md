# Rule-50 TT investigation: actual-Forge reproducer

The owner subsequently authorized one bounded compile/run against the coherent
Release library. That original diagnostic **reproduced** the wrong qsearch bound;
see actual results below. No repository source was modified. Additional regression
execution and candidate builds remain deferred to the owner.

## Actual unchanged-engine result

Compile succeeded, using `/workspace/.cloud-setup/forge-tt-coherent-release/libforge_core.a`
and the matching current headers. Probe took approximately 0.42 seconds, diagnostic
exit1 (reproduced), empty stderr. Genuine learned exact low-clock score was -426.
At99, warm null-window qsearch returned -426 versus cold0; warm main-depth1 and warm
full-window qsearch returned0. At100 all controls returned0. Checkmate100 was -31999.
Both actual Forge evasions h8g7/h8g8 reached100 and had legal replies.

Independent python-chess (chess module1.11.2) confirmed a valid checked position,
exactly these two legal evasions, no zeroing move, 16 legal replies per child,
halfmove100/fifty-move draw and no checkmate. See `python-chess-oracle.json`.
This is an actual one-ply draw-oracle failure, not a generic warm/cold difference.

Exact commands, compiler flags, headers/source/library/binary hashes, stdout/stderr
and exit status are in `compile-command.json`, `compile-result.json`,
`run-command.json`, `run-result.json`, `probe.stdout` and `probe.stderr`.

## Prepared minimal candidate and regressions, not built or applied

`qsearch-near50-bound-guard.patch` adds only the existing main-search `<90` policy
to qsearch direct bound consumption. TT move selection, raw evaluation and score-as-eval
substitution remain untouched. This is a narrow candidate for the demonstrated
failure, not a comprehensive rule50/repetition context solution.

`rule50_regression.cpp` is a standalone actual-Worker regression harness. Build/link
it as above against each exact source/library pair when authorized. It should fail
against the unchanged library and pass the targeted cases with the candidate.
It checks clock89 TT cutoff still takes one visited node, clocks90/98/99 require
searching evasions, draw100/mate100 precedence, legal resetting pawn/capture moves
with nonterminal material, and evaluated post-reset children.

The same harness prints explicitly non-gating LIMITATION diagnostics for a naturally
learned high99 exact draw reused at low0, and a high99 main-search score replacing
low0 full-window qsearch static evaluation. Those paths remain unverified until run;
their warm/cold differences alone do not establish an exact game-theoretic low-clock
score. The targeted guard cannot solve reverse-direction contamination or TT-score
eligibility generally. Do not stack broader policy changes without separate proofs.

## Source and research provenance

Research ref `origin/forge/research-20261019-2115`, commit
`56c90436f1f85de5cad0a762be75d50d6b71c247`, contains a research-only report,
`validation/hourly/2026-10-19-2115/RESEARCH.md`. It hypothesizes qsearch TT cutoff
and TT-score-as-eval context mismatch; its earlier models/reports are not actual
engine reproduction. Preserve this attribution and the original reports.

Inspected current HEAD: `df5d839a6a03f705310bb958601375fa9411e810`.
Current Worker friendship and call setup come from actual `tests/tests.cpp`;
old `tools/audit/see_and_tt_probe.cpp` targets an obsolete pre-Worker API.
This driver calls the actual private Worker functions via existing friend access.
Record the exact source/header/library/compiler hashes when it is finally built.

## Source-grounded mechanism

`Worker::is_draw` checks the current halfmove >=100 before probing TT, with
checkmate precedence. Main search's direct cutoff requires halfmove <90.
Qsearch's direct non-PV cutoff has no halfmove/context guard. Both paths can also
replace corrected static evaluation with a cached search score without that guard.
Raw static evaluation is position-dependent and must be treated separately.

`Board::compute_key` excludes the halfmove counter. Identical placement/turn/etc
can therefore share a TT key with different rule-50 horizons. A warm/cold score
difference alone is insufficient: depth, window, ply, root/history, heuristics and
genuine path-dependent repetition can legitimately differ.

## Tight fixture and falsifiable result

Use `7k/8/8/8/8/8/8/K6R b - - 99 80`: black h8 is checked by white rook h1,
white king a1. Enumerate **every legal evasion** with Forge itself. Require every
move to be a nonzeroing king move, producing halfmove100 with legal replies. Thus
every move is an immediate rule-50 draw under this engine's policy, establishing
score0 independently of evaluation, pruning, DTZ/tablebases or a quiet qsearch
stand-pat assumption. Clock99 itself is not yet a terminal draw.

Warm TT using actual full-window qsearch on the identical position at clock0.
Require a naturally learned nonzero losing score/valid entry; no fabricated score.
Reset all worker histories/eval caches/stack while preserving TT, then compare
warm and cold clock99 qsearch at identical ply1 and window [-1,0]. A negative warm
value versus cold0 flips fail-low/fail-high against the one-ply draw oracle.
Inspect the stored entry/bound and repeat independently; no earlier root iterations
or move-order-history differences are needed. Main depth1 is a control for its
existing <90 cutoff protection (its seed is an actual depth1 main search), not the
same-depth qsearch comparison. Warm full-window qsearch99 also must return0:
it bypasses the direct non-PV cutoff while following the same one-ply draw oracle.

Also test clocks0/90/98/100; high100 must draw even warm, checkmate100 must mate.
The low-clock result is a search horizon score, not an asserted exact WDL value.
Optional public-facade searches use equal depth4 but are exploratory only.

## Later execution, only after owner clears other jobs

Choose the library built from the exact inspected source/header snapshot, with
matching compiler ABI, target flags and NNUE weights. Do not use the older original
6.4 archive library: its Worker/TT layout and friend API differ.

```sh
g++ -std=c++20 -O2 -march=x86-64-v3 -mtune=znver5 \
  -fno-fast-math -ffp-contract=off -I "$SOURCE/include" \
  /workspace/.cloud-setup/rule50-investigation/rule50_worker_probe.cpp \
  "$BUILD/libforge_core.a" -pthread \
  -o /workspace/.cloud-setup/rule50-investigation/rule50-worker-probe
/workspace/.cloud-setup/rule50-investigation/rule50-worker-probe \
  > /workspace/.cloud-setup/rule50-investigation/probe.stdout \
  2> /workspace/.cloud-setup/rule50-investigation/probe.stderr
```

Capture original probe exit status separately: **1 reproduced**, **0 not demonstrated**,
**2 invalid fixture/control**, crash/sanitizer failure neither a valid reproduction
nor a negative finding. Keep stdout/stderr and checksums. Compile/run has NOT been
performed for the new regression/candidate; only the original probe has run.

## Follow-up policy: evidence first

If demonstrated, first isolate suppression of qsearch **bound consumption** in
the near-rule50 context, preserving TT moves, raw eval and other search behavior.
Do not present a <90 threshold as a mathematically complete history-key solution:
low/high clocks can differ below90, and draw-derived cached scores can flow in the
reverse direction. Test actual search-score-as-eval consumers separately before
changing them. A fabricated TT entry can prove reachability but not natural impact.

No production patch is applied here. Accepting the prepared minimal patch requires
the actual regression to fail on unchanged source and pass with that isolated change, then
terminal/mate/resetting-capture/pawn/repetition controls, full relevant tests and
separate preregistered strength evidence. Do not suppress every TT use or demand
universal warm/cold equality merely to force agreement.
