# Artifact preservation note

The original `provenance.json` began as a preparation manifest and was updated as
the owner authorized actual probe execution, then the RED regression. Those earlier
manifest versions were not separately saved; do not claim its current hash is the
original preparation-manifest hash or that an old ledger hash still matches it.

Original compile/run command/result files, raw stdout/stderr and independent oracle
files were not overwritten for the subsequent RED regression. The RED regression
uses separate `regression-red-*` files. The context proposal has its own new
`context-proposal-provenance.json`; no original raw file is being rewritten.

The prepared original probe source was refined before its first compilation;
the actual compiler input hash in `compile-result.json` authenticates the executed
source, not an earlier unexecuted draft. Use per-run command/result input hashes
and the newly archived directory manifest as the authoritative experiment record.
