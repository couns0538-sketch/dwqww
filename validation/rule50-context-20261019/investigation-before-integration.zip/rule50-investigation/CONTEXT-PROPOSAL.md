# Bounded rule50 context candidate, not applied/built

The earlier `qsearch-near50-bound-guard.patch` is retained as **insufficient**:
actual RED diagnostics demonstrate high99->low0 direct q cutoff and PV score-as-eval
contamination that a current-clock `<90` guard cannot prevent. Do not integrate it
as a complete fix for the demonstrated family.

`qsearch-rule50-context-proposal.patch` is an outside-checkout static proposal based
on HEAD77ee53b. Its separate immutable input/proposal hashes are in
`context-proposal-provenance.json`. It changes no checkout file.

## Narrow policy

Replace the two-byte spare padding with a one-byte stored capped halfmove context
and one spare byte. Assert entry16B and cluster64B. Store `min(clock,100)` only
inside the existing admitted-score-payload branch. Independent move updates must
leave the old score's clock untouched, just as they leave the old score/depth intact.

The helper admits a searched score when both capped counters are below90, or their
capped values match exactly. Apply it when deriving `tt_score` in both Worker
searches. An ineligible score becomes ValueNone; TT hit, move, depth, bound/PV flags
and raw static eval remain available. Preserve the existing `<90` restriction on
main direct cutoffs; this proposal does not expand main near50 cutoffs.

Four real production store sites must pass the current board halfmove clock
explicitly; the API has no silently defaulted context. The included existing-test
migration passes actual board clock to terminal seeds and explicit0 to generic TT
fixtures; those generic fixtures do not pretend to model a real highclock board.
Metadata-specific tests remain to be added before acceptance.

Source review found no halfmove component in `Worker::static_evaluate`, NNUE
evaluation or the cached raw Evaluator path. Raw evaluation precedes correction
history and searched-score substitution. Therefore preserving raw eval/TTmove reuse
is intentional; blanket TT rejection would be a separate unnecessary intervention.

Central gating covers q/main direct bound returns, both score-as-eval substitutions,
null-move TT-upper veto, ProbCut TT condition and singular-extension score use.
Existing checks either explicitly reject ValueNone or compare it in a way that
disables the particular score-dependent veto. Confirm this reasoning in review;
do not assume replacing only the first cutoff condition covers every consumer.

## Required focused checks before integration

- Promote both actual reverse diagnostics to RED assertions; near99 oracle0 and
  low0 reverse-q/PV-eval scores must match matched cold controls after the candidate.
- Clock89 remains eligible with a different lowclock seed. Same99 remains eligible
  in qsearch; 0<->99 and 89<->90 are ineligible. Test capping100/65535 without
  bypassing actual terminal/checkmate precedence.
- Check stored clock follows admitted exact/new/deeper/generation payload, but is
  unchanged by rejected shallower score writes even when their move updates.
- Correlate clock in concurrent snapshot tuples; preserve stale/foreign/lifecycle
  handle tests and move-only update semantics. Assert16B/64B and matched-layout ABI.
- Retain legal pawn/capture-reset, mate100/draw100 controls; verify TT moves/raw eval
  are still available with a mismatched score context. Run relevant full tests.

## Explicit limits

Both-below90 is the existing conservative heuristic policy, not a theorem: scores
can already incorporate rule50 or repetition effects before90, depending on depth,
resets and path. Exact same clock still does not identify repetition history.
Capping all clocks>=100 intentionally relies on terminal rule50 checks before
score use; checkmate precedence remains separate. No universal history-safety or
strength claim follows from a targeted regression pass. Lower TT hit utility may
affect NPS and playing strength; measure separately after correctness.

Independent static review was requested; its actual findings are saved separately
when available. No new model, candidate build, patched engine run or match occurred.
