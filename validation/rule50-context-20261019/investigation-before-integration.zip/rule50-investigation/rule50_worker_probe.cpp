// Original actual-Forge diagnostic. No copied or simulated search algorithm.
#include "forge/board.hpp"
#include "forge/nnue.hpp"
#include "forge/search.hpp"
#include <chrono>
#include <iostream>
#include <stdexcept>
#include <string>

namespace forge {
// Existing production friendship is also used by tests/tests.cpp.
struct SearcherTestProbe {
    static int run(Searcher& searcher, Board board, int depth, int alpha, int beta) {
        auto& worker = searcher.main_worker();
        worker.clear(); // Reset every worker-local cache/history/stack; preserve TT only.
        worker.shared_.stop.store(false, std::memory_order_relaxed);
        worker.shared_.ponder_hit_ns.store(0, std::memory_order_relaxed);
        worker.all_workers_ = nullptr;
        worker.aborted_ = false;
        worker.local_nodes_ = 0;
        worker.nodes_.store(0, std::memory_order_relaxed);
        worker.node_limit_ = 0;
        worker.node_limit_specified_ = false;
        worker.hard_limit_ms_ = worker.soft_limit_ms_ = 0;
        worker.time_managed_ = worker.pondering_ = false;
        worker.start_ = std::chrono::steady_clock::now();
        worker.seldepth_ = 0;
        worker.root_history_index_ = board.history_size() - 1;
        auto* ss = &worker.stack_[5];
        ss->ply = 1; // Non-root search; same ply/window/depth in warm/cold calls.
        nnue::refresh(board, ss->accumulator);
        return depth == 0 ? worker.qsearch(board, ss, alpha, beta)
                          : worker.search(board, ss, depth, alpha, beta, false);
    }
};
}

forge::Board position(int clock) {
    forge::Board board;
    if (!board.set_fen("7k/8/8/8/8/8/8/K6R b - - " + std::to_string(clock) + " 80"))
        throw std::runtime_error("invalid FEN");
    return board;
}

void print_tt(forge::Searcher& searcher, const forge::Board& board) {
    const auto probe = searcher.transposition_table().probe(board.key());
    std::cout << "tt_hit=" << probe.hit << " score=" << probe.entry.score
              << " eval=" << probe.entry.eval << " depth=" << int(probe.entry.depth)
              << " bound=" << int(probe.entry.bound()) << '\n';
}

int main(int argc, char** argv) {
    using namespace forge;
    const bool public_probe = argc == 2 && std::string(argv[1]) == "--public";
    if (argc > 2 || (argc == 2 && !public_probe)) return 2;
    auto low = position(0), high = position(99);
    bool oracle = high.in_check() && !high.legal_moves().empty();
    std::cout << "same_key=" << (low.key() == high.key()) << " high_fen=" << high.fen() << '\n';
    for (const auto move : high.legal_moves()) {
        const bool zeroing = move.is_capture() || piece_type(high.moved_piece(move)) == Pawn;
        Undo undo;
        if (!high.make_move(move, undo)) throw std::runtime_error("legal move rejected");
        const bool child_draw = high.halfmove_clock() == 100 && high.has_legal_move();
        oracle = oracle && !zeroing && child_draw;
        std::cout << "oracle_evasion=" << Board::move_to_uci(move)
                  << " zeroing=" << zeroing << " child_halfmove=" << high.halfmove_clock()
                  << " child_has_legal_move=" << high.has_legal_move() << '\n';
        high.unmake_move(move, undo);
    }
    if (!oracle || low.key() != high.key()) {
        std::cerr << "FIXTURE_INVALID: no forced one-ply rule50 draw oracle\n";
        return 2;
    }
    bool demonstrated = false;
    std::cout << "forced_rule50_draw_oracle=1\n";
    for (int clock : {0, 90, 98, 99, 100}) {
        Searcher warm(4, 1), cold(4, 1), main_control(4, 1);
        const int low_q = SearcherTestProbe::run(warm, low, 0, -Infinite, Infinite);
        auto target = position(clock);
        std::cout << "learned_low_q=" << low_q << ' ';
        print_tt(warm, target);
        const int cached_q = SearcherTestProbe::run(warm, target, 0, -1, 0);
        const int cold_q = SearcherTestProbe::run(cold, target, 0, -1, 0);
        const int low_main_seed = SearcherTestProbe::run(main_control, low, 1, -Infinite, Infinite);
        const int cached_main = SearcherTestProbe::run(main_control, target, 1, -1, 0);
        std::cout << "clock=" << clock << " q_warm=" << cached_q << " q_cold=" << cold_q
                  << " main_warm_depth1=" << cached_main << " main_seed=" << low_main_seed << '\n';
        if (clock == 99) {
            // Same qsearch horizon with a full window bypasses direct TT cutoff;
            // every evasion still reaches the exact terminal draw before TT use.
            Searcher pv_control(4, 1);
            (void)SearcherTestProbe::run(pv_control, low, 0, -Infinite, Infinite);
            const int warm_pv_q = SearcherTestProbe::run(pv_control, target, 0, -Infinite, Infinite);
            std::cout << "q_warm_fullwindow99=" << warm_pv_q << '\n';
            demonstrated = cached_q < -1 && cold_q == 0 && cached_main == 0 && warm_pv_q == 0;
        }
        if (clock == 100 && (cached_q != 0 || cold_q != 0 || cached_main != 0)) {
            std::cerr << "UNEXPECTED: actual rule50 draw bypassed\n";
            return 2;
        }
    }
    // Checkmate precedence at 100 is a separate terminal control, not a draw.
    Board mate;
    if (!mate.set_fen("7k/6Q1/6K1/8/8/8/8/8 b - - 100 80")) return 2;
    Searcher terminal(4, 1);
    const int mate_score = SearcherTestProbe::run(terminal, mate, 0, -Infinite, Infinite);
    std::cout << "mate100_score=" << mate_score << '\n';
    if (!mate.in_check() || mate.has_legal_move() || mate_score > -MateInMaxPly) return 2;
    if (public_probe) {
        // Exploratory UCI-equivalent facade experiment: identical final depth.
        // Its warm/cold difference alone is NOT an oracle/correctness proof.
        Searcher warm(4, 1), cold(4, 1);
        SearchLimits limits;
        limits.depth = 4;
        const auto seed = warm.search(low, limits);
        const auto cached = warm.search(high, limits);
        const auto fresh = cold.search(high, limits);
        std::cout << "public_depth4 low=" << seed.score << " warm99=" << cached.score
                  << " cold99=" << fresh.score << '\n';
    }
    std::cout << (demonstrated ? "DEMONSTRATED_WRONG_RULE50_Q_BOUND\n"
                               : "NOT_DEMONSTRATED_RETAIN_NEGATIVE_FINDING\n");
    return demonstrated ? 1 : 0; // 1 means diagnostic reproduced; 2 means invalid control.
}
