# Independent static review

Reviewer agent: `rule50_context_review`, fresh context, read-only. No edits, builds
or engine runs. Reviewed outside proposal against actual current source and RED
results. Verdict: **no definite implementation/migration bug found; unvalidated proposal**.

Findings:

- Four production stores pass restored current board clock. Repository test call
  sites appear migrated; signature changes alone add no context regression tests.
- Clock metadata is updated only with admitted score payload. Rejected shallow
  score writes with an independent move update retain old score and context.
- Two score-extraction gates preserve TT moves/raw eval/depth/bounds and existing
  main-search `<90` direct-cutoff restriction.
- ProbCut and singular extension explicitly reject ValueNone. Null-move veto lacks
  an explicit sentinel check but currently remains safe: ValueNone32002 exceeds all
  valid beta values, bounded by Infinite32001, so `tt_score < beta` cannot hold.
  An explicit check could improve readability but is not required for this proof.
- Coherent store/snapshot locks include the new byte;16B/64B assertions protect
  layout. Rebuild every linked component after API/layout semantics change.

Minimum pre-acceptance checks:

1. Eligibility matrix:0<->89 allowed;89<->90,90<->98,98<->99,99<->0 rejected;
   exact90/98/99 allowed; capped100/101/65535 behavior.
2. Payload admission/rejection/independent move updates, concurrent clock/score
   snapshot correlation, and stale/foreign/lifecycle handles.
3. Actual forward/reverse q cutoff and PV score-as-eval assertions, preserved
   below90 cutoff and existing main near50 restriction.
4. Mismatch retains raw eval/hash move, disables score-dependent null veto,
   ProbCut suppression and singular use.
5. Pawn/capture resets, draw100/mate100 precedence, mate-score ply normalization.

The below90 grouping remains heuristic. Equal clocks and below90 compatibility do
not identify repetition history. Do not describe this as comprehensive history/rule50
correctness, an accepted fix, or measured strength improvement.
