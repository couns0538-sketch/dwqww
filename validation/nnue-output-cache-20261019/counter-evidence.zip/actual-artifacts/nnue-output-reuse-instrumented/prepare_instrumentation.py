from pathlib import Path
import difflib
import hashlib
import json
import tarfile

BASE = Path(__file__).resolve().parent
SOURCE = BASE / "source"
EVIDENCE = Path("/workspace/dwqww/validation/nnue-output-cache-20261019")
EVIDENCE.mkdir(parents=True, exist_ok=False)
with tarfile.open(BASE / "source-c5cbf97.tar") as archive:
    originals = {row.name: archive.extractfile(row).read().decode()
                 for row in archive.getmembers() if row.isfile()
                 and row.name.endswith((".cpp", ".hpp"))}

def replace(path, old, new, count=1):
    source = SOURCE / path
    text = source.read_text()
    assert text.count(old) == count, (path, old, text.count(old), count)
    source.write_text(text.replace(old, new))

replace("include/forge/nnue.hpp", "extern bool enabled;", """extern bool enabled;
// Audit-only: actual public output-layer entries, per search thread.
extern thread_local std::uint64_t audit_output_calls;""")
replace("src/nnue.cpp", "bool enabled = true;", """bool enabled = true;
thread_local std::uint64_t audit_output_calls = 0;""")
replace("src/nnue.cpp", """int evaluate(const Board& board, const Accumulator& accumulator) {
    const Weights& w = weights();""", """int evaluate(const Board& board, const Accumulator& accumulator) {
    ++audit_output_calls;
    const Weights& w = weights();""")
replace("include/forge/search.hpp", "    bool pondering_ = false;", """    // Audit state is separate from SearchStack and never used by search decisions.
    struct AuditSlot {
        bool seen = false;
        std::uint64_t key = 0;
        int halfmove = 0;
        Color side = White;
        std::string fen;
        nnue::Accumulator input{};
        int output = 0;
    };
    std::array<AuditSlot, MaxPly + 8> audit_slots_{};
    std::uint64_t audit_network_calls_ = 0;
    std::uint64_t audit_duplicate_identity_ = 0;
    std::uint64_t audit_duplicate_exact_input_ = 0;
    std::uint64_t audit_changed_input_ = 0;
    std::uint64_t audit_output_mismatch_ = 0;
    std::uint64_t audit_key_fen_mismatch_ = 0;
    std::uint64_t audit_unmarked_position_change_ = 0;
    std::uint64_t audit_real_invalidations_ = 0;
    std::uint64_t audit_null_invalidations_ = 0;
    std::uint64_t audit_tt_raw_hits_ = 0;
    void audit_emit(const Board& board, const SearchInfo& result);

    bool pondering_ = false;""")
replace("src/search.cpp", """    const int network = nnue::evaluate(board, ss->accumulator);
    if (!nnue::residual()) return network;""", """    AuditSlot& audit = audit_slots_[static_cast<std::size_t>(ss - stack_.data())];
    const std::string audit_fen = board.fen();
    const bool same_key = audit.seen && audit.key == board.key() &&
        audit.halfmove == board.halfmove_clock() && audit.side == board.side_to_move();
    const bool same_identity = same_key && audit.fen == audit_fen;
    const bool exact_input = same_identity &&
        std::memcmp(audit.input.values.data(), ss->accumulator.values.data(),
                    sizeof(ss->accumulator.values)) == 0;
    if (audit.seen && !same_identity) ++audit_unmarked_position_change_;
    if (same_key && !same_identity) ++audit_key_fen_mismatch_;
    ++audit_network_calls_;
    const int network = nnue::evaluate(board, ss->accumulator);
    if (same_identity) {
        ++audit_duplicate_identity_;
        if (exact_input) ++audit_duplicate_exact_input_;
        else ++audit_changed_input_;
        if (exact_input && network != audit.output) ++audit_output_mismatch_;
        if (audit_duplicate_identity_ <= 16) {
            const std::lock_guard<std::mutex> lock(uci_output_mutex());
            std::cerr << "{\\\"event\\\":\\\"duplicate_nnue_call\\\",\\\"call\\\":" << audit_network_calls_
                      << ",\\\"ply\\\":" << ss->ply << ",\\\"key\\\":" << board.key()
                      << ",\\\"halfmove\\\":" << board.halfmove_clock()
                      << ",\\\"side\\\":" << static_cast<int>(board.side_to_move())
                      << ",\\\"exact_input\\\":" << (exact_input ? "true" : "false")
                      << ",\\\"same_output\\\":" << (network == audit.output ? "true" : "false")
                      << ",\\\"fen\\\":\\\"" << audit_fen << "\\\"}\\n";
        }
    }
    audit.seen = true;
    audit.key = board.key();
    audit.halfmove = board.halfmove_clock();
    audit.side = board.side_to_move();
    audit.fen = audit_fen;
    audit.input = ss->accumulator;
    audit.output = network;
    if (!nnue::residual()) return network;""")
replace("src/search.cpp", """    (ss + 1)->dirty = nnue::dirty_pieces(board, move);
    (ss + 1)->accumulator.valid = false;""", """    (ss + 1)->dirty = nnue::dirty_pieces(board, move);
    (ss + 1)->accumulator.valid = false;
    audit_slots_[static_cast<std::size_t>(ss + 1 - stack_.data())].seen = false;
    ++audit_real_invalidations_;""")
replace("src/search.cpp", """            (ss + 1)->dirty.count = 0;
            (ss + 1)->accumulator.valid = false;""", """            (ss + 1)->dirty.count = 0;
            (ss + 1)->accumulator.valid = false;
            audit_slots_[static_cast<std::size_t>(ss + 1 - stack_.data())].seen = false;
            ++audit_null_invalidations_;""")
replace("src/search.cpp", """        if (tt_hit && tte.eval != ValueNone) ss->raw_eval = tte.eval;
        else ss->raw_eval = static_evaluate(board, ss);""", """        if (tt_hit && tte.eval != ValueNone) {
            ++audit_tt_raw_hits_;
            ss->raw_eval = tte.eval;
        } else ss->raw_eval = static_evaluate(board, ss);""", count=2)
replace("src/search.cpp", """SearchInfo Worker::search(Board board, const SearchLimits& limits, bool emit_info, const std::vector<Worker*>& all) {
    start_ =""", """SearchInfo Worker::search(Board board, const SearchLimits& limits, bool emit_info, const std::vector<Worker*>& all) {
    for (auto& audit : audit_slots_) audit.seen = false;
    audit_network_calls_ = audit_duplicate_identity_ = audit_duplicate_exact_input_ = 0;
    audit_changed_input_ = audit_output_mismatch_ = audit_key_fen_mismatch_ = 0;
    audit_unmarked_position_change_ = audit_real_invalidations_ = audit_null_invalidations_ = audit_tt_raw_hits_ = 0;
    nnue::audit_output_calls = 0;
    start_ =""")
path = SOURCE / "src/search.cpp"
text = path.read_text()
begin, end = text.index("SearchInfo Worker::search("), text.index("// Searcher facade")
part = text[begin:end]
assert part.count("return result;") == 4
part = part.replace("return result;", "audit_emit(board, result);\n        return result;")
text = text[:begin] + part + text[end:]
path.write_text(text)
replace("src/search.cpp", """// ---------------------------------------------------------------------------
// Searcher facade""", """void Worker::audit_emit(const Board& board, const SearchInfo& result) {
    const std::lock_guard<std::mutex> lock(uci_output_mutex());
    std::cerr << "{\\\"event\\\":\\\"nnue_reuse_summary\\\",\\\"worker\\\":" << id_
              << ",\\\"network_calls\\\":" << audit_network_calls_
              << ",\\\"actual_public_evaluate_calls\\\":" << nnue::audit_output_calls
              << ",\\\"duplicate_identity\\\":" << audit_duplicate_identity_
              << ",\\\"duplicate_exact_input\\\":" << audit_duplicate_exact_input_
              << ",\\\"changed_input_same_identity\\\":" << audit_changed_input_
              << ",\\\"output_mismatch\\\":" << audit_output_mismatch_
              << ",\\\"key_fen_mismatch\\\":" << audit_key_fen_mismatch_
              << ",\\\"unmarked_position_change\\\":" << audit_unmarked_position_change_
              << ",\\\"real_invalidations\\\":" << audit_real_invalidations_
              << ",\\\"null_invalidations\\\":" << audit_null_invalidations_
              << ",\\\"tt_raw_eval_hits\\\":" << audit_tt_raw_hits_
              << ",\\\"nodes\\\":" << result.nodes << ",\\\"depth\\\":" << result.depth
              << ",\\\"score\\\":" << result.score
              << ",\\\"bestmove\\\":\\\"" << Board::move_to_uci(result.best_move)
              << "\\\",\\\"root_fen\\\":\\\"" << board.fen() << "\\\"}\\n";
}

// ---------------------------------------------------------------------------
// Searcher facade""")

patch = ""
changed = []
for name, original in originals.items():
    new = (SOURCE / name).read_text()
    if new != original:
        changed.append(name)
        patch += "".join(difflib.unified_diff(original.splitlines(True), new.splitlines(True),
                                             fromfile="a/" + name, tofile="b/" + name))
(EVIDENCE / "instrumentation.patch").write_text(patch)
(EVIDENCE / "source-before.json").write_bytes((BASE / "source-before.json").read_bytes())
after = {p.relative_to(SOURCE).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
         for p in SOURCE.rglob("*") if p.is_file()}
(EVIDENCE / "instrumented-source.json").write_text(json.dumps({
    "base_source": "c5cbf97a7291a3bd960c71dcd77a29bf7c95ad8e",
    "changed_files": changed,
    "instrumentation_only": True,
    "no_cache_implemented": True,
    "patch_sha256": hashlib.sha256(patch.encode()).hexdigest(),
    "source_files_sha256": after,
}, indent=2) + "\n")
print(json.dumps({"changed_files": changed, "evidence": str(EVIDENCE)}))
