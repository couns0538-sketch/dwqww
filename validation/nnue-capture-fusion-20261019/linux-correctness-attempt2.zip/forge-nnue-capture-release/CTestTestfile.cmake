# CMake generated Testfile for 
# Source directory: /workspace/dwqww
# Build directory: /workspace/.cloud-setup/forge-nnue-capture-release
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test(forge_tests "/workspace/.cloud-setup/forge-nnue-capture-release/forge_tests")
set_tests_properties(forge_tests PROPERTIES  _BACKTRACE_TRIPLES "/workspace/dwqww/CMakeLists.txt;59;add_test;/workspace/dwqww/CMakeLists.txt;0;")
add_test(forge_tt_tests "/workspace/.cloud-setup/forge-nnue-capture-release/forge_tt_tests")
set_tests_properties(forge_tt_tests PROPERTIES  _BACKTRACE_TRIPLES "/workspace/dwqww/CMakeLists.txt;60;add_test;/workspace/dwqww/CMakeLists.txt;0;")
add_test(forge_rule50_tests "/workspace/.cloud-setup/forge-nnue-capture-release/forge_rule50_tests")
set_tests_properties(forge_rule50_tests PROPERTIES  _BACKTRACE_TRIPLES "/workspace/dwqww/CMakeLists.txt;61;add_test;/workspace/dwqww/CMakeLists.txt;0;")
add_test(forge_legal_witness_tests "/workspace/.cloud-setup/forge-nnue-capture-release/forge_legal_witness_tests" "/workspace/dwqww/tests/legal_witness_fixtures.tsv" "/workspace/dwqww/tools/openings/forge-10000.epd")
set_tests_properties(forge_legal_witness_tests PROPERTIES  _BACKTRACE_TRIPLES "/workspace/dwqww/CMakeLists.txt;62;add_test;/workspace/dwqww/CMakeLists.txt;0;")
add_test(match_tool_tests "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3.12" "/workspace/dwqww/tools/match/test_match_tools.py")
set_tests_properties(match_tool_tests PROPERTIES  _BACKTRACE_TRIPLES "/workspace/dwqww/CMakeLists.txt;85;add_test;/workspace/dwqww/CMakeLists.txt;0;")
add_test(windows_validation_tests "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3.12" "/workspace/dwqww/tools/match/tests/test_windows_validate.py")
set_tests_properties(windows_validation_tests PROPERTIES  _BACKTRACE_TRIPLES "/workspace/dwqww/CMakeLists.txt;87;add_test;/workspace/dwqww/CMakeLists.txt;0;")
add_test(uci_regression "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3.12" "/workspace/dwqww/tools/uci_regression.py" "/workspace/.cloud-setup/forge-nnue-capture-release/forge" "--log" "/workspace/.cloud-setup/forge-nnue-capture-release/uci-regression.log")
set_tests_properties(uci_regression PROPERTIES  _BACKTRACE_TRIPLES "/workspace/dwqww/CMakeLists.txt;89;add_test;/workspace/dwqww/CMakeLists.txt;0;")
add_test(ponder_regression "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3.12" "/workspace/dwqww/tools/ponder_regression.py" "/workspace/.cloud-setup/forge-nnue-capture-release/forge")
set_tests_properties(ponder_regression PROPERTIES  _BACKTRACE_TRIPLES "/workspace/dwqww/CMakeLists.txt;92;add_test;/workspace/dwqww/CMakeLists.txt;0;")
add_test(ownbook_regression "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3.12" "/workspace/dwqww/tools/ownbook_regression.py" "/workspace/.cloud-setup/forge-nnue-capture-release/forge" "/workspace/.cloud-setup/forge-nnue-capture-release/ownbook-regression.json")
set_tests_properties(ownbook_regression PROPERTIES  _BACKTRACE_TRIPLES "/workspace/dwqww/CMakeLists.txt;95;add_test;/workspace/dwqww/CMakeLists.txt;0;")
