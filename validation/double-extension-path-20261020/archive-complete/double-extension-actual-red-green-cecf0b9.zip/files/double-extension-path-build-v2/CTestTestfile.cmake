# CMake generated Testfile for 
# Source directory: /workspace/.cloud-setup/double-extension-path-source
# Build directory: /workspace/.cloud-setup/double-extension-path-build-v2
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test(forge_tests "/workspace/.cloud-setup/double-extension-path-build-v2/forge_tests")
set_tests_properties(forge_tests PROPERTIES  _BACKTRACE_TRIPLES "/workspace/.cloud-setup/double-extension-path-source/CMakeLists.txt;59;add_test;/workspace/.cloud-setup/double-extension-path-source/CMakeLists.txt;0;")
add_test(forge_tt_tests "/workspace/.cloud-setup/double-extension-path-build-v2/forge_tt_tests")
set_tests_properties(forge_tt_tests PROPERTIES  _BACKTRACE_TRIPLES "/workspace/.cloud-setup/double-extension-path-source/CMakeLists.txt;60;add_test;/workspace/.cloud-setup/double-extension-path-source/CMakeLists.txt;0;")
add_test(forge_rule50_tests "/workspace/.cloud-setup/double-extension-path-build-v2/forge_rule50_tests")
set_tests_properties(forge_rule50_tests PROPERTIES  _BACKTRACE_TRIPLES "/workspace/.cloud-setup/double-extension-path-source/CMakeLists.txt;61;add_test;/workspace/.cloud-setup/double-extension-path-source/CMakeLists.txt;0;")
add_test(forge_legal_witness_tests "/workspace/.cloud-setup/double-extension-path-build-v2/forge_legal_witness_tests" "/workspace/.cloud-setup/double-extension-path-source/tests/legal_witness_fixtures.tsv" "/workspace/.cloud-setup/double-extension-path-source/tools/openings/forge-10000.epd")
set_tests_properties(forge_legal_witness_tests PROPERTIES  _BACKTRACE_TRIPLES "/workspace/.cloud-setup/double-extension-path-source/CMakeLists.txt;62;add_test;/workspace/.cloud-setup/double-extension-path-source/CMakeLists.txt;0;")
add_test(match_tool_tests "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3.12" "/workspace/.cloud-setup/double-extension-path-source/tools/match/test_match_tools.py")
set_tests_properties(match_tool_tests PROPERTIES  _BACKTRACE_TRIPLES "/workspace/.cloud-setup/double-extension-path-source/CMakeLists.txt;85;add_test;/workspace/.cloud-setup/double-extension-path-source/CMakeLists.txt;0;")
add_test(windows_validation_tests "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3.12" "/workspace/.cloud-setup/double-extension-path-source/tools/match/tests/test_windows_validate.py")
set_tests_properties(windows_validation_tests PROPERTIES  _BACKTRACE_TRIPLES "/workspace/.cloud-setup/double-extension-path-source/CMakeLists.txt;87;add_test;/workspace/.cloud-setup/double-extension-path-source/CMakeLists.txt;0;")
add_test(uci_regression "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3.12" "/workspace/.cloud-setup/double-extension-path-source/tools/uci_regression.py" "/workspace/.cloud-setup/double-extension-path-build-v2/forge" "--log" "/workspace/.cloud-setup/double-extension-path-build-v2/uci-regression.log")
set_tests_properties(uci_regression PROPERTIES  _BACKTRACE_TRIPLES "/workspace/.cloud-setup/double-extension-path-source/CMakeLists.txt;89;add_test;/workspace/.cloud-setup/double-extension-path-source/CMakeLists.txt;0;")
add_test(ponder_regression "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3.12" "/workspace/.cloud-setup/double-extension-path-source/tools/ponder_regression.py" "/workspace/.cloud-setup/double-extension-path-build-v2/forge")
set_tests_properties(ponder_regression PROPERTIES  _BACKTRACE_TRIPLES "/workspace/.cloud-setup/double-extension-path-source/CMakeLists.txt;92;add_test;/workspace/.cloud-setup/double-extension-path-source/CMakeLists.txt;0;")
add_test(ownbook_regression "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3.12" "/workspace/.cloud-setup/double-extension-path-source/tools/ownbook_regression.py" "/workspace/.cloud-setup/double-extension-path-build-v2/forge" "/workspace/.cloud-setup/double-extension-path-build-v2/ownbook-regression.json")
set_tests_properties(ownbook_regression PROPERTIES  _BACKTRACE_TRIPLES "/workspace/.cloud-setup/double-extension-path-source/CMakeLists.txt;95;add_test;/workspace/.cloud-setup/double-extension-path-source/CMakeLists.txt;0;")
