file(REMOVE_RECURSE
  "CMakeFiles/forge_rule50_tests.dir/link.d"
  "CMakeFiles/forge_rule50_tests.dir/tests/rule50_tests.cpp.o"
  "CMakeFiles/forge_rule50_tests.dir/tests/rule50_tests.cpp.o.d"
  "forge_rule50_tests"
  "forge_rule50_tests.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/forge_rule50_tests.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
