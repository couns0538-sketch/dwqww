# Empty compiler generated dependencies file for forge_rule50_tests.
# This may be replaced when dependencies are built.
