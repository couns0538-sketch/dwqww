# Empty dependencies file for forge_legal_witness_tests.
# This may be replaced when dependencies are built.
