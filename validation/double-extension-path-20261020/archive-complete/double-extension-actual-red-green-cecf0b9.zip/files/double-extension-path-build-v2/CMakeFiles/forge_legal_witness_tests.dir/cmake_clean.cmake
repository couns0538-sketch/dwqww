file(REMOVE_RECURSE
  "CMakeFiles/forge_legal_witness_tests.dir/link.d"
  "CMakeFiles/forge_legal_witness_tests.dir/tests/legal_witness_tests.cpp.o"
  "CMakeFiles/forge_legal_witness_tests.dir/tests/legal_witness_tests.cpp.o.d"
  "forge_legal_witness_tests"
  "forge_legal_witness_tests.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/forge_legal_witness_tests.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
