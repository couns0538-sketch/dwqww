
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/workspace/.cloud-setup/double-extension-path-source/tests/legal_witness_tests.cpp" "CMakeFiles/forge_legal_witness_tests.dir/tests/legal_witness_tests.cpp.o" "gcc" "CMakeFiles/forge_legal_witness_tests.dir/tests/legal_witness_tests.cpp.o.d"
  "" "forge_legal_witness_tests" "gcc" "CMakeFiles/forge_legal_witness_tests.dir/link.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
