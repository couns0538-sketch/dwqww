
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/workspace/.cloud-setup/double-extension-path-source/src/bitboard.cpp" "CMakeFiles/forge_core.dir/src/bitboard.cpp.o" "gcc" "CMakeFiles/forge_core.dir/src/bitboard.cpp.o.d"
  "/workspace/.cloud-setup/double-extension-path-source/src/board.cpp" "CMakeFiles/forge_core.dir/src/board.cpp.o" "gcc" "CMakeFiles/forge_core.dir/src/board.cpp.o.d"
  "/workspace/.cloud-setup/double-extension-path-source/src/book.cpp" "CMakeFiles/forge_core.dir/src/book.cpp.o" "gcc" "CMakeFiles/forge_core.dir/src/book.cpp.o.d"
  "/workspace/.cloud-setup/double-extension-path-source/src/eval.cpp" "CMakeFiles/forge_core.dir/src/eval.cpp.o" "gcc" "CMakeFiles/forge_core.dir/src/eval.cpp.o.d"
  "/workspace/.cloud-setup/double-extension-path-source/src/eval_params.cpp" "CMakeFiles/forge_core.dir/src/eval_params.cpp.o" "gcc" "CMakeFiles/forge_core.dir/src/eval_params.cpp.o.d"
  "/workspace/.cloud-setup/double-extension-path-source/src/nnue.cpp" "CMakeFiles/forge_core.dir/src/nnue.cpp.o" "gcc" "CMakeFiles/forge_core.dir/src/nnue.cpp.o.d"
  "/workspace/.cloud-setup/double-extension-path-source/src/search.cpp" "CMakeFiles/forge_core.dir/src/search.cpp.o" "gcc" "CMakeFiles/forge_core.dir/src/search.cpp.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
