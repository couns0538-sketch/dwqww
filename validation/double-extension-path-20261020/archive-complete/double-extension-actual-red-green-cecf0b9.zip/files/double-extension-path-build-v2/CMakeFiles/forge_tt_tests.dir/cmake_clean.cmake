file(REMOVE_RECURSE
  "CMakeFiles/forge_tt_tests.dir/link.d"
  "CMakeFiles/forge_tt_tests.dir/tests/tt_coherence_tests.cpp.o"
  "CMakeFiles/forge_tt_tests.dir/tests/tt_coherence_tests.cpp.o.d"
  "forge_tt_tests"
  "forge_tt_tests.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/forge_tt_tests.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
