forge_tests: \
  /usr/lib/gcc/x86_64-linux-gnu/14/../../../x86_64-linux-gnu/Scrt1.o \
  /usr/lib/gcc/x86_64-linux-gnu/14/../../../x86_64-linux-gnu/crti.o \
  /usr/lib/gcc/x86_64-linux-gnu/14/crtbeginS.o \
  CMakeFiles/forge_tests.dir/tests/tests.cpp.o \
  libforge_core.a \
  /usr/lib/gcc/x86_64-linux-gnu/14/libstdc++.so \
  /usr/lib/gcc/x86_64-linux-gnu/14/../../../x86_64-linux-gnu/libm.so \
  /usr/lib/gcc/x86_64-linux-gnu/14/../../../x86_64-linux-gnu/libm.so \
  /usr/lib/gcc/x86_64-linux-gnu/14/../../../x86_64-linux-gnu/libm.so \
  /lib/x86_64-linux-gnu/libm.so.6 \
  /lib/x86_64-linux-gnu/libmvec.so.1 \
  /usr/lib/gcc/x86_64-linux-gnu/14/libgcc_s.so \
  /usr/lib/gcc/x86_64-linux-gnu/14/libgcc_s.so \
  /usr/lib/gcc/x86_64-linux-gnu/14/libgcc_s.so \
  /usr/lib/gcc/x86_64-linux-gnu/14/../../../x86_64-linux-gnu/libgcc_s.so.1 \
  /usr/lib/gcc/x86_64-linux-gnu/14/libgcc.a \
  /usr/lib/gcc/x86_64-linux-gnu/14/libgcc.a \
  /usr/lib/gcc/x86_64-linux-gnu/14/../../../x86_64-linux-gnu/libc.so \
  /usr/lib/gcc/x86_64-linux-gnu/14/../../../x86_64-linux-gnu/libc.so \
  /usr/lib/gcc/x86_64-linux-gnu/14/../../../x86_64-linux-gnu/libc.so \
  /lib/x86_64-linux-gnu/libc.so.6 \
  /usr/lib/x86_64-linux-gnu/libc_nonshared.a \
  /lib64/ld-linux-x86-64.so.2 \
  /usr/lib/gcc/x86_64-linux-gnu/14/libgcc_s.so \
  /usr/lib/gcc/x86_64-linux-gnu/14/libgcc_s.so \
  /usr/lib/gcc/x86_64-linux-gnu/14/libgcc_s.so \
  /usr/lib/gcc/x86_64-linux-gnu/14/../../../x86_64-linux-gnu/libgcc_s.so.1 \
  /usr/lib/gcc/x86_64-linux-gnu/14/libgcc.a \
  /usr/lib/gcc/x86_64-linux-gnu/14/libgcc.a \
  /usr/lib/gcc/x86_64-linux-gnu/14/crtendS.o \
  /usr/lib/gcc/x86_64-linux-gnu/14/../../../x86_64-linux-gnu/crtn.o \
  /lib64/ld-linux-x86-64.so.2

/usr/lib/gcc/x86_64-linux-gnu/14/../../../x86_64-linux-gnu/Scrt1.o:

/usr/lib/gcc/x86_64-linux-gnu/14/../../../x86_64-linux-gnu/crti.o:

/usr/lib/gcc/x86_64-linux-gnu/14/crtbeginS.o:

CMakeFiles/forge_tests.dir/tests/tests.cpp.o:

libforge_core.a:

/usr/lib/gcc/x86_64-linux-gnu/14/libstdc++.so:

/usr/lib/gcc/x86_64-linux-gnu/14/../../../x86_64-linux-gnu/libm.so:

/usr/lib/gcc/x86_64-linux-gnu/14/../../../x86_64-linux-gnu/libm.so:

/usr/lib/gcc/x86_64-linux-gnu/14/../../../x86_64-linux-gnu/libm.so:

/lib/x86_64-linux-gnu/libm.so.6:

/lib/x86_64-linux-gnu/libmvec.so.1:

/usr/lib/gcc/x86_64-linux-gnu/14/libgcc_s.so:

/usr/lib/gcc/x86_64-linux-gnu/14/libgcc_s.so:

/usr/lib/gcc/x86_64-linux-gnu/14/libgcc_s.so:

/usr/lib/gcc/x86_64-linux-gnu/14/../../../x86_64-linux-gnu/libgcc_s.so.1:

/usr/lib/gcc/x86_64-linux-gnu/14/libgcc.a:

/usr/lib/gcc/x86_64-linux-gnu/14/libgcc.a:

/usr/lib/gcc/x86_64-linux-gnu/14/../../../x86_64-linux-gnu/libc.so:

/usr/lib/gcc/x86_64-linux-gnu/14/../../../x86_64-linux-gnu/libc.so:

/usr/lib/gcc/x86_64-linux-gnu/14/../../../x86_64-linux-gnu/libc.so:

/lib/x86_64-linux-gnu/libc.so.6:

/usr/lib/x86_64-linux-gnu/libc_nonshared.a:

/lib64/ld-linux-x86-64.so.2:

/usr/lib/gcc/x86_64-linux-gnu/14/libgcc_s.so:

/usr/lib/gcc/x86_64-linux-gnu/14/libgcc_s.so:

/usr/lib/gcc/x86_64-linux-gnu/14/libgcc_s.so:

/usr/lib/gcc/x86_64-linux-gnu/14/../../../x86_64-linux-gnu/libgcc_s.so.1:

/usr/lib/gcc/x86_64-linux-gnu/14/libgcc.a:

/usr/lib/gcc/x86_64-linux-gnu/14/libgcc.a:

/usr/lib/gcc/x86_64-linux-gnu/14/crtendS.o:

/usr/lib/gcc/x86_64-linux-gnu/14/../../../x86_64-linux-gnu/crtn.o:

/lib64/ld-linux-x86-64.so.2:
