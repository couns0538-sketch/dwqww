file(REMOVE_RECURSE
  "CMakeFiles/forge_core.dir/src/bitboard.cpp.o"
  "CMakeFiles/forge_core.dir/src/bitboard.cpp.o.d"
  "CMakeFiles/forge_core.dir/src/board.cpp.o"
  "CMakeFiles/forge_core.dir/src/board.cpp.o.d"
  "CMakeFiles/forge_core.dir/src/book.cpp.o"
  "CMakeFiles/forge_core.dir/src/book.cpp.o.d"
  "CMakeFiles/forge_core.dir/src/eval.cpp.o"
  "CMakeFiles/forge_core.dir/src/eval.cpp.o.d"
  "CMakeFiles/forge_core.dir/src/eval_params.cpp.o"
  "CMakeFiles/forge_core.dir/src/eval_params.cpp.o.d"
  "CMakeFiles/forge_core.dir/src/nnue.cpp.o"
  "CMakeFiles/forge_core.dir/src/nnue.cpp.o.d"
  "CMakeFiles/forge_core.dir/src/search.cpp.o"
  "CMakeFiles/forge_core.dir/src/search.cpp.o.d"
  "libforge_core.a"
  "libforge_core.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/forge_core.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
