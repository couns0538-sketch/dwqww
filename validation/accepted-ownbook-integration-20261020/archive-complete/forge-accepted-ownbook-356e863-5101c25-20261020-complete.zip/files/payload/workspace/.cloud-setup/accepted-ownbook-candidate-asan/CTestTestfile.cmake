# CMake generated Testfile for 
# Source directory: /workspace/.cloud-setup/accepted-ownbook-candidate-source
# Build directory: /workspace/.cloud-setup/accepted-ownbook-candidate-asan
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test(forge_tests "/workspace/.cloud-setup/accepted-ownbook-candidate-asan/forge_tests")
set_tests_properties(forge_tests PROPERTIES  _BACKTRACE_TRIPLES "/workspace/.cloud-setup/accepted-ownbook-candidate-source/CMakeLists.txt;50;add_test;/workspace/.cloud-setup/accepted-ownbook-candidate-source/CMakeLists.txt;0;")
add_test(match_tool_tests "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3" "/workspace/.cloud-setup/accepted-ownbook-candidate-source/tools/match/test_match_tools.py")
set_tests_properties(match_tool_tests PROPERTIES  _BACKTRACE_TRIPLES "/workspace/.cloud-setup/accepted-ownbook-candidate-source/CMakeLists.txt;71;add_test;/workspace/.cloud-setup/accepted-ownbook-candidate-source/CMakeLists.txt;0;")
add_test(uci_regression "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3" "/workspace/.cloud-setup/accepted-ownbook-candidate-source/tools/uci_regression.py" "/workspace/.cloud-setup/accepted-ownbook-candidate-asan/forge" "--log" "/workspace/.cloud-setup/accepted-ownbook-candidate-asan/uci-regression.log")
set_tests_properties(uci_regression PROPERTIES  _BACKTRACE_TRIPLES "/workspace/.cloud-setup/accepted-ownbook-candidate-source/CMakeLists.txt;73;add_test;/workspace/.cloud-setup/accepted-ownbook-candidate-source/CMakeLists.txt;0;")
add_test(ponder_regression "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3" "/workspace/.cloud-setup/accepted-ownbook-candidate-source/tools/ponder_regression.py" "/workspace/.cloud-setup/accepted-ownbook-candidate-asan/forge")
set_tests_properties(ponder_regression PROPERTIES  _BACKTRACE_TRIPLES "/workspace/.cloud-setup/accepted-ownbook-candidate-source/CMakeLists.txt;76;add_test;/workspace/.cloud-setup/accepted-ownbook-candidate-source/CMakeLists.txt;0;")
