file(REMOVE_RECURSE
  "CMakeFiles/forge_bench.dir/link.d"
  "CMakeFiles/forge_bench.dir/bench/benchmark.cpp.o"
  "CMakeFiles/forge_bench.dir/bench/benchmark.cpp.o.d"
  "forge_bench"
  "forge_bench.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/forge_bench.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
