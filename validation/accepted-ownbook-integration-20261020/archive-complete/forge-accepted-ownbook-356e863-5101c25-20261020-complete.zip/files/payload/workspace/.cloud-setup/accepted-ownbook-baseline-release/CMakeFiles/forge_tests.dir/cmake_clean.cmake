file(REMOVE_RECURSE
  "CMakeFiles/forge_tests.dir/link.d"
  "CMakeFiles/forge_tests.dir/tests/tests.cpp.o"
  "CMakeFiles/forge_tests.dir/tests/tests.cpp.o.d"
  "forge_tests"
  "forge_tests.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/forge_tests.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
