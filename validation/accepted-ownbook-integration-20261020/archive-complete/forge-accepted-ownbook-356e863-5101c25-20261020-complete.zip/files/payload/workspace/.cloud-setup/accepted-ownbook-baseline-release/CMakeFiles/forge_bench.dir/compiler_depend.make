# Empty compiler generated dependencies file for forge_bench.
# This may be replaced when dependencies are built.
