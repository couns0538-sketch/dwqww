# GrokChess NNUE net log
Every net goes here, including failed or aborted ones. **All nets are UNPROVEN** until Engine Strength has run a gated
match vs the current lock AND the NPS loss is confirmed ≤25% vs the lock (Threads=1, Hash=16).

**Base lock for all future NNUE Elo/NPS gates: GrokChess 1.7.36** = `/workspace/chess-engine/baseline/dist-v1.7.36` (badcap, js 274bbb1d, HCE bench d9 286362). Locked 2026-10-14 ~19:11 PT; supersedes 1.7.35. `baseline/dist-v1.7.37` is an NNUE overlay (n64d40ftbk net 157e6b16), NOT the classical lock. Earlier NPS/Elo vs older locks must be re-measured on 1.7.36 builds. NNUE never writes under baseline/.

(Previous lock note kept for history: **1.7.34** = `/workspace/chess-engine/baseline/dist-v1.7.34` (evalfast, js c5d3a1dd, bench d9 269586). Locked 2026-10-14 ~13:05 PT; supersedes 1.7.33.)

(Previous note kept for history: 1.7.29 was prune2-1728 js-tree 8ba774d7.) = `/workspace/chess-engine/baseline/dist-v1.7.29` (prune2-1728, js-tree 8ba774d7, bench d9 269586). Locked 2026-10-13 ~23:38 PT; it supersedes 1.7.28 (some routine text still says 1.7.28). Earlier test-net NPS numbers below were measured vs 1.7.28 and must be re-measured vs 1.7.29.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| zero.nnue | 2026-10-13 22:42 | none (all-zero weights) | 768->? plumbing test | - | - | - | - | TEST ONLY, not a real net — UNPROVEN |
| dist-nnue-test-h32/h64/h128(/h128-acc32) | 2026-10-13 ~23:10 | random weights (make_test_net.js) | 768->32/64/128 x2->1 | - | - | bench d9 vs 1.7.28 (HCE ~395-403k nps): h32 ~450-582k, h64 ~365k (~-8%), h128 ~317k (~-20%); node counts differ, noisy | - | SPEED/PLUMBING TEST ONLY; bug_gate: known HCE draw-rule skips under UseNNUE + some mate failures with random nets — UNPROVEN |
| (no trained net yet) | | | | | | | | |

## Data sets
- Lichess `lichess_db_eval.jsonl.zst` (raw/): **COMPLETE** 22,423,777,007 bytes (2026-10-14 00:03 PT). Remote Last-Modified Fri 2026-10-02 20:16:33 GMT, ETag "6ac01121-5388faeef". `run_after_0240.sh` (WAIT=1) passed the 02:40 PT gate and started filter at 02:40:35 PT: `filter_lichess.py --cap 20000000` (nice 19, throttles at load≥4). As of ~03:40 PT: ~7M lines scanned, ~3.16M kept (log `logs/filter.log`); train.bin/val.bin not written until cap. Classical push load keeps the filter mostly sleeping; training (h64 then h128) waits for load<4 after filter finishes. No trained net yet — UNPROVEN.
- `quiet-evals.csv` conversion (/workspace/nnue/convert.py): ABORTED 2026-10-13 22:41 PT at ~2M/5M rows on plan change; no output. UNPROVEN / unused.

## Sign convention
Stored scores are from White's view. Raw Lichess cp is already from White's view (do not flip). quiet-evals.csv is from the SIDE TO MOVE's view despite its header.
Every dataset and run must log the `signcheck` result: corr > 0.1 and the mirror check OK. A net trained without a passing signcheck is INVALID.

## Engine NNUE path caveats (UNPROVEN, 2026-10-13)
- With a net loaded (UseNNUE on), `evaluate()` returns the net output directly and **skips all HCE draw and scaling rules**
  (insufficient material/KBvKB, wrong-colored bishop + rook pawn, opposite-bishop and other endgame scaling, eval cache).
  Search-level draws (repetition, 50-move, stalemate) still apply. Any draw-rule port on top of the net is future work.
- Int16 accumulator bound: `max|ftB| + 32*max|ftW| < 32767` (QA units). train.py clamps during training and clips on export;
  engine `loadNet` rejects nets that violate it and falls back to HCE. Pack trainer output with
  `/workspace/chess-engine-nnue/tools/pack_trainer_net.js <outdir> <dist>/net.nnue`.

## Engine tree status (2026-10-14 ~00:00 PT)
- `/workspace/chess-engine-nnue/src/search/search.ts` now has **prune2** (patch `/workspace/chess-engine-strength/research/prune2_1728_ts.patch`, applied clean with `patch -p0`;
  result byte-identical to research/prune2_1728/src/search/search.ts). No board/move/tt files touched. Pre-patch copy: `/workspace/chess-engine-nnue/search.ts.pre-prune2.bak`.
- Build `dist-nnue-v2-prune2-1729` (snapshot of dist/, js-tree 222de22b, package.json version 1.7.29-nnue cosmetic): perft 25/25; HCE mode (no net / UseNNUE off) bench d9 nodes **269586 = lock 1.7.29** (output-identical search);
  `search.js` byte-identical to the lock; vs lock only eval/evaluate.js, eval/nnue.js, search/smp*.js, uci/main.js differ. acc_check h32 60 games 9533 checks 0 mismatches.
  bug_gate_nofuzz (HCE): PASS, 0 new, 8 KNOWN, 1 FIXED reminder (mate_distance two rooks m3). Fuzz skipped (QA runs it).
- Patches: `nnue-768-v2_on1729_ts.patch` (NNUE delta on top of 1.7.29 TS src, md5 bfc1954b) and `nnue-768-v2-prune2_vs1728_ts.patch` (NNUE+prune2 vs 1.7.28 TS src, md5 29b79da0). Old 1.7.28-based build kept as `dist-nnue-v2-pre-prune2`.
- Note: prune2 calls evaluate() at PV nodes too, so with a net loaded PV nodes now pay one NNUE eval (same as lock HCE behaviour).

## Pipeline after 02:40 PT
`/workspace/chess-tools/nnue/run_after_0240.sh` **RUNNING** (pid in `logs/run_after_0240.pid`; flock `.run_after_0240.lock`). Started filter 2026-10-14 02:40:35 PT after zst size check. Next: finish filter → train hidden **64 then 128** (10 epochs) → pack → `dist-nnue-n64-e10` / `dist-nnue-n128-e10` from `dist-nnue-v2-prune2-1729` → acc_check + bench vs 1.7.29 → append UNPROVEN rows. Why 64 first: random-net bench showed h64 ~-8% NPS vs h128 ~-20% (vs 1.7.28 under load); h64 trains ~2x faster. Classical push extended to ~10:40 PT Wed; filter/train stay nice 19 and waitload<4 so they do not fight the push.

## 2026-10-14 ~07:55 PT status (Engine NNUE routine) — all UNPROVEN
- Data: filter finished 06:27 PT. 19,971,852 quiet positions (train 19,772,133 / val 199,719), signcheck corr 0.501 mirror ok (data/stats.json).
- Training `n64-e10` running since 06:27 PT (nice 19, pauses at load>=4). Val loss by epoch: 0.010682, 0.010358, 0.010198, 0.010053, 0.010019, 0.009985 (ep 6), still improving.
  This run uses the old train.py (no early stopping, exports last epoch); per-epoch val is in nets/n64-e10/log.json, so best-vs-last is checkable.
- train.py now has early stopping (`--patience 2`, saves net_best.pt, exports best-val weights, log.json has best_epoch/best_val). Applies to n128 onward. Backup logs/train.py.bak-*.
- HCE baseline loss: `hce/hce_valloss.py` scores the HCE on the same val.bin with the same loss (raw and best cp scale k). Running in background (waits load<4) -> hce/hce_valloss.json. No net goes to QA unless its best val loss beats the HCE's.
- Rebased onto lock 1.7.32: `/workspace/chess-engine-nnue/dist-nnue-v3-1732` = cp of baseline/dist-v1.7.32 + NNUE files (eval/evaluate.js, eval/nnue.js) + 3-way merged search/smp.js, smp_worker.js, smp.d.ts, uci/main.js (two trivial conflicts: worker warmup now carries Hash entries; UCI Hash option kept next to UseNNUE/EvalFile). search.js byte-identical to the lock. No board/move/tt files touched.
  Checks: perft_all PASS; HCE bench d9 nodes 269586 = lock 1.7.32; js-tree da7f0eb6; acc_check (test h64 net) 20 games 3128 checks 0 mismatches; UCI smoke with EvalFile + Threads 2 OK, nnueinfo prints the net path.
  JS patch vs lock: `/workspace/chess-engine-nnue/nnue-768-v3_on1732_js.patch` (md5 8a44d203). TS source still on the 1.7.29 tree; TS rebase is pending (no exact TS source for 1.7.32 smp/uci was found).
- `follow_1732.sh` (background) waits for run_after_0240.sh to finish, then rebuilds each trained net as dist-nnue-<id>-1732 with acc_check + bench vs 1.7.32 and appends rows below. The 1.7.29-based rows from run_after_0240.sh are superseded by the -1732 rows.

## Trained nets (appended by run_after_0240.sh; all UNPROVEN)
| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.29 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|

## 2026-10-14 ~08:57 PT status (Engine NNUE routine) — all UNPROVEN
- Progress since ~07:55: **NEW LOCK 1.7.33** noticed (rephist3); rebased NNUE onto it as `dist-nnue-v4-1733`.
- Training `n64-e10` still at **epoch 6/10** (best val so far 0.009985); nice 19, paused most of the hour because load ~5.2–5.4 (>=4). No new epochs since ~07:35 PT. `net.pt` present; no `net.nnue` export yet (exports after last/best epoch).
- `hce/hce_valloss.py` still waiting for load<4 (empty log). `follow_1733.sh` armed (replaces 1732 follow for packaging).
- Rebase `dist-nnue-v4-1733`: 3-way merge of NNUE overlays onto lock 1.7.33 (search.js byte-identical; files: eval/evaluate.js, eval/nnue.js(+d.ts), search/smp.js, smp_worker.js, smp.d.ts, uci/main.js). perft 25/25 PASS; HCE bench d9 nodes **269586 = lock 1.7.33**; js-tree **e26a2edf**; acc_check (test h64) 20 games 3128 checks 0 mismatches; UCI EvalFile smoke prints net path. JS patch `nnue-768-v4_on1733_js.patch` md5 **f72c89ca**. No board/move/tt touched. TS source still on older tree — pending.
- Push still ends ~1:35 PM PT. No trained net for QA yet. Nothing needed from Couns.

## Engine tree status (2026-10-14 ~08:57 PT)
- Current NNUE base: `/workspace/chess-engine-nnue/dist-nnue-v4-1733` vs lock **1.7.33**. Prior `dist-nnue-v3-1732` kept (vs 1.7.32) for history.

## 2026-10-14 ~10:57 PT status (Engine NNUE routine) — all UNPROVEN
- HCE val loss finished: raw 0.014273, best cp scale k=0.95 0.014259 (corr 0.556) on the same 199,719 val positions (hce/hce_valloss.json).
- n64-e10 still stuck at epoch 6/10 (val 0.009985), throttled since ~07:35 PT because box load stays ~6 (>=4). Its ep6 val is about 30% below the HCE's val loss.
- Interim snapshot exported (no wait for training): `nets/n64-ep6snap` = n64-e10 epoch-6 net.pt, same int16 export as train.py (export_snapshot.py), packed net.nnue md5 8223d8a7.
  Dist `/workspace/chess-engine-nnue/dist-nnue-n64-ep6snap-1733` = dist-nnue-v4-1733 + this net (js-tree e26a2edf, same JS as v4). acc_check 20 games 3128 checks 0 mismatches; nnueinfo prints the net path; KQRRBBNN-vs-K eval +1731 (sign sane).
  Pending: bench/NPS vs lock 1.7.33 (follow_1733.sh will add the row when load<4), bug_gate with net, Profiler NPS, Code Review diff. Not for QA yet.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.33 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n64-ep6snap | 2026-10-14 10:54 | Lichess quiet 19.97M, lambda 1.0 | 768->64 x2->1 | ep 6 of 10 / 1e-3 | 0.009985 (HCE 0.014259) | pending | not tested | UNPROVEN, interim snapshot |
| n64-e10 | 2026-10-14 12:21 | lichess eval, filter cap 20000000 (data/stats.json) | 768->64 x2->1 | 10 ep / lr 1e-3 step0.3 | 0.00993 | -4.4% bench d9 (noisy; Profiler to confirm T1 H16) | not tested | UNPROVEN — dist /workspace/chess-engine-nnue/dist-nnue-n64-e10, js-tree 222de22b, ACC_CHECK games=60 checks=9533 mismatches=0 |

## 2026-10-14 ~13:05 PT status (Engine NNUE routine) — all UNPROVEN
- **NEW LOCK 1.7.34** (evalfast-1733, js c5d3a1dd, eval/evaluate.js only, output-identical to 1.7.33). Rebased: `/workspace/chess-engine-nnue/dist-nnue-v5-1734` = cp dist-v1.7.34 + NNUE files; evaluate.js via `git merge-file` (clean, NNUE delta = require + 2-line early return), other overlays unchanged in lock 33->34.
  search.js byte-identical to lock; perft 25/25; HCE bench d9 nodes 269586 = lock; js-tree c92155b4; acc_check (n64-e10) 20 g 3128 checks 0 mismatches; nnueinfo prints net path. JS patch `nnue-768-v5_on1734_js.patch` md5 e51fe30d.
- n64-e10 finished 12:21 PT: 10 epochs, last = best val **0.009930** (HCE 0.014259, ~30% lower). run_after_0240.sh packed it on the old 1.7.29 base (row above, superseded).
- `dist-nnue-n64-e10-1734` (v5 + n64-e10 net md5 3adcd608): bug_gate_nofuzz with net loaded **FAIL**: 2 new failures, mate-distance two rooks m3 (found m4) and KQK m5 (found m6); lock and HCE mode pass both. Cause: net is weak in bare-king endings (quiet Lichess data), ID stops at first (longer) mate.
- Fix `dist-nnue-n64e10bk-1734` ("nnue-bk"): evaluate() uses the HCE when either side has only its king (bareKing check in eval/evaluate.js only). Mate-distance ALL PASS; bug_gate_nofuzz with net loaded **PASS** (0 new, 5 KNOWN, 3 FIXED reminders incl. KBvKB same colour; KvK 0; mate suite ALL PASS; fuzz left to QA).
  acc_check 20 g 3128 checks 0 mismatches; bench d9 nodes 290469 (same as without bk). js-tree 08edb663. JS patch vs lock `/workspace/chess-engine-nnue/nnue-768-v5bk_on1734_js.patch` md5 6ce7282a.
  Box bench d9 (load ~4, noisy): n64 272997/262156/257736 nps vs lock 267712/232402 → roughly equal NPS; nodes to d9 +7.7% (290469 vs 269586). Needs Agent Profiler T1 H16 confirmation, Code Review of the patch, then QA.
- n128-e10 training since 12:21 PT (early stopping): val by epoch 0.010302, 0.009901, 0.009724, 0.009538, 0.009497, 0.009456, 0.009421, 0.009413 (ep 8) — already better than n64. `follow_1734.sh` armed: after run_after_0240.sh exits, builds dist-nnue-n128-e10-1734 on the bk dist + acc_check + bench vs 1.7.34 and appends a row.
- follow_1732.sh / follow_1733.sh still armed (superseded; Auto-review blocked killing them). They will add -1732/-1733 rows for history only; ignore those for gating.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.34 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n64-e10-1734 | 2026-10-14 13:00 | Lichess quiet 19.97M, lambda 1.0 | 768->64 x2->1 | 10 ep / 1e-3 | 0.009930 (HCE 0.014259) | ~0% box bench d9 (noisy) | not tested | UNPROVEN — FAILED bug_gate (mate distance), not for QA |
| n64-e10bk-1734 | 2026-10-14 13:05 | same net as n64-e10 + bare-king HCE fallback | 768->64 x2->1 | 10 ep / 1e-3 | 0.009930 (HCE 0.014259) | ~0% box bench d9 (noisy; Profiler to confirm) | not tested | UNPROVEN — bug_gate PASS (no fuzz), awaiting Profiler NPS + Code Review; dist /workspace/chess-engine-nnue/dist-nnue-n64e10bk-1734 js-tree 08edb663 |
| n128-e10 | 2026-10-14 13:14 | lichess eval, filter cap 20000000 (data/stats.json) | 768->128 x2->1 | 10 ep / lr 1e-3 step0.3 | 0.009391 | -38.9% bench d9 (noisy; Profiler to confirm T1 H16) | not tested | UNPROVEN — dist /workspace/chess-engine-nnue/dist-nnue-n128-e10, js-tree 222de22b, ACC_CHECK games=60 checks=9533 mismatches=0 |
| n128-e10-1733 | 2026-10-14 13:15 | same net as n128-e10, on 1.7.33 NNUE dist | 768->H x2->1 | - | best 0.009391 ep 10 of 10 (HCE: hce/hce_valloss.json) | -32.2% bench d9 vs 1.7.33 (noisy; Profiler to confirm T1 H16) | not tested | UNPROVEN — dist /workspace/chess-engine-nnue/dist-nnue-n128-e10-1733, js-tree e26a2edf, ACC_CHECK games=60 checks=9533 mismatches=0 |
| n128-e10-1734 | 2026-10-14 13:15 | same net as n128-e10, on 1.7.34 NNUE dist | 768->H x2->1 | - | best 0.009391 ep 10 of 10 (HCE: hce/hce_valloss.json) | -33.6% bench d9 vs 1.7.34 (noisy; Profiler to confirm T1 H16) | not tested | UNPROVEN — dist /workspace/chess-engine-nnue/dist-nnue-n128-e10-1734, js-tree 08edb663, ACC_CHECK games=60 checks=9533 mismatches=0 |
| n64-e10-1733 | 2026-10-14 13:15 | same net as n64-e10, on 1.7.33 NNUE dist | 768->H x2->1 | - | best 0.00993 ep ? of 10 (HCE: hce/hce_valloss.json) | +0.7% bench d9 vs 1.7.33 (noisy; Profiler to confirm T1 H16) | not tested | UNPROVEN — dist /workspace/chess-engine-nnue/dist-nnue-n64-e10-1733, js-tree e26a2edf, ACC_CHECK games=60 checks=9533 mismatches=0 |
| n64-ep6snap-1733 | 2026-10-14 13:15 | same net as n64-ep6snap, on 1.7.33 NNUE dist | 768->H x2->1 | - | best 0.009985 ep 6 of 6 (HCE: hce/hce_valloss.json) | +17.3% bench d9 vs 1.7.33 (noisy; Profiler to confirm T1 H16) | not tested | UNPROVEN — dist /workspace/chess-engine-nnue/dist-nnue-n64-ep6snap-1733, js-tree e26a2edf, ACC_CHECK games=60 checks=9533 mismatches=0 |
| n128-e10-1732 | 2026-10-14 13:15 | same net as n128-e10, on 1.7.32 NNUE dist | 768->H x2->1 | - | best 0.009391 ep 10 of 10 (HCE: hce/hce_valloss.json) | -11.9% bench d9 vs 1.7.32 (noisy; Profiler to confirm T1 H16) | not tested | UNPROVEN — dist /workspace/chess-engine-nnue/dist-nnue-n128-e10-1732, js-tree da7f0eb6, ACC_CHECK games=60 checks=9533 mismatches=0 |
| n64-e10-1732 | 2026-10-14 13:15 | same net as n64-e10, on 1.7.32 NNUE dist | 768->H x2->1 | - | best 0.00993 ep ? of 10 (HCE: hce/hce_valloss.json) | +2.1% bench d9 vs 1.7.32 (noisy; Profiler to confirm T1 H16) | not tested | UNPROVEN — dist /workspace/chess-engine-nnue/dist-nnue-n64-e10-1732, js-tree da7f0eb6, ACC_CHECK games=60 checks=9533 mismatches=0 |
| n64-ep6snap-1732 | 2026-10-14 13:15 | same net as n64-ep6snap, on 1.7.32 NNUE dist | 768->H x2->1 | - | best 0.009985 ep 6 of 6 (HCE: hce/hce_valloss.json) | +13.3% bench d9 vs 1.7.32 (noisy; Profiler to confirm T1 H16) | not tested | UNPROVEN — dist /workspace/chess-engine-nnue/dist-nnue-n64-ep6snap-1732, js-tree da7f0eb6, ACC_CHECK games=60 checks=9533 mismatches=0 |

## n64e10bk-v6-1734 (2026-10-14 ~13:25 PT) — UNPROVEN
- dist: /workspace/chess-engine-nnue/dist-nnue-n64e10bk-v6-1734 (same net.nnue md5 3adcd608 as n64e10bk-1734; on lock 1.7.34)
- patch: nnue-768-v6bk_on1734_js.patch md5 15c06abe360e751d8109a0d1831c88e5 (vs dist-v1.7.34)
- Code Review notes on v5bk (6ce7282a) fixed: nnueEvaluate clamped to ±28000; shared+worker TTs cleared when UseNNUE changes or EvalFile loads a new net; UseNNUE default reflects GROKCHESS_USE_NNUE; 'true' parsed case-insensitively; failed EvalFile keeps the old net + "info string ERROR ..."; empty EvalFile = no change; setPoolNNUE keeps file ?? nnueCfg?.file.
- Verified: perft 25/25 PASS; acc_check 200 games 31,615 checks 0 mismatches; bench d9 net 290469 (= v5bk), UseNNUE off 269586 (= lock); nnueinfo main+workers identical at Threads 2 and after growing to 3; bad EvalFile keeps old net in main and workers; bug_gate (no fuzz) with net PASS (0 new, 5 known; mate suite + mate_distance + KvK pass).
- Still known: NNUE path bypasses HCE draw/scaling rules except the bare-king fallback (KBvK/KNvK still nonzero, same as lock).
- Next: QA fuzz+TL, PC paired timing, [0,10] vs 1.7.34. UNPROVEN.

## n128-e10 → dist-nnue-n128e10bk-v6-1734 (2026-10-14 14:26 PT) — UNPROVEN
- 768→128→1, 10 epochs on data/ (19.97M quiet Lichess, lambda 1.0); best val 0.009391 @ ep10 (n64-e10bk 0.009930; HCE 0.014259). Training finished; nets/n128-e10/net.nnue md5 b23e44a71f0b2e6249e163d6c5c2cabc.
- Build = copy of dist-nnue-n64e10bk-v6-1734 (patch nnue-768-v6bk_on1734_js.patch md5 15c06abe360e751d8109a0d1831c88e5, code unchanged) + n128 net.
- Verified (v6verify/all_n128.log): perft PASS (in bug_gate); acc_check 200 games 31,615 checks 0 mismatches; bench d9 net 183200, UseNNUE off 269586 (= lock); EvalFile bad-file keeps old net; bug_gate no-fuzz PASS (0 new, KNOWN 6: KBvK/KNvK x4 as lock, + KBvKB same-colour now -3cp (n64 gave 0), ep-hash).
- No NPS/Profiler or QA yet. Not handed off.
- Dataset in progress: data40m/ (PID 3325908, started 14:15 PT, cap 40M, quiet, lambda 1.0, log logs/filter_data40m.log). 40M not 60M because RAM (~6 GB available; dedup/shuffle needs ~3-4x the 32 B/record array).

## 2026-10-14 ~14:55 PT status (Engine NNUE routine) — all UNPROVEN
- Lock still **1.7.34** (no newer dist-v*). No rebase needed.
- Progress since ~13:25: `n128-e10` finished (best val **0.009391** @ ep10 vs n64 0.009930 / HCE 0.014259). Built `dist-nnue-n128e10bk-v6-1734` (same v6bk JS as n64, net md5 b23e44a7, js-tree dd63e29e). perft/acc_check/bug_gate PASS; box bench d9 NPS **~-34%** vs lock → fails ≤25% NPS gate → **not for QA**.
- Primary QA candidate unchanged: `dist-nnue-n64e10bk-v6-1734` (net 3adcd608, patch nnue-768-v6bk_on1734_js.patch md5 15c06abe, js-tree dd63e29e, bench d9 nodes 290469 net / 269586 HCE). Handed to Engine QA after the push; still needs formal Profiler T1 H16 NPS + fuzz/TL + [0,10] vs 1.7.34.
- Data: `filter_lichess.py --cap 40000000` → `data40m/` running since ~14:17 PT (nice 19, max-load 4, PID 3325908). Log: 11M lines / ~4.95M kept (~12% of cap), keep rate ~0.45. Box load ~6–8 (classical SPRT/TL) so filter is throttled; no new training until load <4 and filter finishes.
- Push window ended ~1:35 PM PT. Nothing blocked on Couns.

## n64-ft1 (started 2026-10-14 15:17 PT) — UNPROVEN, training
- Warm start from nets/n64-e10/net.pt (= its best, ep10 val 0.009930). 768→64→1, data/ (19.97M), lr 3e-4 (0.3x of 1e-3; StepLR every 3 ep ×0.3), up to 10 epochs, patience 2, nice 19, max-load 4.
- train.py: added --init (warm start) + epoch-0 val baseline; backup train.py.bak_preft1. Start val 0.009930 (matches).
- PID 3423674; log logs/train_n64-ft1.log; out nets/n64-ft1 (net_best.pt, log.json per-epoch val). No dist built.

## 2026-10-14 ~15:52 PT status (Engine NNUE routine) — all UNPROVEN
- Lock still **1.7.34** (`/workspace/chess-engine/baseline/dist-v1.7.34`, evalfast, js c5d3a1dd, bench d9 269586). Newest baseline under chess-engine trees; no rebase needed. Never edited.
- Box load **5.60 / 4.94 / 4.53** (>=4) — no new heavy jobs started this run.
- **data40m filter** still running: PID **3325908**, nice 19, `filter_lichess.py … data40m --cap 40000000 --max-load 4`, cwd `/workspace/chess-tools/nnue`. Log `logs/filter_data40m.log`: **28M lines / 12,668,281 kept** (~31.7% of 40M kept cap), ~5125s wall; currently **throttled** (WCHAN nanosleep). `data40m/` not written yet (outdir created only at end after dedup/shuffle).
- **n64-ft1** training: PID **3423678**, nice 19, warm-start from `nets/n64-e10/net.pt`, data/ 19.97M, lr 3e-4, patience 2. Through **epoch 3/10**: start val 0.009930 → best **0.009912** @ ep3 (ep1 0.009939, ep2 0.009928). Also throttled on load. Out `nets/n64-ft1/` (net_best.pt present). No dist yet. UNPROVEN.
- Primary QA candidate unchanged: `dist-nnue-n64e10bk-v6-1734` (net md5 **3adcd608**, patch **15c06abe**, js-tree dd63e29e). Still needs Profiler T1 H16 + QA fuzz/TL/[0,10] vs 1.7.34.
- `dist-nnue-n128e10bk-v6-1734` (net **b23e44a7**, val 0.009391): box NPS ~-34% fails ≤25% gate — not for QA.
- Progress since ~14:55: filter advanced 11M→28M lines / 4.95M→12.67M kept; n64-ft1 started (~15:17) and reached ep3. No new dist builds this hour.

## 2026-10-14 ~16:53 PT status (Engine NNUE routine) — all UNPROVEN
- **NEW LOCK 1.7.35** = `/workspace/chess-engine/baseline/dist-v1.7.35` (tteval-1734; search.js only vs 1.7.34; all-.js tree md5 `0178310193a55e5955040e10928d6574`). Cut ~16:48 PT (DR note ~16:50). NNUE gates move to 1.7.35; prior NPS/Elo vs 1.7.34 must be re-measured after rebase. Lock never edited by NNUE.
- Progress since ~15:52: filter **33M lines / 15,012,796 kept** (~37.5% of 40M cap; was 28M/12.67M); **n64-ft1** through **epoch 7/10**, best val **0.009859** (was 0.009912 @ ep3; start 0.009930; HCE 0.014259). Both still nice 19, max-load 4, currently throttled (box load ~4–9 from classical SPRTs).
- Frozen (untouched): `dist-nnue-n64e10bk-v6-1734` (net **3adcd608**, js-tree dd63e29e, patch 15c06abe) — Profiler T1 H16 vs 1.7.34 **+11.7%** NPS PASS; CR sign-off. `dist-nnue-n128e10bk-v6-1734` (net **b23e44a7**) — Profiler median **−20.1%** NPS PASS (≤25% gate; close; PC advisable). Both still UNPROVEN Elo.
- **Action this hour:** rebase NNUE overlays onto 1.7.35 as new folders `dist-nnue-*-v6-1735` (do not modify frozen *-1734). Overlay files only (evaluate/nnue/smp*/main); search.js stays lock-identical. Then Profiler re-NPS vs 1.7.35, then QA fuzz/TL/[0,10] on n64 then n128.
- data40m still writing at end of filter (outdir after dedup/shuffle). No new train until filter finishes + load<4. Push classical window to ~19:15 PT.
- Nothing needed from Couns. Need from crew: rebase completion → Profiler T1 H16 vs 1.7.35 → QA slot for n64 then n128.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n64-ft1 (training) | 2026-10-14 16:53 | Lichess quiet 19.97M warm-start n64-e10 | 768->64 x2->1 | ep7/10 lr 3e-4 patience2 | best 0.009859 (HCE 0.014259) | n/a (no dist yet) | not tested | UNPROVEN — training nets/n64-ft1 |
| n64e10bk-v6-1734 | 2026-10-14 (frozen) | same as n64-e10 | 768->64 x2->1 | 10 ep / 1e-3 | 0.009930 | +11.7% vs **1.7.34** (superseded lock) | not tested | UNPROVEN FROZEN — rebase to 1.7.35 required before QA |
| n128e10bk-v6-1734 | 2026-10-14 (frozen) | same as n128-e10 | 768->128 x2->1 | 10 ep / 1e-3 | 0.009391 | −20.1% vs **1.7.34** (superseded lock) | not tested | UNPROVEN FROZEN — rebase to 1.7.35 required before QA |


## 2026-10-14 ~17:58 PT status (Engine NNUE routine) — all UNPROVEN
- Lock **1.7.35** (`/workspace/chess-engine/baseline/dist-v1.7.35`, js-tree 01783101, bench d9 219984). Never edited.
- Rebase done 16:55–17:06: `dist-nnue-n64e10bk-v6-1735` (net 3adcd608) and `dist-nnue-n128e10bk-v6-1735` (net b23e44a7), js-tree 1182327b, patch `nnue-768-v6bk_on1735_js.patch` md5 562227b7, search.js == lock. Perft PASS, HCE bench (USE_NNUE=0) 219984 = lock, net bench d9 n64 232587 / n128 199461, acc_check 60 g 0 mismatches, nnueinfo prints net path (main + workers), bug_gate nofuzz with net PASS (0 new). Frozen *-1734 untouched.
- Agent Profiler (prof1735_box/results.md, box, d10 T1): n64 **+17.2%** median NPS vs 1.7.35 (8/8) PASS; n128 **−19.8%** median (worst −24.3%) PASS. Time-to-d10 n64 +7.5%, n128 +10.3%.
- **n64-ft1 finished** 17:37: 10/10 epochs, best val **0.009853** @ ep10 (start 0.009930; HCE 0.014259). Packed net.nnue md5 **2c5dac9c**. Built `dist-nnue-n64ft1bk-v6-1735` (cp of n64e10bk-v6-1735 + new net); all_1735.sh verify running → `v6verify/all_n64ft1_1735.log`.
- data40m filter: 42M lines / 19.16M kept (~48% of 40M cap), nice 19, throttled.
- Needed: Code Review on the 1735 patch (562227b7); Engine QA fuzz/TL/[0,10] vs 1.7.35 on n64e10bk-v6-1735 first, then n128e10bk-v6-1735.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n64ft1bk-v6-1735 | 2026-10-14 17:58 | Lichess quiet 19.97M, warm-start n64-e10 | 768->64 x2->1 | 10 ep lr 3e-4 (StepLR) | 0.009853 (HCE 0.014259) | −0.3% d10 (Profiler prof1735_1817) PASS | not tested | UNPROVEN — net 2c5dac9c; verify ALLDONE 17:54; same JS as v6bk (js-tree 1182327b) |
| n64e10bk-v6-1735 | 2026-10-14 17:06 | as n64-e10 | 768->64 x2->1 | 10 ep / 1e-3 | 0.009930 | +17.2% d10 (Profiler, box) | not tested | UNPROVEN — CR PASS 18:22; QA queued fuzz+TL box then [0,10] PC |
| n128e10bk-v6-1735 | 2026-10-14 17:06 | as n128-e10 | 768->128 x2->1 | 10 ep / 1e-3 | 0.009391 | −19.8% d10 (Profiler, box) | not tested | UNPROVEN — CR PASS (same patch); QA after n64 |

## 2026-10-14 ~18:57 PT status (Engine NNUE routine) — all UNPROVEN
- Lock still **1.7.35** (`/workspace/chess-engine/baseline/dist-v1.7.35`, js-tree 01783101, bench d9 219984). No dist-v1.7.36. Never edited by NNUE. Frozen *-v6-1734 untouched (nets 3adcd608 / b23e44a7).
- Progress since ~17:58:
  - **n64ft1bk-v6-1735 verify DONE** 17:54:59 (`v6verify/all_n64ft1_1735.log`): perft PASS, acc_check 60g 9533 checks 0 mismatches, bug_gate nofuzz PASS (0 new, KNOWN 5), HCE bench d9 219984 = lock, net bench d9 **230971**, js-tree **1182327b**, search.js == lock, nnueinfo main+workers OK. Net md5 **2c5dac9c**.
  - **Code Review PASS** 18:22 PT on `nnue-768-v6bk_on1735_js.patch` md5 **562227b7** (`research/cr_nnue_v6_1735_review.md`): pure overlay rebase of v6bk_on1734; bare-king fallback kept.
  - **Profiler** `prof1735_1817` (18:19–18:31): n64ft1bk d10 NPS median **−0.3%** vs 1.7.35 (worst −19.0%) **PASS** ≤25% gate (time-to-d10 often better via fewer nodes). Box only / UNVERIFIED.
  - Prior Profiler `prof1735_box` still stands: n64e10bk **+17.2%**, n128e10bk **−19.8%** PASS.
- Training: **n64-ft1 done** (best val 0.009853 @ ep10). No other train running. **data40m** filter still running (pid 3325908, nice 19, max-load 4): ~81M lines scanned / **~37.3M kept** of 40M cap (~93%); outdir `data40m/` not finalized yet (writes at end). Load ~3.3–4.3.
- No new train started this hour (filter owns the load budget). No board/move/tt touched. No fastchess.
- Gate checklist:
  - **n64e10bk-v6-1735**: perft✓ acc✓ bug_gate✓ Profiler +17.2%✓ CR✓ → QA fuzz+TL (box) then [0,10] PC vs 1.7.35 — already in QUEUE 17:41/17:42.
  - **n128e10bk-v6-1735**: same JS/CR; Profiler −19.8%✓ → QA after n64 (14 PC pairs first).
  - **n64ft1bk-v6-1735**: perft✓ acc✓ bug_gate✓ Profiler −0.3%✓ same CR patch → ready to queue after n64e10bk (or parallel policy per QA).
- Patch: `nnue-768-v6bk_on1735_js.patch` md5 **562227b7**. No separate ft1 patch (net-only swap on same JS).
- Needed from crew: Engine QA to run queued n64e10bk-v6-1735 fuzz+TL; then n128; optionally queue n64ft1bk. Nothing needed from Couns.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.35 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n64ft1bk-v6-1735 | 2026-10-14 18:57 | Lichess quiet 19.97M, warm-start n64-e10 | 768->64 x2->1 | 10 ep lr 3e-4 | 0.009853 (HCE 0.014259) | −0.3% d10 (prof1735_1817) PASS | not tested | UNPROVEN — dist /workspace/chess-engine-nnue/dist-nnue-n64ft1bk-v6-1735 net 2c5dac9c js-tree 1182327b; verify+CR ready for QA |
| n64e10bk-v6-1735 | 2026-10-14 18:57 | as n64-e10 | 768->64 x2->1 | 10 ep / 1e-3 | 0.009930 | +17.2% d10 (prof1735_box) PASS | not tested | UNPROVEN — CR PASS; QA queued fuzz+TL then [0,10] PC; bench d9 net 232587 / HCE 219984 |
| n128e10bk-v6-1735 | 2026-10-14 18:57 | as n128-e10 | 768->128 x2->1 | 10 ep / 1e-3 | 0.009391 | −19.8% d10 (prof1735_box) PASS | not tested | UNPROVEN — CR PASS (same patch); QA after n64; bench d9 net 199461 |

## 2026-10-14 ~19:20 PT — v6 overlays rebased on lock 1.7.36 (badcap, js 274bbb1d) — all UNPROVEN
- Lock `/workspace/chess-engine/baseline/dist-v1.7.36` (untouched), HCE bench d9 **286362**. Only search.js differs from 1.7.35, so the overlay files are byte-identical to the 1.7.35 rebase.
- Patch `nnue-768-v6bk_on1736_js.patch` md5 **7679e921** (same +/- body as v6bk_on1735 562227b7; only headers differ). Base `dist-nnue-v6bk-1736`. search.js == lock. js-tree **01b94330** (all three builds).
- Verify logs `v6verify/all_{n64e10bk,n64ft1bk,n128e10bk}_1736.log` (script all_1736.sh): perft PASS, HCE bench d9 286362 = lock, acc_check 60g 9533 checks 0 mismatches, nnueinfo main+workers OK, bug_gate nofuzz PASS 0 new.

| id | date (PT) | net md5 | net bench d9 | HCE bench d9 | NPS vs 1.7.36 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|
| n64e10bk-v6-1736 | 2026-10-14 19:11 | 3adcd608 | 215696 | 286362 | not measured | not tested | UNPROVEN — gate PASS (KNOWN 6); needs CR, Profiler, QA fuzz+TL then [0,10] |
| n64ft1bk-v6-1736 | 2026-10-14 19:13 | 2c5dac9c | 253621 | 286362 | not measured | not tested | UNPROVEN — gate PASS (KNOWN 5; KBvKB same-colour now passes) |
| n128e10bk-v6-1736 | 2026-10-14 19:18 | b23e44a7 | 142209 | 286362 | not measured | not tested | UNPROVEN — gate PASS (KNOWN 6) |

## 2026-10-14 ~19:57 PT — data40m finalized; n64-d40ft training started — all UNPROVEN
- **data40m** filter finished 19:04 PT (17313 s): 86.8M lines scanned, 40.0M kept, 59,670 dupes removed → 39,940,330 final = **39,540,927 train / 399,403 val** (`data40m/train.bin` 1.27 GB, `val.bin`). Quiet only (mate, check, best capture/promo, shallow dropped), signcheck mirror ok. About 2x the 19.97M set used for n64-e10/n128-e10/n64-ft1.
- New val set differs from the old one, so val losses are NOT comparable across data sets; HCE + prior-net val losses on data40m/val measured 20:09–20:20 PT (see section below).
- **n64-d40ft** training started 19:54 PT: 768->64 x2->1, warm start from n64-ft1/net_best.pt, lr 3e-4, 10 ep, patience 2, nice 19, max-load 4, out `nets/n64-d40ft`, log `logs/train_n64-d40ft.log`. Start val on data40m/val **0.009922**.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.36 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n64-d40ft | 2026-10-14 19:54 | data40m 39.54M quiet, warm-start n64-ft1 | 768->64 x2->1 | 10 ep / 3e-4 | start 0.009922 (data40m val) | not built | not tested | UNPROVEN — training |

## 2026-10-14 ~20:20 PT — data40m HCE + prior-net val losses (UNPROVEN)
- Measured with `nice -n 19`, `TZ=America/Los_Angeles`. Did not kill or restart `n64-d40ft` (trainer still running).
- **HCE** on `data40m/val.bin` (399,403 positions) via `hce/hce_valloss.py` + lock **1.7.36** (`/workspace/chess-engine/baseline/dist-v1.7.36`, UseNNUE off):
  - raw **0.014216**, best cp scale **k=1.0** → **0.014216**, corr **0.5594**
  - JSON: `hce/hce_valloss_data40m.json` (also mirrored to `hce/hce_valloss.json`). Prior data/ result kept as `hce/hce_valloss_data.json` (raw 0.014273, k=0.95 → 0.014259 on 199,719).
- **Prior nets** scored on the same data40m val with `eval_checkpoint.py` (same Net + MSE(sigmoid) loss as `train.py`):

| id | checkpoint | data40m val loss | prior data/ val (for ref only) |
|---|---|---|---|
| HCE (1.7.36) | — | **0.014216** (k=1.0) | 0.014259 (k=0.95) |
| n64-e10 | nets/n64-e10/net.pt | **0.009996** | 0.009930 |
| n64-ft1 | nets/n64-ft1/net_best.pt | **0.009922** | 0.009853 |
| n128-e10 | nets/n128-e10/net_best.pt | **0.009488** | 0.009391 |
| n64-d40ft (start) | warm-start from n64-ft1 | **0.009922** | n/a |

- Sanity: n64-ft1 on data40m val equals n64-d40ft epoch-0 start val (0.009922). All three prior nets still beat HCE on data40m (~30%+ lower). Summary JSON: `logs/valloss_data40m_summary.json`.
- n64-d40ft training continues (as of measure: best val improving past start). No message sent to crew.

## 2026-10-14 ~20:57 PT status (Engine NNUE routine) — all UNPROVEN
- Lock **1.7.36** (`/workspace/chess-engine/baseline/dist-v1.7.36`, js 274bbb1d, HCE bench d9 **286362**). Never edited. Frozen *-v6-1734/*-v6-1735 untouched.
- Progress since ~19:57:
  - **n64-d40ft DONE** 20:50: 10/10 ep, best val **0.009779** @ ep10 (start 0.009922; HCE data40m **0.014216**). Packed net.nnue md5 **157e6b16**. Built `dist-nnue-n64d40ftbk-v6-1736` (cp of n64e10bk-v6-1736 + new net); js-tree **01b94330**; search.js == lock. Net bench d9 **194011**. Verify `v6verify/all_n64d40ftbk_1736.log` **PASS** 20:57:42 (perft/acc/bug_gate nofuzz; new failures 0, KNOWN 6).
  - **n128-d40ft** training started 20:57: warm start n128-e10, data40m, H128, lr 3e-4, start val **0.009488**, nice 19, max-load 4, log `logs/train_n128-d40ft.log`.
  - data40m HCE + prior-net val losses already recorded (HCE 0.014216; n64-e10 0.009996; n64-ft1 0.009922; n128-e10 0.009488).
- Still gate-blocked vs 1.7.36 (same as last hour): n64e10bk / n64ft1bk / n128e10bk *-v6-1736 have perft/acc/bug_gate PASS but need **CR** on `nnue-768-v6bk_on1736_js.patch` md5 **7679e921**, **Profiler** NPS T1 H16 vs 1.7.36, then **QA** fuzz/TL/[0,10] (queue still named *-1735 — rebase to *-1736).
- No board/move/tt touched. No fastchess.
- Needed: Code Review confirm 1736 patch; Agent Profiler NPS on the three *-v6-1736 (and n64d40ft after verify); Engine QA retarget queue to *-1736. Nothing needed from Couns.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.36 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n64-d40ft / n64d40ftbk-v6-1736 | 2026-10-14 20:50 | data40m 39.54M quiet, warm-start n64-ft1 | 768->64 x2->1 | 10 ep / 3e-4 | **0.009779** (HCE 0.014216) | not measured | not tested | UNPROVEN — verify PASS; net 157e6b16; dist `/workspace/chess-engine-nnue/dist-nnue-n64d40ftbk-v6-1736`; bench d9 net 194011 / HCE 286362; js-tree 01b94330 |
| n128-d40ft | 2026-10-14 20:57 | data40m, warm-start n128-e10 | 768->128 x2->1 | 10 ep / 3e-4 | start 0.009488 | not built | not tested | UNPROVEN — training |
| n64e10bk-v6-1736 | 2026-10-14 19:11 | as n64-e10 | 768->64 x2->1 | 10 ep / 1e-3 | 0.009930 | not measured | not tested | UNPROVEN — perft/acc/bug_gate PASS; needs CR+Profiler+QA vs 1.7.36 |
| n64ft1bk-v6-1736 | 2026-10-14 19:13 | as n64-ft1 | 768->64 x2->1 | 10 ep / 3e-4 | 0.009853 | not measured | not tested | UNPROVEN — same gate |
| n128e10bk-v6-1736 | 2026-10-14 19:18 | as n128-e10 | 768->128 x2->1 | 10 ep / 1e-3 | 0.009391 | not measured | not tested | UNPROVEN — same gate |

## 2026-10-14 ~21:55 PT status (Engine NNUE routine) — all UNPROVEN
- Lock **1.7.36** (dist-v1.7.36) unchanged, never edited. Push ends ~00:05 PT Thu Oct 15.
- Gate pipeline unblocked since ~21:00: CR passed patch 7679e921 for all four *-v6-1736; Profiler: 1.7.35 NPS results carry over (no re-time).
- QA running **n64d40ftbk-v6-1736** (net 157e6b16): PC pcA fuzz PASS, TL 200 g 0 bad/0 TL, **[0,10] 10+0.1 H64 vs 1.7.36 started 21:35 PT** (in progress). Box duplicate gate: fuzz 20 g 0 illegal/crash; TL 200 g in progress.
- **n128-d40ft** training: ep8/10 best val **0.009269** (start 0.009488; HCE 0.014216), nice 19, max-load 4. Build/verify dist-nnue-n128d40ftbk-v6-1736 when done.
- No board/move/tt touched. No fastchess run by NNUE.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.36 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n128-d40ft | 2026-10-14 21:55 | data40m, warm-start n128-e10 | 768->128 x2->1 | ep8/10 / 3e-4 | 0.009269 (best so far) | not built | not tested | UNPROVEN — training |
| n64d40ftbk-v6-1736 | 2026-10-14 21:55 | data40m | 768->64 x2->1 | 10 ep / 3e-4 | 0.009779 | not re-timed (1.7.35 n64 results carry over per Profiler) | [0,10] PC in progress | UNPROVEN — QA fuzz/TL PASS |

## 2026-10-14 22:08 PT n64d40ftbk-v6-1736 SPRT RESULT (reported by Engine Strategist; QA verdict)
[0,10] 10+0.1 vs lock 1.7.36 on grok-pc pcA: H1 ACCEPTED 21:58:46 PT, 200 games, Elo +235.45 +/-54.35, LLR 2.95, 0 TL. Net md5 157e6b16, js-tree 01b94330. Still UNPROVEN beyond this one SPRT; no classical lock is cut from it.

## 2026-10-14 ~22:50 PT status (Engine NNUE routine) — all UNPROVEN
- Lock **1.7.36** (`/workspace/chess-engine/baseline/dist-v1.7.36`) unchanged; NNUE never edits baseline. `dist-v1.7.37` = NNUE overlay only (same net as n64d40ftbk). Push ends ~00:05 PT Thu Oct 15.
- Progress since ~21:55: **n128-d40ft DONE** 22:02 (10/10 ep, best val **0.009262** @ ep10; start 0.009488; HCE data40m **0.014216**). Packed net.nnue md5 **14656706**. Built `dist-nnue-n128d40ftbk-v6-1736` (cp of n128e10bk-v6-1736 + new net); js-tree **01b94330**; search.js == lock. Verify `v6verify/all_n128d40ftbk_1736.log` **PASS** 22:54:06 (HCE bench d9 286362=lock, net bench **169395**, acc 60g 9533 checks 0 mismatches, bug_gate 0 new/KNOWN 6, nnueinfo path OK).
- **n64d40ftbk-v6-1736** SPRT: H1 ACCEPTED 21:58 PT, 200 g, Elo **+235.45 ±54.35**, LLR 2.95, 0 TL vs 1.7.36 (net 157e6b16). Still UNPROVEN beyond that one SPRT; no classical lock cut from it.
- Gate-ready queue (CR 7679e921, Profiler carry-over): n64e10bk → n128e10bk → n64ft1bk *-v6-1736, then n128d40ftbk after verify. Asking QA for next PC slot.
- No board/move/tt touched. No fastchess. Training idle (n128-d40ft finished).

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.36 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n128-d40ft / n128d40ftbk-v6-1736 | 2026-10-14 22:02 | data40m 39.54M quiet, warm-start n128-e10 | 768->128 x2->1 | 10 ep / 3e-4 | **0.009262** (HCE 0.014216) | carry-over n128e10bk −19.8% (≤25% PASS) | not tested | UNPROVEN — verify **PASS** 22:54 (perft/acc 0 mism/bug_gate 0 new); bench d9 net **169395** / HCE 286362; net 14656706; js-tree 01b94330; ready for QA after n64e10/n128e10/n64ft1 |
| n64d40ftbk-v6-1736 | 2026-10-14 21:58 | data40m | 768->64 x2->1 | 10 ep / 3e-4 | 0.009779 | carry-over PASS | **H1 +235.45±54.35 @200g** | UNPROVEN — SPRT H1 vs 1.7.36; not classical lock |
| n64e10bk-v6-1736 | 2026-10-14 19:11 | as n64-e10 | 768->64 x2->1 | 10 ep / 1e-3 | 0.009930 | carry-over +17.2% PASS | not tested | UNPROVEN — CR+Profiler ready; next QA after d40ftbk |
| n64ft1bk-v6-1736 | 2026-10-14 19:13 | as n64-ft1 | 768->64 x2->1 | 10 ep / 3e-4 | 0.009853 | carry-over −0.3% PASS | not tested | UNPROVEN — same gate |
| n128e10bk-v6-1736 | 2026-10-14 19:18 | as n128-e10 | 768->128 x2->1 | 10 ep / 1e-3 | 0.009391 | carry-over −19.8% PASS | not tested | UNPROVEN — same gate |

## 2026-10-14 ~23:57 PT status (Engine NNUE routine) — all UNPROVEN
- **NEW LOCK 1.7.37 = NNUE n64d40ftbk-v6-1736** (baseline/dist-v1.7.37, net md5 157e6b16, js-tree 01b94330; cut by QA 23:29 PT, approved by Couns). NNUE never edits baseline.
- Since ~22:50: eval-scale check done (evalscale_n64d40ft.md: overall NNUE/HCE scale 1.02, but ~0.6x opening / ~1.25x endgame) and self-play plan written (SELFPLAY_PLAN.md, plan only, generator needs repetition detection first).
- Superseded (worse val than the lock net, same arch/code): n64e10bk-v6-1736 (0.009930), n64ft1bk-v6-1736 (0.009853), n128e10bk-v6-1736 (0.009391 but n128d40ftbk is better). Recommend QA drops them. Only n128d40ftbk remains a candidate (net-only change vs 1.7.37, same js-tree 01b94330).
- **NPS risk:** n128d40ftbk vs the NEW lock (n64 NNUE) is likely ~-30% NPS (carry-over: n64 +17.2%, n128 -19.8%, both vs HCE 1.7.35, ratio ~0.68), which may FAIL the <=25% gate. Needs Agent Profiler re-time vs 1.7.37 at T1 H16 before QA.
- New training: **n64-d40ft2** started 23:55 PT (warm start n64-d40ft, data40m, lr 1e-4, 10 ep, patience 2, nice 19, max-load 4; start val 0.009779). Net-only candidate vs lock if val improves.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.37 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n64-d40ft2 | 2026-10-14 23:55 | data40m, warm-start n64-d40ft | 768->64 x2->1 | 10 ep / 1e-4 (patience 2) | start 0.009779 | n/a (same arch as lock) | not tested | UNPROVEN — training |
| n128d40ftbk-v6-1736 | 2026-10-14 22:02 | data40m | 768->128 x2->1 | 10 ep / 3e-4 | 0.009262 | est. ~-30% (needs Profiler) | not tested | UNPROVEN — QA next-push pcC #1 vs 1.7.37 pending NPS gate |
| n64e10bk / n64ft1bk / n128e10bk -v6-1736 | — | — | — | — | — | — | — | UNPROVEN — SUPERSEDED by lock net, recommend drop |

## 2026-10-15 ~00:55 PT status (Engine NNUE routine) — all UNPROVEN
- Lock **1.7.37** (NNUE n64d40ftbk, baseline/dist-v1.7.37, net 157e6b16) unchanged. 12 h push on 1.7.37 running to ~12:30 PT (QA 00:40). NNUE never edits baseline.
- n64d40ftbk lock confirmed by QA PC 1000 g T1 H64 sanity vs 1.7.36: +195.51 ±22.41, 0 TL/crash (ended 00:07).
- **n128d40ftbk-v6-1736** (net 14656706): Profiler d10 vs 1.7.37, 9 rounds, median **−16.1%** NPS (worst −27.5%, 1/9 rounds) → **PASS** ≤25% (box, info). QA has it on PC pcC: fuzz+TL then [0,10] 10+0.1 vs 1.7.37 (net-only diff confirmed by Deep Research). My earlier ~−30% estimate was too pessimistic.
- **n64-d40ft2** training: ep6/10 best val **0.009762** (start 0.009779, −0.17%; tiny). Will build a net-only candidate only if the final gain is meaningful.
- Queued **n128-d40ft2** (warm n128-d40ft, lr 1e-4, 10 ep, patience 2, nice 19, max-load 4) to start when n64-d40ft2 ends (follow_n128d40ft2.sh).
- No board/move/tt touched. No fastchess.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.37 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n64-d40ft2 | 2026-10-14 23:55 | data40m, warm n64-d40ft | 768->64 x2->1 | 10 ep / 1e-4 | ep6 best 0.009762 (start 0.009779) | same arch | not tested | UNPROVEN — training |
| n128d40ftbk-v6-1736 | 2026-10-14 22:02 | data40m | 768->128 x2->1 | 10 ep / 3e-4 | 0.009262 | **−16.1% median PASS** (Profiler 00:34) | testing pcC [0,10] | UNPROVEN — in QA |
| n128-d40ft2 | queued | data40m, warm n128-d40ft | 768->128 x2->1 | 10 ep / 1e-4 | — | — | — | UNPROVEN — queued |

## 2026-10-15 ~01:55 PT status (Engine NNUE routine) — all UNPROVEN
- Lock **1.7.37** (NNUE n64d40ftbk, baseline/dist-v1.7.37, net 157e6b16) unchanged. 12 h push to ~12:30 PT. NNUE never edits baseline.
- **n128d40ftbk-v6-1736 REJECTED by QA at the fuzz gate** (PC pcC, 00:43:46 PT: coder-fuzz "Crashed: 1", 2 matching lines; no TL/SPRT run). Same js-tree as the lock (01b94330), only net.nnue differs, so the H128 path or this net is the suspect. Box repro without games: 300-position single-process UCI sweep at depth 7 (crashrepro/sweep.py) = 0 crashes, 0 illegal moves. A game-based repro vs SF was blocked by Auto-review (my rules: no match play from NNUE). Need QA's PC crash lines/PGN to find the cause. Not cleared.
- **n64-d40ft2 DONE** ~01:11 PT: 10/10 ep, best val **0.009757** (ep10) vs start 0.009779 = −0.23%, under the Strategist's 0.5% bar (<0.009730) → **no build, no PC test**.
- **n128-d40ft2** training since 01:12 PT (warm n128-d40ft, lr 1e-4): ep5 val **0.009233** (start 0.009262, −0.31%). Won't be built until the n128 fuzz crash is understood.
- **Output buckets (Strategist next one-variable test):** new trainer `train_ob.py` (copy of train.py + `--obuckets 8`, bucket = min(7,(pieces−2)//4), warm start copies the single output into all buckets, so start val = lock net exactly 0.009779). Smoke test OK; export out_w = 8×2H int16, out_b = 8 int32. **n64-ob8** queued (follow_n64ob8.sh, warm n64-d40ft, lr 3e-4, 10 ep, patience 2, nice 19, max-load 4) to start when n128-d40ft2 ends. Engine side (nnue.js reads 8 output rows + picks bucket by piece count) not written yet; needs CR + Profiler + bug_gate before QA.
- No board/move/tt touched. No fastchess.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.37 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n64-d40ft2 | 2026-10-15 01:11 | data40m, warm n64-d40ft | 768->64 x2->1 | 10 ep / 1e-4 | 0.009757 (start 0.009779, −0.23%) | same arch | not tested | UNPROVEN — gain below 0.5% bar, not built |
| n128d40ftbk-v6-1736 | 2026-10-14 22:02 | data40m | 768->128 x2->1 | 10 ep / 3e-4 | 0.009262 | −16.1% median PASS | — | UNPROVEN — **REJECTED QA fuzz (1 crash, PC 00:43)**; box sweep 300 pos clean; cause unknown |
| n128-d40ft2 | 2026-10-15 01:12 | data40m, warm n128-d40ft | 768->128 x2->1 | 10 ep / 1e-4 | ep5 0.009233 | — | — | UNPROVEN — training; held behind n128 crash |
| n64-ob8 | queued | data40m, warm n64-d40ft | 768->64 x2->8 buckets | 10 ep / 3e-4 | start 0.009779 | — | — | UNPROVEN — queued after n128-d40ft2 |

## 2026-10-15 02:08 PDT n128d40ftbk-v6-1736 fuzz-crash investigation (UNPROVEN)
- Build base verified: js-tree 01b94330 == lock 1.7.37; only net.nnue differs (14656706 vs 157e6b16).
- Box replay (node v20.19.2, heap limit 4144 MB, nice 19): plies 71-81 incl. post-Rc5 (ply 81), movetime 100 / depth 13 / depth 16, Hash 64/T1, 16/T1, 256/T2; lock 1.7.37 same positions; 7 full-game single-process replays at 7s+0.08. 0 crashes, 0 stderr, rc 0. NOT reproduced. Post-Rc5 n128 plays f7e6 (+732..+758), lock f7e6 (+677..+701).
- Engine has no uncaughtException handler, so a JS throw would print to stderr; fastchess log does not capture engine stderr, so "no stderr" is not evidence. Root-cause guess: PC environment (orphan node procs / Windows-side kill), not net or code. Logs: crash_n128/.

## 2026-10-15 ~02:56 PT status (Engine NNUE routine) — all UNPROVEN
- Lock **1.7.37** (NNUE n64d40ftbk, baseline/dist-v1.7.37, net 157e6b16, js-tree 01b94330) unchanged. 12 h push to ~12:30 PT. NNUE never edits baseline.
- Progress since ~01:55/02:08: **n128-d40ft2** still training (pid 779, nice 19, max-load 4; load ~4.0). Through ep8/10: best val **0.009225** (start 0.009262, −0.40%). Ep7–8 slowed (1387s / 2577s) under load. **follow_n64ob8.sh** waiting on 779.
- **n64-d40ft2** still not built (−0.23% < 0.5% bar). **n128d40ftbk-v6-1736** still REJECTED at PC fuzz; box crash replay 0 crashes (NETS 02:08); QA logs at `research/n128_fuzz_crash/`.
- Next when n128-d40ft2 ends: pack → box fuzz with logs → ask QA for first free PC slot; then ob8 engine side in nnue.js (train_ob.py ready); SCReLU after. Forge tools staged under `forge_datagen_pkg/` (evaluate on box; nothing on grok-pc without Couns 1:1).
- No board/move/tt touched. No fastchess.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.37 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n128-d40ft2 | 2026-10-15 01:12 | data40m, warm n128-d40ft | 768->128 x2->1 | ep8/10 / 1e-4 | **0.009225** best (start 0.009262) | — | — | UNPROVEN — training |
| n128d40ftbk-v6-1736 | 2026-10-14 22:02 | data40m | 768->128 x2->1 | 10 ep / 3e-4 | 0.009262 | −16.1% median PASS | — | UNPROVEN — **REJECTED QA fuzz**; box not reproduced |
| n64-d40ft2 | 2026-10-15 01:11 | data40m, warm n64-d40ft | 768->64 x2->1 | 10 ep / 1e-4 | 0.009757 (−0.23%) | same arch | not tested | UNPROVEN — below 0.5% bar, not built |
| n64-ob8 | queued | data40m, warm n64-d40ft | 768->64 x2->8 buckets | 10 ep / 3e-4 | start 0.009779 | — | — | UNPROVEN — follow_n64ob8 after n128-d40ft2; engine side not written |

## 2026-10-15 ~03:57 PT status (Engine NNUE routine) — all UNPROVEN
- Lock is now **1.7.38** (baseline/dist-v1.7.38, magicflat3 speedup, same net 157e6b16, js-tree 1ec7deec). NNUE never edits baseline.
- **n128-d40ft2 DONE** 03:39 PT: 10/10 ep, best val **0.009223** (ep10; start 0.009262, −0.42%; lock net n64 0.009779; HCE 0.014216).
- Packed net-only on the 1.7.38 tree: `/workspace/chess-engine-nnue/dist-nnue-n128d40ft2-v6-1738` (cp -rp of lock, only net.nnue replaced; net md5 d1679b6b, js-tree 1ec7deec == lock, search.js == lock). Verify (bench, uci, acc, bug_gate nofuzz with net) running via v6verify/all_1738.sh → v6verify/all_n128d40ft2_1738.log, waiting for load < 4.
- **n64-ob8** training started 03:39 PT (train_ob.py, warm n64-d40ft, lr 3e-4, 10 ep, patience 2, nice 19, max-load 4); start val 0.009779. Engine side (8 output rows in nnue.js) not written yet.
- n128d40ftbk-v6-1736 still REJECTED (PC fuzz, 1 crash, box not reproduced). No board/move/tt touched. No fastchess.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.38 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n128-d40ft2 (dist-nnue-n128d40ft2-v6-1738) | 2026-10-15 03:39 | data40m, warm n128-d40ft | 768->128 x2->1 | 10 ep / 1e-4 | **0.009223** (start 0.009262) | not yet re-timed (same arch as n128d40ftbk −16.1% vs 1.7.37) | not tested | UNPROVEN — verify running; then Profiler + QA box fuzz/PC |
| n64-ob8 | 2026-10-15 03:39 | data40m, warm n64-d40ft | 768->64 x2->8 buckets | 10 ep / 3e-4 | start 0.009779 | — | — | UNPROVEN — training |

## 2026-10-15 ~04:50 PT status (Engine NNUE routine) — all UNPROVEN
- Lock **1.7.38** (baseline/dist-v1.7.38, net md5 157e6b16). No dist-v1.7.39 yet. NNUE never edits baseline.
- **n128-d40ft2** verify **PASS** 03:57 (ALLDONE): perft OK, acc 60g 0 mismatches, bug_gate PASS PARTIAL (fuzz skipped, 0 new). Dist `/workspace/chess-engine-nnue/dist-nnue-n128d40ft2-v6-1738`, net md5 **d1679b6b**, js-tree == lock, search.js == lock. Bench d9: net **193301** / lock 194011 / HCE 286362. Next: Agent Profiler re-time vs 1.7.38 (T1 H16), then QA box fuzz → PC. If orderfast becomes 1.7.39 first, repack net-only on that js-tree.
- **n64-ob8** training (train_ob.py, warm n64-d40ft, lr 3e-4, 10 ep, patience 2, nice 19, max-load 4): ep1 best val **0.009741** (start 0.009779). Engine-side 8-bucket load in nnue.js WIP this hour (executor).
- n128d40ftbk still the prior PC-fuzz reject (box unreproduced); Strategist noted a later n128-1738 re-fuzz/TL clean with SPRT harness stuck — not this net-only dist.
- No board/move/tt touched. No fastchess.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.38 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n128-d40ft2 (dist-nnue-n128d40ft2-v6-1738) | 2026-10-15 03:39 | data40m, warm n128-d40ft | 768->128 x2->1 | 10 ep / 1e-4 | **0.009223** | pending Profiler | not tested | UNPROVEN — verify PASS 03:57; net d1679b6b |
| n64-ob8 | 2026-10-15 03:39 | data40m, warm n64-d40ft | 768->64 x2->8 buckets | ep1/10 / 3e-4 | **0.009741** (start 0.009779) | — | — | UNPROVEN — training; engine side WIP |
| n64-d40ft2 | 2026-10-15 01:11 | data40m | 768->64 x2->1 | 10 ep / 1e-4 | 0.009757 (−0.23%) | — | — | UNPROVEN — below 0.5% bar, not built |
| n128d40ftbk-v6-1736 | 2026-10-14 22:02 | data40m | 768->128 x2->1 | 10 ep / 3e-4 | 0.009262 | −16.1% vs 1.7.37 | — | UNPROVEN — prior PC fuzz reject |

## Forge / published data conversion — UNPROVEN (data only, no training started)
- convert_forge.py (+ filter_lichess_rec.py encoder): Forge PGN fastchess comments ({±x.xx/depth}, mover POV, labels pre-move position; played move used for quiet filter) and forge_selfplay `FEN | score(STM) | result(White)` -> 32-byte REC, White-POV cp, data40m filters (no check, <=30 pcs, move not capture/promo, no mate, clip 3000), dedup, 1% val. No WDL stored (REC has no result field; rsv bytes free).
- Selfplay sample (examples/forge_sample.txt, 916 lines): 835 kept, signcheck corr 0.916 mirror ok (/tmp/fs_test).
- forge_pgns (28 PGNs, ~22k games, depths mostly 8-10 in SPRT games, i.e. much shallower than data40m d>=20): running -> data_forgepgn/ (min-depth 8), log logs/convert_forgepgn.log, nice 19, single thread (box has only CPUs 0-7, so taskset 12-15 is impossible).
- Published SF/Leela: raw_ext/head1G.test80-2023-11-nov-2tb7p.min-v2.v6.binpack.zst = first 1 GiB (HTTP range) of linrock/test80-2023 on Hugging Face. NOT converted: no C++ compiler on box to build Sopel97/nnue_data_compress decoder; apt install of g++/make blocked by Auto-review then interrupted. No pure-Python binpack decoder written.

## grok-pc GPU setup (05:2x-05:31 PT Thu) — UNPROVEN
- PC "FoxOS" (Win 11 26200, RX 7900 XT, 16 logical CPUs, ~42 GB free C:). Folder C:\Users\Administrator\grok-pc\nnue\ ; STOP file C:\Users\Administrator\grok-pc\nnue\STOP_nnue (exists => pause; contains "exit" => quit).
- Python 3.10.22 via uv (local to folder), .venv with torch 2.4.1 + torch-directml 0.2.5.dev240914; forge pkg tests 11/12 pass (1 fail = no C++ compiler on PATH).
- train_gpu.py = DirectML port of train.py (same features/loss/clamps/int16 export). Warm-start n128-d40ft2 val on PC = 0.009223 (box 0.009223) => forward matches. Launcher run_train.cmd = start /low /affinity F000.
- Not running: data40m copy to PC interrupted by user; no long training or self-play started. forge.exe (6.2 v3) staged in folder.

## Data set: data_bt4fp32 (2026-10-15 ~05:45 PT) — UNPROVEN
- Source: HF `vondele/master-binpacks_relabel` file `fishpack32.relabel-BT4-tf13tune.binpack` (SF master-binpacks relabelled by Leela BT4; SF19-era data type). Streamed (first ~155M positions of 5.86 GB), raw not stored. **License UNVERIFIED** (no dataset card; source sets ODbL).
- Converter: `/workspace/chess-tools/raw_ext/sfconv/conv` (C++, built from nnue_data_compress reader; g++/make installed 05:35 PT with Couns approval). Validated: 0 invalid/in-check boards, byte-identical re-encode vs filter_lichess_rec.encode_board, mirror ok.
- Filters: ply<8, mates (|s|>=30000), |cp|>3000, in-check, next move capture/promo/ep, dedupe by position (64-bit hash). Score White POV cp, no rescale.
- rsv[0]=game result White POV (0 loss/1 draw/2 win), rsv[1]=min(ply,255), rsv[2]=1 source tag. Ready for WDL blending.
- Counts: seen 154,555,381 → train 100,000,000 (md5 92d7a7ed5098ec9496c9bd65178cb71c), SF held-out val 94,575 (md5 023534a0e684da47f5844b28e5702fde, by game). Stats `data_bt4fp32/stats.json`.
- Eval scale: sigmoid(cp/k) fit to results → k=265 (BT4) vs k=275 on SF-search test80 sample: BT4 labels ≈ SF cp scale (factor ~1.04), so no rescale proposed for scale 400.
- signcheck corr_white_material=0.082 (fails 0.1 guard) because positions are nearly material-balanced; mirror ok and corr(score,result)=0.586 confirm White POV. Treat as known exception, not a sign bug.
- Shared val: `val_shared/val.bin` built by `build_shared_val.py` (data40m val + ≤100k Forge val) automatically once Forge conversion (PID 284758) finishes. FIXED once written.

## 2026-10-15 ~05:51 PT status (Engine NNUE routine) — all UNPROVEN
- Lock **1.7.38** (baseline/dist-v1.7.38, net md5 157e6b16, H64). No 1.7.39. NNUE never edits baseline. Box load ~4.0–4.1 (QA classical slots busy); NNUE trainer auto-paused at max-load 4.
- Progress since ~04:50: **data_bt4fp32** ready (100M train md5 92d7a7ed from HF fishpack32 BT4 relabel, streamed first ~155M; SF val 94,575; k_fit≈265; licence UNVERIFIED). Forge PGN convert still running (nice 19, → data_forgepgn/); shared val builds automatically after. **n64-ob8** through ep3 best val **0.009686** (start 0.009779, −0.95%); ep4+ paused on load. Engine-side 8-bucket nnue.js still not written.
- **n128-d40ft2** still verify PASS (dist-nnue-n128d40ft2-v6-1738, net d1679b6b, bench d9 193301); still needs Agent Profiler vs 1.7.38 then QA box fuzz → PC. grok-pc GPU slot idle pending data copy / STOP check (this run).
- Next: Profiler on n128d40ft2; finish forge→val_shared; resume n64-ob8 when load <4; write ob8 engine loader; then n128 on data40m+BT4 mix (Strategist GPU order) when PC ready. No board/move/tt. No fastchess.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.38 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n128-d40ft2 (dist-nnue-n128d40ft2-v6-1738) | 2026-10-15 03:39 | data40m | 768->128 x2->1 | 10 ep / 1e-4 | **0.009223** | pending Profiler | not tested | UNPROVEN — verify PASS; net d1679b6b |
| n64-ob8 | 2026-10-15 03:39 | data40m | 768->64 x2->8 buckets | ep3/10 / 3e-4 | **0.009686** best (−0.95%) | — | — | UNPROVEN — training; paused load≥4; engine side not written |
| data_bt4fp32 | 2026-10-15 05:45 | fishpack32 BT4 relabel | — | — | — | — | — | UNPROVEN — 100M train ready; licence UNVERIFIED |
| n128d40ftbk-v6-1736 | 2026-10-14 22:02 | data40m | 768->128 x2->1 | 10 ep / 3e-4 | 0.009262 | −16.1% vs 1.7.37 | — | UNPROVEN — prior PC fuzz reject |

### PC live @ ~05:53 PT (same hour) — UNPROVEN
- grok-pc `nnue\`: no STOP_nnue; data40m present; ~41 GB free.
- **n128-d40g1** GPU train (train_gpu.py DirectML, warm init\n128-d40ft2.pt, affinity F000 /low): ep1 val **0.009252** (start 0.009223), ~270k pos/s; ep2 running. log `logs\n128-d40g1.log`.
- Forge selfplay concurrent on CPUs 12–15 (2 workers, 5000 nodes/move): ~1.5M pos/h after ~2 min. log `logs\selfplay.log`.
- QA notified via hourly status (jobs already running when routine sampled).


## grok-pc GPU + datagen RUNNING (from ~05:50 PT Thu) — all UNPROVEN
- Folder C:\Users\Administrator\grok-pc\nnue\ ; STOP file C:\Users\Administrator\grok-pc\nnue\STOP_nnue (trainer: pause while present, quit if it contains "exit"; self-play guard: exits self-play when present). All procs Idle, affinity F000 (CPUs 12-15), trainer 2 torch threads + 2 Forge workers.
- Data on PC verified: data40m/train.bin md5 9566b3a0...b5 (39.5M), bt4/train.bin md5 92d7a7ed...1c (100M), bt4/val.bin md5 023534a0...02fde.
- Pipeline check: PC export of n128-d40ft2 warm start is byte-identical to box files; a GPU-trained net.pt -> export -> pack_trainer_net.js loads in nnue.js, acc_check 60 games 9533 checks 0 mismatches, int-sim eval == nnue.js on 5 FENs exactly (float vs int differs ~2-26cp = existing QB=64 quantization, same as box nets).
- GPU throughput: ~265-310k pos/s (n128, bs 8192, with self-play running); data40m epoch ~130-145 s vs box 285-2577 s.
- n128-d40g1 (data40m only, lr 3e-4, warm n128-d40ft2): early-stopped, no gain (ep1 0.009252, ep2 0.009237 vs start 0.009223). Not a candidate.
- RUNNING n128-mixbt4: data40m + BT4 (data-only change), warm n128-d40ft2, lr 3e-4, 10 ep, patience 2; ~17k batches/epoch (~8 min). Log logs\n128-mixbt4.log; out nets\n128-mixbt4\ (copy back, pack on box). Val reported on data40m val (+ bt4 val as val_other); switch to val_shared when it exists.
- RUNNING Forge 6.2 self-play: selfplay_guard.py -> forge_selfplay.py, 2 workers, 5000 nodes, out selfplay_out\ (FEN|score|result), ~1.4-1.8M pos/h; log logs\selfplay.log.

## 2026-10-15 06:12 PT — grok-pc NNUE data moved C: → D: (UNPROVEN, ops only)
- Couns approved D:\grok-pc-data for NNUE data (06:05 PT, via QA). STOP_nnue (empty → 'exit') paused/stopped both jobs 06:07–06:11 PT.
- Moved to D:\grok-pc-data\{data40m,bt4,selfplay_out}; md5 OK: data40m/train 9566b3a0…, bt4/train 92d7a7ed…, bt4/val 023534a0…, data40m/val a0757c0b… (src=dst); selfplay files identical. C: copies deleted; C: free 39.8 GB.
- n128-mixbt4 had no finished epoch (stopped ep1 batch ~7000/17033), so restarted from init\n128-d40ft2.pt with --data D:\grok-pc-data\data40m,D:\grok-pc-data\bt4 (old log → logs\n128-mixbt4.run1-stopped.log). selfplay_guard.py --out → D:\grok-pc-data\selfplay_out. All Idle, affinity F000.

## 2026-10-15 ~06:53–07:00 PT — lock 1.7.39; n64-ob8 done; PC failures; BT4 scale finding — all UNPROVEN
- **Lock is GrokChess 1.7.39** = baseline/dist-v1.7.39 (orderfast), js-tree **b1db953ca05316e8272b5842ef6c4b71**, net md5 **157e6b16**e87c923a699429702af0c334 (prior 1.7.38 js-tree 1ec7deec…). Lock bench d9 194011 (same as 1.7.38). NETS columns "vs lock" now mean vs 1.7.39.
- **n128-d40ft2 net-only repack on 1.7.39**: `/workspace/chess-engine-nnue/dist-nnue-n128d40ft2-v6-1739` = cp -rp dist-v1.7.39 + net.nnue from dist-nnue-n128d40ft2-v6-1738. js-tree b1db953c == lock, net d1679b6b, only net.nnue differs. Verify (`v6verify/all_1739.sh`, log `v6verify/all_n128d40ft2_1739.log`): bench d9 net 193301 (HCE 286362, lock 194011), uci smoke OK (2 threads load net), acc_check 60 g 9533 checks 0 mismatches, bug gate nofuzz PASS (0 new, KNOWN 6, FIXED 2; fuzz skipped). Needs Profiler vs 1.7.39, then QA fuzz/TL/[0,10].
- **Shared-val (val_shared, 417,974 pos) + per-source val losses** (`eval_multi.py`, `logs/eval_multi_0655.json`, loss @ scale 400):

| net | val_shared | BT4-val (data_bt4fp32) | data40m val | forgepgn val |
|---|---|---|---|---|
| n64-d40ft (lock net 157e6b16 source) | 0.009565 | 0.023771 | 0.009779 | 0.004962 |
| n128-d40ft2 | **0.009031** | 0.023384 | 0.009223 | 0.004915 |
| n64-ob8 | 0.009414 (−1.6% vs lock net) | 0.023665 | 0.009615 | 0.005083 |

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.39 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n64-ob8 / n64ob8bk-v6-1739 | 2026-10-15 03:39→07:15 | data40m | 768->64 x2->8 out buckets (piece count) | 10/10 ep / 3e-4, warm n64-d40ft | **0.009615** data40m (start 0.009779, −1.7%); shared 0.009414 | pending Profiler | not tested | UNPROVEN — packed dist-nnue-n64ob8bk-v6-1739; verify PASS; needs CR+Profiler+QA |
| n128-d40g1 (grok-pc GPU) | 2026-10-15 05:50 | data40m | 768->128 x2->1 | warm n128-d40ft2, 3e-4, early stop ep2 | ep1 0.009252, ep2 0.009237 vs start 0.009223 | — | — | FAIL — no gain, not a candidate |
| n128-mixbt4 (grok-pc GPU) | 2026-10-15 06:11 | data40m + BT4 100M (raw scores) | 768->128 x2->1 | warm n128-d40ft2, 3e-4, early stop ep2 | data40m val ep1 0.011963, ep2 0.012202 (start 0.009223); BT4-val 0.015388 / 0.014972 | — | — | FAIL — val exploded; cause likely BT4 label scale (below) |
| n128-bt4only (grok-pc GPU, parent-launched ~06:54) | 2026-10-15 06:54 | BT4 only (raw scores), --min-corr -1 | 768->128 x2->1 | warm n128-d40ft2, 1e-4, pat 2 | BT4-val start 0.023384 | — | — | UNPROVEN — running; only BT4-val logged (no data40m/shared val) |
| n128-mixbt4s45 (box) | 2026-10-15 06:58→07:18 | data40m 39.54M + 20M BT4 sampled across all 100M, **scores ×0.45**, val = val_shared | 768->128 x2->1 | warm n128-d40ft2, 1e-4, 10 ep, pat 2 | shared-val start **0.009031**; ep1 0.009214; ep2 0.009201 | — | — | FAIL — early stop, no gain vs warm start |

- **BT4 finding (UNPROVEN):** BT4 sign is White POV (corr(result,score) +0.54/+0.55 for both STM; low material corr 0.14–0.16 is because positions are near material-balanced). But the **label scale is ~2–2.5× data40m cp**: least-squares net/label = 0.27 on BT4 vs 0.65 on data40m (median |net|/|label| 0.36 vs 0.72), median BT4 score +237 White POV, results W 41% / D 58% / B 0.5% (UHO-style White-favoured openings). Likely SF internal units, not normalized cp. This most likely caused the n128-mixbt4 failure, and a raw-BT4-only net will learn inflated eval units (risk to pruning margins). Fix: rescale BT4 scores by ~0.4–0.5 (box ablation uses 0.45) or fit per-source scale; also check UHO bias.
- New tooling: `eval_multi.py` (single or K-bucket nets, many val sets). New data: `data_mix_d40bt4s45/` (1.9 GB, stats.json).

## 2026-10-15 ~07:15 PT — n64-ob8 packed as net-only candidate on 1.7.39 — UNPROVEN
- Dist: /workspace/chess-engine-nnue/dist-nnue-n64ob8bk-v6-1739 (copy of lock 1.7.39 + nnue.js v2 loader + net). net.nnue md5 179dbf5f394095ca62b435df79a91090 (GKNN v2, H64, NB8); eval/nnue.js md5 34f745da5db43daa80d741f6c5dce15a; js-tree 310b24ce.
- Format v2: version=2, nb u32 after H, outW int16[NB*2H] bucket-major, outB int32[NB]. bucket=min(NB-1,(pieces-2)/(32/NB)) incl. kings = train_ob.py. Piece count kept per accumulator slot (refresh/applyMove), checked in checkAccumulator. v1 nets load unchanged; packer emits byte-identical v1 for 1-output nets (lock repack = 157e6b16).
- Patch: /workspace/chess-engine-nnue/nnue-768-n64ob8bk_on1739_js.patch (md5 19f22c60), nnue.js + tools/pack_trainer_net.js.
- Verify: perft PASS; acc_check 200 g 31615 checks 0 mismatches; trainer-int vs nnue.js parity 2000 val positions 0 mismatches (all 8 buckets hit); lock net via new nnue.js 2000/2000 and bench 194011 = lock. bench d9 nodes 194107 (lock 194011). bug_gate_nofuzz PASS (KNOWN 6, fuzz left to QA). Log: chess-engine-nnue/v6verify/all_n64ob8bk_1739.log
- Status: UNPROVEN — needs CR review, Profiler NPS (≤25% gate), QA fuzz/TL/SPRT.

## 2026-10-15 ~07:54 PT — hourly keep-going — all UNPROVEN
- Lock still **1.7.39** (baseline/dist-v1.7.39, js-tree b1db953c, net 157e6b16). NNUE never edits baseline.
- **n128-mixbt4s45 FAIL**: early-stopped ep2; best = warm start shared-val **0.009031** (ep1 0.009214, ep2 0.009201). BT4×0.45 mix did not improve.
- **n128-mixforge STARTED** on box (nice 19, max-load 4, PID train.py): data_mix_d40forge = data40m 39.54M + forgepgn 1.84M (41.38M), val=val_shared, warm n128-d40ft2, H128, lr 1e-4, pat 2; start val **0.009031**. Log `logs/train_n128-mixforge.log`.
- Gate-ready still waiting: **dist-nnue-n128d40ft2-v6-1739** (net d1679b6b, verify PASS) and **dist-nnue-n64ob8bk-v6-1739** (net 179dbf5f, verify PASS, nnue.js v2). Need Agent Profiler NPS vs 1.7.39 (≤25%), Code Review on ob8 patch, then QA fuzz/TL/[0,10]. No fastchess from NNUE.
- Next after mixforge: SCReLU (needs engine+trainer change — Coordinated with Coder), or BT4 rescale revisit; PC GPU/selfplay health checked this hour.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.39 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n128-mixbt4s45 | 2026-10-15 06:58→07:18 | data40m+BT4×0.45 | 768->128 x2->1 | warm n128-d40ft2, 1e-4, pat 2 | best 0.009031 (start) | — | — | FAIL — no gain |
| n128-mixforge | 2026-10-15 07:54 | data40m+forgepgn | 768->128 x2->1 | warm n128-d40ft2, 1e-4, pat 2 | start 0.009031 | — | — | UNPROVEN — training |

## 2026-10-15 ~09:05 PT — lock 1.7.40; n128-d40ft2 + n64-ob8 rebases — all UNPROVEN
- **Lock is GrokChess 1.7.40** = `/workspace/chess-engine/baseline/dist-v1.7.40` (matestop-of1738), js-tree **be272ca50b0e6d55bc5a2248caa0901b**, net md5 **157e6b16**e87c923a699429702af0c334. Lock bench d9 **194011**. NNUE never edits baseline. (No `chess-engine-nnue/baseline` symlink; lock lives under chess-engine.)
- **n128-d40ft2 net-only on 1.7.40**: `/workspace/chess-engine-nnue/dist-nnue-n128d40ft2-v6-1740` = lock copy + net.nnue from 1739 (d1679b6b). Only `net.nnue` differs from lock; eval/nnue.js == lock (6b61f3dc). js-tree be272ca5 == lock. Verify (`v6verify/all_1740.sh`, log `v6verify/all_n128d40ft2_1740.log` @ 08:57 PT): perft PASS; acc_check 60g 9533 checks 0 mismatches; bug_gate_nofuzz PASS (KNOWN 6, fuzz skipped); bench d9 net **193301** (HCE 286362, lock 194011). UCI smoke OK.
- **n64-ob8 on 1.7.40**: `/workspace/chess-engine-nnue/dist-nnue-n64ob8bk-v6-1740` = lock + nnue.js v2 (34f745da) + net 179dbf5f (GKNN v2 H64 NB8). Diff vs lock: `eval/nnue.js` + `net.nnue` only. Patch vs 1.7.40: `/workspace/chess-engine-nnue/nnue-768-n64ob8bk_on1740_js.patch` md5 **ea1ba2b7** (nnue.js + tools/pack_trainer_net.js; applies clean -p1). Verify (`v6verify/all_n64ob8bk_1740.log` + `ob8extra_n64ob8bk_1740.log` @ 08:57–08:58 PT): perft PASS; bug_gate_nofuzz PASS; trainer-int vs nnue.js parity 2000/2000 mismatches=0 (all 8 buckets hit); lock net via new nnue.js 2000/2000 + bench 194011 = lock; bench d9 net **194107**.
- **mixforge** (box, nice 19, max-load 4, PID 486763 still running): data_mix_d40forge, warm n128-d40ft2, H128, lr 1e-4, pat 2. Start val **0.009031**; ep5 best **0.0089917** (−0.44% vs start). Epochs 1–5: 0.009028 / 0.009022 / 0.009012 / 0.008995 / 0.008992. ep6+ in flight.
- Gate path: both 1740 dists need Agent Profiler NPS vs 1.7.40 (≤25%), Code Review on ob8 patch ea1ba2b7, then QA fuzz/TL/SPRT. No fastchess from NNUE.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.40 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n128-d40ft2 / n128d40ft2-v6-1740 | 2026-10-15 09:05 | data40m (same net) | 768->128 x2->1 | — | **0.009223** | pending Profiler | not tested | UNPROVEN — dist-nnue-n128d40ft2-v6-1740; net d1679b6b; verify PASS; js-tree be272ca5 |
| n64-ob8 / n64ob8bk-v6-1740 | 2026-10-15 09:05 | data40m (same net) | 768->64 x2->8 buckets | — | **0.009615** | pending Profiler | not tested | UNPROVEN — dist-nnue-n64ob8bk-v6-1740; net 179dbf5f; nnue.js 34f745da; patch ea1ba2b7; verify+parity PASS |
| n128-mixforge | 2026-10-15 07:54→ | data40m+forgepgn | 768->128 x2->1 | warm n128-d40ft2, 1e-4, pat 2 | best **0.0089917** @ep5 (start 0.009031) | — | — | UNPROVEN — training ep6+ |

## 2026-10-15 ~09:53 PT — hourly keep-going — all UNPROVEN
- Lock still **1.7.40** (js-tree be272ca5, net 157e6b16). NNUE never edits baseline.
- **n128-mixforge DONE** (box): 10/10 epochs, no early stop, best ep10 shared-val **0.0089832** (start 0.009031, −0.53%). Epochs 6–10 ended 0.008985 / 0.008985 / 0.008983. Still slowly improving.
- **Packed net-only candidate** `/workspace/chess-engine-nnue/dist-nnue-n128mixforge-v6-1740` = cp -rp lock 1.7.40 + net.nnue md5 **8220b2a2**cebe3a9c4b18eb487e502e0f (H128 NB1). Only net.nnue differs; js-tree be272ca5 == lock; search.js == lock.
- Verify (`v6verify/all_n128mixforge_1740.log`, 09:50–09:51 PT): perft PASS; acc_check 60 g 9533 checks 0 mismatches; bug_gate_nofuzz PASS (mate suite, KvK, KNOWN 6, fuzz left to QA); nnueinfo prints loaded net path; bench d9 net **221171** (lock 194011, HCE 286362). Rough box bench ms net 1573/1345 vs lock 1304/1191 (noisy, not an NPS gate; Profiler must time).
- **n128-mixforge2 STARTED** (box, nice 19, max-load 4): warm mixforge best, lr 5e-5, 10 ep, pat 2, start val 0.008983. Log `logs/train_n128-mixforge2.log`.
- **grok-pc**: Forge self-play had stalled at 08:57 PT (guard parent died; workers orphaned, no CPU, output frozen at 3.13M pos). Killed only the orphaned self-play tree and relaunched selfplay_guard.py (Idle, affinity F000, forge Idle/0xF000) at ~09:52 PT; appending logs\selfplay.log. GPU n128-bt4s45 (BT4×0.45 only) ep9 BT4s45-val 0.005923 (not comparable to shared val), ep10 running. n128-bt4only (raw) finished ep10 val 0.014417 BT4-val. No STOP_nnue; D: ~200 GB free.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.40 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n128-mixforge / n128mixforge-v6-1740 | 2026-10-15 07:54→09:49 | data40m+forgepgn (41.38M) | 768->128 x2->1 | warm n128-d40ft2, 1e-4, 10 ep | best **0.0089832** shared-val (start 0.009031) | pending Profiler | not tested | UNPROVEN — dist-nnue-n128mixforge-v6-1740; net 8220b2a2; verify PASS; needs Profiler+QA (net-only, no code diff for CR) |
| n128-bt4only (grok-pc GPU) | 2026-10-15 06:54→~08:16 | BT4 raw | 768->128 x2->1 | warm n128-d40ft2, 1e-4 | best BT4-val 0.014417 @ep10 | — | — | DONE, not a candidate (raw BT4 scale) |
| n128-mixforge2 | 2026-10-15 09:52→ | data40m+forgepgn | 768->128 x2->1 | warm n128-mixforge, 5e-5, pat 2 | start 0.008983 | — | — | UNPROVEN — training |

## 2026-10-15 ~12:00 PT — hourly keep-going — all UNPROVEN
- **Lock is GrokChess 1.7.41** = `/workspace/chess-engine/baseline/dist-v1.7.41` (nncache, cut 11:36 PT), js-tree **b60447ca**29d04e10000515801970fdc6, net md5 **157e6b16** (unchanged), bench d9/d10 194011/350802 = 1.7.40. Diff vs 1.7.40 = eval/evaluate.js + eval/nnue.js (eval cache for NNUE, evalGen bump on net load / UseNNUE). NNUE never edits baseline. Push now runs to **23:23 PT** (QA 11:28).
- **n128-mixforge2 FAIL**: warm mixforge, lr 5e-5, early stop after ep2 (0.008987 / 0.008985), best = start 0.008983. No net built.
- **n128-mixob8 training** (box, nice 19, max-load 4): warm n128-mixforge, H128, 8 output buckets, data_mix_d40forge, lr 1e-4. Start shared-val 0.008983; ep6 **0.0089022** (−0.90% vs mixforge, −1.4% vs d40ft2). Still improving.
- **Rebased onto 1.7.41** (`/workspace/chess-engine-nnue`): `dist-nnue-n128mixforge-v6-1741` (net 8220b2a2, net-only), `dist-nnue-n128d40ft2-v6-1741` (net d1679b6b, net-only), `dist-nnue-n64ob8bk-v6-1741` (net 179dbf5f + ob8 nnue.js on top of nncache nnue.js; diff vs lock = eval/nnue.js + net.nnue; patch `nnue-768-n64ob8bk_on1741_js.patch` md5 **27930532**, nnue.js md5 9fca3c10; hunks applied clean, result = 1740 ob8 nnue.js + nncache evalGen lines exactly). Verify (`v6verify/all_1741.sh` + `ob8extra_1741.sh`, logs `v6verify/*_1741.log`, 11:55–11:57 PT): all three perft PASS, acc_check 60 g 9533 checks 0 mismatches, bug_gate_nofuzz PASS (KNOWN 6, fuzz left to QA), nnueinfo prints loaded net path. Bench d9: mixforge 221171, d40ft2 193301, ob8 194107 (lock 194011, HCE 286362). js-tree mixforge/d40ft2 b60447ca (= lock); ob8 5ffe6541. ob8 parity trainer-int 2000/2000 0 mism (all 8 buckets); lock net via ob8 nnue.js 2000/2000 + bench 194011 = lock.
- **grok-pc**: Forge self-play healthy (Idle, F000, 2 workers ~1.32M pos/h, 2.69M pos since 09:52 restart; file 003 growing). **GPU trainer idle since n128-bt4s45 finished ~09:55 PT** (ep10 BT4s45-val 0.005919, not on shared val, not a candidate). No STOP_nnue; D: 173 GB free.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.41 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n128-mixforge2 | 2026-10-15 09:52→10:10 | data40m+forgepgn | 768->128 x2->1 | warm mixforge, 5e-5, pat 2 | best 0.008983 (start) | — | — | FAIL — no gain |
| n128-bt4s45 (grok-pc GPU) | 2026-10-15 08:57→09:55 | BT4×0.45 only | 768->128 x2->1 | warm n128-d40ft2, 1e-4 | best BT4s45-val 0.005919 @ep10 | — | — | DONE, not a candidate (other val set) |
| n128-mixob8 | 2026-10-15 ~11:10→ | data40m+forgepgn | 768->128 x2->8 buckets | warm mixforge, 1e-4, pat 2 | ep6 **0.0089022** (start 0.008983) | — | — | UNPROVEN — training |
| n128mixforge-v6-1741 | 2026-10-15 ~12:00 | (same net 8220b2a2) | 768->128 x2->1 | — | 0.0089832 | Profiler −1.35% vs 1.7.40 (lock nodes identical) | not tested | UNPROVEN — verify PASS; net-only, needs QA |
| n128d40ft2-v6-1741 | 2026-10-15 ~12:00 | (same net d1679b6b) | 768->128 x2->1 | — | 0.009223 | Profiler −8.1% vs 1.7.40 | not tested | UNPROVEN — verify PASS; net-only, needs QA |
| n64ob8bk-v6-1741 | 2026-10-15 ~12:00 | (same net 179dbf5f) | 768->64 x2->8 buckets | — | 0.009615 | Profiler −4.2% vs 1.7.40; needs re-time on nncache | not tested | UNPROVEN — verify+parity PASS; patch 27930532 needs CR, then QA |
- 12:10 PT check: n128-1741 opponent = `dist-nnue-n128d40ft2-v6-1741` (net d1679b6b, bench d9 193301 = -1740 build; perft/acc/bug_gate_nofuzz PASS 11:56). mixforge-1741 (8220b2a2, bench 221171) confirmed intact. n128-mixob8 ep7 val **0.0088971** still improving (10 epochs, pat 2, ~6 min/ep) — let run; pack as dist-nnue-n128mixob8-v6-1741 when done. ob8 nnue.js (v2 loader) is generic in H (8..1024) x NB, so H128x8 needs no new patch beyond 27930532. UNPROVEN.
- **12:25 PT CORRECTION — n128-1741 opponent**: the 12:10 entry was WRONG (d40ft2/d1679b6b is a candidate, not the opponent). Correct opponent = n128-1740 net (n128d40ftbk) md5 **14656706**b1fc701ba6f821d93a62f3eb, from `/workspace/chess-engine/dist-cand-n128-1740`. Built net-only on lock 1.7.41: `/workspace/chess-engine-nnue/dist-nnue-n128-1741` and identical `/workspace/chess-engine/dist-cand-n128-1741` (cp -rp baseline/dist-v1.7.41 + net.nnue; only net.nnue differs; js-tree b60447ca == lock; search.js == lock). Verify (v6verify/all_1741.sh, log v6verify/n128-1741.log, 12:09–12:10): bench d9 **169395** / d10 **288859** == n128-1740 (lock 194011, HCE 286362); uci smoke OK; perft PASS; acc_check 60 g 9533 checks 0 mismatches; bug_gate_nofuzz PASS (KNOWN 6, new 0; fuzz left to QA). No baseline writes, no fastchess. UNPROVEN.
- 12:28 PT **n128-mixob8 DONE**: 10 epochs, best ep10 val **0.0088935** (start 0.008983, −1.0% vs mixforge). Packed by hand as GKNN v2 (hdr magic,2,H=128,NB=8; ftW,ftB,outW[8×256] i16, outB[8] i32; 201008 B) — export_snapshot.py is v1-only (scalar bias), train_ob.py writes the multi-bucket raw files. Dist `dist-nnue-n128mixob8-v6-1741`: net **84af2a31**, nnue.js 9fca3c10 (= n64ob8bk-1741, patch 27930532; no new diff), js-tree 5ffe6541. Diff vs lock = eval/nnue.js + net.nnue. Verify (`v6verify/dist-nnue-n128mixob8-v6-1741_1741.log`): trainer-int parity 2000/2000 0 mism (all 8 buckets hit), bench d9 **225212** (lock 194011, HCE 286362), perft PASS, acc 60 g 9533 checks 0 mism, bug_gate_nofuzz PASS (KNOWN 6, fuzz → QA). Needs Profiler NPS, then QA. UNPROVEN.

| n128mixob8-v6-1741 | 2026-10-15 12:27 | data_mix_d40forge | 768->128 x2->8 buckets | warm mixforge, 1e-4 | 0.0088935 | needs Profiler | not tested | UNPROVEN — verify+parity PASS |

## 2026-10-15 ~12:55 PT — hourly keep-going — all UNPROVEN
- Lock still **1.7.41** (dist-v1.7.41 newest). QA net queue vs n128-1741 (net 14656706): mixforge-1741 -> mixob8-1741 -> ob8-1741 -> d40ft2-1741. mixob8 Profiler speed PASS -5.7%; ob8 CR PASS 27930532.
- **grok-pc GPU n128-d40-from-mixforge DONE 12:30 PT**: warm n128-mixforge, data40m only, 10 ep; data40m-val 0.0091925 -> best ep10 **0.0091557** (-0.4%, data40m val, NOT shared val). Net at grok-pc nnue\nets\n128-d40-from-mixforge; not a candidate until scored on the shared val.
- **grok-pc GPU n256-d40 STARTED ~12:54 PT** (run_train.cmd, Idle, F000): H256 from scratch, data40m, lr 1e-3, 20 ep, pat 2. Prep for larger-H only; needs Profiler H256 timing before any build. Log nnue\logs\n256-d40.log.
- **Box n128-mixob8b STARTED ~12:53 PT** (nice 19, max-load 4): warm n128-mixob8 best, lr 7e-5, 10 ep, pat 2, data_mix_d40forge, start shared-val 0.0088935. Log logs/train_n128-mixob8b.log.
- grok-pc Forge self-play healthy (Idle, F000, ~1.33M pos/h, 3.98M pos since 09:52 restart). No STOP_nnue.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.41 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n128-d40-from-mixforge (GPU) | 2026-10-15 12:01→12:30 | data40m | 768->128 x2->1 | warm mixforge, 10 ep | best 0.0091557 data40m-val (start 0.0091925) | — | — | DONE, needs shared-val score |
| n256-d40 (GPU) | 2026-10-15 12:54→ | data40m | 768->256 x2->1 | scratch, 1e-3, 20 ep, pat 2 | — | needs Profiler H256 | — | UNPROVEN — training |
| n128-mixob8b | 2026-10-15 12:53→ | data_mix_d40forge | 768->128 x2->8 buckets | warm mixob8, 7e-5, pat 2 | start 0.0088935 | — | — | UNPROVEN — training |

## 2026-10-15 ~13:55 PT — hourly keep-going — all UNPROVEN
- **Lock is GrokChess 1.7.43** = `/workspace/chess-engine/baseline/dist-v1.7.43` (n128 lock net), js-tree **88b970cf**02d1c524884969eed3aa8820 (js-only), net md5 **14656706**b1fc701ba6f821d93a62f3eb, bench d9 **169395**. Diff vs 1.7.41 = search/* + uci/main.js + net.nnue (nnue.js unchanged 7724c5d4). NNUE never edits baseline.
- **n128-mixob8b FAIL** (box): warm mixob8 lr 7e-5, early stop after ep2 (0.008898 / 0.008894), best = start shared-val **0.0088935**. No pack. Log `logs/train_n128-mixob8b.log`.
- **Rebased onto 1.7.43** (`/workspace/chess-engine-nnue`): `dist-nnue-n128mixforge-v6-1743` (net 8220b2a2, net-only), `dist-nnue-n128d40ft2-v6-1743` (net d1679b6b, net-only), `dist-nnue-n128mixob8-v6-1743` (net 84af2a31 + ob8 nnue.js 9fca3c10), `dist-nnue-n64ob8bk-v6-1743` (net 179dbf5f + same nnue.js). Patch `nnue-768-n64ob8bk_on1743_js.patch` md5 **27930532** (= on1741; lock nnue.js identical). Smoke (`v6verify/smoke_1743.sh`, logs `v6verify/smoke_dist-nnue-*-v6-1743.log`, 13:53–13:54 PT): all four perft PASS, uci smoke OK, bench d9 mixforge **221171**, d40ft2 **193301**, mixob8 **225212**, ob8 **194107** (lock 169395). search.js == lock on all. No fastchess. No board/move/tt touched.
- **Box**: no active train after mixob8b; load ~3–4; no STOP_nnue. SCReLU next per Strategist but needs Coder+trainer change — not started. Stray bash waiter for old eval_checkpoint still present (harmless).
- **grok-pc**: no STOP_nnue. Forge self-play healthy (~1.34M pos/h, ~5.35M pos @ ~4.0 h since restart). GPU n256-d40 in ep19 of 20 (data40m-val ~0.00837, NOT shared val; needs Profiler H256 before candidate). Affinity/Idle noted for QA notify.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.43 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n128-mixob8b | 2026-10-15 12:53→13:30 | data_mix_d40forge | 768->128 x2->8 buckets | warm mixob8, 7e-5, pat 2 | best 0.0088935 (start) | — | — | FAIL — no gain |
| n128mixforge-v6-1743 | 2026-10-15 ~13:53 | (same net 8220b2a2) | 768->128 x2->1 | — | 0.0089832 | pending re-Profiler on 1.7.43 | not tested | UNPROVEN — smoke PASS; net-only |
| n128mixob8-v6-1743 | 2026-10-15 ~13:54 | (same net 84af2a31) | 768->128 x2->8 buckets | — | 0.0088935 | Profiler −5.7% was vs 1.7.41 | not tested | UNPROVEN — smoke PASS; needs re-Profiler+QA |
| n64ob8bk-v6-1743 | 2026-10-15 ~13:54 | (same net 179dbf5f) | 768->64 x2->8 buckets | — | 0.009615 | Profiler −4.2% was vs 1.7.40 | not tested | UNPROVEN — smoke PASS; patch 27930532 |
| n128d40ft2-v6-1743 | 2026-10-15 ~13:53 | (same net d1679b6b) | 768->128 x2->1 | — | 0.009223 | Profiler −8.1% was vs 1.7.40 | not tested | UNPROVEN — smoke PASS; net-only |
| n256-d40 (GPU) | 2026-10-15 12:54→ | data40m | 768->256 x2->1 | scratch, 1e-3, 20 ep | ep19 data40m-val ~0.00837 | needs Profiler H256 | — | UNPROVEN — training near end |

## 2026-10-15 ~13:58 PT — box worker keep-slot — all UNPROVEN
- Lock **1.7.43**. No STOP_nnue. No other train running. Load was ~3.8 at start (now throttles at ≥4). Did **not** touch baseline/, grok-pc, or fastchess.
- **(a) skipped**: `n128-d40-from-mixforge` GPU checkpoint is **not on the box** (lives on grok-pc); cannot score shared-val without CopyFromBox/PC Shell (Auto-review pending).
- **(b) started `n128-mixob8c`**: one-variable continue of best shared-val net. mixob8 finished ep10 still improving (0.0088935); mixob8b FAIL only after dropping lr to 7e-5. This run keeps **lr 1e-4** (same as successful mixob8) for 10 more epochs.
  - cmd: `nice -n 19 venv/bin/python train_ob.py --data data_mix_d40forge --out nets/n128-mixob8c --hidden 128 --epochs 10 --lr 1e-4 --max-load 4 --init nets/n128-mixob8/net_best.pt --obuckets 8 --patience 2`
  - pid **1316188**, nice 19, log `logs/train_n128-mixob8c.log`
  - warm `nets/n128-mixob8/net_best.pt` md5 **0edff0cf**14814922624621713bb18a34; start shared-val **0.008893493** (= mixob8 best)
  - data: `data_mix_d40forge` (data40m+forgepgn); no new converted forge/self-play on box; BT4 skipped (scale not fixed); SCReLU waiting on Coder
- Next-command if this fails: score GPU `n128-d40-from-mixforge` on `val_shared` once checkpoint is on box; else idle pending SCReLU or new forge convert from grok-pc self-play.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.43 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n128-mixob8c | 2026-10-15 13:58→ | data_mix_d40forge | 768->128 x2->8 buckets | warm mixob8, 1e-4, pat 2 | start 0.0088935 | — | — | UNPROVEN — training |

## 2026-10-15 ~14:52 PT — hourly keep-going — all UNPROVEN
- Lock still **1.7.43** (`baseline/dist-v1.7.43`, net md5 **14656706**, bench d9 **169395**). NNUE never edits baseline.
- **n128-mixob8c FAIL** (box): warm mixob8, lr 1e-4, early stop after ep2 (val 0.008900 / 0.008898), best = start shared-val **0.0088935**. No pack. Log `logs/train_n128-mixob8c.log`.
- **Shared-val eval** (`eval_multi.py`, nice 19, max-load 4 → `logs/eval_shared_1452.json`, n=417974):
  - n128-mixob8 net_best: **0.008893** (H128×8) — still best packed H128
  - n128-mixforge net_best: **0.008983** (H128×1)
  - n128-d40ft2 net_best: **0.009031** (H128×1)
  - n128-d40-from-mixforge net_best (GPU→box): **0.008967** (H128×1) — better than mixforge, worse than mixob8; not a pack over mixob8
  - **n256-d40 net_best (GPU→box): 0.008232** (H256×1) — **best shared-val on box** (−7.4% vs mixob8); needs Profiler H256 NPS before any candidate pack
- **Skipped n128-mixob8d** (lr 1.5e-4 warm continue): mixob8b (7e-5) and mixob8c (1e-4) already FAIL from same warm start; another lr bump is a long shot vs the n256 finding. Slot intentionally idle pending SCReLU (Coder) / H256 Profiler / new data. No STOP_nnue. No baseline edits. No fastchess. All UNPROVEN.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.43 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n128-mixob8c | 2026-10-15 13:58→~14:37 | data_mix_d40forge | 768->128 x2->8 buckets | warm mixob8, 1e-4, pat 2 | best 0.0088935 (start) | — | — | FAIL — no gain |
| eval_shared_1452 n256-d40 | 2026-10-15 ~14:55 | data40m (GPU train) | 768->256 x2->1 | scratch, scored on val_shared | **0.008232** shared-val | needs Profiler H256 | not tested | UNPROVEN — best shared-val; not packed |
| eval_shared_1452 n128-d40-from-mixforge | 2026-10-15 ~14:55 | data40m (GPU) | 768->128 x2->1 | warm mixforge, scored on val_shared | 0.008967 | — | — | UNPROVEN — below mixob8; not packed |

### 2026-10-15 ~15:00 PT (executor)
- **dist-nnue-n256d40-v6-1743** verified: js-tree 88b970cf (== lock 1.7.43, search.js/nnue.js == lock), net md5 14623076 (146230763c2c76cfbf444ab67db8d148, H256x1), perft PASS, acc_check 30 games 4729 checks 0 mismatches, bench d9 237947 nodes 1453 ms. Needs Profiler H256 NPS. UNPROVEN.
- **SCReLU act=1 train NOT started**: train.py / train_ob.py are clipped-ReLU only (forward `torch.clamp(...,0,1)`), no |outW|<=127 Lizard clamp in the step, and export writes v1/v2 (no GKNN v3 act header). Box slot left free.

### 2026-10-15 ~15:10 PT (executor) — SCReLU act=1 trainer + box train — UNPROVEN
- Trainer support added: `train.py`, `train_ob.py` take `--act 0|1` (1 = SCReLU `clamp(x,0,1)**2`), Lizard clamp `|outW| <= 127/64` after each step when act=1 (and clipped again at export), `--init-ft` (copies ft.weight/fb only, new output layer), and they always write `net_v3.nnue` (GKNN magic,3,H,NB,act + ftW,ftB,outW,outB). The act=0 raw i16/i32 export is unchanged. `eval_checkpoint.py` and `eval_multi.py` take `--act`. Backups are in `bak_screlu/`.
- Smoke test (H16, 80k rows): v3 header 0x4E4E4B47/3/16/1/1, size OK, max|outW|=12. Spec int formula vs float on 500 random positions: mean 0.71 cp, max 3.0 cp (quantization only).
- **Train n128-screlu-a**: `nice -n 19 venv/bin/python train.py --data data_mix_d40forge --out nets/n128-screlu-a --hidden 128 --epochs 10 --lr 1e-3 --max-load 4 --act 1 --patience 2`, pid 1894276, log `logs/train_n128-screlu-a.log`. From scratch, NB=1. Score on shared-val with `eval_multi.py --act 1 --vals val_shared`.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.43 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n128-screlu-a | 2026-10-15 ~15:08→ | data_mix_d40forge | 768->128 x2->1 SCReLU (act=1, Lizard) | scratch, 1e-3, 10 ep, pat 2 | start n/a (scratch); target < 0.008893 shared-val | — | — | UNPROVEN — training |

## 2026-10-15 ~15:53 PT — hourly keep-going — all UNPROVEN
- **Lock now 1.7.44** (`baseline/dist-v1.7.44`, net md5 **8220b2a2** = mixforge). Prior lock 1.7.43 net was 14656706. NNUE never edits baseline.
- **Box**: `n128-screlu-a` still training (pid **1894276**, nice 19, `--act 1` SCReLU scratch, data_mix_d40forge, lr 1e-3, max-load 4). Through ep2: train 0.009386 / val **0.009240** (run val, not shared-val yet). Load ~4.2–4.8; no second box train.
- **n256**: Profiler vs 1.7.43 median **−7.05% PASS** (`research/prof1743_n256`). On-nnsimd2 vs 1.7.44 median **+0.52% PASS** (`research/prof1744_nnsimd2`). Candidate `dist-cand-n256simd-1744` HOLD until nnsimd2 → 1.7.45 (filed REQUESTS). Scalar pack `dist-nnue-n256d40-v6-1743` net **14623076**, shared-val **0.008232**.
- **grok-pc**: STOP_nnue absent. Forge self-play healthy (~1.28M pos/h, ~7.7M pos, Idle/F000). GPU **idle** after finishes: n256-d40 done (best ep19 data40m-val 0.008373); n128-d40-cont done (best ep12 data40m-val 0.009166, not a shared-val win vs mixforge). Next GPU job start in progress this hour. D: ~173 GB free.
- No fastchess. No board/move/tt edits. All UNPROVEN.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n128-screlu-a | 2026-10-15 ~15:08→ | data_mix_d40forge | 768->128 x2->1 SCReLU | scratch 1e-3 pat2 | ep2 val 0.009240 (run val) | — | — | UNPROVEN — training |
| n128-d40-cont (GPU) | 2026-10-15 ~14:55→~15:24 | data40m | 768->128 x2->1 | warm mixforge 5e-5 | best 0.009166 data40m-val | — | — | FAIL-ish — below mixforge shared; not packed |
| n256-d40 (GPU) | 2026-10-15 12:54→~13:55 | data40m | 768->256 x2->1 | scratch 1e-3 | shared-val **0.008232**; data40m-val 0.008373 | −7.05% vs 1.7.43 PASS; +0.52% on nnsimd2 vs 1.7.44 | not tested | UNPROVEN — HOLD n256simd-1744 for nnsimd2 lock cut |

## 2026-10-15 ~16:53 PT — hourly keep-going — all UNPROVEN
- Lock still **1.7.44** (latest `baseline/dist-v1.7.44`, net 8220b2a2); no 1.7.45 yet (nnsimd2b pending QA).
- **Box**: `n128-screlu-a` (pid 1894276) alive; ep3 val **0.009050** (run val; shared-val bar 0.008893 not beaten yet). Ep4 slower — box load 4.4–5.8, so max-load 4 throttling. No second box train.
- **grok-pc** (last check ~16:15): GPU `n256-d40-cont` PID 8572 moved Normal/0xFFFF → Idle/0xF000; ep7 best 0.008363 (data40m-val). Forge self-play Idle/F000. STOP_nnue absent.
- n256simd-1744 still HOLD for nnsimd2 → 1.7.45. No fastchess, no board/move/tt edits.

| n128-screlu-a | 2026-10-15 ~15:08→ | data_mix_d40forge | 768->128 x2->1 SCReLU | scratch 1e-3 pat2 | ep3 val 0.009050 (run val) | — | — | UNPROVEN — training |
| n256-d40-cont (GPU) | 2026-10-15 ~16:00→ | data40m | 768->256 x2->1 | cont | ep7 best 0.008363 data40m-val | — | — | UNPROVEN — training |

### ~17:20 PT Thu Oct 15 — Strategist 17:15 actions (all UNPROVEN)
- **dist-nnue-n256d40-v6-1744** packed: /workspace/chess-engine-nnue/dist-nnue-n256d40-v6-1744 = copy of baseline/dist-v1.7.44 with net.nnue → n256-d40 (md5 146230763c2c76cfbf444ab67db8d148). `diff -rq` vs dist-v1.7.44: only net.nnue differs. Box UCI smoke OK (startpos d9 cp29 63569 nodes; d10 cp25 81976 nodes, bestmove d2d4). Synced to grok-pc `C:\Users\Administrator\grok-pc\nnue\dist-nnue-n256d40-v6-1744\` (net md5 verified on PC).
- **n128-screlu-a** (box, PID 1894276): ep4 val **0.008883** (val.bin = copy of val_shared → this IS shared-val) — just under bar 0.008893 (−0.1%). Below ep5 → left running per Strategist rule; recheck at ep5.
- **grok-pc GPU n256-forgeall** queued: converting ALL forge self-play (001+002+003 snapshot to last full line, ~12.8M lines) → D:\grok-pc-data\forge_sp_all (convert_forge.py, Idle/0xF000). Watcher start_n256_forgeall.ps1 launches train_gpu.py --data data40m,forgepgn(1.84M),forge_sp_all --hidden 256 --lr 1e-4 --epochs 10 --patience 3 --init nets\n256-d40-cont\net_best.pt (ep10 0.008363) at Idle/0xF000 when stats.json appears; honors STOP_nnue. Log logs\n256-forgeall.log, logs\start_n256_forgeall.log. Val logged = data40m val; shared-val + forgepgn-val to score after.

## 2026-10-15 ~17:56 PT — hourly keep-going — all UNPROVEN
- Lock still **1.7.44** (net 8220b2a2); no 1.7.45 yet.
- **Box** `n128-screlu-a` (pid 1894276): ep5 0.008840, ep6 0.008802, ep7 **0.008752** shared-val — beats mixforge bar 0.008893 by ~1.6% and still improving (10 epochs, patience 2). Box load ~5.2, so max-load 4 throttles it.
- **grok-pc GPU** `n256-forgeall` (warm from n256-d40-cont, data40m+forgepgn+forge_sp_all, lr 1e-4): started 17:39, early-stopped ~17:50 after ep3 (ep3 data40m-val 0.008525, other vals 0.003692/0.00325); best = epoch 0 val 0.008363 = no gain over its start net. FAIL on data40m-val; not packed. GPU now idle.
- grok-pc forge self-play healthy: ~10.03M positions, ~1.24M pos/h, Idle/0xF000. STOP_nnue absent. D: 168 GB free.
- `dist-nnue-n256d40-v6-1744` (net 14623076) packed + synced, waiting QA slot. No fastchess, no board/move/tt edits.

| n128-screlu-a | 2026-10-15 ~15:08→ | data_mix_d40forge | 768->128 x2->1 SCReLU | scratch 1e-3 pat2 | ep7 shared-val 0.008752 | — | — | UNPROVEN — training, beats bar |
| n256-forgeall (GPU) | 2026-10-15 17:39→~17:50 | data40m+forgepgn+forge_sp_all | 768->256 x2->1 | warm n256-d40-cont 1e-4 pat3 | best ep0 0.008363 data40m-val (no gain) | — | — | FAIL — early stop, not packed |

### 2026-10-15 ~18:00 PT — GPU n256-screlu-a launched (all UNPROVEN)
- **train_gpu.py** on box + grok-pc: ported SCReLU from train.py — `--act 0|1`, `--init-ft`, Lizard `|outW|<=127/64` when act=1, always writes `net_v3.nnue` (GKNN magic,3,H,NB,act). Backup PC: `train_gpu.py.bak_prescrelu` (md5 795E23E72EF0ACA4D7B58C011834AF4D); patched md5 99D2913B2E98698C1787EB47A6C438B6. Box copy: `/workspace/chess-tools/nnue/train_gpu.py`.
- **Launch** grok-pc PID **8920**: Idle + affinity **0xF000** (CPUs 12-15) verified via Start-Process + Get-Process.
  - cmd: `.venv\Scripts\python.exe -u train_gpu.py --data D:\grok-pc-data\data40m,D:\grok-pc-data\forgepgn,D:\grok-pc-data\forge_sp_all --out nets\n256-screlu-a --hidden 256 --epochs 10 --lr 1e-3 --act 1 --init-ft nets\n256-d40-cont\net_best.pt --patience 3 --stop-dir C:\Users\Administrator\grok-pc\nnue`
  - data sizes: data40m 39.5M + forgepgn 1.84M + forge_sp_all 11.7M train rows; val = data40m val
  - FT-only warm from n256-d40-cont (fresh SCReLU out); lr 1e-3; torch threads 2 (≤4)
  - log `logs\n256-screlu-a.log` / `.err`; launcher `pc_launch\start_n256_screlu_a.ps1`
- STOP_nnue absent. No baseline/run_*/orch_* edits. All UNPROVEN.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n256-screlu-a (GPU) | 2026-10-15 ~18:00 PT→ | data40m+forgepgn+forge_sp_all | 768->256 x2->1 SCReLU act=1 Lizard | FT-only n256-d40-cont, 1e-3, 10 ep, pat 3 | start n/a (fresh out) | — | — | UNPROVEN — training PID 8920 Idle/0xF000 |

### 2026-10-15 ~18:15 PT — n256-forgeall ep3 rescue + GPU switch (all UNPROVEN)
- **FROZEN ep3 weights (QA gate source):** PC `C:\Users\Administrator\grok-pc\nnue\nets\n256-forgeall\net_ep3_frozen.pt` (read-only) and box `/workspace/chess-tools/nnue/nets/n256-forgeall/net_ep3_frozen.pt` (a-w), md5 **1c22c082657dcd8312f15f6ddf313196** (= net.pt at 17:50).
- forgepgn val.bin md5 PC xfer\forgepgn = box data_forgepgn = 5e86be53c436eefdcec83e3eaf313b37.
- eval_multi act=0: ep3 val_shared **0.008310** / data40m 0.008525 / forgepgn **0.003692**; lock mixforge 0.008983 / 0.009193 / 0.004480 (−7.5% / −7.3% / −17.6%).
- **Packed** /workspace/chess-engine-nnue/dist-nnue-n256forgeall-v6-1744 = cp baseline/dist-v1.7.44 + net.nnue (v1 GKNN H256, md5 **d0e1c9f00cd2e00de42ab2e034b6c5bb**; built from export_snapshot of frozen pt, format verified by rebuilding n256d40 bit-exact). diff -rq: only net.nnue. acc_check 60 g 9533 checks 0 mism; bench d9 220563 nodes; UCI d10 cp29 82103 nodes bestmove d2d4. Synced PC `C:\Users\Administrator\grok-pc\nnue\dist-nnue-n256forgeall-v6-1744\` (net md5 verified, 91 files).
- **train_gpu.py `--select-val N`** (index into --data; drives best/early-stop; val_other = rest). md5 aedca8930187d0dcd4e20a1a962d3cc9 box+PC; backups train_gpu.py.bak_preselect.
- GPU: killed n256-screlu-a (8920 tree: 8920/7728/11684) mid-ep1 (no epoch saved). Started **n256-forgeall-b** (launcher 1340, python 8436, both Idle/0xF000): --init frozen ep3, lr 5e-5, 10 ep, pat 3, --select-val 1 (forgepgn; note random split, leaky), data data40m,forgepgn,forge_sp_all, out nets\n256-forgeall-b. Start val (forgepgn) 0.003692.


## 2026-10-15 ~18:56 PT — hourly keep-going — all UNPROVEN
- Lock still **1.7.44** (net 8220b2a2 mixforge). Box load high (~16, QA matches); no new box train.
- **Box n128-screlu-a DONE**: ep10 best_val **0.008713** (beats bar 0.008893 by ~2.0%). Export `nets/n128-screlu-a/net_v3.nnue` / `nets-export/n128-screlu-a-v3-act1.nnue` md5 **743b284f109eb660a3fdc6777b77dcad** (GKNN v3 H128 NB1 act=1). Earlier interim export 86b2c2ad was ep9; final is ep10.
- **GPU n256-forgeall-b DONE**: early-stop best ep5 forgepgn-val **0.003620** (start 0.003692); ep8 val_other data40m ~0.008506 / forge_sp ~0.00317. Wrote `nets/n256-forgeall-b/net_v3.nnue` act=0. Shared-val score pending before any pack vs forgeall ep3 (shared 0.008310, net d0e1c9f0).
- **GPU**: was idle after forgeall-b; restarting **n256-screlu-a** (SCReLU act=1, FT-only n256-d40-cont, data40m+forgepgn+forge_sp_all, lr 1e-3, pat 3) Idle/0xF000.
- Forge self-play healthy Idle/0xF000; D: ~168 GB free. STOP_nnue absent.
- QA: `dist-nnue-n256d40-v6-1744` (14623076) + `dist-nnue-n256forgeall-v6-1744` (d0e1c9f0, Profiler NPS median −15.7% PASS) in flight / waiting slots; PC orch already matching n256forgeall. screlu2 needs final 743b284f net beside cand after CR. All UNPROVEN.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n128-screlu-a | 2026-10-15 15:08→~18:20 | data_mix_d40forge | 768->128 x2->1 SCReLU act=1 | scratch 1e-3 10ep pat2 | **best ep10 0.008713** shared-val | needs screlu2 wasm | not tested | UNPROVEN — DONE export 743b284f |
| n256-forgeall-b (GPU) | 2026-10-15 18:03→~18:36 | data40m+forgepgn+forge_sp_all | 768->256 x2->1 | warm frozen ep3, 5e-5, select-val forgepgn | best ep5 **0.003620** forgepgn | — | — | UNPROVEN — DONE; shared-val pending |
| n256-screlu-a (GPU) | 2026-10-15 ~19:00→ | data40m+forgepgn+forge_sp_all | 768->256 x2->1 SCReLU | FT n256-d40-cont 1e-3 pat3 | restart after mid-ep1 kill | — | — | UNPROVEN — restarting |

### 2026-10-15 ~19:12 PT — Strategist 19:10 correction (NNUE acted) — all UNPROVEN
- **DO NOT pack forgeall-b.** Shared-val 0.008301 vs forgeall ep3 0.008310 (flat). Confirmed no `dist-nnue-*forgeall-b*` on box or grok-pc. Note: `nets/n256-forgeall-b/NO_PACK.md`. Leave train artifacts only.
- **Select on data40m:** future GPU early-stop must use `--select-val 0` (first `--data` file = data40m). forgepgn-val is leaky (random split) and had ranking backwards; n256d40 (+56.5 @190) leads n256forgeall (+36.4 @185) in real QA matches, as data40m-val predicted (0.008373 vs 0.008525).
- **Live GPU n256-screlu-a** (grok-pc): PID **8180** (train; torch threads 2) + launcher/wrapper **9228**. Priority **Idle**, affinity **0xF000** (61440). STOP_nnue absent. Cmdline has **no** `--select-val` → train_gpu.py default **0** = data40m. Logged `val` is data40m (ep1 0.008814, ep2 0.008735); mid-ep3. **No restart** (already correct select; mid-epoch; low impact). Re-pinned not needed (Idle/F000 held). Launcher `pc_launch/start_n256_screlu_a.ps1` updated to pass `--select-val 0` explicitly for future relaunches.
- **screlu3 plan (Coder):** screlu3 = screlu2 + fast `fwd_sc`: `t = i16x8.mul(c, w)` then `acc += i32x4.dot_i16x8_s(t, c)`. Exact for net **743b284f** (max|outW|=84, trainer clips 127 → c*w fits i16). Expected **+20..30% NPS** on SCReLU nets. Gates: parity vs screlu2 w/ 743b284f (0 mism), bench 145322/233995, Profiler pairs; Code Review nnue.js+wat. Pack after CR PASS. CReLU path untouched; gate at load keep old kernel fallback.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n256-forgeall-b (GPU) | 2026-10-15 18:03→~18:36 | data40m+forgepgn+forge_sp_all | 768->256 x2->1 | warm frozen ep3, 5e-5, select-val forgepgn | shared **0.008301** (flat vs ep3 0.008310); forgepgn best 0.003620 | — | — | **NO PACK** — Strategist 19:10 |
| n256-screlu-a (GPU) | 2026-10-15 ~19:00→ | data40m+forgepgn+forge_sp_all | 768->256 x2->1 SCReLU | FT n256-d40-cont 1e-3 pat3; select-val **0** (default) | ep2 data40m-val 0.008735; mid-ep3 | — | — | UNPROVEN — training PID 8180 Idle/0xF000 |

## 2026-10-15 ~19:55 PT — hourly keep-going — all UNPROVEN
- Lock still **1.7.44** (net 8220b2a2). Box load ~2.1; no NNUE box job running (box slot idle, awaiting Strategist pick for next ablation).
- **GPU n256-screlu-a DONE** (10/10 ep, no early stop, still improving): best ep10 data40m-val **0.008384** (ep9 0.008397); val_other forgepgn 0.003335 / forge_sp 0.002849; train 0.006872. Wrote PC `nets\n256-screlu-a\net_v3.nnue` act=1 (md5 not yet taken). Roughly flat vs n256d40 data40m-val 0.008373 — no pack yet; needs screlu3 wasm anyway.
- **GPU started n256-screlu-b**: --init n256-screlu-a/net_best.pt, lr 2e-4, 10 ep, pat 3, act 1, --select-val 0 (data40m), same 3-file mix. PID **5444** Idle/0xF000 verified; start val 0.008384. Launcher `pc_launch\start_n256_screlu_b.ps1`.
- PC process-inspection command was blocked by Auto-review this run; Forge self-play health not re-verified this hour.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n256-screlu-a (GPU) | 2026-10-15 ~19:00→~19:45 | data40m+forgepgn+forge_sp_all | 768->256 x2->1 SCReLU | FT n256-d40-cont 1e-3 pat3 select-val 0 | best ep10 data40m **0.008384** | needs screlu3 | — | UNPROVEN — DONE, no pack (flat vs n256d40 0.008373) |
| n256-screlu-b (GPU) | 2026-10-15 ~19:53→ | same | 768->256 x2->1 SCReLU | warm screlu-a best, 2e-4, 10ep pat3 select-val 0 | start 0.008384 | — | — | UNPROVEN — training PID 5444 Idle/0xF000 |

### 2026-10-15 ~19:56 PT — Box ablation n128-screlu-ob8 (Strategist pick)
- **Train n128-screlu-ob8**: `nice -n 19 venv/bin/python train_ob.py --data data_mix_d40forge --out nets/n128-screlu-ob8 --hidden 128 --epochs 10 --lr 1e-3 --max-load 4 --act 1 --patience 2 --obuckets 8`, pid 242166, log `logs/train_n128-screlu-ob8.log`. Clone of n128-screlu-a with the only change being NB=8 output buckets (bucket=min(7,(pieces-2)//4), kings included). Existing train_ob.py, no code change. Single thread. Neither trainer sets a seed, so seed matches n128-screlu-a (unseeded). Run val = data_mix_d40forge/val.bin, which is byte-identical to val_shared (data40m shared-val), so selection is on shared-val. Load at start 2.6. Second TODO (not started): leak-free Forge val split by game ID.

| n128-screlu-ob8 | 2026-10-15 19:56→ | data_mix_d40forge | 768->128 x2->8 SCReLU act=1 NB8 | scratch 1e-3 10ep pat2 | bar: beat 0.008713 shared-val (n128-screlu-a) | needs NB8 in screlu3 | not tested | UNPROVEN — training |

## 2026-10-15 ~20:58 PT — hourly keep-going — all UNPROVEN
- **Lock now 1.7.45** (`baseline/dist-v1.7.45`, net md5 **d0e1c9f0**0cd2e00de42ab2e034b6c5bb = n256forgeall ep3). Prior 1.7.44 was mixforge **8220b2a2**. NNUE never edits baseline.
- **Box**: `n128-screlu-ob8` still training (pid **242166**, nice 19, `--act 1` NB=8, data_mix_d40forge). Through **ep6** best shared-val **0.008660** (bar = n128-screlu-a 0.008713 — already beating by ~0.6%). Load ~3.7; left running. No second box train.
- **grok-pc (FoxOS)**: STOP_nnue absent. **GPU n256-screlu-b DONE** ~20:05 PT: early-stop after ep3; best = **epoch 0** data40m-val **0.008384** (ep1 0.008412 / ep2 0.008386 / ep3 0.008385) — **no gain** over screlu-a start; wrote `nets\n256-screlu-b\net_v3.nnue` act=1 (not packed). GPU trainer idle (no `train_gpu` process). **Forge self-play healthy**: ~13.84M pos @ ~1.25M/h (004.part growing), workers `--cpus 12-15`, Win32 Priority **4=Idle** on guard/selfplay/forge PIDs; affinity 0xF000 not re-read this hour (Get-Process blocked previously). D: **167.8 GB** free.
- No new GPU launch (no documented next ablation after screlu-b). forgeall-b remains **NO_PACK**. screlu3 packing still Coder-owned (`dist-cand-screlu3n128-1744` / screlu2-1745 exist). No fastchess. No baseline edits. All UNPROVEN.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n128-screlu-ob8 | 2026-10-15 19:56→ | data_mix_d40forge | 768->128 x2->8 SCReLU NB8 | scratch 1e-3 10ep pat2 | ep6 best **0.008660** shared-val (beats 0.008713) | needs NB8+screlu3 | — | UNPROVEN — training PID 242166 |
| n256-screlu-b (GPU) | 2026-10-15 19:53→~20:05 | data40m+forgepgn+forge_sp_all | 768->256 x2->1 SCReLU | warm screlu-a 2e-4 pat3 select-val 0 | best ep0 **0.008384** (no gain) | — | — | FAIL — early stop; not packed |
| n256-screlu-a (GPU) | 2026-10-15 ~19:00→~19:45 | same | 768->256 SCReLU | FT n256-d40-cont 1e-3 | best ep10 **0.008384** data40m | needs screlu3 | — | UNPROVEN — DONE, flat vs n256d40 0.008373; no pack |

### 2026-10-15 ~21:35 PT — forge whole-game holdout + n256-screlu-c (all UNPROVEN)
- **Lock 1.7.45** = 1.7.44 JS + net d0e1c9f0 (frozen pt `nets\n256-forgeall\net_ep3_frozen.pt` md5 1c22c082657dcd8312f15f6ddf313196, verified on PC).
- **Forge holdout built** (PC `D:\grok-pc-data\forge_holdout\`, script `nnue\build_forge_holdout.py`, log `logs\forge_holdout.log`). Source lines have NO game id → games derived: new game when fullmove decreases OR piece count increases OR result field changes. game_id=`<file>#<ordinal>`; held out if sha1(game_id+"fho1")%10000<500 (5%). Same filters as convert_forge.py (pieces<=30, clip 3000, White-POV), dedup per set, train positions also present in holdout dropped (0 overlap). Sources: forge_selfplay_001/002/003 (md5 5c82679f / 1cb03e14 / b13fafe3) + snapshot of 004.part to last newline `forge_holdout\forge_selfplay_004_snap.txt` (md5 7013ad8f). 17,498,006 lines, 193,592 games (~90 lines/game), **9,851 held-out games**. **val.bin 819,894 pos md5 325c3f33a7ea0793157b1c3f29e4f830**; **train.bin 15,272,952 pos md5 454441d709183ca4f6385c9098cf6de7**; holdout_game_ids.txt md5 34d6da7f90507b33378c1f13fb544062. Caveat: nets trained on old forge_sp_all (forgeall, screlu-a/b, forgeall-b) saw the 001-003 holdout games → their holdout scores are contaminated; only nets trained from now on with forge_holdout/train.bin are clean. Old forge_sp_all/val.bin is now leaky vs the new train.
- **Reference scores** (`score_nets.py`, logs\score_nets.json; matches trainer loss): forge_holdout / data40m-val / forgepgn-val
  - d0e1c9f0 (forgeall ep3 frozen): 0.003315* / 0.008525 / 0.003692
  - n256d40 14623076 (`nets\n256-d40\net_best.pt`, export bytes verified in dist net.nnue): 0.005186 / 0.008373 / 0.005186 (no forge in training → clean)
  - n256-screlu-a net_best: 0.002909* / 0.008384 / 0.003335   (*contaminated, see caveat)
- **train_gpu.py**: added `--obuckets K` (box train_ob.py bucket=min(K-1,(pieces-2)//(32//K)) incl kings; single-head init repeated into all buckets; v3 export NB=K), `--extra-val` (logged per epoch), `--keep-last N` (net_ep<N>.pt). Backup `train_gpu.py.bak_preob`. Smoke H256 NB8 from d0e1c9f0: start val 0.008525 identical to source → init exact.
- **GPU n256-screlu-c STARTED 21:28 PT** (supersedes planned n256-forgeall-c and n256-forgeall-ob8; neither was launched). PID **6900** (launcher 4768), Idle/0xF000 verified x3 re-pins; torch 2 threads. Cmd: `.venv\Scripts\python.exe -u train_gpu.py --data D:\grok-pc-data\data40m,D:\grok-pc-data\forgepgn,D:\grok-pc-data\forge_holdout --out nets\n256-screlu-c --hidden 256 --act 1 --epochs 5 --lr 2e-4 --init nets\n256-screlu-a\net_best.pt --patience 99 --select-val 2 --keep-last 99 --extra-val D:\grok-pc-data\forge_sp_all,D:\grok-pc-data\val_shared --stop-dir <nnue>` (launcher pc_launch\start_n256_screlu_c.ps1). Select = forge holdout; every epoch saved; logs data40m/forgepgn/holdout + shared. ep1: holdout 0.002762 (start 0.002909), data40m 0.008473, forgepgn 0.00318, shared 0.008238.
- **Next GPU: n256-forgeall-ob8** (H256 act0 NB8, init d0e1c9f0 heads copied, lr 5e-4, 6-8 ep, same new selection: --select-val 2 forge holdout, keep all epochs) — not launched.
- **screlu3: PARKED** (Strategist 20:25: +1.6% NPS = noise). **n256-screlu-b: FAIL** (already recorded).

## 2026-10-15 ~21:57 PT — hourly keep-going — all UNPROVEN
- **Lock 1.7.45** (`baseline/dist-v1.7.45`, net md5 **d0e1c9f0**0cd2e00de42ab2e034b6c5bb = n256forgeall). NNUE never edits baseline.
- **Box DONE: n128-screlu-ob8** finished all 10 epochs (~21:34 PT). Best = **epoch 10** shared-val **0.008582** (bar n128-screlu-a 0.008713, −1.5%). Export `nets/n128-screlu-ob8/net_v3.nnue` act=1 NB=8 size 201012 md5 **2861fb6f**a46a6f68fcee7b428c533589; net_best.pt md5 **61378b50**. Log `logs/train_n128-screlu-ob8.log`. **Needs Coder** screlu2ob8 path for real parity+bench (`dist-cand-screlu2ob8-1745` currently has a 394768-byte placeholder net). Box slot **idle**, load ~2.5 — awaiting Strategist next ablation. No second box train started.
- **GPU n256-screlu-c** (from prior ~21:28): select forge holdout; see PC check this hour.
- **Next GPU (queued, not launched): n256-forgeall-ob8** H256 act=0 NB=8 from d0e1c9f0, select forge holdout.
- No fastchess. No baseline edits. All UNPROVEN.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n128-screlu-ob8 | 2026-10-15 19:56→~21:34 | data_mix_d40forge | 768->128 x2->8 SCReLU act=1 NB8 | scratch 1e-3 10ep pat2 | best ep10 shared-val **0.008582** (beats 0.008713) | needs screlu2ob8 parity | — | UNPROVEN — DONE; export md5 2861fb6f; send Coder |
| n256-screlu-c (GPU) | 2026-10-15 21:28→ | data40m+forgepgn+forge_holdout | 768->256 SCReLU | warm screlu-a 2e-4 select holdout | ep1 holdout 0.002762 / shared 0.008238 | — | — | UNPROVEN — training (check PC) |
| n256-screlu-b (GPU) | 2026-10-15 19:53→~20:05 | data40m+forgepgn+forge_sp_all | 768->256 SCReLU | warm screlu-a 2e-4 | best ep0 **0.008384** | — | — | FAIL — not packed |

### 2026-10-15 ~22:01 PT — screlu-c DONE + forgeall-ob8 STARTED (all UNPROVEN)
- **n256-screlu-c DONE** ~21:50 PT: 5/5 ep, select=forge holdout. Best = **ep1** holdout **0.002762** (start 0.002909); ep5 holdout 0.002822. Shared (extra) best ~**0.008181**. data40m-val ~0.00841. net_best.pt md5 **d1294716**1a414c02cad4689ae5497b81 (=ep1); net_v3.nnue md5 **ba972c71**fdd5c89e312a0aef491ecc62; ep1.pt md5 da6bfe0b. Not packing yet (SCReLU; games rank nets). Log copied to box `logs/n256-screlu-c-log.json`.
- **GPU started n256-forgeall-ob8** (Strategist queue): `--act 0 --obuckets 8 --init net_ep3_frozen.pt --lr 5e-4 --epochs 8 --select-val 2` (forge holdout) `--keep-last 99 --extra-val forge_sp_all,val_shared`. Launcher `pc_launch\start_n256_forgeall_ob8.ps1`. PIDs **2536**/6328/**4896** Idle Aff=**0xF000** (61440). start val **0.003315** (= lock holdout ref). ep1 underway ~198k pos/s. STOP_nnue absent. D: **167 GB** free.
- **Forge SP**: `selfplay_out\forge_selfplay_004.txt.part` ~325 MB / **~5.03M lines** @ 21:58–22:00 PT (still growing). 001–003 intact. Workers Idle.
- **Box**: idle after n128-screlu-ob8; awaiting Strategist next ablation. Coder needs screlu2ob8 parity on export md5 **2861fb6f**.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n256-screlu-c (GPU) | 2026-10-15 21:28→21:50 | data40m+forgepgn+forge_holdout | 768->256 SCReLU | warm screlu-a 2e-4 select holdout | best ep1 holdout **0.002762**; shared ~0.008181 | needs screlu | — | UNPROVEN — DONE; not packed |
| n256-forgeall-ob8 (GPU) | 2026-10-15 22:00→ | same | 768->256 x2->8 CReLU NB8 | init ep3_frozen 5e-4 8ep select holdout | start holdout **0.003315** | needs CReLU NB8 engine | — | UNPROVEN — training Idle/F000 |
| n128-screlu-ob8 | 2026-10-15 19:56→~21:34 | data_mix_d40forge | 768->128 x2->8 SCReLU NB8 | scratch 1e-3 | best ep10 shared **0.008582** | needs screlu2ob8 | — | UNPROVEN — DONE; md5 2861fb6f |

| n128-screlu-ob4 | H128 SCReLU NB=4, data_mix_d40forge, 10ep lr1e-3 | running (box PID 1311987, nice 19, 4 thr) | bar ob8 shared-val 0.008582 | UNPROVEN |

### n128-screlu-ob4 (FALLBACK for n128-screlu-ob8-wdl) — UNPROVEN
- Started 2026-10-15 ~22:04 PT on the box. Same as n128-screlu-ob8 except --obuckets 4; --patience 99 (full 10 epochs). Threads 4, nice 19, --max-load 4.
- Why fallback: train_ob.py is eval-only (loss on sigmoid(score) only; implicit WDL lambda 0 / "lambda 1.0 eval" in docstring), and the record format (occ,pcs,stm,castle,score,ep,rsv[3]) carries NO game result. convert_forge.py drops the selfplay result; rsv is all 0 in data_mix_d40forge. Forge rows can't be told apart from Lichess rows, so the result blend can't be applied. To do the WDL run: reconvert forge selfplay with result in rsv[0] plus a "has result" flag.
- Code change: train_ob.py now also saves nets/<run>/net_ep{N}.pt every epoch (one line; backup train_ob.py.bak_preob4).
- Selection: shared-val (data_mix_d40forge/val.bin = val_shared), same as ob8. Bar: ob8 best shared-val 0.008582.
- Game-split forge holdout NOT on box: CopyToBox from grok-pc D:\grok-pc-data\forge_holdout\val.bin was refused (outside local-exec root). Score ob8 net_best.pt and the per-epoch ob4 checkpoints on it once it's copied. Caveat: forge rows in data_mix_d40forge probably include holdout games, so holdout scores are contaminated, but ob4 vs ob8 is still apples to apples.

### 2026-10-15 ~22:06 PT — forge holdout on box + score n128-screlu-ob8 / n128-screlu-a (all UNPROVEN)
- **Holdout copied to box**: grok-pc `D:\grok-pc-data\forge_holdout\val.bin` → `C:\Users\Administrator\grok-pc\nnue\forge_holdout\val.bin` (C: had ~42 GB free; wrote only under nnue\) → CopyToBox → `data_forge_holdout/val.bin`. **md5 ok** `325c3f33a7ea0793157b1c3f29e4f830`; n=819894. Did not touch run_*/orch_*/STOP_*/dist-v*.
- **Scored** with `nice -n 19 venv/bin/python eval_multi.py --vals data_forge_holdout --act 1 --max-load 12` (same loss as trainers / score_nets.py; buckets auto from out.weight). Log `logs/score_forge_holdout_ob8_a.json`. Did not disturb n128-screlu-ob4 (PID 1311989 still running).
- **n128-screlu-ob8**: no `net_ep*.pt` on disk (per-epoch save was added later for ob4; only `net_best.pt` + `net.pt`). Both score identical on holdout (best_epoch was 10).
  - `nets/n128-screlu-ob8/net_best.pt` NB8 H128 SCReLU: holdout **0.004415** (3.8s)
  - `nets/n128-screlu-ob8/net.pt` NB8 H128 SCReLU: holdout **0.004415** (3.3s)
- **n128-screlu-a** `net_best.pt` NB1 H128 SCReLU: holdout **0.004326** (3.1s)
- **Contamination caveat**: both nets trained on `data_mix_d40forge` (includes old forge self-play that overlaps holdout games). Holdout scores are **contaminated** for ranking absolute Elo; ok for relative ob4-vs-ob8 once ob4 epochs are scored the same way. Ref: n256-screlu-a holdout on PC was 0.002849 (H256; different arch).
- **Blockers**: none for copy/score. WDL ablation still blocked (no result in records). ob4 holdout scoring deferred until its `net_ep*.pt` exist / run finishes.

### 2026-10-15 ~22:56 PT — n256-forgeall-ob8 DONE + n256-screlu-ob8 STARTED (all UNPROVEN)
- **n256-forgeall-ob8 DONE** 22:37 PT (8/8 ep, select = forge holdout). Best **ep4** holdout **0.002899** (start/lock ref 0.003315*, −12.5%); ep4 data40m 0.008526 (lock 0.008525, flat), forgepgn 0.003308 (lock 0.003692), shared 0.008294. Later epochs beat the lock on data40m: ep7 data40m **0.008459** / holdout 0.002965 / shared 0.008233; ep8 0.008467 / 0.002945 / 0.008239. *Lock and this net share lineage that saw old forge games, so holdout numbers are relative only.
- PC `nets\n256-forgeall-ob8\`: net_v3.nnue (ep4, act 0, NB8) md5 **dc639f3b**92e4caa7fb6ba25462e02e43; net_best.pt md5 d796f832; net_ep1..8.pt kept. Not packed. Needs CReLU NB8 engine support from Coder (Strategist rule: beats lock on data40m → ping Coder). ep7 export can be made on request.
- **GPU started n256-screlu-ob8** 22:55 PT: `--act 1 --obuckets 8 --init nets\n256-screlu-c\net_best.pt (d1294716) --lr 2e-4 --epochs 8 --select-val 2 --keep-last 99 --extra-val forge_sp_all,val_shared`, data data40m+forgepgn+forge_holdout. Launcher `pc_launch\start_n256_screlu_ob8.ps1`. PIDs 8212/14124/8396 Idle Aff 0xF000 (61440) verified x3. Start holdout **0.002762** (= screlu-c best, init exact). ~182k pos/s.
- **Box n128-screlu-ob4**: ep5 shared-val 0.008760 (ob8 bar 0.008582 at ep10); running PID 1311989 nice 19, 4 thr.
- **Forge SP**: 004.part ~397 MB, growing; workers Idle/0xF000. D: 166.9 GB free. STOP_nnue absent.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n256-forgeall-ob8 (GPU) | 2026-10-15 22:00→22:37 | data40m+forgepgn+forge_holdout | 768->256 x2->8 CReLU NB8 | init d0e1c9f0 5e-4 8ep select holdout | best ep4 holdout **0.002899** (lock 0.003315); ep7 data40m **0.008459** (lock 0.008525) | needs CReLU NB8 engine | — | UNPROVEN — DONE; md5 dc639f3b; not packed |
| n256-screlu-ob8 (GPU) | 2026-10-15 22:55→ | same | 768->256 x2->8 SCReLU NB8 | init screlu-c 2e-4 8ep select holdout | start holdout 0.002762 | needs screlu2ob8 | — | UNPROVEN — training Idle/F000 |
| n128-screlu-ob4 (box) | 2026-10-15 22:04→ | data_mix_d40forge | 768->128 x2->4 SCReLU NB4 | scratch 1e-3 10ep | ep5 shared 0.008760 (bar 0.008582) | — | — | UNPROVEN — training |

### 2026-10-15 ~23:08 PT — n256-forgeall-ob8 ep7 exported (UNPROVEN)
- Strategist request: export ep7 too, so Coder can gate both ep4 and ep7. Strategist leans to ep7 if only one gets a slot. Both are on HOLD behind n256screlu.
- Exported with a one-off script, PC `nnue\_export_ep.py`, which uses the same quantization as train_gpu.py (Idle/0xF000, 4 threads). The script reproduces ep4 as dc639f3b exactly.
- PC `nets\n256-forgeall-ob8\net_v3_ep7.nnue` and box `nets/n256-forgeall-ob8/net_v3_ep7.nnue`: GKNN v3, act 0, H256, NB8, 401,972 bytes, md5 **d98e9e93**c3a007a378a6129a5950b678 (box md5 matches PC).

| n256-forgeall-ob8 ep7 | 2026-10-15 23:08 | data40m+forgepgn+forge_holdout | 768->256 x2->8 CReLU NB8 | ep7 of 8, init d0e1c9f0 5e-4 | data40m **0.008459** (lock 0.008525); holdout 0.002965* | needs CReLU NB8 engine | — | UNPROVEN — md5 d98e9e93; not packed; HOLD |

### 2026-10-15 ~23:50 PT — n256-screlu-ob8 DONE (GPU) + n128-screlu-ob4 DONE (box) (all UNPROVEN)
- **n256-screlu-ob8 DONE** 23:33 PT (8/8 ep, select = forge holdout, init screlu-c d1294716, lr 2e-4). Best **ep1** holdout **0.002756** (init 0.002762, flat −0.2%); ep1 data40m 0.008425, forgepgn 0.003152, forge_sp_all 0.002630, shared 0.008191. Later epochs drift up on holdout but improve data40m/shared: **ep7** holdout 0.002823, data40m **0.008323** (lock 0.008525), forgepgn 0.003197, shared **0.008095**; ep8 0.002814 / 0.008326 / 0.008097. vs forgeall-ob8 (CReLU): better on every set.
- Exports (GKNN v3, act 1, H256, NB8, 401,972 B): ep1 `net_v3.nnue` (box copy `net_v3_ep1.nnue`) md5 **d4ddc9e4**59c30ab4a64cb9e6953134bd; ep7 `net_v3_ep7.nnue` md5 **5877e14c**78e10b06252a3eeff75ad88a. ep7 made with PC `nnue\_export_ep_act.py` (= _export_ep.py + act arg); it reproduces ep1 d4ddc9e4 exactly. net_best.pt md5 795b27de. Box md5s match PC.
- **n128-screlu-ob4 DONE** 23:32 PT (box, 10/10 ep): best ep10 shared-val **0.008651**, worse than n128-screlu-ob8 (0.008582) → ob8 > ob4 at H128. `nets/n128-screlu-ob4/net_v3.nnue` act 1 NB4. Not for packing.
- GPU and box slot now idle. Strategist queue: WDL reconvert (result + has-result flag, new files) → H256 WDL warm from best screlu.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n256-screlu-ob8 (GPU) | 2026-10-15 22:55→23:33 | data40m+forgepgn+forge_holdout | 768->256 x2->8 SCReLU NB8 | init screlu-c 2e-4 8ep select holdout | best ep1 holdout 0.002756; ep7 data40m **0.008323** (lock 0.008525), shared 0.008095 | needs screlu2ob8 | — | UNPROVEN — DONE; ep1 d4ddc9e4, ep7 5877e14c; not packed |
| n128-screlu-ob4 (box) | 2026-10-15 22:04→23:32 | data_mix_d40forge | 768->128 x2->4 SCReLU NB4 | scratch 1e-3 10ep | ep10 shared 0.008651 (ob8 0.008582) | — | — | UNPROVEN — DONE; loses to ob8; not packed |

## WDL reconvert + n128-screlu-ob8-wdl — UNPROVEN (started 2026-10-16 ~00:20 PT)
- Result encoding (format-compatible REC rsv bytes): rsv[0] bit0 = has_result; rsv[1] = WHITE-POV result 0=loss 1=draw 2=win; rsv[2]=0. Old files rsv==0 -> score-only. Trainer: result_stm = rsv[1]/2 (white to move) else 1-rsv[1]/2.
- convert_forge_wdl.py (copy of convert_forge.py; dedup key ignores score+rsv; new files only; STOP_nnue-aware).
- data_forgepgn_wdl: train 1,839,067 (md5 a9e54904c6bc132ed1932bfcb4d63f90) / val 18,576 (md5 004df63df12ae3ba1bc09dfc9406b8c5); identical to data_forgepgn except rsv; 100% has_result (W 549,290 / D 823,848 / L 484,505); mean white cp by result -262/+8/+278.
- data_mix_d40forge_wdl: data40m train (score-only, has_result 0) + data_forgepgn_wdl train = 41,379,994 rows (md5 ba18ed19a119c0f3b63744a113b9ac32); identical to data_mix_d40forge except rsv; val = val_shared (7bd6e227...).
- PC: build_forge_holdout_wdl.py -> D:\grok-pc-data\forge_holdout_wdl (same sources/md5, seed fho1, game ids; Idle/F000, STOP_nnue-aware) — IN PROGRESS, stats.json will hold ids_match_old/counts_match_old.
- train_ob.py: --result-w (blend only where has_result), --extra-val, --select; backup train_ob.py.bak_prewdl. Val losses are score-only (comparable to old bars).
- n128-screlu-ob8-wdl: train_ob.py data_mix_d40forge_wdl, H128 act1 ob8 lr1e-3 bs8192 10 ep, --result-w 0.2, select val+holdout, saves net_ep{N}.pt. PID 2251183, log logs/train_n128-screlu-ob8-wdl.log. Bar: shared 0.008582, holdout 0.004415. UNPROVEN.

### 2026-10-16 ~00:51 PT — NNUE hourly (UNPROVEN)
- Lock **1.7.45** net.md5 **d0e1c9f0** (n256forgeall).
- **Box** `n128-screlu-ob8-wdl` PID 2251183 nice19: ep5/10, shared-val **0.008717**, holdout **0.004505**, d40 0.008918 (bars shared 0.008582 / holdout 0.004415 — still above, trending down). Log `logs/train_n128-screlu-ob8-wdl.log`.
- **PC** `forge_holdout_wdl` DONE (ids_match_old/counts_match_old; train.md5 11099aed / val 5f075dc5). Forge SP ~19.0M healthy Idle/F000.
- **GPU idle** since n256-screlu-ob8 DONE 23:33; keep-going restarting H256 WDL warm (port `--result-w` into `train_gpu`, stage forgepgn_wdl/mix on D, launch `n256-screlu-ob8-wdl` Idle/F000 from screlu-ob8 `net_best`). Stale n128-d40-cont cmd ignored (not in queue).
- Pack HOLD unchanged: n256screlu-1745, screlu-ob8 ep7 **5877e14c**, forgeall-ob8 ep4/ep7.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n128-screlu-ob8-wdl (box) | 2026-10-16 ~00:20→ | data_mix_d40forge_wdl | 768->128 x2->8 SCReLU NB8 | scratch 1e-3 rw0.2 select val+holdout | ep5 shared 0.008717 / holdout 0.004505 | — | — | UNPROVEN — training |
| n256-screlu-ob8-wdl (GPU) | 2026-10-16 ~00:51→ | data40m+forgepgn_wdl+forge_holdout_wdl | 768->256 x2->8 SCReLU NB8 | warm screlu-ob8 2e-4 rw0.2 | pending start | needs screlu2ob8 | — | UNPROVEN — launching |


### 2026-10-16 ~02:05 PT — NNUE hourly (UNPROVEN)
- Lock **1.7.45** (d0e1c9f0). Push on (01:36 → ~13:36 PT Fri); QA owns all match slots.
- **Box n128-screlu-ob8-wdl DONE** ~01:49 PT (10/10 ep, rw 0.2, select val+holdout). Best ep10: shared **0.008609**, holdout **0.004555**, d40 0.008804. Bars (n128-screlu-ob8 score-only): shared 0.008582 / holdout 0.004415 → WDL loses on score-only val (expected partly, since rw blends results into the target; only an Elo test can judge WDL). Export `nets/n128-screlu-ob8-wdl/net_v3.nnue` act1 NB8, md5 2086b437. Not packed.
- **GPU lapse**: the 00:51 run logged "launching" but nothing started; GPU was idle 23:33 → 02:00 (~2.5 h). Fixed now.
- Ported `--result-w` into PC `train_gpu.py` (backup `train_gpu.py.bak_prewdl` f18739b8; new md5 6af604d0; box copy `pc_wdl/train_gpu_pc.py`). Blend only where rsv[0]&1; val losses stay score-only. CPU smoke test on box passed.
- Staged `D:\grok-pc-data\forgepgn_wdl` (train a9e54904 / val 004df63d, = box data_forgepgn_wdl).
- **GPU n256-screlu-ob8-wdl STARTED** 02:00 PT, PID 13920 Idle/0xF000: data40m + forgepgn_wdl + forge_holdout_wdl, H256 SCReLU NB8, init n256-screlu-ob8 net_best (ep1 d4ddc9e4), lr 2e-4, 8 ep, rw 0.2, select forge holdout, extra val forge_sp_all + val_shared. Start val 0.002756 (= ep1). ~227k pos/s, ~5 min/epoch. Launcher `start_n256_screlu_ob8_wdl.ps1`, log `logs\n256-screlu-ob8-wdl.log`.
- Box NNUE slot idle; next box ablation awaiting Strategist.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n128-screlu-ob8-wdl (box) | 2026-10-16 00:20→01:49 | data_mix_d40forge_wdl | 768->128 x2->8 SCReLU NB8 | scratch 1e-3 rw0.2 10ep | ep10 shared 0.008609 / holdout 0.004555 (bars 0.008582 / 0.004415) | — | — | UNPROVEN — DONE; loses on score-only val; not packed |
| n256-screlu-ob8-wdl (GPU) | 2026-10-16 02:00→ | data40m+forgepgn_wdl+forge_holdout_wdl | 768->256 x2->8 SCReLU NB8 | warm screlu-ob8 ep1 2e-4 rw0.2 8ep | start 0.002756 | needs screlu2ob8 | — | UNPROVEN — training |

## 2026-10-16 02:10 PT — GPU utilization audit (grok-pc, n256-screlu-ob8-wdl) — UNPROVEN, no change
- 60 s sample: GPU compute ~16-20%, 3D ~0%, VRAM ~1.1-1.3 GB of 20 GB. Total CPU 100%.
- Bottleneck: CPU-side feats()/dense one-hot build in train_gpu.py (torch 2 threads), sharing CPUs 12-15 with Forge self-play's 2 workers (each ~13k CPU-s vs trainer ~316 CPU-s). ~225k pos/s, ~252 s/epoch.
- No GPU temps readable (no AMD tools / sensors exposed) -> no load added. No second job (would exceed 4-thread cap). Running PID 12180 untouched (Idle/F000).
- Proposed fix (next run, not the current one): preload train set + GPU-side featurization, larger batch (bs 32768, lr x2), so the GPU no longer waits on CPU.

### 2026-10-16 ~02:13 PT — Box ablation n128-screlu-ob8-sp (Strategist pick) — UNPROVEN
- Clone of n128-screlu-ob8 (data_mix_d40forge, H128, act=1 SCReLU, NB8, 10ep, lr 1e-3, bs 8192, score-only rw 0, rng seed 0 / torch unseeded as before) with ONE change: each 8192 batch = 4096 base rows (original ob8 mix, contiguous chunks as before) + 4096 rows drawn uniformly at random from the game-split Forge SP **train side** `data_forge_holdout_train/train.bin` (15,272,952 rows, md5 454441d709183ca4f6385c9098cf6de7 = PC D:\grok-pc-data\forge_holdout\train.bin; holdout games excluded). Steps/epoch kept = len(base)//8192 (same compute/schedule as ob8; each epoch sees a random half of the base chunks).
- New train_ob.py options `--sp-data` / `--sp-frac` (backup `train_ob.py.bak_presp`). patience 10 so all 10 epochs run; net_ep{N}.pt saved every epoch.
- Vals every epoch: shared-val (data_mix_d40forge/val.bin, md5 7bd6e227), holdout (data_forge_holdout/val.bin, md5 325c3f33), data40m. Select = shared+holdout. Bar: ob8 shared 0.008582 / holdout 0.004415.
- No newer SP positions added (would need holdout-id-filtered reconvert of the fresh snapshot; not done).
- Cmd: `run_n128_sp.sh` (nice 19, TZ LA, max-load 4), PID 3181723, log `logs/train_n128-screlu-ob8-sp.log`.

| n128-screlu-ob8-sp | 2026-10-16 02:13→ | data_mix_d40forge + 50% forge_holdout train | 768->128 x2->8 SCReLU NB8 | scratch 1e-3 10ep | bar shared 0.008582 / holdout 0.004415 | — | not tested | UNPROVEN — training PID 3181723 |

## 2026-10-16 02:40 PT — train_gpu2.py (GPU-resident data trainer) + n256-screlu-ob8-wdl final + n256-screlu-ob8-sp launch (all UNPROVEN)
- **train_gpu2.py** (new, grok-pc `nnue\train_gpu2.py`; box copy `gpu2/train_gpu2.py`; train_gpu.py untouched). Records loaded once into VRAM as int16[N,16]; features/shuffle/batching on GPU (DML has no right_shift → floor-div on 16-bit halves). Default bs 32768, lr 2e-3. Adds `--weights` (per-batch share per --data set), `--export-only`, `--parity`. Saves net_ep<N>.pt every epoch.
  - Parity vs train_gpu.py on 8192 rows each of data40m/forgepgn_wdl/forge_holdout_wdl, same net (n256-screlu-ob8 ep1): all 7 feature tensors max diff 0; loss identical (score-only and WDL w=0.2), rel diff 0.0.
  - Export parity: train_gpu2 --export-only and train_gpu.py --epochs 0 on net_ep1.pt → both md5 d4ddc9e459c30ab4a64cb9e6953134bd (= existing _chk_ep1.nnue).
  - Throughput: ~418k pos/s full run (old ~200-245k/s), GPU Engine compute avg 34.2% (min 29, max 37) over 60 s (old ~18%). Remaining limiter: Adam lerp falls back to CPU on DML + per-step sync.
- **n256-screlu-ob8-wdl** (PID 12180, train_gpu.py, rw 0.2, warm n256-screlu-ob8 net_best, lr 2e-4, 8 ep) finished ~02:33 PT. Holdout (select) never beat start 0.002756: ep1 0.003354 … ep8 0.003397. ep7: data40m 0.008279, forgepgn 0.003613, forge_sp_all 0.003238, shared 0.008071. Exported best = epoch 0 = start weights (md5 d4ddc9e4, i.e. no new net). Not packed. Per-epoch nets in nets/n256-screlu-ob8-wdl/net_ep*.pt.
- **n256-screlu-ob8-sp** launched 02:35 PT with train_gpu2.py: score-only (rw 0), warm n256-screlu-ob8 ep1 (d4ddc9e4), lr 4e-4 @ bs 32768, 8 ep, patience 99, batch mix 50% forge_holdout_wdl/train (game-split train side) + 47.7% data40m + 2.3% forgepgn_wdl; select on forge holdout val, also logs data40m, forgepgn, forge_sp_all, val_shared. Newer SP beyond the holdout split NOT included (no game-id-filtered newer file exists yet). PIDs cmd 7860 → venv py 4492 → python 11768, all Idle / affinity 0xF000. Log logs\train_n256-screlu-ob8-sp.log. ~135 s/epoch (~20 min total).

## 2026-10-16 ~02:56 PT — NNUE hourly (all UNPROVEN)
- **n256-screlu-ob8-sp (GPU, train_gpu2.py) DONE** 02:52 PT. Score-only, warm n256-screlu-ob8 ep1 (d4ddc9e4), lr 4e-4 bs 32768, 8 ep, 50% forge_holdout_wdl train side. Best = ep7: forge holdout val 0.002325 (start 0.002756, -16%), shared 0.008360 (n256-screlu-ob8 ep7 was 0.008095, so worse on shared), forge_sp_all 0.002159. ~450k pos/s. Export net_v3.nnue md5 fb2d5425904bc7ae32facf75c626a3c1 (act 1 NB8, grok-pc nets\n256-screlu-ob8-sp\). Not packed. Mixed signal: big holdout gain, shared-val loss.
- grok-pc: train_gpu3.py (GPU-side Adam) optimizer parity PASS (loss maxrel 2.3e-7). forge_sp_new_train built: 6,911,538 rows, holdout leaks 0, md5 4493f1e3. Smoke run smoke_g3_32k (train_gpu3, warm sp ep7, 4 sets incl. sp_new) running at ~545k pos/s, Idle/0xF000.
- Box n128-screlu-ob8-sp PID 3181723 at ep4: shared 0.009228 / holdout 0.002403 (bar 0.008582 / 0.004415): holdout well past bar, shared still behind; ETA ~03:35 PT.

| n256-screlu-ob8-sp (GPU) | 2026-10-16 02:35→02:52 | data40m + forge_holdout_wdl train 50% + forgepgn_wdl | 768->256 x2->8 SCReLU NB8 | warm 4e-4 bs32k 8ep score-only | ep7 holdout 0.002325 / shared 0.008360 | needs screlu2ob8 | — | UNPROVEN — DONE, md5 fb2d5425, not packed |

## 2026-10-16 03:05 PT — grok-pc GPU (all UNPROVEN)
- **n256-screlu-ob8-sp** (PID 11768, train_gpu2, done 02:54 PT): warm d4ddc9e4 (n256-screlu-ob8 ep1), 50% forge_holdout_wdl train + data40m/forgepgn, score-only, 8 ep, lr 4e-4, select holdout.
  Per epoch (holdout / data40m / shared / forge_sp_all[contam]): start 0.002756 | ep1 0.002383/0.008658/0.008401/0.00224 | ep2 0.002355/0.008661/0.008404 | ep3 0.002336/0.008628/0.008371 | ep4 0.002334/0.008628/0.008371 | ep5 0.002326/0.008620/0.008363 | ep6 0.002328/0.008616/0.008359 | **ep7 0.002325/0.008617/0.008360 (best)** | ep8 0.002326/0.008615/0.008358.
  Export ep7 net_v3.nnue md5 fb2d5425904bc7ae32facf75c626a3c1 (pt 73a460a4…). Note: holdout drop partly reflects 50% same-source SP data; shared 0.008360 vs screlu-ob8 ep7 0.008095 shared is WORSE on shared. Not packed.
- **forge_sp_new_train** (D:\grok-pc-data\forge_sp_new_train, build_forge_sp_new.py): 004 rows past snap + 005.part snapshot, same game-boundary ids; 6,911,538 rows, WDL rsv (all has_result), md5 4493f1e34b2f4e38bf9cfaae6c1e12c9; 83,846 new games, holdout games excluded 0 (0 overlap), leak/dup/already-in-train dropped 0. val.bin = dummy 16k rows of train (not a holdout).
- **train_gpu3.py**: copy of train_gpu2 with on-GPU hand-written Adam (GAdam). Parity vs torch Adam CPU, 50 steps, fixed 8192-row batch, H256 SCReLU ob8, lr 1e-3: weights maxrel 3e-6..2.4e-5 (ft; ≤5e-6 of elements >1e-5), loss maxrel ≤2.4e-7 → PASS (one early run showed 2.2e-3 on isolated ft elements: Adam sign-noise on ~0 grads).
  Throughput (DML compute util): gpu2 bs32k 450k pos/s ~31%; gpu3 bs32k 550k ~44%; bs64k 559k ~40%; bs128k 538k ~37%.
- **n256-screlu-ob8-sp2** started 03:01 PT, train_gpu3 bs32768 lr 4e-4, warm sp ep7, weights data40m .477 / forgepgn .023 / forge_holdout_wdl .344 / forge_sp_new_train .156, score-only, 8 ep, select holdout, logs all vals. python PID 13768 (parent 11432, cmd 7844) Idle/0xF000. 60 s util avg 45.8% (34–48), ~590k pos/s. ETA ~03:25 PT.

- 2026-10-16 ~03:10 PT **n256-screlu-ob8-sp25** — UNPROVEN, training on PC GPU concurrently with sp2 (PID 13768). Script train_gpu3s.py (= train_gpu3 + `--select-add`; select metric = forge_holdout_wdl val + val_shared, summed). Warm from nets\n256-screlu-ob8\net_ep7.pt (export 5877e14c); score-only rw 0; bs 32768, lr 4e-4, 8 ep, every epoch saved; mix data40m 0.70 / forgepgn_wdl 0.05 / forge_holdout_wdl 0.17 / forge_sp_new_train 0.08; --chunk 3000000. PID 13560 (child 13796) Idle, 0xF000. ep1: holdout 0.002832, shared 0.008117, data40m val 0.008348 (ep7 reference: shared 0.008095). Combined GPU util ~87% vs ~42% for sp2 alone.

### 2026-10-16 ~03:56 PT — NNUE hourly (all UNPROVEN)
- Lock **1.7.46** (same net.md5 **d0e1c9f0** as 1.7.45). Push on until ~13:36 PT Fri. Box rebooted ~03:37 PT (uptime was ~15–18 min at check); NNUE `venv/` was missing and was recreated (torch 2.14.1+cpu).
- **Box n128-screlu-ob8-sp** interrupted at ep9/10 by reboot. Best ep9 shared **0.009078** / holdout **0.002368** / d40 0.009364 (bars shared 0.008582 / holdout 0.004415). Exported `nets/n128-screlu-ob8-sp/net_v3.nnue` md5 **eb0126ed**. Shared much worse → **FAIL, not packed**.
- **GPU n256-screlu-ob8-sp2 DONE** ~03:18: best ep8 holdout **0.002276** / shared **0.008328** / d40 ~0.008586; export md5 **a28bc822**. Shared worse than screlu-ob8 ep7 (0.008095) → not packed.
- **GPU n256-screlu-ob8-sp25 DONE** ~03:38 (finished after thermal stop of concurrent run): select=holdout+shared, data40m-heavy mix. Best ep8 shared **0.008048** (beats screlu-ob8 ep7 **0.008095**), d40 **0.008277**, forge_sp_all 0.002682, implied holdout ~0.002808. Export md5 **4260c1f2**. **Best shared so far among recent H256 SCReLU runs — HOLD for pack once screlu2ob8 path is ready; not packed this hour.**
- **GPU was idle**; idle temps ~GPU 47 / memJ 70 / hotspot ~50–54. Thermal guard PID 1800 + HWiNFO alive. STOP_nnue absent. Started **one** job `n256-screlu-ob8-sp25c` PIDs **13908/8600** Idle/F000 (warm sp25, lr 2e-4, weights 0.65/0.05/0.15/0.15, select-add shared). No second job (memJ hits ~89–90 under one trainer).
- Forge SP healthy Idle/0xF000 ~**22.88M** pos @ ~1.27M/h. D: **165.5 GB** free.
- Box NNUE slot idle (load ~2.8); awaiting Strategist next ablation after SP FAIL.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n128-screlu-ob8-sp (box) | 2026-10-16 02:13→~03:35 | mix + 50% forge_holdout train | 768->128 x2->8 SCReLU NB8 | scratch 1e-3 9/10 ep | ep9 shared 0.009078 / holdout 0.002368 | — | — | UNPROVEN — FAIL shared; md5 eb0126ed; not packed |
| n256-screlu-ob8-sp2 (GPU) | 2026-10-16 03:01→03:18 | data40m+holdout+sp_new | 768->256 x2->8 SCReLU NB8 | warm sp ep7 4e-4 bs32k | ep8 holdout 0.002276 / shared 0.008328 | needs screlu2ob8 | — | UNPROVEN — DONE; md5 a28bc822; not packed |
| n256-screlu-ob8-sp25 (GPU) | 2026-10-16 03:10→03:38 | data40m 0.70 + SP mix | 768->256 x2->8 SCReLU NB8 | warm ob8 ep7 4e-4 select-add shared | ep8 shared **0.008048** / d40 0.008277 | needs screlu2ob8 | — | UNPROVEN — DONE; md5 4260c1f2; HOLD pack |
| n256-screlu-ob8-sp25c (GPU) | 2026-10-16 ~03:59→ | warm sp25; 0.65/0.05/0.15/0.15 | 768->256 x2->8 SCReLU NB8 | lr 2e-4 8ep select-add shared | training | needs screlu2ob8 | — | UNPROVEN — RUNNING PIDs 13908/8600 Idle/F000 |


### 2026-10-16 ~04:02 PT — Box ablation n128-screlu-ob8-sp15 (Strategist pick) — UNPROVEN
- Clone of n128-screlu-ob8 / run_n128_sp.sh with ONE change: `--sp-frac 0.15` (was 0.5). Same: data_mix_d40forge, H128, act=1 SCReLU, NB8, 10ep, lr 1e-3, bs 8192, score-only rw 0, patience 10, select val+holdout, extra-val holdout+data40m. SP train side `data_forge_holdout_train/train.bin` md5 **454441d7**. Per batch 6963 base + 1229 sp. Bar: shared 0.008582.
- Preflight after ~03:37 reboot: venv recreated (torch 2.14.1+cpu); installed `chess` for signcheck; data md5s OK (sp-train 454441d7, mix train 2b43322b, mix/shared val 7bd6e227). Load at start ~3.2 (<4).
- Cmd: `run_n128_sp15.sh` (nice 19, TZ LA, max-load 4), PID **54326**, log `logs/train_n128-screlu-ob8-sp15.log`. Out `nets/n128-screlu-ob8-sp15`. Every epoch saved.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n128-screlu-ob8-sp15 | 2026-10-16 04:02→ | data_mix_d40forge + 15% forge_holdout train | 768->128 x2->8 SCReLU NB8 | scratch 1e-3 10ep | bar shared 0.008582 | — | not tested | UNPROVEN — training PID 54326 |

### 2026-10-16 03:20–03:36 PT — backfill (missing entry) — UNPROVEN
- sp2 (n256-screlu-ob8-sp2) md5 a28bc822: holdout 0.002276 / shared 0.008328 — not packed. UNPROVEN.
- Thermal guard started, PID 1800 (trips hot spot 88 / mem junction 94 / edge 82).
- sp25 (n256-screlu-ob8-sp25) md5 4260c1f2: shared 0.008048 / d40 0.008277. UNPROVEN.
- One-job GPU temps: edge 65 / hot spot 74 / mem junction 89–90 °C → over the ≤88 mem-junction bar for a second job, so the second job was stopped.

### 2026-10-16 ~04:09 PT — PACK n256-screlu-ob8-sp25 on 1.7.46 — UNPROVEN
- Dist: `/workspace/chess-engine-nnue/dist-cand-n256sp25-1746` = copy of Coder's `chess-engine/dist-cand-n256fob8e7-1746` (screlu2ob8 patch f56faaa3), only net.nnue replaced (nnue.js loads `<dist>/net.nnue`; no embedded net).
- net.nnue md5 **4260c1f24c50712efbf39129154956ea** (GKNN v3 act=1 NB8, from nets/n256-screlu-ob8-sp25/net_v3.nnue). js-tree md5 (sorted *.js) **0db67462** = identical to Coder's dir; lock 1.7.46 js-tree 654484ce, net d0e1c9f0.
- Gates (nice 19, TZ LA, CPUs 0-7; log chess-engine-nnue/gates_sp25_1746.log): perft PASS, movegen 36/36, tactics 6/6, mate suite ALL PASS, mate_distance 5/5 PASS, uci_edge 27/27, draw_rules PASS, insufficient_material 5 FAIL all KNOWN, ep_repetition 1 FAIL KNOWN, label sign PASS. Fuzz/TL/krk of bug_gate.sh NOT run (they use fastchess) — QA to do.
- Bench d9: 167895 nodes, ~281k NPS vs lock 220563 nodes, ~354k NPS (−20.6% NPS; 2 runs each, load ~4).

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n256-screlu-ob8-sp25 → dist-cand-n256sp25-1746 | 2026-10-16 04:09 | data40m 0.70 + SP mix | 768->256 x2->8 SCReLU NB8 | warm ob8 ep7 4e-4 | shared 0.008048 / d40 0.008277 | −20.6% (bench d9) | not tested | UNPROVEN — PACKED, gates PASS (fuzz pending QA) |
- **ep1–8** (still training PID 54326): ep1 shared 0.009444 / holdout 0.003597; ep8 shared **0.008667** / holdout **0.003321** / data40m **0.008902** (bar shared 0.008582). Still above bar; ETA ~2 ep.

### 2026-10-16 ~04:54 PT — NNUE hourly — UNPROVEN
- Lock **1.7.46** (net **d0e1c9f0**). Push until ~13:36 PT Fri. STOP_nnue absent (box+PC).
- **GPU n256-screlu-ob8-sp25c DONE** ~04:14: warm sp25, lr 2e-4, weights 0.65/0.05/0.15/0.15. Shared stuck ~0.008076–0.0081; best export was **epoch 0** (init). net_v3.nnue md5 **4260c1f2** (= sp25, no new weights). **FAIL improve, not packed.**
- **GPU was idle** at check; idle HWiNFO ~04:56: GPU edge **45** / memJ **66** / hotspot **47** °C. D: **165.4 GB** free. Forge SP still running (selfplay_guard + forge_selfplay workers). Thermal guard/HWiNFO up.
- Started **one** next job **n256-screlu-ob8-sp80** (warm sp25, weights 0.80/0.05/0.10/0.05 data40m-heavy, lr 3e-4, 8ep, select-add shared). No second job.
- Box **n128-screlu-ob8-sp15** ep9 shared **0.008660** / holdout 0.003289 (bar 0.008582), load ~3.6, nice 19, 1 ep left. Packed cand still `dist-cand-n256sp25-1746` (4260c1f2, gates PASS, bench −20.6% NPS) awaiting Profiler/QA. All UNPROVEN.
- **GPU n256-screlu-ob8-sp80** launched ~04:57 PIDs **10812/12016**; under load temps ~GPU 53 / memJ 78 / hotspot 60.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n256-screlu-ob8-sp25c (GPU) | 2026-10-16 03:59→04:14 | 0.65/0.05/0.15/0.15 | 768->256 x2->8 SCReLU NB8 | warm sp25 2e-4 8ep | shared ~0.008076 (best ep0=sp25) | — | — | UNPROVEN — FAIL improve; md5 4260c1f2 (=sp25); not packed |
| n256-screlu-ob8-sp80 (GPU) | 2026-10-16 ~04:57→ | 0.80/0.05/0.10/0.05 | 768->256 x2->8 SCReLU NB8 | warm sp25 3e-4 8ep | training | needs screlu2ob8 | — | UNPROVEN — RUNNING PIDs 10812/12016 Idle/F000 |
| n128-screlu-ob8-sp15 (box) | 2026-10-16 04:02→ | mix + 15% forge_holdout | 768->128 x2->8 SCReLU NB8 | scratch 1e-3 | ep9 shared 0.008660 / holdout 0.003289 | — | — | UNPROVEN — training PID 54326; above bar 0.008582 |

### 2026-10-16 ~05:10 PT — n128-screlu-ob8-sp15 DONE (UNPROVEN)
- Finished 10/10 epochs. Best shared-val **0.008647** (ep10) vs bar **0.008582** (n128-screlu-ob8) → **MISSED** (+0.75%). ep10 holdout/data40m in log. Export nets/n128-screlu-ob8-sp15/net_v3.nnue (selected on val+holdout, ep10). SP-share series done at H128. Not packing. UNPROVEN.
- **Launched n128-screlu-ob8-cos** (PID 126873, run_n128_cos.sh): original n128-screlu-ob8 command + `--lr-sched cos` (trainer COPY train_ob_cos.py; live train_ob.py default was StepLR(epochs//3, 0.3), not cos). Cosine per-epoch from 1e-3 (1.0x ep1) to 0.05x at ep10. Same epochs/pat2/unseeded; saves every epoch. Added eval-only `--extra-val holdout,data40m` (selection still on shared val). Bar shared 0.008582. UNPROVEN.
- n128-screlu-ob8-cos **ep1** (14:17 PT): shared 0.009347, holdout 0.004621, data40m 0.009570, train 0.010345 (orig ob8 ep1 'val': 0.009370596588364869). UNPROVEN — training PID 126873.

### 2026-10-16 ~05:55 PT — NNUE hourly (all UNPROVEN)
- Lock still **1.7.46** (net **d0e1c9f0**). `baseline/dist-v1.7.47` exists as staged cut candidate (net **5877e14c** = n256-screlu-ob8 ep7) but QUEUE says **not cut yet** (pcE n256screluob8e7 near H1). Push until ~13:36 PT Fri. STOP_nnue absent (box).
- **Box n128-screlu-ob8-sp15 DONE** earlier (~05:10): best shared **0.008647** vs bar **0.008582** → MISSED; export md5 **e5c55b78**. Not packed.
- **Box n128-screlu-ob8-cos RUNNING** PID **126873** nice19 max-load4: ep3 shared **0.008885** / holdout 0.004562 / d40 0.009091 (bar 0.008582). Box load ~5.1–5.5 (QA SPRTs pcsf+ttcuthist2 + cos); trainer self-throttles at max-load 4.
- Packed HOLD unchanged: `dist-cand-n256sp25-1746` net **4260c1f2** shared **0.008048**, js-tree **0db67462** (= staged 1.7.47 / screlu2ob8; ≠ lock 1.7.46 js **654484ce**). Gates PASS earlier; bench −20.6% NPS vs 1.7.46. On a 1.7.47 cut this becomes **net-only** vs lock.
- **GPU n256-screlu-ob8-sp80 DONE** ~05:13 PT: warm sp25, weights 0.80/0.05/0.10/0.05, lr 3e-4, select-add shared. Best ep8 shared **0.007933** (beats sp25 **0.008048** and screlu-ob8 ep7 **0.008095**). Export md5 **248f6fd8**.
- **PACKED** `dist-cand-n256sp80-1746` (js-tree 0db67462 = screlu2ob8 / staged 1.7.47). Gates PASS (insuf 5 + ep 1 KNOWN fails). Bench d9 vs 1.7.46 (load~4.5 noisy): cand 152369 nodes ~263k/221k NPS; lock 220563 ~309k/274k → about **−15% to −19%** NPS (within 25%).
- **GPU n256-screlu-ob8-sp90 RUNNING** PIDs 12492/8712 Idle/F000 (warm sp80, weights 0.90/0.03/0.05/0.02, lr 2.5e-4). Forge SP up. STOP_nnue absent. D:~165 GB. Temps idle-ish at launch.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n128-screlu-ob8-sp15 (box) | 2026-10-16 04:02→~05:10 | mix + 15% forge_holdout | 768->128 x2->8 SCReLU NB8 | scratch 1e-3 10ep | best shared **0.008647** (bar 0.008582) | — | — | UNPROVEN — DONE MISSED; md5 e5c55b78; not packed |
| n128-screlu-ob8-cos (box) | 2026-10-16 ~05:10→~07:00 | data_mix_d40forge | 768->128 x2->8 SCReLU NB8 | scratch 1e-3 cos 10ep | best ep10 shared **0.008480** (holdout 0.004486, data40m 0.008675) | — | — | UNPROVEN — DONE; beats n128 bar 0.008582 (vs ob8 step-LR); cos helps at H128 |
| n256-screlu-ob8-sp80 (GPU) | 2026-10-16 04:57→05:13 | 0.80/0.05/0.10/0.05 | 768->256 x2->8 SCReLU NB8 | warm sp25 3e-4 8ep | shared **0.007933** | −15..−19% (noisy) | not tested | UNPROVEN — PACKED dist-cand-n256sp80-1746 md5 248f6fd8 |
| n256-screlu-ob8-sp90 (GPU) | 2026-10-16 ~05:58→ | 0.90/0.03/0.05/0.02 | 768->256 x2->8 SCReLU NB8 | warm sp80 2.5e-4 8ep | training | needs screlu2ob8 | — | UNPROVEN — RUNNING Idle/F000 |

### 2026-10-16 ~06:00 PT — PACK n256-screlu-ob8-sp80 on screlu2ob8 JS — UNPROVEN
- Dist: `/workspace/chess-engine-nnue/dist-cand-n256sp80-1746` = copy of sp25 cand tree, net replaced.
- net.nnue md5 **248f6fd830c7f953aaf775cc0c8518c5** (GKNN v3 act=1 NB8). Shared-val **0.007933** (best recent H256).
- Gates (nice 19, TZ LA; log gates_sp80_1746.log): perft PASS, movegen PASS, tactics PASS, mate suite ALL PASS, mate_distance 5/5, uci_edge 27/27, draw_rules PASS, insufficient_material 5 FAIL KNOWN, ep_repetition 1 FAIL KNOWN. No fastchess.
- Bench d9 (bench.js, 2 runs, load~4.5): cand nodes 152369 nps ~263k/221k; lock 1.7.46 nodes 220563 nps ~309k/274k. NPS loss ~15–19% (bar 25%). Profiler ABBA still needed.
- Vs lock 1.7.46 this is **code+net** (js 0db67462 ≠ 654484ce). If QA cuts 1.7.47 (net 5877e14c on same JS), this becomes **net-only**.


### 2026-10-16 ~06:56 PT — NNUE hourly (all UNPROVEN)
- Lock **1.7.47** (baseline/dist-v1.7.47, net **5877e14c** = n256-screlu-ob8 ep7, js 0db67462). QA queue mentions an upcoming "accroot" lock for [0,10]; not cut on disk yet. Push until ~13:36 PT Fri. STOP_nnue absent (box + PC).
- **GPU n256-screlu-ob8-sp90 DONE** 06:12 PT (warm sp80, weights 0.90/0.03/0.05/0.02, lr 2.5e-4, 8 ep, gadam, ~560-640k pos/s). Shared-val ep1 0.007897 → ep7/ep8 **0.007851** (beats sp80 **0.007933**, −1.0%). forge_sp_all extra-val drifted up 0.003479 (ep1) → 0.003558 (ep8) — watch: shared gain may trade off self-play-style positions. Export (ep8 best val+shared) net_v3.nnue md5 **d1e821d4** (d1e821d427a87a9f9cb6ea3d2b59900f), 401972 B. Copied to box nets/n256-screlu-ob8-sp90/.
- **PACKED** `/workspace/chess-engine-nnue/dist-cand-n256sp90-1747` = cp -rp dist-v1.7.47 + net replaced; diff vs lock = net.nnue only. Gates running (gates_sp90_1747.sh/.log).
- GPU sat idle 06:12→06:58 (~45 min gap between hourly runs). **GPU n256-screlu-ob8-sp95 RUNNING** from 06:58 PT, PIDs 12064/5772 Idle/F000 (warm sp90, weights 0.95/0.01/0.03/0.01, lr 2e-4, 8 ep; start_n256_screlu_ob8_sp95.ps1). ~630k pos/s. HWiNFO running.
- **Box n128-screlu-ob8-cos** PID 126873 ep8 shared **0.008513** (beats H128 bar 0.008582, −0.8%) / holdout 0.004532 / d40 0.008706. H128 only; not a candidate vs H256 lock (info for H128/SMP-speed fallback). Load ~3.9.
- KB/HM spec written (KB_HM_SPEC.md, GKNN v4) and kbtest/ lock_kb1/kb4/kb4hm test files exist; no KB net trained yet.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n256-screlu-ob8-sp90 (GPU) | 2026-10-16 05:58→06:12 | 0.90/0.03/0.05/0.02 | 768->256 x2->8 SCReLU NB8 | warm sp80 2.5e-4 8ep | shared **0.007851** | net-only (same JS) | not tested | UNPROVEN — PACKED dist-cand-n256sp90-1747 md5 d1e821d4 |
| n256-screlu-ob8-sp95 (GPU) | 2026-10-16 06:58→ | 0.95/0.01/0.03/0.01 | 768->256 x2->8 SCReLU NB8 | warm sp90 2e-4 8ep | training | — | — | UNPROVEN — RUNNING Idle/F000 |
| n128-screlu-ob8-cos (box) | 2026-10-16 ~05:10→ | data_mix_d40forge | 768->128 x2->8 SCReLU NB8 | scratch 1e-3 cos 10ep | ep8 shared 0.008513 | — | — | UNPROVEN — RUNNING PID 126873 |
- **sp90-1747 gates** (07:00 PT, nice 19, gates_sp90_1747.log): perft PASS, movegen PASS, tactics PASS, mate suite ALL PASS, mate_distance 5/5 ALL PASS, draw_rules PASS, uci_edge 27/27, insufficient_material 5 FAIL KNOWN (same as lock/sp80), ep_repetition 1 FAIL KNOWN. No fastchess.
- Bench d9 H16 (research/prof1746_sp25/bench_hash.js, 2 runs, load ~4): sp90 nodes 189762, 298k/327k NPS; sp80-1747 152394, 295k/302k; lock 1.7.47 219395, 346k/334k. Same JS as lock, so the gap is net-shaped search only: about −5% to −14% NPS (bar 25%). UNPROVEN.
| n256-screlu-ob8-hm (box) | 2026-10-16 07:2x→ | data_mix_d40forge | 768->256 x2->8 SCReLU NB8, HM=1 KB=1 (v4) | warm sp90 v3 (d1e821d4) via train_kb2.py --init-v3, 3e-4 cos 8ep, pat 3 | start val 0.010439 (unmirrored init); ep1 (791 s) val 0.008259, holdout 0.004330, data40m 0.008447 — data_mix val, NOT the shared-val metric of sp90 0.007851; score with val_shared before comparing | — | — | UNPROVEN — RUNNING PID 261254 (run_n256_hm.sh, logs/train_n256-screlu-ob8-hm.log) |
- **train_kb2.py** (07:2x PT) = train_kb.py + `--init-v3` (dequant GKNN v3/v4: ft/QA, out_w/QB, out_b/(QA*QB)) + `--lr-sched cos` (train_ob_cos.py lambda). test_initv3.py: float dequant vs ref_eval_v4 on 20 FENs, max |diff| 0.98 cp PASS. UNPROVEN.
- **gpu2/train_gpu3kb.py** = grok-pc train_gpu3s.py + --hm/--kbuckets (dense GPU kbx(), KB_HM_SPEC math) + --init-v3 + --lr-sched cos + v4 export when KB>1/HM. gpu2/test_gpu3kb_feats.py (box CPU, 4000 rows): features identical to train_kb.py for kb1/kb1hm/kb4/kb4hm (maxdiff 0). NOT copied to / launched on grok-pc; queued after sp95. UNPROVEN.

### 2026-10-16 ~07:55 PT — NNUE hourly (all UNPROVEN)
- Lock **1.7.47** (net 5877e14c) is still the newest baseline on disk. Push until ~13:36 PT Fri. STOP_nnue absent (box + PC). Box load ~4.3 (QA matches); box trainer self-throttles at max-load 4.
- **GPU n256-screlu-ob8-sp95 DONE** 07:12 PT (warm sp90, weights 0.95/0.01/0.03/0.01, lr 2e-4, 8 ep, ~645k pos/s). Shared-val ep1 0.007853 → ep7/ep8 **0.007822** (−0.4% vs sp90 0.007851), BUT forge_sp_all extra-val **0.003871 → 0.003961** (sp90 was 0.00348–0.00356, ~+11% worse). Export ep8 net_v3.nnue md5 **9126db97** (9126DB97EB571D9F131AF2A32113DB84), on PC nets\n256-screlu-ob8-sp95\. **NOT PACKED**: tiny shared gain bought with a clear regression on self-play-style positions; data40m weighting looks saturated. sp90 (d1e821d4) stays the best packed candidate.
- GPU idle 07:12 → 07:52 PT (~40 min gap again between hourly runs).
- **GPU n256-screlu-ob8-hmg RUNNING** from 07:52 PT, PIDs 7516/12180 Idle/F000 (start_n256_screlu_ob8_hmg.ps1). Trainer train_gpu3kb.py md5 743ca859 copied from box gpu2/ (base train_gpu3s.py md5 a4db22e6 identical box/PC). HM=1 KB=1, --init-v3 sp90 net_v3 (d1e821d4), sp90 weights 0.90/0.03/0.05/0.02, lr 3e-4 cos, 8 ep. DML falls back to CPU for addmv (king-square calc) → ~375k pos/s, ~23 min, ETA ~08:16 PT. Start val 0.0211 (unmirrored init). ep1 shared **0.007853**, forge_sp_all **0.003871**.
- **Box n256-screlu-ob8-hm** PID 261254 (train_kb2.py, same idea on box data_mix): ep1 val 0.008259 → ep2 **0.008116** (data_mix val; eval_checkpoint.py can't score HM/ob8 on shared, so GPU hmg gives the comparable shared number). ~13–14 min/epoch, ETA ~09:10 PT.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n256-screlu-ob8-sp95 (GPU) | 2026-10-16 06:58→07:12 | 0.95/0.01/0.03/0.01 | 768->256 x2->8 SCReLU NB8 | warm sp90 2e-4 8ep | shared **0.007822**; forge_sp_all 0.003961 (worse) | — | not tested | UNPROVEN — DONE, NOT PACKED (self-play regression); md5 9126db97 |
| n256-screlu-ob8-hmg (GPU) | 2026-10-16 07:52→ | 0.90/0.03/0.05/0.02 | 768->256 x2->8 SCReLU NB8 HM=1 KB=1 (v4) | init-v3 sp90, 3e-4 cos 8ep | ep1 shared 0.007853 | needs HM JS | — | UNPROVEN — RUNNING Idle/F000 |
| n256-screlu-ob8-hm (box) | 2026-10-16 07:2x→ | data_mix_d40forge | as above | init-v3 sp90, 3e-4 cos 8ep | ep2 mix-val 0.008116 | needs HM JS | — | UNPROVEN — RUNNING PID 261254 |

## n256-screlu-ob8-kb4hm (grok-pc GPU) — QUEUED 2026-10-16 07:56 PT, UNPROVEN
- Chain: grok-pc nnue\chain_kb4hm.ps1, PID 14156 (Idle, aff 0xF000). Waits for hmg python exit (60 s poll), then STOP_nnue + one-GPU-job + temps (hot spot <=80, mem jct <=88) check.
- Cmd: hmg settings (train_gpu3kb.py md5 743ca859, H256 screlu ob8, 8 ep, cos lr 3e-4, weights 0.90,0.03,0.05,0.02, select-add val_shared, keep every epoch) + --kbuckets 4 --hm.
- Init: hmg net_v4.nnue via --init-v3 (load_v3 reads v4; KB1 FT repeated into 4 buckets) -> else hmg net_best.pt via --init -> else sp90 net_v3 with --hm.
- Status: nnue\chain_kb4hm.status; done-marker nnue\chain_kb4hm.done (STARTED ... pids=... or STOPPED). Log logs\n256-screlu-ob8-kb4hm.log.
- hmg at queue time: ep1/8 done, shared 0.008323, sp_all 0.003737 (select val 0.016846); ETA ~08:16 PT.

### 2026-10-16 ~08:20 PT — GPU n256-screlu-ob8-hmg DONE (UNPROVEN)
- Finished 08:14:49 PT (8/8 ep; best = ep8). train 0.007614. **shared val 0.007983** (ep7 0.007986) vs sp90 **0.007851** → **+1.7% WORSE**. Holdout (forge_holdout_wdl) 0.003806; forge_sp_all 0.003694 (sp90 ~0.00348–0.00356, worse); forge_sp_new_train val 0.003625; forgepgn_wdl 0.003884; selection val 0.016157. Shared curve ep1→8: 0.008323, 8161, 8086, 8041, 8012, 7995, 7986, 7983 (still falling slowly). Note: the 07:55 entry "ep1 shared 0.007853" was wrong; ep1 shared was 0.008323.
- net_v4.nnue md5 **d86d7faf**8056a837287b126f6005d9e3, 401980 B; header GKNN v4 H256 NB8 act1(SCReLU) KB1 HM1. Box copy nets/n256-screlu-ob8-hmg/net_v4.nnue.
- ref_eval_v4.py 5 FENs: startpos w 14 / b 14, Italian-ish 14, KPK 33, Q-up 1320 (sane). parity.js on dist-cand-v4load-1747: refresh 0/300 mismatches, inc 2386 evals 0/0/0 mism (1525 king moves, 170 mirror crossings, 731 rank crossings) — PASS (results_hmg.json).
- Verdict: does NOT beat sp90 on shared or self-play val; not a pack candidate. sp90 stays best.
- kb4hm chain: hmg exited 08:15:08, temps hs67 mj83 OK, init hmg net_v4.nnue; **kb4hm STARTED 08:15:28 PIDs 2396,7028** (start val 0.016255). chain_kb4hm.done = STARTED.

| n256-screlu-ob8-hmg (GPU) | 2026-10-16 07:52→08:15 | 0.90/0.03/0.05/0.02 | 768->256 x2->8 SCReLU NB8 HM=1 KB=1 (v4) | init-v3 sp90, 3e-4 cos 8ep | shared **0.007983** (sp90 0.007851, +1.7% worse); sp_all 0.003694 | needs v4load | not tested | UNPROVEN — DONE, NOT PACKED; md5 d86d7faf |
| n256-screlu-ob8-kb4hm (GPU) | 2026-10-16 08:15→ | same | KB4 HM1 v4 | init hmg v4, 3e-4 cos 8ep | start sel-val 0.016255 | needs v4load | — | UNPROVEN — RUNNING PIDs 2396,7028 |

### 2026-10-16 ~08:50 PT — NNUE hourly (all UNPROVEN)
- Lock **1.7.48** (net **5877e14c**, same as 1.7.47). Push until weekly usage hits 100%. STOP_nnue absent (box + PC). Box load ~3.5.
- Progress since ~07:55: **hmg DONE** shared **0.007983** (+1.7% vs sp90 0.007851) → NOT packed (md5 **d86d7faf**). kb4hm chain started 08:15 after temps OK.
- **GPU n256-screlu-ob8-kb4hm RUNNING** ep8 (~1000/1939 at check), PIDs 2396/7028 Idle/F000, ~230k pos/s. Shared ep1→7: 0.007746 → 0.007635 → 0.007575 → 0.007537 → 0.007509 → 0.007491 → **0.007481** (**beats sp90 0.007851 by ~4.7%**). forge_sp_all ~0.00373→0.00380 (sp90 ~0.00348–0.00356, slightly worse). Temps Edge63 HotSpot71 MemJ88 — stay one GPU job (MemJ at second-job ceiling). ETA ~08:55 PT.
- **Box n256-screlu-ob8-hm** PID 261254 ep6/8, best mix-val **0.007933** (data_mix; not shared-val). ETA ~09:15.
- Best packed still **sp90** md5 **d1e821d4** at `dist-cand-n256sp90-1747`. Plan: on kb4hm finish, if ep8 shared still beats sp90, pack net-only with `dist-cand-v4load-1747` JS (md5 459ab123) → `chess-engine-nnue/dist-cand-kb4hm-1748`, gates, then QA. pilot_r2 still datagen-only (lock+progress.log) — not ready to consume.
- Need from Couns: nothing. Need from crew: QA keep testing sp90 net-only vs 1.7.48; after pack, kb4hm+v4load as next net-only.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n256-screlu-ob8-kb4hm (GPU) | 2026-10-16 08:15→ | 0.90/0.03/0.05/0.02 | 768->256 x2->8 SCReLU NB8 KB4 HM1 (v4) | init hmg v4, 3e-4 cos 8ep | ep7 shared **0.007481** (sp90 0.007851) | needs v4load | — | UNPROVEN — RUNNING ep8 PIDs 2396/7028 |
| n256-screlu-ob8-hm (box) | 2026-10-16 07:2x→ | data_mix_d40forge | KB1 HM1 v4 | init-v3 sp90, 3e-4 cos 8ep | ep6 mix-val **0.007933** | needs v4load | — | UNPROVEN — RUNNING PID 261254 |


### 2026-10-16 ~10:05 PT — NNUE hourly (all UNPROVEN)
- Lock **1.7.48** (net 5877e14c). STOP_nnue absent. Box load ~5.7 (no box training started).
- **GPU n256-screlu-ob8-kb4hm DONE** 08:54 PT (8/8, best ep8). train 0.006976, **shared val 0.007479** (sp90 0.007851 → **−4.7%**, best so far); forge_sp_all 0.003802 (sp90 ~0.0035, worse); sel-val 0.015125; val_other 0.003892/0.003957/0.003714. net_v4.nnue md5 **9cc41084**392f05b819bb25cef269b2fd, 1581628 B (KB4 HM1 act1 NB8). Box copy nets/n256-screlu-ob8-kb4hm/net_v4.nnue.
- Packed net-only (+ v4load JS) at `/workspace/chess-engine-nnue/dist-cand-kb4hm-1748` = dist-v1.7.48 + dist-cand-v4load-1747 eval/nnue.js (459ab123) + uci/main.js (nnuev2c startup-error info) + kb4hm net. v4 parity kit on the pack: refresh 0/300, inc 2386 evals 0/0/0 mismatches (1525 king moves, 170 mirror, 731 rank crossings) — PASS (v4_parity/results_kb4hm.json). Gates running → gates_kb4hm_1748.log.
- GPU was idle 08:54→10:00 (the 08:50 follow-up didn't happen). **GPU n256-screlu-ob8-kb4hm-sp80 STARTED ~10:00** PIDs 12972/13452 Idle/F000: warm kb4hm net_v4, weights 0.80/0.05/0.10/0.05, lr 1.5e-4 cos, 6 ep, KB4 HM (start script nnue\start_n256_screlu_ob8_kb4hm_sp80.ps1; temps at start hs47 mj66). Goal: keep shared gain and win back forge_sp_all.
- **Box n256-screlu-ob8-hm DONE** ~09:35: best ep8 mix-val 0.007919 (data_mix, not shared-val; holdout 0.004457). net_v4.nnue written (KB1 HM1). Not packed: kb4hm is clearly better on shared val; needs val_shared eval to compare fairly.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n256-screlu-ob8-kb4hm (GPU) | 2026-10-16 08:15→08:54 | 0.90/0.03/0.05/0.02 | 768->256 x2->8 SCReLU NB8 KB4 HM1 (v4) | init hmg v4, 3e-4 cos 8ep | shared **0.007479** (sp90 0.007851); sp_all 0.003802 | gates pending | not tested | UNPROVEN — PACKED dist-cand-kb4hm-1748; md5 9cc41084 |
| n256-screlu-ob8-hm (box) | 2026-10-16 07:2x→09:35 | data_mix_d40forge | KB1 HM1 v4 | init-v3 sp90, 3e-4 cos 8ep | ep8 mix-val 0.007919 | — | — | UNPROVEN — DONE, NOT PACKED |
| n256-screlu-ob8-kb4hm-sp80 (GPU) | 2026-10-16 10:00→ | 0.80/0.05/0.10/0.05 | KB4 HM1 v4 | init kb4hm v4, 1.5e-4 cos 6ep | start sel-val 0.015194 | — | — | UNPROVEN — RUNNING PIDs 12972/13452 |
- ~10:00 PT gates dist-cand-kb4hm-1748 (gates_kb4hm_1748.log): perft OK, movegen 36/36, tactics 6/6, mate_suite OK, mate_distance OK, draw_rules OK, uci_edge 27/27. Known fails same as sp90 pack: insufficient_material 4 (sp90 had 5; KBvKB same colour now passes), ep_repetition 1. Quick bench.js is too small to judge NPS (KB4 FT is 4x larger, 1.58 MB); needs Profiler ABBA vs 1.7.48. UNPROVEN.

### 2026-10-16 ~10:25 PT — GPU idle guard: kb4hm-sp80 DONE, kb4hm-sp70 STARTED (all UNPROVEN)
- **n256-screlu-ob8-kb4hm-sp80 DONE** ~10:18 PT (6/6 ep, best = ep6). train 0.006515, sel-val 0.015151. **shared val 0.007480** (kb4hm 0.007479 → flat); **forge_sp_all 0.003255** (kb4hm 0.003802 → **−14.4%**, best sp_all of any net; sp90 ~0.0035); val_other 0.003395/0.003429/0.003163 (kb4hm 0.003892/0.003957/0.003714 → ~−13–15%). Shared curve ep1→6: 0.007531, 7509, 7498, 7489, 7483, 7480; sp_all 0.003346→0.003255. ~320k pos/s.
- PC `nets\n256-screlu-ob8-kb4hm-sp80\net_v4.nnue` md5 **d313fbb7**193aeec57b5f15124d4ad02c, 1581628 B (KB4 HM1 act1 NB8, same shape as kb4hm). net_ep1..6.pt kept, log.json, logs\n256-screlu-ob8-kb4hm-sp80.log. Not yet copied to box / packed. Verdict: dominates kb4hm (equal shared, much better self-play/holdout) → should REPLACE kb4hm 9cc41084 as the KB4HM pack net once the kb4hm SIMD repack (Strategist 10:05, hold kb4hm launch) is done. Needs v4 parity + gates on the repack.
- **GPU n256-screlu-ob8-kb4hm-sp70 STARTED ~10:23 PT** PIDs 4492/6688 Idle aff 0xF000: warm kb4hm-sp80 net_v4, weights 0.70/0.07/0.15/0.08 (data40m/forgepgn_wdl/forge_holdout_wdl/forge_sp_new_train), lr 1e-4 cos, 6 ep, KB4 HM, start sel-val 0.015213. Launcher nnue\start_n256_screlu_ob8_kb4hm_sp70.ps1; temps at start hs47 mj68. ETA ~10:45 PT. Goal: check if the self-play/holdout trend continues without losing shared val. STOP_nnue absent.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n256-screlu-ob8-kb4hm-sp80 (GPU) | 2026-10-16 10:00→10:18 | 0.80/0.05/0.10/0.05 | 768->256 x2->8 SCReLU NB8 KB4 HM1 (v4) | init kb4hm v4, 1.5e-4 cos 6ep | shared **0.007480**; sp_all **0.003255** | needs SIMD repack | not tested | UNPROVEN — DONE, NOT PACKED; md5 d313fbb7 |
| n256-screlu-ob8-kb4hm-sp70 (GPU) | 2026-10-16 10:23→ | 0.70/0.07/0.15/0.08 | KB4 HM1 v4 | init kb4hm-sp80 v4, 1e-4 cos 6ep | start sel-val 0.015213 | — | — | UNPROVEN — RUNNING PIDs 4492/6688 |
- 10:24 PT: kb4hm-sp80 v4 export copied to box `/workspace/chess-tools/nnue/nets/kb4hm-sp80/net_v4.nnue` (md5 d313fbb7193aeec57b5f15124d4ad02c verified; also at nets/n256-screlu-ob8-kb4hm-sp80/). Source of truth on grok-pc: C:\Users\Administrator\grok-pc\nnue\nets\n256-screlu-ob8-kb4hm-sp80\net_v4.nnue. Coder packing on kb4hmsimd JS. UNPROVEN.

### 2026-10-16 ~10:48 PT — NNUE hourly (all UNPROVEN)
- Lock 1.7.48 (5877e14c). kb4hm-sp80 (d313fbb7) packed on SIMD JS at chess-engine-nnue/dist-cand-kb4hmsp80simd-1748 (net md5 verified); replaces kb4hm 9cc41084 as KB4HM net-only candidate. Needs Profiler ABBA vs 1.7.48, then QA. GPU kb4hm-sp70 running since 10:23 (idle guard handles finish/chain). Box load ~2.5, no box training. STOP_nnue absent. Status sent to 7 agents priority false.

### 2026-10-16 ~10:50 PT — GPU idle guard: kb4hm-sp70 DONE (no gain), n384-screlu-ob8-kb4hm STARTED (all UNPROVEN)
- **n256-screlu-ob8-kb4hm-sp70 DONE** ~10:43 PT (6/6 ep, ~305-320k pos/s). Selection val got worse every epoch (start 0.015213 → ep6 0.015273), so the trainer exported **epoch 0** = the unchanged kb4hm-sp80 init: PC `nets\n256-screlu-ob8-kb4hm-sp70\net_v4.nnue` md5 **d313fbb7** (byte-identical to sp80). Per-epoch: shared val ep1→6 0.007548, 7549, 7543, 7537, 7533, **0.007532** (sp80 0.007480 → +0.7% worse); forge_sp_all 0.002956 → **0.002864** (sp80 0.003255 → −12%); val_other ep6 0.003042/0.003054/0.002777. ep6 weights kept as net_ep6.pt (md5 ed517191), not exported. Verdict: shifting further to forge data keeps trading shared val for self-play-style val; no clear winner over sp80, NOT packed. kb4hm-sp80 (d313fbb7) stays the best KB4HM net. GPU idle ~10:43→10:49.
- **pilot_r2 datagen finished** (D:\grok-pc-data\pilot_r2: train.bin 54.9 MB = 1,716,364 rows, val.bin 92,727 rows, stats.json, holdout_game_ids; 28,882 games, dupes 948,947, leak 0). Still NOT verified (signcheck/result byte/legacy not checked) → not consumed yet.
- **GPU n384-screlu-ob8-kb4hm STARTED ~10:49 PT** PIDs **13744/7748** Idle aff 0xF000 (61440). Strategist order "H384/H512 run after sp90". Init = function-preserving widen of kb4hm-sp80 H256→H384 (`widen_v4.py` md5 5b971f68, seed 1: new 128 units ftW ~N(0, 31.7 int), ftB 0, outW 0) → `nets/kb4hm-sp80-w384/init_w384.nnue` md5 **381dd076**, 2,372,412 B; ref_eval_v4 identical to sp80 on 4 FENs, and trainer start val **0.015212737** = exactly sp80's. Mix 0.80/0.05/0.10/0.05, lr 2e-4 cos, 8 ep, KB4 HM1 act1 NB8, select val+shared, extra-val forge_sp_all+val_shared. ~269k pos/s → ETA ~11:25 PT. Launcher nnue\start_n384_screlu_ob8_kb4hm.ps1 (box copy pc_launch/). Temps at start hs50 mj70. Bar: shared < 0.007480 with sp_all ≤ ~0.0033. Risk: H384 KB4 FT is 1.5x the H256 one → NPS; v4 SIMD path must handle H=384 (check before packing). STOP_nnue absent.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n256-screlu-ob8-kb4hm-sp70 (GPU) | 2026-10-16 10:23→10:43 | 0.70/0.07/0.15/0.08 | 768->256 x2->8 SCReLU NB8 KB4 HM1 (v4) | init kb4hm-sp80 v4, 1e-4 cos 6ep | ep6 shared 0.007532 / sp_all 0.002864; export = ep0 (= sp80) | — | not tested | UNPROVEN — DONE, NO GAIN, NOT PACKED; export md5 d313fbb7 (=sp80), ep6 pt ed517191 |
| n384-screlu-ob8-kb4hm (GPU) | 2026-10-16 10:49→ | 0.80/0.05/0.10/0.05 | 768->384 x2->8 SCReLU NB8 KB4 HM1 (v4) | init widened kb4hm-sp80 (381dd076), 2e-4 cos 8ep | start sel-val 0.015213 (= sp80) | — | — | UNPROVEN — RUNNING PIDs 13744/7748 |

### 2026-10-16 ~11:30 PT — pilot_r2 PASS, n384 DONE + PACKED, n512 STARTED (all UNPROVEN)
- **pilot_r2 check: PASS** (PILOT_R2_CHECK.md). Format, results (White POV, corr 0.78) and .games are all OK. Small position overlap with val_shared (102), forge_holdout (5,146) and forge_sp_all (5,018), so I made a de-leaked copy, D:\grok-pc-data\pilot_r2_clean (train 1,694,647, 21,717 rows dropped). Train only on the clean copy.
- **n384-screlu-ob8-kb4hm DONE** ~11:21 PT (8/8 ep). Best = ep8: shared **0.007389** (sp80 0.007480, −1.2%), forge_sp_all **0.003208** (sp80 0.003255), holdouts val_other 0.003333/0.003424/0.003123. Export md5 **313c4c09**63b4405682724bf46b1db70e, 2,372,412 B; box copy nets/n384-screlu-ob8-kb4hm/net_v4.nnue.
- **Packed** /workspace/chess-engine-nnue/dist-cand-kb4hmn384simd-1748 = dist-cand-kb4hmsp80simd-1748 with only net.nnue swapped (diff -rq: net.nnue only; nnue.js c4ed2b9d unchanged). v4 parity on the pack's net: 2386 evals, 0 mismatches. Gates (gates_n384_1748.log): perft PASS, movegen 36/0, tactics 6/0, mate suite 10/0, mate_distance 5/5, uci_edge 27, bug_gate PASS (PARTIAL, fuzz skipped because slots were full), 0 new failures, KNOWN 5 (sp80 pack: KNOWN 6). Next: Profiler game_seq speed check vs 1.7.48, then QA net slot.
- **GPU n512-screlu-ob8-kb4hm STARTED ~11:24 PT**, PIDs **2668/13604**, Idle, aff 0xF000. Init = widen_v4.py seed 1 of n384 (313c4c09) H384→H512, new outW=0 → nets\init_n512kb4hm-w512.nnue md5 17c8cac1; ref_eval_v4 identical to n384 on 4 FENs (7/−213/31/−665). Mix: sp80 mix + pilot_r2_clean, 0.76/0.05/0.09/0.05/0.05, lr 2e-4 cos, 8 ep. Start sel-val 0.015073: not comparable to n384's 0.014967, because sel-val now includes pilot val. ~262k pos/s, ETA ~11:58 PT. Temps hs66 mj81.
| n384-screlu-ob8-kb4hm (GPU) | 10:49→11:21 | 0.80/0.05/0.10/0.05 | 768->384 x2->8 SCReLU NB8 KB4 HM1 | widen sp80, 2e-4 cos 8ep | shared 0.007389 / sp_all 0.003208 | dist-cand-kb4hmn384simd-1748 | gates PASS | UNPROVEN — PACKED, md5 313c4c09 |
| n512-screlu-ob8-kb4hm (GPU) | 11:24→ | 0.76/0.05/0.09/0.05/0.05 (+pilot_r2_clean) | 768->512 KB4 HM1 | widen n384 (17c8cac1), 2e-4 cos 8ep | — | — | — | UNPROVEN — RUNNING PIDs 2668/13604 |

### 2026-10-16 ~11:52 PT — NNUE hourly (all UNPROVEN)
- Lock still 1.7.48 (baseline/dist-v1.7.48). Box load 2.4.
- GPU n512-screlu-ob8-kb4hm RUNNING (PIDs 2668/13604 alive, STOP_nnue absent), ep6/8 done 11:47 PT: sel-val 0.014746, shared **0.007279** (n384 0.007389, −1.5%), forge_sp_all 0.003170 (n384 0.003208), val_other 0.003239/0.003433/0.003078/0.002948. ~270k pos/s, ETA ~11:56 PT; idle guard chains next job and exports/packs if it beats n384.
- Waiting: Profiler speed check for dist-cand-kb4hmn384simd-1748 (and kb4hmsp80simd-1748) vs 1.7.48, then QA net-only slot. Status sent to 7 agents priority false.

### 2026-10-16 ~12:03 PT — GPU idle guard: n512 DONE, n384-p2 STARTED (all UNPROVEN)
- **n512-screlu-ob8-kb4hm DONE** ~11:55 PT (8/8 ep, ~262-282k pos/s). Best = ep8: sel-val 0.014734, shared **0.007273** (n384 0.007389, −1.6%; best shared of any net), forge_sp_all **0.003162** (n384 0.003208), val_other 0.003227/0.003427/0.003070/0.002944 (last = pilot_r2 val). Curve flattened late (ep6 0.007279, ep7 0.007274, ep8 0.007273) under cosine. Export PC `nets\n512-screlu-ob8-kb4hm\net_v4.nnue` md5 **e52ebdae**7dd259ad84b86a158f3e9a46, 3,163,196 B (KB4 HM1 act1 NB8 H512); net_ep1..8.pt, net_best.pt, log.json kept; log logs\n512-screlu-ob8-kb4hm.log. Box copy nets/n512-screlu-ob8-kb4hm/net_v4.nnue (md5 verified). NOT packed: v4 SIMD path must be checked for H=512, and NPS risk (KB4 FT is 2x H256, ~3.1 MB). Note: gain vs n384 mixes width and the added pilot_r2_clean data, so n384-p2 below separates them. GPU idle ~11:55→12:02 PT.
- **GPU n384-screlu-ob8-kb4hm-p2 STARTED ~12:02 PT** PIDs **10964/12924** Idle aff 0xF000 (61440). Warm n384 (313c4c09, same shape as packed dist-cand-kb4hmn384simd-1748), same mix as n512 (sp80 mix + pilot_r2_clean 0.76/0.05/0.09/0.05/0.05), lr 1.5e-4 cos, 8 ep, KB4 HM1. Start sel-val 0.015073 (= n512 start, as expected). ~243k pos/s → ETA ~12:35 PT. Launcher nnue\start_n384_screlu_ob8_kb4hm_p2.ps1 (box copy pc_launch/). Temps at start hs60 mj78. Bar: shared < 0.007389 (n384) and ideally near n512's 0.007273; if it gets close, it's a drop-in net swap for the faster n384 pack. STOP_nnue absent. Self-play datagen alive (forge_selfplay → D:\grok-pc-data\selfplay_out\forge_selfplay_006.txt.part, writing).

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n512-screlu-ob8-kb4hm (GPU) | 11:24→11:55 | 0.76/0.05/0.09/0.05/0.05 (+pilot_r2_clean) | 768->512 x2->8 SCReLU NB8 KB4 HM1 (v4) | widen n384 (17c8cac1), 2e-4 cos 8ep | shared **0.007273** / sp_all 0.003162 | H512 SIMD parity 0 mism; gates PASS (fuzz skipped); quick NPS ≈ n384; needs Profiler | not tested | UNPROVEN — PACKED dist-cand-kb4hmn512simd-1748 (net-only vs n384 pack); md5 e52ebdae |
| n384-screlu-ob8-kb4hm-p2 (GPU) | 12:02→ | 0.76/0.05/0.09/0.05/0.05 (+pilot_r2_clean) | 768->384 KB4 HM1 (v4) | warm n384 (313c4c09), 1.5e-4 cos 8ep | start sel-val 0.015073 | — | — | UNPROVEN — RUNNING PIDs 10964/12924 |
- **PACKED dist-cand-kb4hmn512simd-1748 ~12:10 PT** (UNPROVEN): copy of dist-cand-kb4hmn384simd-1748, only net.nnue swapped (e52ebdae; nnue.js c4ed2b9d same). v4 parity (results_n512.json): refresh 0/300, inc 2386 evals 0 mism (inc_vs_fresh/checkAcc/inc_vs_ref), simd on. Gates (gates_n512_1748.log): perft/movegen 36/tactics 6/mate 10/mate_distance 5/5/uci_edge 27 PASS; bug_gate PASS new 0, KNOWN 6 vs n384 5 — extra is pre-existing known "insufficient KBvKB same colour" (eval cp 8; n384 happened to pass it; sp80simd also had 6). Quick 1T NPS d12 x3 (load ~2.8, noisy): n512 med 243.7k/172802 nodes vs n384 230.8k/160185 nodes. Next: Profiler ABBA.

### 2026-10-16 ~12:40 PT — GPU idle guard: n384-kb4hm-p2 DONE, n512-kb4hm-c2 STARTED (all UNPROVEN)
- **n384-screlu-ob8-kb4hm-p2 DONE** ~12:34 PT (8/8 ep, best = ep8, ~270-293k pos/s). train 0.006118, sel-val 0.014854. **shared 0.007332** (n384 0.007389 → −0.8%; n512 0.007273 still best), forge_sp_all **0.003168** (n384 0.003208; ≈ n512 0.003162), val_other 0.003267/0.003402/0.003080/0.002919 (last = pilot_r2 val; n512 0.002944). Shared curve ep5→8: 0.007347, 7336, 7333, 7332 (flat). Export PC `nets\n384-screlu-ob8-kb4hm-p2\net_v4.nnue` md5 **bfa76347**504cc7a87bdc63abc88dacbe, 2,372,412 B (KB4 HM1 act1 NB8 H384, same shape as the dist-cand-kb4hmn384simd-1748 net → drop-in swap); net_ep1..8.pt, net_best.pt, log.json kept; log logs\n384-screlu-ob8-kb4hm-p2.log. Box copy nets/n384-screlu-ob8-kb4hm-p2/net_v4.nnue (md5 verified). Verdict: of n512's −1.6% over n384, about half is the pilot_r2_clean data and half is width. Not packed yet: worth a net-only n384 repack if Profiler shows n512 is too slow; otherwise n512 stays the candidate. GPU idle ~12:34→12:40.
- **GPU n512-screlu-ob8-kb4hm-c2 STARTED ~12:40 PT** PIDs **3816/7036** Idle aff 0xF000 (61440). Warm n512 (e52ebdae, the packed dist-cand-kb4hmn512simd-1748 net), same mix (sp80 mix + pilot_r2_clean 0.76/0.05/0.09/0.05/0.05), re-warmed lr 1e-4 cos, 8 ep, KB4 HM1. No queued Strategist job, so this is a re-warm continue on the best net (n512's curve was flattening only because cosine lr hit ~0). Start sel-val 0.014896. ~248k pos/s → ETA ~13:15 PT. Launcher nnue\start_n512_screlu_ob8_kb4hm_c2.ps1 (box copy pc_launch/). Temps at start hs53 mj72. Bar: shared < 0.007273 → drop-in net swap into the n512 pack. STOP_nnue absent. Self-play datagen alive (forge_selfplay_006.txt.part ~201 MB, writing; PIDs 9308/9896/10456 + guards).

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n384-screlu-ob8-kb4hm-p2 (GPU) | 12:02→12:34 | 0.76/0.05/0.09/0.05/0.05 (+pilot_r2_clean) | 768->384 x2->8 SCReLU NB8 KB4 HM1 (v4) | warm n384 (313c4c09), 1.5e-4 cos 8ep | shared **0.007332** / sp_all 0.003168 | same shape as n384 pack | not tested | UNPROVEN — DONE, NOT PACKED; md5 bfa76347 |
| n512-screlu-ob8-kb4hm-c2 (GPU) | 12:40→ | 0.76/0.05/0.09/0.05/0.05 (+pilot_r2_clean) | 768->512 KB4 HM1 (v4) | warm n512 (e52ebdae), 1e-4 cos 8ep | start sel-val 0.014896 | — | — | UNPROVEN — RUNNING PIDs 3816/7036 |

### 2026-10-16 ~12:47 PT — n512-kb4hm-c2 STOPPED, n384-kb4hm-c3 STARTED (all UNPROVEN)
- **n512-screlu-ob8-kb4hm-c2 STOPPED ~12:46 PT** at ep1 batch ~1000/1991 (no epoch finished, nothing exported). Killed only its train_gpu3kb.py PIDs **3816/7036**. Why: QA parked H512 as too slow (Profiler: n384 reaches d10 25.6% faster than n512; n512 NPS −14.3% vs 1.7.48), so more H512 training has no slot. QA wants an H384 net that clearly beats 0.007389 at n384 speed.
- **GPU n384-screlu-ob8-kb4hm-c3 STARTED ~12:46 PT** PIDs **12360/11860** Idle aff 0xF000 (61440). Warm n384-kb4hm-p2 (bfa76347, shared 0.007332; drop-in for dist-cand-kb4hmn384simd-1748), same mix (sp80 mix + pilot_r2_clean 0.76/0.05/0.09/0.05/0.05), lr 1e-4 cos, **10 ep**, KB4 HM1, selection = val + val_shared (--select-add, same as p2). Start sel-val **0.014944** (p2 final float 0.014854; the +0.6% gap is int-export quantization on warm reload, same pattern as n512→c2 0.014734→0.014896). Trainer doesn't print start shared on its own; ep1 shared (~12:51 PT) is the first direct check vs 0.007332. ~278k pos/s, ~4.3 min/ep → ETA ~13:30 PT. Launcher nnue\start_n384_screlu_ob8_kb4hm_c3.ps1 (box copy pc_launch/). Temps at start hs59 mj78. Bar: shared clearly < 0.007389 (ideally < 0.007332) → net-only swap into the n384 pack. STOP_nnue absent.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n512-screlu-ob8-kb4hm-c2 (GPU) | 12:40→12:46 | 0.76/0.05/0.09/0.05/0.05 (+pilot_r2_clean) | 768->512 KB4 HM1 (v4) | warm n512 (e52ebdae), 1e-4 cos 8ep | start sel-val 0.014896; no epoch done | — | — | UNPROVEN — STOPPED (QA parked H512 as too slow); PIDs 3816/7036 killed |
| n384-screlu-ob8-kb4hm-c3 (GPU) | 12:46→ | 0.76/0.05/0.09/0.05/0.05 (+pilot_r2_clean) | 768->384 KB4 HM1 (v4) | warm n384-p2 (bfa76347), 1e-4 cos 10ep | start sel-val 0.014944 | same shape as n384 pack | — | UNPROVEN — RUNNING PIDs 12360/11860 |
- c3 ep1 (~12:50 PT): sel-val 0.014866, **shared 0.007338** (p2 0.007332 → start matches within quantization), forge_sp_all 0.003172, val_other 0.003277/0.003410/0.003074/0.002937. 228 s/ep at ~286k pos/s → ETA ~13:28 PT.

### 2026-10-16 ~12:52 PT — hourly: n384-p2 PACKED (all UNPROVEN)
- **PACKED dist-cand-kb4hmn384p2simd-1748** (built ~12:41 PT, recorded here at the hourly run): copy of dist-cand-kb4hmn384simd-1748 with only net.nnue swapped to n384-kb4hm-p2 (md5 bfa76347; diff -rq: net.nnue only; nnue.js c4ed2b9d unchanged). v4 parity v4_parity/results_n384p2.json: 0 mismatches. Gates (gates_n384p2_1748.log, 12:43 PT): perft PASS, movegen 36/0, tactics 6/0, mate suite 10/0, mate_distance 5/5, uci_edge 27, bug_gate PASS (PARTIAL, fuzz skipped, slots full), new 0, KNOWN 5. Same shape/speed class as the n384 pack, shared 0.007332 vs 0.007389 → supersedes dist-cand-kb4hmn384simd-1748 as the H384 net-only candidate. Next: Profiler confirm (net-only swap, same shape) then QA net-only slot vs 1.7.48.
- GPU n384-kb4hm-c3 running (ep1 shared 0.007338, ETA ~13:28 PT). n512 pack parked by QA (NPS −14.3% vs 1.7.48).

- **PACKED dist-cand-kb4hmn384p2simd-1748 ~12:55 PT** (UNPROVEN): copy of dist-cand-kb4hmn384simd-1748, only net.nnue swapped for nets/n384-screlu-ob8-kb4hm-p2/net_v4.nnue (md5 bfa76347504cc7a87bdc63abc88dacbe verified; shared 0.007332 vs n384 0.007389). diff -rq: net.nnue only. v4 parity (v4_parity/results_n384p2.json): refresh 0/300, inc 2386 evals, 0 mismatches all checks, simd on. Gates (gates_n384p2_1748.log): perft PASS, movegen 36/0, tactics 6/0, mate suite 10/0, mate_distance 5/5, uci_edge 27, bug_gate PASS (PARTIAL, fuzz skipped: slots full), new 0, KNOWN 5 (= n384). Bench H256 (prof1748_n384 bench_hash.js): d9 140626, d10 209328 (n384 re-run d10 249869, matches). Next: Profiler game_seq speed check, then QA net slot.

### 2026-10-16 ~13:25 PT — GPU idle guard: n384-kb4hm-c3 DONE, n384-kb4hm-c4 STARTED (all UNPROVEN)
- **n384-screlu-ob8-kb4hm-c3 DONE** ~13:21 PT (10/10 ep, best = ep9 (last), ~271-326k pos/s). train 0.006047, sel-val 0.014763. **shared 0.007288** (p2 0.007332 → −0.6%; n384 0.007389 → −1.4%; ≈ n512 0.007273 at n384 speed), forge_sp_all **0.003173** (p2 0.003168), val_other 0.003260/0.003424/0.003085/0.002942 (last = pilot_r2 val). Shared curve ep6→9: 0.007295, 7292, 7290, 7288 (still slowly falling). Export PC `nets\n384-screlu-ob8-kb4hm-c3\net_v4.nnue` md5 **1dfe6122**14f04e95b63fef4d53888af0, 2,372,412 B (KB4 HM1 act1 NB8 H384, same shape as dist-cand-kb4hmn384p2simd-1748 net → drop-in net-only swap); net_ep1..9.pt, net_best.pt, log.json kept; log logs\n384-screlu-ob8-kb4hm-c3.log. Box copy nets/n384-screlu-ob8-kb4hm-c3/net_v4.nnue (md5 verified). Meets QA's bar (clearly < 0.007389 at n384 speed). NOT packed yet: next step is a net-only repack of dist-cand-kb4hmn384p2simd-1748 with this net (parity + gates), superseding p2. GPU idle ~13:21→13:23.
- **GPU n384-screlu-ob8-kb4hm-c4 STARTED ~13:23 PT** PIDs **10776/12696** Idle aff 0xF000 (61440). Warm c3 (1dfe6122), same mix (sp80 mix + pilot_r2_clean 0.76/0.05/0.09/0.05/0.05), lr **8e-5** cos, 10 ep, KB4 HM1, select val + val_shared. Start sel-val 0.014854 (c3 float 0.014763; quantization gap on warm reload as before). ~276k pos/s → ETA ~14:05 PT. Launcher nnue\start_n384_screlu_ob8_kb4hm_c4.ps1 (box copy pc_launch/). Temps at start hs61 mj78. No Strategist job queued; continuation chosen because c3's shared curve was still falling. Bar: shared < 0.007288 → net-only swap. STOP_nnue absent. Self-play datagen alive (forge_selfplay_006.txt.part ~251 MB, writing; PIDs 9308/9896/10456 + guards). Note: forge_selfplay_005.txt (complete, 648 MB) may not be in forge_sp_new_train yet — candidate fresh data for a later run.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n384-screlu-ob8-kb4hm-c3 (GPU) | 12:46→13:21 | 0.76/0.05/0.09/0.05/0.05 (+pilot_r2_clean) | 768->384 x2->8 SCReLU NB8 KB4 HM1 (v4) | warm n384-p2 (bfa76347), 1e-4 cos 10ep | shared **0.007288** / sp_all 0.003173 | same shape as n384 pack | not tested | UNPROVEN — DONE, NOT PACKED; md5 1dfe6122 |
| n384-screlu-ob8-kb4hm-c4 (GPU) | 13:23→ | 0.76/0.05/0.09/0.05/0.05 (+pilot_r2_clean) | 768->384 KB4 HM1 (v4) | warm c3 (1dfe6122), 8e-5 cos 10ep | start sel-val 0.014854 | — | — | UNPROVEN — RUNNING PIDs 10776/12696 |

### 2026-10-16 ~13:27 PT: auto_queue supervisor started on grok-pc (UNPROVEN)
- c3 note: the trainer exported epoch 10 (sel-val 0.014762), shared **0.007287** (ep9 0.007288), md5 1dfe6122.
- `nnue\auto_queue.ps1` (md5 c54021af) is running detached at Idle priority, PID 1380. It waits for c4 (10776/12696) and records it, then runs a1 H384 7e-5, c3 H512 1e-4 from e52ebdae, a2 H384 5e-5, then repeats H384 at decaying lr until STOP_nnue. New nets go in F:\grok-pc-nnue-auto\nets\<job>. Results are in nnue\AUTO_RESULTS.md, auto_results.csv and AUTO_BEST.txt, backed up to D:\grok-pc-data\auto_backup. See AUTO_README.md (box mirror: nnue/auto_results/).
- **PACKED dist-cand-kb4hmn384c3simd-1748 ~13:25 PT** (UNPROVEN): copy of dist-cand-kb4hmn384p2simd-1748, only net.nnue swapped for nets/n384-screlu-ob8-kb4hm-c3/net_v4.nnue (md5 1dfe612214f04e95b63fef4d53888af0 verified; shared 0.007288 vs p2 0.007332). diff -rq: net.nnue only. v4 parity (v4_parity/results_n384c3.json): refresh 0/300, inc 2386 evals, 0 mismatches all checks, simd on. Gates (gates_n384c3_1748.log): perft PASS, movegen 36/0, tactics 6/0, mate suite 10/0, mate_distance 5/5, uci_edge 27, bug_gate PASS (PARTIAL, fuzz skipped: slots full), new 0, KNOWN 5 (= p2). Bench H256 (prof1748_n384 bench_hash.js): d9 165424, d10 245500 (p2 140626/209328). Supersedes p2 as H384 net-only candidate. Next: Profiler game_seq, then QA net slot.
- **PACKED dist-cand-kb4hmn384c3simd-1749 ~13:36 PT** (UNPROVEN): copy of baseline/dist-v1.7.49 (chess-engine/baseline) + eval/nnue.js c4ed2b9d, uci/main.js 31a45e5e, net.nnue 1dfe6122 from c3-1748 (the exact 3 files where c3-1748 differs from 1.7.48). diff -rq vs 1.7.49: those 3 only; vs c3-1748: move/movegen.js only (9077e904). v4 parity (v4_parity/results_n384c3_1749.json): refresh 0/300, inc 2372 evals, 0 mismatches, simd on. Gates (gates_n384c3_1749.log): perft PASS, movegen 36/0, tactics 6/0, mate 10/0, mate_distance 5/5, uci_edge 27, bug_gate PASS (PARTIAL, fuzz skipped: slots full), new 0, KNOWN 5. Bench H256 d10 245541 (c3-1748 245500). Next: Profiler vs 1.7.49 and n384p2-1749, QA net slot, fuzz still owed.

### 2026-10-16 ~13:52 PT — hourly (all UNPROVEN)
- Lock now 1.7.49. dist-cand-kb4hmn384c3simd-1749 (net 1dfe6122) is gated (PASS, fuzz skipped) and QA has it on pcE (run_match_1749_pcE ... tlcheck seen in grok-pc process list 13:50 PT). Still owed: Profiler NPS confirm vs 1.7.49, fuzz.
- GPU n384-kb4hm-c4 (PIDs 10776/12696) ep7/10: sel-val 0.014706, **val_shared 0.007260** (c3 0.007287 → −0.4%), forge_sp_all 0.003182, ~318-336k pos/s, ETA ~14:01 PT. auto_queue PID 1380 alive (chains a1 after c4). STOP_nnue absent. Self-play datagen (forge_selfplay + selfplay_guard) alive.

### 2026-10-16 ~14:04 PT — GPU idle guard (all UNPROVEN)
- **n384-screlu-ob8-kb4hm-c4 DONE ~14:00 PT** (pc 23:00): best = ep10, **val_shared 0.007257** (new best; c3 0.007287, n512 0.007273), forge_sp_all 0.003177, md5 01c2c0822dc98e5bc683c2ec29d59872. Net on PC at nnue\nets\n384-screlu-ob8-kb4hm-c4\net_v4.nnue (+net_ep*.pt, log.json); full per-epoch record in PC AUTO_RESULTS.md. NOT copied to box, NOT packed (drop-in net-only swap for dist-cand-kb4hmn384c3simd-1749).
- auto_queue (PID 1380) chained the next job itself at 14:00 PT: **auto-n384-kb4hm-a1** (PIDs 14012/3076, Idle): warm c4 01c2c082, same 5-source mix 0.76/0.05/0.09/0.05/0.05, lr 7e-5 cos 10ep, out F:\grok-pc-nnue-auto\nets\auto-n384-kb4hm-a1-10162300. GPU busy (sensor row 14:03 PT). Self-play datagen (forge_selfplay 9308 + selfplay_guard) alive. STOP_nnue absent.

### 2026-10-16 ~14:55 PT — hourly: auto-a1 DONE + PACKED (all UNPROVEN)
- **auto-n384-kb4hm-a1-10162300 DONE ~14:40 PT** (auto_queue job, pc 23:00→23:40): warm c4 01c2c082, mix 0.76/0.05/0.09/0.05/0.05 (data40m, forgepgn_wdl, forge_holdout_wdl, forge_sp_new_train, pilot_r2_clean), H384 lr 7e-5 cos 10ep bs32768 KB4 HM1 ob8, select val_shared. Best ep10 **val_shared 0.007233** (new best; c4 0.007257, c3 0.007287, n512 0.007273), forge_sp_all 0.003182, md5 **95ee653c6709d083528daaa293fa46f9**. PC: F:\grok-pc-nnue-auto\nets\auto-n384-kb4hm-a1-10162300 (+ staged copy nnue\nets\auto-n384-kb4hm-a1-10162300); box: nets/auto-n384-kb4hm-a1-10162300/{net_v4.nnue,log.json,settings.txt}.
- **PACKED dist-cand-kb4hmn384a1simd-1749** (UNPROVEN): cp -a of dist-cand-kb4hmn384c3simd-1749 with only net.nnue swapped (diff -rq: net.nnue only; md5 95ee653c verified). v4 parity v4_parity/results_n384a1_1749.json: refresh 0/300, inc 2372 evals, 0 mismatches, simd on. Gates running: chess-engine-nnue/gates_n384a1_1749.log (fuzz skipped). Supersedes c3-1749 as the H384 net-only candidate if gates pass; c4 (01c2c082) skipped (a1 strictly better, same lineage).
- auto_queue (PID 1380) chained **auto-n512-kb4hm-c3-10162340** (H512 1e-4 from e52ebdae) at 14:40 PT; note QA parked H512 for NPS (−14.3%), so this net is only useful if H512 gets un-parked. Self-play datagen alive. STOP_nnue absent. Free: C 40.1 / D 164.2 / F 173.9 GB.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| auto-n384-kb4hm-a1 (GPU, auto_queue) | 14:00→14:40 | 0.76/0.05/0.09/0.05/0.05 (+pilot_r2_clean) | 768->384 KB4 HM1 (v4) | warm c4 (01c2c082), 7e-5 cos 10ep | shared **0.007233** / sp_all 0.003182 | same shape as c3 pack | not tested | UNPROVEN — PACKED dist-cand-kb4hmn384a1simd-1749, gates running; md5 95ee653c |
| auto-n512-kb4hm-c3 (GPU, auto_queue) | 14:40→15:13 | same mix | 768->512 KB4 HM1 (v4) | warm n512 (e52ebdae), 1e-4 cos 8ep | shared **0.007235** (ep8) / sp_all 0.003177 | H512 parked (−14.3%) | not tested | UNPROVEN — DONE, NOT packed (H512 parked; ≈ a1 0.007233 at H384); md5 98778fb4 |
| auto-n384-kb4hm-a2 (GPU, auto_queue) | 15:13→ | same mix | 768->384 KB4 HM1 (v4) | warm a1 (95ee653c), 5e-5 cos 10ep | — | — | — | UNPROVEN — RUNNING |

- 2026-10-16 ~15:16 PT GPU idle guard: **auto-n512-kb4hm-c3-10162340 DONE 15:13 PT** (pc 23:40→00:13): warm n512 e52ebdae, same 5-source mix, H512 lr 1e-4 cos 8ep. Best ep8 **val_shared 0.007235** (prev H512 best 0.007273; a1 H384 0.007233 still overall best), forge_sp_all 0.003177, md5 **98778fb41ac22e3e5f0cb55e0fac8596**. PC: F:\grok-pc-nnue-auto\nets\auto-n512-kb4hm-c3-10162340\net_v4.nnue. Not packed: H512 parked by QA for NPS and it gives no loss edge over H384 a1. UNPROVEN.
- auto_queue (PID 1380) chained **auto-n384-kb4hm-a2-10170013** at 15:13 PT (PIDs 5456/8584): warm a1 95ee653c, same mix, H384 lr 5e-5 cos 10ep, out F:\grok-pc-nnue-auto\nets\auto-n384-kb4hm-a2-10170013. Self-play datagen (forge_selfplay 9308 + 2 workers, selfplay_guard) alive. STOP_nnue absent. UNPROVEN.
| auto-n384-kb4hm-a2 (GPU, auto_queue) | 15:13→15:45 | same mix | 768->384 KB4 HM1 (v4) | warm a1 (95ee653c), 5e-5 cos 10ep | shared **0.007219** (ep10) / sp_all 0.003184 | same shape as a1 pack | not tested | UNPROVEN — DONE, new best, NOT yet packed (net-only swap candidate for dist-cand-kb4hmn384a1simd-1749); md5 cf1bd00f |
| auto-n384-kb4hm-r1 (GPU, auto_queue) | 15:45→ | same mix | 768->384 KB4 HM1 (v4) | warm a2 (cf1bd00f), 3.5e-5 cos 8ep | — | — | — | UNPROVEN — RUNNING |

- 2026-10-16 ~15:52 PT GPU idle guard: **auto-n384-kb4hm-a2-10170013 DONE 15:45 PT** (pc 00:13→00:45): warm a1 95ee653c, same 5-source mix, H384 lr 5e-5 cos 10ep. Best ep10 **val_shared 0.007219** (new best; a1 0.007233, H512 c3 0.007235), forge_sp_all 0.003184 (a1 0.003182, flat), md5 **cf1bd00fdbcd7969a74d315b8cb216e8**. PC: F:\grok-pc-nnue-auto\nets\auto-n384-kb4hm-a2-10170013\net_v4.nnue. Not packed yet (small −0.000014 shared gain; next: net-only swap of the a1-1749 pack + parity). UNPROVEN.
- auto_queue (PID 1380) chained **auto-n384-kb4hm-r1-10170045** at 15:45 PT (PIDs 13892/5660, Idle, affinity 0xF000): warm a2 cf1bd00f, same mix, H384 lr 3.5e-5 cos 8ep, out F:\grok-pc-nnue-auto\nets\auto-n384-kb4hm-r1-10170045. Self-play datagen (selfplay_guard + forge_selfplay 6624/9308) alive. STOP_nnue absent. GPU temps from HWiNFO in range. UNPROVEN.
- **PACKED dist-cand-kb4hmn384a2simd-1749 ~15:55 PT** (UNPROVEN): cp -a of dist-cand-kb4hmn384a1simd-1749, only net.nnue swapped for nets/auto-n384-kb4hm-a2/net_v4.nnue (md5 cf1bd00fdbcd7969a74d315b8cb216e8 verified; copied F: -> pc staging nnue\nets\auto-n384-kb4hm-a2-10170013 -> box, since F: is outside local-exec root; shared 0.007219 vs a1 0.007233). diff -rq: net.nnue only. v4 parity (v4_parity/results_n384a2_1749.json): refresh 0/300, inc 2372 evals, 0 mismatches all checks, simd on. Gates (chess-engine-nnue/gates_n384a2_1749.log): perft PASS, movegen 36/0, tactics 6/0, mate 10/0, mate_distance 5/5, uci_edge 27, bug_gate PASS (PARTIAL, fuzz skipped: slots full), new 0, KNOWN 6 (a1: 5) — the extra is known-class "insufficient KBvKB same colour" (a2 cp 2, a1 passes; net eval, not a draw-rule code change). Bench H256 d10 (prof1748_n384 bench_hash.js): a2 236967 nodes, a1 262519 (NPS not comparable: gates running concurrently). a1-1749 gates: DONE 14:54 PT, all PASS (PARTIAL, fuzz skipped), KNOWN 5. Next: Profiler a2 vs 1.7.49 (+a1 re-time), QA chooses a2 vs a1; fuzz still owed for both.

### 2026-10-16 ~15:58 PT — hourly (all UNPROVEN)
- Lock still 1.7.49 (baseline/dist-v1.7.49). Box load 4.1 (no box training; GPU work is on grok-pc).
- Profiler a1-1749 (net 95ee653c) vs 1.7.49 (prof1749_a1, 5 ABBA, game_seq d10 T1): nodes −36%, time-to-d10 −16.7% (5/5 faster), NPS −23.6% → ≤25% gate PASS but close (c3-1749 same shape measured −13.5%; spread is likely load noise).
- dist-cand-kb4hmn384a2simd-1749 (net cf1bd00f, shared 0.007219) packed + gated 15:53 PT: PASS (PARTIAL, fuzz skipped), KNOWN 6 vs a1 5 (extra = KBvKB same-colour eval cp 2; net eval, not code). Preferred H384 net-only candidate over a1/c3 on val loss; still needs Profiler NPS vs 1.7.49 and QA fuzz/TL/[0,10].
- GPU: auto_queue r1 (auto-n384-kb4hm-r1-10170045, warm a2, 3.5e-5 cos 8ep) running since 15:45 PT. Datagen alive per 15:52 guard. STOP_nnue absent.
| auto-n384-kb4hm-r1 (GPU, auto_queue) | 15:45→16:14 | same mix | 768->384 KB4 HM1 (v4) | warm a2 (cf1bd00f), 3.5e-5 cos 8ep | shared **0.007211** (ep7) / sp_all 0.003186 | same shape as a2 pack | not tested | UNPROVEN — DONE, new best, NOT packed (net-only swap candidate for dist-cand-kb4hmn384a2simd-1749); md5 55d8f913 |
| auto-n384-kb4hm-r2 (GPU, auto_queue) | 16:14→16:45 | same mix | 768->384 KB4 HM1 (v4) | warm r1 (55d8f913), 2.45e-5 cos 8ep | shared **0.007207** (ep7) / sp_all 0.003184 | same shape as a2 pack | not tested | UNPROVEN — DONE, new best (tiny), NOT packed; md5 f4c42da6 |
| auto-n384-kb4hm-r3 (GPU, auto_queue) | 16:46→ | same mix | 768->384 KB4 HM1 (v4) | warm r2 (f4c42da6), 1.715e-5 cos 8ep | — | — | — | UNPROVEN — RUNNING |

- 2026-10-16 ~16:22 PT GPU idle guard: **auto-n384-kb4hm-r1-10170045 DONE 16:14 PT** (pc 00:45→01:14): warm a2 cf1bd00f, same 5-source mix, H384 lr 3.5e-5 cos 8ep. Best ep7 **val_shared 0.007211** (new best; a2 0.007219, −0.000008), forge_sp_all 0.003186 (a2 0.003184, flat), md5 **55d8f913fef542483aea07b014afe4c5**. PC: F:\grok-pc-nnue-auto\nets\auto-n384-kb4hm-r1-10170045\net_v4.nnue. Not packed (tiny gain; diminishing returns on this lineage). UNPROVEN.
- auto_queue (PID 1380) chained **auto-n384-kb4hm-r2-10170114** at 16:14 PT (PIDs 13320/7856, Idle, affinity 0xF000): warm r1 55d8f913, same mix, H384 lr 2.45e-5 cos 8ep, out F:\grok-pc-nnue-auto\nets\auto-n384-kb4hm-r2-10170114 (ep1 checkpoint 16:18 PT). Self-play datagen (selfplay_guard 9100/10368 + forge_selfplay 9308/6624 + 2 workers) alive. STOP_nnue absent. No job started by guard (GPU busy). UNPROVEN.

- 2026-10-16 ~16:52 PT GPU idle guard: **auto-n384-kb4hm-r2-10170114 DONE 16:45 PT** (pc 01:14→01:45): warm r1 55d8f913, same 5-source mix, H384 lr 2.45e-5 cos 8ep. Best ep7 **val_shared 0.007207** (new best; r1 0.007211, −0.000004, diminishing), forge_sp_all 0.003184 (flat), md5 **f4c42da60008c7504536767dd0f6ed45**. PC: F:\grok-pc-nnue-auto\nets\auto-n384-kb4hm-r2-10170114\net_v4.nnue. Not packed (tiny gain over a2 cf1bd00f 0.007219; LR-decay chain is flattening).
- auto_queue (PID 1380) chained **auto-n384-kb4hm-r3-10170146** at 16:46 PT (python PID 412, Idle, affinity 0xF000): warm r2 f4c42da6, same mix, H384 lr 1.715e-5 cos 8ep (ep1 checkpoint 16:50 PT). Self-play datagen alive (forge_selfplay_006.txt.part growing, 525 MB at 16:51 PT). STOP_nnue absent. No job started by guard (GPU busy). nvidia-smi not on PATH this run; job judged live from process + fresh checkpoints. All UNPROVEN.
- 2026-10-16 ~16:57 PT NNUE hourly: lock 1.7.49 (unchanged). auto_queue PID 1380 alive; **auto-n384-kb4hm-r3-10170146** training (python PID 412, ep2 checkpoint 16:54 PT, warm r2 f4c42da6, 1.715e-5 cos 8ep). AUTO_BEST H384 = r2 f4c42da6 0.007207 (not packed; tiny gain over packed a2 cf1bd00f). Self-play datagen alive (forge_selfplay_006.txt.part 532 MB, growing). STOP_nnue absent. Free C 40 / D 164 / F 173 GB. Box load 4.16, so no box work this hour. Nothing new to pack or gate; no messages sent. All UNPROVEN.
- 2026-10-16 ~17:24 PT GPU idle guard: **auto-n384-kb4hm-r3-10170146 DONE 17:18 PT** (pc 01:46→02:18): warm r2 f4c42da6, same 5-source mix, H384 lr 1.715e-5 cos 8ep. Best ep7 **val_shared 0.007205** (new best; r2 0.007207, −0.000002, LR-decay chain nearly flat), forge_sp_all 0.003182 (flat), md5 **d741d7ac248c8818c19bfb48f66573ab**. PC: F:\grok-pc-nnue-auto\nets\auto-n384-kb4hm-r3-10170146\net_v4.nnue. Not packed (gain over packed a2 cf1bd00f 0.007219 is tiny). UNPROVEN.
- auto_queue (PID 1380) chained **auto-n384-kb4hm-r4-10170218** at 17:18 PT (python PIDs 10776/13316, Idle, affinity 0xF000): warm r3 d741d7ac, same mix, H384 lr 1.2005e-5 cos 8ep, out F:\grok-pc-nnue-auto\nets\auto-n384-kb4hm-r4-10170218. Self-play datagen (selfplay_guard 9100/10368 + forge_selfplay 9308/6624 + 2 workers) alive. STOP_nnue absent. No job started by guard (GPU busy). Note: further r-chain steps give ~0.000002 each; Strategist/hourly should consider a new experiment after r4 instead of r5. All UNPROVEN.

### 2026-10-17 ~07:06 PT — GPU idle guard (all UNPROVEN)
- **GPU BUSY** (live process + HWiNFO util): **auto-n384-kb4hm-r46-10171550** running. Wrapper PID 12776 + train PID 6868, Idle, affinity 0xF000. Warm **r3** d741d7ac, H384 lr **1e-5** cos 8ep, same 5-source mix, out F:\grok-pc-nnue-auto\nets\auto-n384-kb4hm-r46-10171550. auto_queue PID 1380 + thermal_guard PID 1800 alive. No second GPU job started.
- Temps (HWiNFO gpu_sensors.csv, PC clock ~9h ahead of real PT): hot spot **70 C**, memory junction **88 C**, GPU util **55%**, edge/GPU temp 61 C. STOP_nnue absent.
- **AUTO_BEST still r3**: H384 shared **0.007205** md5 **d741d7ac** (auto-n384-kb4hm-r3-10170146). NOT packed.
- Catch-up: auto_queue kept chaining LR-flat repeats **r4…r45** overnight (all warm r3, lr 1e-5 cos 8ep); every recorded shared stayed **0.007205** (same md5 a8f1d7b4 on several), none beat r3, none packed. Chain is fully flat — after r46, prefer a **new experiment** over more rN.
- **Datagen was DEAD**: forge_selfplay_006 finished PC ~03:07 Oct 17 (~18:07 PT Oct 16) with `Engine returned no score`; selfplay_guard exit 1. No live selfplay processes; no .part. **Restarted** selfplay_guard PID **8828** (Idle 0xF000) → forge_selfplay 2 workers on CPUs 12-15 → new file **D:\grok-pc-data\selfplay_out\forge_selfplay_007.txt.part** (growing). Engine PIDs 7896/10344 Idle 0xF000.
- Parent: no WakeParent/message Couns needed for GPU (busy, not idle-start). Optional note: datagen was down ~13h and is back; LR chain still flattening.

### 2026-10-17 ~07:49 PT GPU idle guard
- **auto-n384-kb4hm-r47-10171609 DONE** ~07:36 PT (PC 16:36): best ep7 shared **0.007205**, md5 **a8f1d7b4** — byte-identical duplicate of r44–r46 (warm r3, lr 1e-5 cos 8ep, same 5-source mix). Not better than AUTO_BEST r3 d741d7ac. NOT packed. UNPROVEN.
- **GPU BUSY**: auto_queue chained **auto-n384-kb4hm-r48-10171636** at 07:36 PT (PIDs 12172/11060), same deterministic config again; at ep3 (net.pt written 07:48 PT). auto_queue 1380 + thermal_guard 1800 alive; STOP_nnue absent. No action taken (job running). Note: r48 will almost certainly reproduce a8f1d7b4 again — auto_queue needs a new experiment instead of more rN repeats.
- Datagen alive: selfplay_guard 8828, forge_selfplay 6328/6504 → D:\grok-pc-data\selfplay_out\forge_selfplay_007.txt.part (62.9 MB, growing).

### 2026-10-17 ~07:50 PT — hourly (all UNPROVEN)
- GPU busy: **auto-n384-kb4hm-r48-10171636** (PIDs 12172/11060, Idle, 0xF000) started 07:37 PT, warm r3 d741d7ac, lr 1e-5 cos 8ep. r47 DONE 07:36 PT: shared 0.007205, md5 a8f1d7b4 = byte-identical to r44–r46 (deterministic repeat). AUTO_BEST unchanged: H384 r3 d741d7ac 0.007205 (not packed), H512 c3 98778fb4 0.007235.
- Cause: auto_queue fallback lr floors at 1e-5 and parent stays r3 when nothing strictly beats it, so every rN is the same run. **Fix:** backed up auto_queue.ps1 (md5 c54021af → nnue\auto_queue.ps1.bak_c54021af_1017), appended 4 new queue entries (state qi=3 so they run next): s1 H384 lr 4e-5 cos 12ep, s2 H384 lr 2e-5 cos 12ep, c4 H512 lr 5e-5 cos 10ep (from 98778fb4), s3 H384 lr 1e-5 cos 16ep. New md5 cb1346ad; parse OK; dry-run picked qi=3. Restarted supervisor: killed 1380, new auto_queue PID 10740 adopted r48 (will record it as "adopted", then launch s1). After s3 the old rN fallback resumes, so add more experiments before then (~3–4 h).
- thermal_guard 1800 alive; temps hot spot 73 C, mem junction 89 C (queue waits to launch above 80/88). Datagen alive: selfplay_guard 8828 (+13440), forge_selfplay 6328/6504, forge 7896/10344; forge_selfplay_007.txt.part 61 MB, growing. STOP_nnue absent. Free C 39 / D 163 / F 171 GB.
- PC also running QA orch_1750 slots (pcE: dist-cand-kb4hmn384a2simd-1750 gain test) — QA's, not touched. Box load 2.2; no box work this hour. No messages sent.

### 2026-10-17 ~08:15 PT — new self-play data + queue de-stuck (Engine NNUE executor, all UNPROVEN)
- **r4…r48 FAILED to beat r3**: all warm r3 d741d7ac, lr 1e-5 cos 8ep, old 5-source mix. Best shared stayed 0.007205. r43–r48 all produced md5 **a8f1d7b4** (byte-identical: same parent, same data, seed 0, lr at the floor). Not packed. Retired.
- **New data sp_new_v1** (D:\grok-pc-data\sp_new_v1; check report SP_NEW_V1_CHECK.md = PASS). Sources: the 005 tail past forge_sp_new_train's prefix, all of 006, and a 007 prefix snapshot (41,456,162 B). **train 16,845,176 (md5 9b6aa8c5ee07a94495a4ecbd155d6894) / val 341,864 (md5 daf456eee6194b4c52a928f929d35166)**, split by game (2% of 210,411 games). Rows keep result + has_result (WDL format). Leak-dropped 800 rows (val_shared 398, ...). **Exact re-check: 0 leaks** against val_shared, holdout val, sp_all val, data40m val, forgepgn val and pilot val. Decode check: 192,404 of 192,411 sampled rows byte-identical to python-chess, 0 in check, 0 invalid.
- **kbdraw_v1** (D:\grok-pc-data\kbdraw_v1): 190,800 / 10,042 synthetic dead draws (KBvKB same colour 55%, ...), score 0, draw. Aimed at a2's KBvKB +2 cp. md5 8d48a920 / 0eee503f. 0 leaks.
- Tools (grok-pc nnue\, copies in nnue/sp_new/): build_sp_new_v1.py, check_sp_new_v1.py, build_kbdraw_v1.py, build_sp_chunk.py (incremental converter for finished files, tested in a sandbox on a 46 MB 007 prefix: 63,275/924 rows, ledger and job append OK), auto_override.py (md5 074ad40e), auto_jobs.json.
- Trainer: train_gpu3kb.py got a top-of-file hook plus `--seed` (743ca859 → c56c199f). CPU parity old vs new vs new --seed 0 gives the identical net md5 c0a778c3. WDL support already existed (`--result-w`). data40m has has_result=0, so lichess stays at λ=1.0.
- Queue: auto_queue.ps1 is **not edited by me**. At 16:49 pc (07:49 PT) another agent replaced it with md5 cb1346ad (adds s1, s2, c4 H512, s3 on the OLD data) and restarted the supervisor as **PID 10740**. PID 1380 was already gone by then; I never touched it. The hook rewrites H384 `rN`/`sN` slots into the next pending job of auto_jobs.json: 24 distinct jobs, a signature repeat guard, a dup-md5 flag, 3 jobs auto-added per converted chunk, and a wait (never repeat) when empty. **s1** (old data, warm r3 lr 4e-5 cos 12ep, launched 08:11 PT, PIDs 13192/4568) is theirs and was left to run. The next H384 slot (s2) becomes **x1** = W1 mix (data40m .72, forgepgn .05, holdout .06, sp_new_train .03, pilot .04, **sp_new_v1 .097**, **kbdraw .003**), warm r3, lr 5e-5 cos 8ep, result-w 0. Then x2 (WDL 0.2), x3 (lr 1e-4 10ep), x4 (W2, SP .157), x5/x6, then the grid. c4 H512 stays theirs.
