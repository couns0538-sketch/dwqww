#!/usr/bin/env python3
"""Independent incremental replay of frozen generation traces; no new games."""
from collections import Counter, deque
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import random
import sys

import chess
import chess.engine

OUT = Path(__file__).resolve().parent
RUN = OUT.parent / 'generated-games-256-attempt1'
FROZEN = Path('/workspace/.cloud-setup/nnue-pipeline-20261023-generator-frozen-v1')
MAX_PLY, THRESHOLD, STREAK, OPENING_PLIES = 300, 2000, 4, 8


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def write_json(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def fail(reason, **details):
    write_json('FIRST-FAILURE.json', {'status': 'FAIL', 'reason': reason, **details})
    raise ValueError(reason + ': ' + json.dumps(details, separators=(',', ':')))


def require(condition, reason, **details):
    if not condition:
        fail(reason, **details)


def key(board):
    # Same complete-position key used by python-chess is_repetition. Counting
    # incrementally avoids replaying the entire move history at every ply.
    return board._transposition_key()


def terminal(board, repetitions):
    flags = {
        'checkmate': board.is_checkmate(),
        'stalemate': board.is_stalemate(),
        'insufficient_material': board.is_insufficient_material(),
        'actual_threefold_repetition': repetitions[key(board)] >= 3,
        'actual_fifty_move_threshold': board.is_fifty_moves() if board.halfmove_clock >= 100 else False,
        'max_ply_reached': board.ply() >= MAX_PLY,
    }
    if flags['checkmate']:
        return (0.0 if board.turn == chess.WHITE else 1.0), 'natural_checkmate', flags
    for name in ('stalemate', 'insufficient_material', 'actual_threefold_repetition', 'actual_fifty_move_threshold'):
        if flags[name]:
            return .5, 'natural_' + name, flags
    if flags['max_ply_reached']:
        return .5, 'max_ply_adjudicated_draw', flags
    return None, None, flags


def draw_opening(seed):
    board = chess.Board()
    rng = random.Random(seed)
    moves = []
    for _ in range(OPENING_PLIES):
        if board.is_game_over(claim_draw=False) or board.is_repetition(3) or board.is_fifty_moves():
            return None
        move = rng.choice(list(board.legal_moves))
        moves.append(move.uci())
        board.push(move)
    if board.is_game_over(claim_draw=False) or board.is_repetition(3) or board.is_fifty_moves():
        return None
    return moves


class WorkerReplay:
    def __init__(self, worker, manifest, by_game, search_stream):
        self.worker = worker
        self.manifest = manifest
        self.by_game = by_game
        self.search_stream = search_stream
        self.game_number = -1
        self.current = None
        self.games = []
        self.trace_rows = 0
        self.search_count = 0
        self.quit_seen = False

    def new_game(self, trace_line):
        if self.current is not None:
            self.finish(trace_line)
        self.game_number += 1
        index = self.worker + 2 * self.game_number
        require(index < 256 and not self.quit_seen, 'Unexpected ucinewgame segment', worker=self.worker, index=index)
        # IDs are taken from the original manifest, not invented by this audit.
        game_id = self.manifest['completed_game_ids'][index]
        require(game_id == self.manifest['run_id'] + ':' + str(index), 'Manifest game index mismatch', index=index)
        board = chess.Board()
        self.current = {'index': index, 'game_id': game_id, 'worker': self.worker,
            'start_trace_line': trace_line, 'board': board, 'history': [],
            'repetitions': Counter({key(board): 1}), 'searching': False,
            'position_pending': False, 'last_score': None, 'last_score_line': None,
            'last_score_bound': False, 'winner': None, 'streak': 0,
            'last_scores': deque(maxlen=4), 'expected_rows': [], 'searches': 0,
            'termination': None, 'last_bestmove_trace_line': None}

    def position(self, line, trace_line):
        c = self.current
        require(c is not None and c['termination'] is None and not c['searching'],
                'Position command outside active nonterminal game', worker=self.worker, trace_line=trace_line)
        words = line.split()
        require(words[:3] == ['position', 'startpos', 'moves'], 'Unexpected position form', trace_line=trace_line)
        moves = words[3:]
        if not c['history']:
            require(len(moves) == OPENING_PLIES, 'Opening length mismatch', game_id=c['game_id'], moves=moves)
            # Failed pre-UCI opening retries leave no trace. Accept only an
            # explicitly reproduced legal opening from the documented seeds.
            attempts = [attempt for attempt in range(10)
                if draw_opening(self.manifest['seed'] + c['index'] + attempt * 256) == moves]
            require(attempts, 'Opening does not match any source RNG attempt', game_id=c['game_id'])
            c['opening_attempt_matches'] = attempts
            c['opening_moves'] = list(moves)
            for text in moves:
                move = chess.Move.from_uci(text)
                require(move in c['board'].legal_moves, 'Illegal opening move', game_id=c['game_id'], move=text)
                c['board'].push(move)
                c['history'].append(text)
                c['repetitions'][key(c['board'])] += 1
        require(moves == c['history'], 'Full position history differs from accepted moves',
                game_id=c['game_id'], trace_line=trace_line, expected=c['history'], actual=moves)
        require(terminal(c['board'], c['repetitions'])[0] is None,
                'Search requested after natural/max-ply terminal', game_id=c['game_id'], ply=c['board'].ply())
        c['position_pending'] = True
        c['position_trace_line'] = trace_line

    def go(self, line, trace_line):
        c = self.current
        require(c is not None and c['position_pending'] and not c['searching'] and c['termination'] is None,
                'Unpaired go command', worker=self.worker, trace_line=trace_line)
        require(line.split() == ['go', 'nodes', '5000'], 'Unexpected search budget', line=line)
        c['position_pending'] = False
        c['searching'] = True
        c['last_score'] = None
        c['last_score_line'] = None
        c['last_score_bound'] = False
        c['go_trace_line'] = trace_line

    def score(self, line, trace_line):
        words = line.split()
        if words[:1] != ['info'] or words[1:2] == ['string'] or 'score' not in words:
            return
        c = self.current
        require(c is not None and c['searching'], 'Score received outside search', trace_line=trace_line)
        require('multipv' not in words or words[words.index('multipv') + 1] == '1',
                'Unexpected non-primary multipv score', trace_line=trace_line)
        offset = words.index('score')
        kind, value = words[offset + 1], int(words[offset + 2])
        require(kind in ('cp', 'mate'), 'Unknown UCI score type', trace_line=trace_line)
        c['last_score'] = {'type': kind, 'value_stm': value}
        c['last_score_line'] = trace_line
        c['last_score_bound'] = 'lowerbound' in words or 'upperbound' in words

    def bestmove(self, line, trace_line):
        c = self.current
        require(c is not None and c['searching'] and c['last_score'] is not None,
                'Bestmove without active scored search', worker=self.worker, trace_line=trace_line)
        board = c['board']
        text = line.split()[1]
        move = chess.Move.from_uci(text)
        require(move in board.legal_moves, 'Illegal engine bestmove', game_id=c['game_id'], trace_line=trace_line, move=text)
        score = c['last_score']
        bounded = c['last_score_bound']
        cp = score['value_stm'] if score['type'] == 'cp' else None
        # Independent reconstruction of both original eligible_score and the
        # completed-game writer filter, which additionally excludes checks.
        retained = (not bounded and cp is not None and abs(cp) <= 3000
            and not board.is_check() and not board.is_capture(move)
            and not move.promotion and not board.gives_check(move))
        fen, ply = board.fen(en_passant='fen'), board.ply()
        if retained:
            expected = {'fen': fen, 'score_cp_stm': cp, 'ply': ply, 'bestmove': text,
                'game_id': c['game_id'], 'engine_sha256': self.manifest['engine']['sha256']}
            c['expected_rows'].append(expected)
        value = chess.engine.Cp(cp) if cp is not None else chess.engine.Mate(score['value_stm'])
        white_score = value if board.turn == chess.WHITE else -value
        winning_side = None
        if not bounded:
            if white_score >= chess.engine.Cp(THRESHOLD):
                winning_side = 'white'
            elif white_score <= chess.engine.Cp(-THRESHOLD):
                winning_side = 'black'
        c['streak'] = c['streak'] + 1 if winning_side is not None and winning_side == c['winner'] else (1 if winning_side else 0)
        c['winner'] = winning_side
        record = {'game_id': c['game_id'], 'worker': self.worker, 'ply': ply, 'fen': fen,
            'move': text, 'score': score, 'score_bounded': bounded, 'winning_side': winning_side,
            'winner_streak': c['streak'], 'row_retained': retained,
            'position_trace_line': c['position_trace_line'], 'go_trace_line': c['go_trace_line'],
            'final_score_trace_line': c['last_score_line'], 'bestmove_trace_line': trace_line}
        self.search_stream.write(json.dumps(record, separators=(',', ':')) + '\n')
        c['last_scores'].append(record)
        c['searches'] += 1
        self.search_count += 1
        c['history'].append(text)
        board.push(move)
        c['repetitions'][key(board)] += 1
        c['searching'] = False
        c['last_bestmove_trace_line'] = trace_line
        result, reason, flags = terminal(board, c['repetitions'])
        if result is None and c['streak'] >= STREAK:
            result = 1. if c['winner'] == 'white' else 0.
            reason = 'four_ply_score_adjudication'
        if result is not None:
            c['termination'] = {'result_white': result, 'reason': reason, 'flags': flags}

    def finish(self, boundary_trace_line):
        c = self.current
        require(not c['searching'] and not c['position_pending'] and c['termination'] is not None,
                'Trace game ended without documented terminal/adjudication', game_id=c['game_id'], ply=c['board'].ply())
        result = c['termination']['result_white']
        actual = self.by_game.get(c['game_id'], [])
        require(len(actual) == len(c['expected_rows']), 'Retained row count mismatch',
                game_id=c['game_id'], expected=len(c['expected_rows']), actual=len(actual))
        for expected, original in zip(c['expected_rows'], actual):
            expected['result_white'] = result
            require(expected == original['row'], 'Saved label/FEN/score/move/history mismatch',
                    game_id=c['game_id'], source_line=original['line'], expected=expected, actual=original['row'])
        # Independent library history verification of the incremental counter.
        require((c['repetitions'][key(c['board'])] >= 3) == c['board'].is_repetition(3),
                'Incremental repetition counter differs from library full-history test', game_id=c['game_id'])
        game = {'game_id': c['game_id'], 'game_index': c['index'], 'worker': self.worker,
            'trace_segment_start_line': c['start_trace_line'], 'trace_segment_boundary_line': boundary_trace_line,
            'opening_attempt_matches': c['opening_attempt_matches'], 'opening_moves_uci': c['opening_moves'],
            'accepted_moves_uci': c['history'], 'final_fen': c['board'].fen(en_passant='fen'),
            'final_ply': c['board'].ply(), 'final_halfmove_clock': c['board'].halfmove_clock,
            'searched_plies': c['searches'], 'retained_rows': len(actual),
            'original_row_source_lines': [row['line'] for row in actual],
            'result_labels_verified': len(actual), **c['termination'],
            'last_score_streak': c['streak'], 'last_score_winning_side': c['winner'],
            'last_four_searches': list(c['last_scores']),
            'final_actual_threefold_library_check': c['board'].is_repetition(3)}
        self.games.append(game)
        if len(self.games) % 16 == 0:
            print(json.dumps({'worker': self.worker, 'verified_games': len(self.games),
                'last_game_id': game['game_id'], 'reason': game['reason']}), flush=True)
        self.current = None

    def replay(self, path):
        with path.open() as stream:
            for number, line in enumerate(stream, 1):
                row = json.loads(line)
                direction, text = row['direction'], row['line']
                self.trace_rows = number
                require(direction in ('send', 'receive'), 'Invalid trace direction', trace_line=number)
                if direction == 'send':
                    if text == 'ucinewgame':
                        self.new_game(number)
                    elif text.startswith('position '):
                        self.position(text, number)
                    elif text == 'go' or text.startswith('go '):
                        self.go(text, number)
                    elif text == 'quit':
                        require(not self.quit_seen and self.current is not None, 'Unexpected quit boundary', worker=self.worker)
                        self.finish(number)
                        self.quit_seen = True
                    else:
                        require(text == 'isready' or text.startswith('setoption '), 'Unexpected sent command', line=text)
                elif text.startswith('bestmove '):
                    self.bestmove(text, number)
                else:
                    self.score(text, number)
        require(self.quit_seen and self.current is None and len(self.games) == 128,
                'Worker game/closure count mismatch', worker=self.worker, games=len(self.games), quit_seen=self.quit_seen)


def main():
    require(not (OUT / 'INPUTS.json').exists(), 'Fresh attempt required')
    manifest_path = RUN / 'manifest.json'
    manifest = json.loads(manifest_path.read_text())
    require(manifest['completed_games'] == 256 and manifest['workers'] == 2
        and manifest['positions']['rows'] == 21000
        and manifest['status'] == 'PASS_COMPLETED_GAMES_OWNED_ENGINES_CLOSED'
        and manifest['termination']['max_ply'] == MAX_PLY
        and manifest['termination']['adjudicate_cp'] == THRESHOLD
        and manifest['termination']['adjudicate_plies'] == STREAK,
        'Unexpected generation manifest')
    paths = [Path(__file__), manifest_path, RUN / 'games.jsonl',
        RUN / 'worker-0-uci.jsonl', RUN / 'worker-1-uci.jsonl',
        RUN / 'worker-0-process.json', RUN / 'worker-1-process.json',
        Path(chess.__file__), Path(chess.engine.__file__),
        Path(manifest['engine']['path']), Path(manifest['network']['path']),
        *[Path(path) for path in manifest['generator_source_files_before']]]
    identities = {str(path): {'sha256': sha(path), 'bytes': path.stat().st_size} for path in paths}
    for path, expected in manifest['generator_source_files_before'].items():
        require(identities[path]['sha256'] == expected == manifest['generator_source_files_after'][path],
                'Frozen source hash mismatch', path=path)
    for kind in ('engine', 'network', 'positions'):
        require(identities[manifest[kind]['path']]['sha256'] == manifest[kind]['sha256'],
                'Manifest input hash mismatch', kind=kind)
    write_json('INPUTS.json', {'utc': datetime.now(timezone.utc).isoformat(),
        'identities': identities, 'python_version': sys.version, 'python_chess_version': chess.__version__,
        'command': [sys.executable, '-B', str(Path(__file__).resolve())],
        'mapping': 'Original completed_game_ids[index], where index=worker_id+2*ucinewgame_segment_index; worker0 even, worker1 odd',
        'scope': 'Independent replay of original raw UCI generation traces, no new engine invocation, no invented PGN or game IDs'})
    by_game, original_count = {}, 0
    with (RUN / 'games.jsonl').open() as stream:
        for number, line in enumerate(stream, 1):
            row = json.loads(line)
            require(row['game_id'] in manifest['completed_game_ids'], 'Unknown saved game ID', source_line=number)
            by_game.setdefault(row['game_id'], []).append({'line': number, 'row': row})
            original_count += 1
    games, workers = [], []
    with (OUT / 'reconstructed-searches.jsonl').open('x') as searches:
        for worker in (0, 1):
            replay = WorkerReplay(worker, manifest, by_game, searches)
            replay.replay(RUN / f'worker-{worker}-uci.jsonl')
            games.extend(replay.games)
            workers.append({'worker': worker, 'games': len(replay.games), 'trace_rows': replay.trace_rows,
                'searches': replay.search_count, 'quit_seen': replay.quit_seen})
    games.sort(key=lambda game: game['game_index'])
    require([game['game_id'] for game in games] == manifest['completed_game_ids'], 'Replayed game ID set/order mismatch')
    require(original_count == sum(game['result_labels_verified'] for game in games) == 21000,
            'Not all original labeled rows were verified')
    require(all(sha(path) == record['sha256'] for path, record in identities.items()),
            'Input changed during replay')
    with (OUT / 'per-game.jsonl').open('x') as stream:
        for game in games:
            stream.write(json.dumps(game, separators=(',', ':')) + '\n')
    terminations = Counter(game['reason'] for game in games)
    rows_by_termination = Counter()
    for game in games:
        rows_by_termination[game['reason']] += game['retained_rows']
    summary = {'status': 'PASS_ALL_256_GAMES_AND_21000_SAVED_ROWS_VERIFIED',
        'utc': datetime.now(timezone.utc).isoformat(), 'games': len(games), 'saved_rows_verified': original_count,
        'workers': workers, 'termination_games': dict(sorted(terminations.items())),
        'termination_game_fractions': {name: count / 256 for name, count in sorted(terminations.items())},
        'saved_rows_by_termination': dict(sorted(rows_by_termination.items())),
        'saved_row_fractions_by_termination': {name: count / original_count for name, count in sorted(rows_by_termination.items())},
        'all_games_result_counts': dict(Counter(str(game['result_white']) for game in games)),
        'max_ply_reached_including_natural_coincidences': sum(game['flags']['max_ply_reached'] for game in games),
        'all_openings_match_attempt_zero': all(0 in game['opening_attempt_matches'] for game in games),
        'all_moves_legal': True, 'all_full_position_histories_match': True,
        'all_retained_fen_ply_bestmove_cp_enginehash_and_result_labels_match': True,
        'all_final_incremental_repetition_counts_match_library': True,
        'all_inputs_unchanged_after_replay': True,
        'note': 'Reason precedence mirrors source: checkmate; natural draw flags in source order; max-ply draw; then 4-ply score adjudication. All final flags retained, so max-ply coincidences are visible.',
        'limitations': 'Outcome labels are source-consistent adjudications, not proof of eventual game-theoretic outcome. Max-ply draws can truncate non-drawn positions. Score adjudication uses low-node same-engine scores and can be wrong. Result-weight ramp inherits these label limitations. No original PGN is invented or claimed, no external-strength or Elo evidence.'}
    write_json('RESULT.json', summary)
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == '__main__':
    main()
