#!/usr/bin/env python3
"""Bounded training-only legacy-label agreement diagnostic; never a holdout."""
from datetime import datetime, timezone
from pathlib import Path
from collections import Counter
import hashlib
import json
import math
import os
import random
import subprocess
import sys

OUT = Path(__file__).resolve().parent
HANDOFF = OUT.parent
REPO = Path('/workspace/dwqww')
MANIFEST = HANDOFF / 'selfplay-input/DATA-INSPECTION.json'
PROBE = Path('/workspace/.cloud-setup/nnue-pipeline-20261023-working-build/forge_nnue_probe')
NET = REPO / 'src/nnue_weights.inc'
SEED, STRIDE, PER_FILE, SCORE_CAP = 20261023, 1500, 1000, 1000
EXPECTED_PROBE = 'd2f400df382c1dc4b048f2bfa1d36c3ca09c84d9c34c043d87b327692b473e49'
EXPECTED_NET = '41487f328ff51f27417564df45b6f3139d038b7e940dedb121340bd61be9a4d3'


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def write_json(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def stat_key(path):
    info = path.stat()
    return {key: getattr(info, key) for key in ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns')}


def probability(cp):
    # Float64 diagnostic arithmetic, fixed pure teacher formula, no WDL mixing.
    value = cp * 2.25 / 400.0
    if value >= 0:
        return 1.0 / (1.0 + math.exp(-value))
    exponent = math.exp(value)
    return exponent / (1.0 + exponent)


def distribution(values):
    if not values:
        return {'n': 0}
    values = sorted(values)
    count = len(values)
    def quantile(q):
        index = (count - 1) * q
        lower = int(math.floor(index))
        upper = int(math.ceil(index))
        return values[lower] + (values[upper] - values[lower]) * (index - lower)
    mean = math.fsum(values) / count
    return {'n': count, 'mean': mean,
            'population_stddev': math.sqrt(math.fsum((v - mean) ** 2 for v in values) / count),
            'min': values[0], 'p01': quantile(.01), 'p05': quantile(.05),
            'p25': quantile(.25), 'median': quantile(.5), 'p75': quantile(.75),
            'p95': quantile(.95), 'p99': quantile(.99), 'max': values[-1],
            'positive_fraction': sum(v > 0 for v in values) / count,
            'negative_fraction': sum(v < 0 for v in values) / count,
            'zero_fraction': sum(v == 0 for v in values) / count}


def summarize(rows):
    if not rows:
        return {'n': 0, 'mse_hce': None, 'mse_shipped_hybrid': None}
    count = len(rows)
    hce_loss = math.fsum(row['hce_probability_squared_error'] for row in rows) / count
    hybrid_loss = math.fsum(row['hybrid_probability_squared_error'] for row in rows) / count
    return {
        'n': count, 'mse_hce': hce_loss, 'mse_shipped_hybrid': hybrid_loss,
        'mse_hybrid_minus_hce': hybrid_loss - hce_loss,
        'relative_mse_reduction_hybrid_vs_hce': 1 - hybrid_loss / hce_loss if hce_loss else None,
        'rows_hybrid_lower_squared_error': sum(row['hybrid_probability_squared_error'] < row['hce_probability_squared_error'] for row in rows),
        'rows_hybrid_higher_squared_error': sum(row['hybrid_probability_squared_error'] > row['hce_probability_squared_error'] for row in rows),
        'rows_equal_squared_error': sum(row['hybrid_probability_squared_error'] == row['hce_probability_squared_error'] for row in rows),
        'teacher_cp_stm': distribution([row['score_cp_stm'] for row in rows]),
        'hce_cp_stm': distribution([row['hce_cp_stm'] for row in rows]),
        'shipped_hybrid_cp_stm': distribution([row['hybrid_cp_stm'] for row in rows]),
        'shipped_nnue_correction_cp_stm': distribution([row['nnue_cp_stm'] for row in rows]),
        'residual_target_teacher_minus_hce_cp': distribution([row['residual_target_cp'] for row in rows]),
        'remaining_target_teacher_minus_hybrid_cp': distribution([row['score_cp_stm'] - row['hybrid_cp_stm'] for row in rows]),
        'teacher_probability_minus_hce_probability': distribution([row['teacher_probability'] - row['hce_probability'] for row in rows]),
        'abs_residual_target_cp': distribution([abs(row['residual_target_cp']) for row in rows]),
        'residual_target_abs_gt100_cp': sum(abs(row['residual_target_cp']) > 100 for row in rows),
        'residual_target_abs_gt300_cp': sum(abs(row['residual_target_cp']) > 300 for row in rows),
    }


def main():
    if (OUT / 'INPUTS.json').exists():
        raise ValueError('Fresh attempt only; existing receipt must never be overwritten')
    assert sha(PROBE) == EXPECTED_PROBE and sha(NET) == EXPECTED_NET
    identities = {str(path): sha(path) for path in (Path(__file__), MANIFEST, PROBE, NET,
        REPO / 'tools/nnue/engine_probe.cpp', REPO / 'src/nnue.cpp',
        REPO / 'include/forge/nnue.hpp', REPO / 'src/search.cpp')}
    files = sorted(json.loads(MANIFEST.read_text())['files'], key=lambda record: record['path'])
    if len(files) != 9 or any(record['lines'] != STRIDE * PER_FILE for record in files):
        raise ValueError('Expected exactly 9 previously inventoried 1.5-million-row legacy files')
    rng = random.Random(SEED)
    plan = [{'path': record['path'], 'expected_sha256': record['sha256'],
             'offset_zero_based': rng.randrange(STRIDE), 'stride': STRIDE,
             'sample_rows': PER_FILE, 'expected_bytes': record['bytes']} for record in files]
    write_json('INPUTS.json', {'utc': datetime.now(timezone.utc).isoformat(),
        'identities_sha256': identities, 'plan': plan,
        'formula': 'line_one_based = offset_zero_based + 1 + k * 1500, k=0..999; sorted source paths; Random(20261023)',
        'command': [sys.executable, '-B', str(Path(__file__).resolve())],
        'source_scope': 'Legacy TRAINING-ONLY diagnostic; no authenticated producer, game IDs, holdout, selection or strength claim'})
    originals = OUT / 'selected-original-lines'
    originals.mkdir(exist_ok=False)
    sampled, receipts = [], []
    for item in plan:
        path = Path(item['path'])
        before = stat_key(path)
        digest, selected_count, line_count = hashlib.sha256(), 0, 0
        with path.open('rb') as stream, (originals / path.name).open('xb') as retained:
            for zero_line, raw in enumerate(stream):
                digest.update(raw)
                line_count = zero_line + 1
                if zero_line >= item['offset_zero_based'] and (zero_line - item['offset_zero_based']) % STRIDE == 0:
                    fields = [field.strip() for field in raw.decode('ascii').split('|')]
                    if len(fields) != 3:
                        raise ValueError(f'Malformed sampled source row {path}:{line_count}')
                    fen, cp_text, result_text = fields
                    cp, white_result = int(cp_text), float(result_text)
                    if len(fen.split()) != 6 or white_result not in (0., .5, 1.):
                        raise ValueError(f'Malformed sampled labels/FEN {path}:{line_count}')
                    retained.write(raw)
                    sampled.append({'source_path': str(path), 'source_line': line_count,
                        'source_sha256': item['expected_sha256'],
                        'original_line_sha256': hashlib.sha256(raw).hexdigest(),
                        'fen': fen, 'score_cp_stm': cp, 'result_white_original': white_result,
                        'score_capped': abs(cp) <= SCORE_CAP})
                    selected_count += 1
        after = stat_key(path)
        if digest.hexdigest() != item['expected_sha256'] or before != after or selected_count != PER_FILE or line_count != STRIDE * PER_FILE:
            raise ValueError(f'Source hash/stat/sample count changed: {path}')
        receipts.append({**item, 'actual_sha256': digest.hexdigest(), 'physical_rows': line_count,
            'actual_sample_rows': selected_count, 'stat_before': before, 'stat_after': after,
            'retained_original_lines_sha256': sha(originals / path.name)})
        print(json.dumps({'stage': 'sample', 'source': path.name, 'offset_zero_based': item['offset_zero_based'], 'sampled': selected_count}), flush=True)
    write_json('SOURCE-RECEIPTS.json', receipts)
    with (OUT / 'sampled-rows.jsonl').open('x') as stream:
        for row in sampled:
            stream.write(json.dumps(row, separators=(',', ':')) + '\n')
    scored = [row for row in sampled if row['score_capped']]
    assert len(sampled) == 9000 and 0 < len(scored) <= 9000
    payload = ('\n'.join(row['fen'] for row in scored) + '\n').encode('ascii')
    (OUT / 'actual-probe.stdin').write_bytes(payload)
    command = [str(PROBE)]
    write_json('actual-probe.command.json', {'command': command, 'single_thread': True,
        'environment': {key: os.environ.get(key) for key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS')},
        'stdin_rows': len(scored), 'stdin_sha256': hashlib.sha256(payload).hexdigest()})
    try:
        completed = subprocess.run(command, input=payload, capture_output=True, timeout=180, check=False)
    except subprocess.TimeoutExpired as error:
        (OUT / 'actual-probe.stdout').write_bytes(error.stdout or b'')
        (OUT / 'actual-probe.stderr').write_bytes(error.stderr or b'')
        write_json('actual-probe.receipt.json', {'returncode': None, 'timed_out': True})
        raise
    (OUT / 'actual-probe.stdout').write_bytes(completed.stdout)
    (OUT / 'actual-probe.stderr').write_bytes(completed.stderr)
    write_json('actual-probe.receipt.json', {'command': command, 'returncode': completed.returncode,
        'timed_out': False, 'stdin_sha256': hashlib.sha256(payload).hexdigest(),
        'stdout_sha256': hashlib.sha256(completed.stdout).hexdigest(),
        'stderr_sha256': hashlib.sha256(completed.stderr).hexdigest()})
    if completed.returncode or completed.stderr:
        raise ValueError('Actual shipped engine probe failed; original streams retained')
    facts = [json.loads(line) for line in completed.stdout.splitlines()]
    if len(facts) != len(scored):
        raise ValueError('Actual probe result count mismatch; original streams retained')
    for index, (row, fact) in enumerate(zip(scored, facts)):
        if (fact['index'] != index or fact['hidden_size'] != 128 or fact['residual_mode'] is not True
                or fact['nnue_available'] is not True or fact['hce_only'] is not False
                or type(fact['hce_cp_stm']) is not int or type(fact['nnue_cp_stm']) is not int
                or not -30000 <= fact['nnue_cp_stm'] <= 30000
                or any(type(fact[key]) is not bool for key in ('in_check', 'terminal', 'has_tactical_legal_move'))):
            raise ValueError('Unexpected immutable shipped probe schema/architecture')
        row.update({key: fact[key] for key in ('hce_cp_stm', 'nnue_cp_stm', 'in_check', 'terminal', 'has_tactical_legal_move')})
        row['probe_index'] = index
        row['hybrid_cp_stm'] = max(-31871, min(31871, row['hce_cp_stm'] + row['nnue_cp_stm']))
        row['residual_target_cp'] = row['score_cp_stm'] - row['hce_cp_stm']
        row['conservative_eligible'] = not (row['in_check'] or row['terminal'] or row['has_tactical_legal_move'])
        row['teacher_probability'] = probability(row['score_cp_stm'])
        row['hce_probability'] = probability(row['hce_cp_stm'])
        row['hybrid_probability'] = probability(row['hybrid_cp_stm'])
        row['hce_probability_squared_error'] = (row['hce_probability'] - row['teacher_probability']) ** 2
        row['hybrid_probability_squared_error'] = (row['hybrid_probability'] - row['teacher_probability']) ** 2
    with (OUT / 'scored-rows.jsonl').open('x') as stream:
        for row in scored:
            stream.write(json.dumps(row, separators=(',', ':'), allow_nan=False) + '\n')
    per_source = []
    for item in plan:
        own = [row for row in scored if row['source_path'] == item['path']]
        per_source.append({'source_path': item['path'], 'source_sha256': item['expected_sha256'],
            'offset_zero_based': item['offset_zero_based'], 'sampled': PER_FILE,
            'score_cap_excluded': PER_FILE - len(own),
            'native_filter_counts_overlap': {key: sum(row[key] for row in own) for key in ('in_check', 'terminal', 'has_tactical_legal_move')},
            'score_capped': summarize(own),
            'conservative_eligible': summarize([row for row in own if row['conservative_eligible']])})
    if any(sha(path) != digest for path, digest in identities.items()):
        raise ValueError('Diagnostic script/probe/network/source identity changed during execution')
    report = {'status': 'PASS_TRAINING_ONLY_DIAGNOSTIC_EXECUTED',
        'utc': datetime.now(timezone.utc).isoformat(),
        'sampled': len(sampled), 'files': len(plan), 'sample_per_file': PER_FILE,
        'stride': STRIDE, 'seed': SEED, 'maximum_absolute_teacher_cp': SCORE_CAP,
        'score_cap_excluded': len(sampled) - len(scored), 'probe_positions': len(scored),
        'probability_formula': 'p(cp_stm) = sigmoid(cp_stm * 2.25 / 400); float64 descriptive arithmetic; no WDL/result mixing',
        'hybrid_formula': 'clamp(native_HCE_cp_stm + native_shipped_NNUE_integer_cp_stm, -31871, 31871); native NNUE already truncates and clamps correction to +/-30000',
        'conservative_filter': 'abs(label)<=1000 and not in_check and not terminal and no legal capture/promotion/checking move',
        'filter_exclusions_overlap': {key: sum(row[key] for row in scored) for key in ('in_check', 'terminal', 'has_tactical_legal_move')},
        'score_capped': summarize(scored),
        'conservative_eligible': summarize([row for row in scored if row['conservative_eligible']]),
        'per_source': per_source, 'identities_sha256': identities,
        'source_hashes_match_prior_manifest': True, 'identities_unchanged_after_run': True,
        'scope': 'Unknown-producer legacy TRAINING-ONLY calibration/agreement diagnostic. Original lines/FEN counters preserved. No game IDs invented. No deduplication, new split, validation/holdout/selection, producer authentication, retraining, speed, Elo, uncertainty or strength conclusion. Teacher labels may be search scores rather than static evaluation; agreement does not authenticate calibration.'}
    write_json('RESULT.json', report)
    print(json.dumps({key: report[key] for key in ('status', 'sampled', 'probe_positions', 'score_cap_excluded')}), flush=True)
    print(json.dumps({'score_capped': {k: report['score_capped'][k] for k in ('n','mse_hce','mse_shipped_hybrid','relative_mse_reduction_hybrid_vs_hce')},
        'conservative_eligible': {k: report['conservative_eligible'][k] for k in ('n','mse_hce','mse_shipped_hybrid','relative_mse_reduction_hybrid_vs_hce')}}, indent=2), flush=True)


if __name__ == '__main__':
    main()
