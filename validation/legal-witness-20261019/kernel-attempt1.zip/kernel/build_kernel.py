#!/usr/bin/env python3
"""Explicit later build; preparation does not invoke this script."""
import argparse, hashlib, json, subprocess
from pathlib import Path
p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--repo', type=Path, required=True)
p.add_argument('--core', type=Path, required=True)
p.add_argument('--out', type=Path, required=True)
a = p.parse_args()
a.repo, a.core, a.out = a.repo.resolve(strict=True), a.core.resolve(strict=True), a.out.resolve()
a.out.mkdir(parents=True, exist_ok=False)
source = Path(__file__).resolve().with_name('kernel.cpp')
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
command = ['g++', '-std=c++20', '-O3', '-march=x86-64-v3', '-mtune=znver5',
           '-fno-fast-math', '-ffp-contract=off', '-fno-lto', '-I', str(a.repo / 'include'),
           str(source), str(a.core), '-pthread', '-o', str(a.out / 'kernel')]
inputs = {str(path): sha(path) for path in (source, a.core, a.repo / 'src/board.cpp',
                                         a.repo / 'include/forge/board.hpp', a.repo / 'include/forge/bitboard.hpp')}
record = {'command': command, 'compiler': subprocess.check_output(['g++', '--version'], text=True),
          'inputs_sha256': inputs, 'archive_build_provenance': 'Caller must retain actual forge_core build evidence'}
flags = a.core.parent / 'CMakeFiles/forge_core.dir/flags.make'
if flags.is_file(): record['core_flags_make'] = flags.read_text()
with (a.out / 'build.log').open('w') as log:
    result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
record['exit_code'] = result.returncode
if result.returncode == 0:
    for name, expected in inputs.items():
        if sha(Path(name)) != expected: raise RuntimeError('input changed during build: ' + name)
    record['binary_sha256'] = sha(a.out / 'kernel')
(a.out / 'build.json').write_text(json.dumps(record, indent=2) + '\n')
raise SystemExit(result.returncode)
