#!/usr/bin/env python3
"""Read-only instruction check; kernel must keep indirect workload dispatch."""
import re, subprocess, sys
assembly = subprocess.check_output(['objdump', '-Cd', sys.argv[1]], text=True)
for name in ('actual', 'reference', 'workload'):
    match = re.search(r'^[0-9a-f]+ <' + name + r'\([^\n]*>:\n(.*?)(?=\n[0-9a-f]+ <|\Z)',
                      assembly, re.M | re.S)
    if not match: raise SystemExit('FAIL: missing unstripped wrapper ' + name)
    if name == 'workload' and not re.search(r'\bcall\w*\s+\*', match.group(1)):
        raise SystemExit('FAIL: workload has no indirect call; inspect hoisting/specialization')
print('PASS: separate actual/reference/workload symbols and indirect workload call present')
