// Linux-only, same-process paired Boolean-kernel measurement. No engine search.
#include "forge/board.hpp"
#include <algorithm>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <sched.h>
#include <sstream>
#include <stdexcept>
#include <string>
#include <time.h>
#include <vector>
#include <utility>
#ifndef __linux__
#error This benchmark requires Linux process CPU time and sched_getaffinity.
#endif
#if defined(__GNUC__) && !defined(__clang__)
#define OPAQUE __attribute__((noinline, noipa))
#else
#define OPAQUE __attribute__((noinline))
#endif
using Function = bool (*)(const forge::Board&);
OPAQUE bool actual(const forge::Board& board) { return board.has_legal_move(); }
OPAQUE bool reference(const forge::Board& board) {
    forge::MoveList moves;
    board.generate_pseudo_legal(moves, false);
    for (const auto move : moves) if (board.is_legal(move)) return true;
    return false;
}
std::int64_t wall_ns() {
    return std::chrono::duration_cast<std::chrono::nanoseconds>(
        std::chrono::steady_clock::now().time_since_epoch()).count();
}
std::int64_t cpu_ns() {
    timespec time{};
    if (clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &time) != 0) throw std::runtime_error("process CPU clock failed");
    return static_cast<std::int64_t>(time.tv_sec) * 1000000000LL + time.tv_nsec;
}
OPAQUE std::uint64_t workload(Function function, const std::vector<forge::Board>& boards, unsigned repeats) {
    // Identical volatile indirect dispatch prevents hoisting, specialization and
    // caller-side purity assumptions. Compile without LTO, using actual core.
    Function volatile invoke = function;
    std::uint64_t checksum = 0;
    for (unsigned repetition = 0; repetition < repeats; ++repetition) {
        std::uint64_t weight = 0;
        for (const auto& board : boards) checksum += static_cast<std::uint64_t>(invoke(board)) * ++weight;
    }
    return checksum;
}
struct Sample { std::int64_t wall, cpu; std::uint64_t checksum; };
Sample sample(Function function, const std::vector<forge::Board>& boards, unsigned repeats) {
    const auto wall = wall_ns(), cpu = cpu_ns();
    const auto sum = workload(function, boards, repeats);
    const auto end_cpu = cpu_ns(), end_wall = wall_ns();
    return {end_wall - wall, end_cpu - cpu, sum};
}
void add_fen(std::vector<forge::Board>& boards, const std::string& text) {
    forge::Board board;
    if (!board.set_fen(text)) throw std::runtime_error("invalid workload FEN: " + text);
    boards.push_back(std::move(board));
}
std::vector<forge::Board> load(const char* corpus, const char* fixtures) {
    std::vector<forge::Board> boards;
    boards.reserve(10064);
    std::ifstream cases(fixtures), openings(corpus);
    if (!cases || !openings) throw std::runtime_error("workload file unavailable");
    std::string line;
    unsigned fixture_count = 0, corpus_count = 0;
    while (std::getline(cases, line)) {
        if (line.empty()) continue;
        const auto first = line.find('\t'), second = line.find('\t', first + 1);
        if (first == std::string::npos || second == std::string::npos) throw std::runtime_error("malformed fixture TSV");
        add_fen(boards, line.substr(second + 1));
        if (boards.back().has_legal_move() != (line.substr(first + 1, second - first - 1) == "1"))
            throw std::runtime_error("curated expected result mismatch");
        ++fixture_count;
    }
    while (std::getline(openings, line)) {
        if (line.empty()) continue;
        std::istringstream input(line);
        std::string pieces, side, castle, ep;
        if (!(input >> pieces >> side >> castle >> ep)) throw std::runtime_error("malformed EPD");
        add_fen(boards, pieces + " " + side + " " + castle + " " + ep + " 0 1");
        ++corpus_count;
    }
    if (fixture_count != 23 || corpus_count != 10000) throw std::runtime_error("expected frozen23fixtures+10000EPD");
    return boards;
}
int main(int argc, char** argv) {
    try {
        if (argc != 4) throw std::runtime_error("usage: kernel corpus.epd fixtures.tsv measurement_wall_seconds");
        const double seconds = std::stod(argv[3]);
        if (!(seconds >= 1.0 && seconds <= 10.0)) throw std::runtime_error("measurement budget must be1..10seconds");
        cpu_set_t affinity; CPU_ZERO(&affinity);
        if (sched_getaffinity(0, sizeof(affinity), &affinity) || CPU_COUNT(&affinity) != 1)
            throw std::runtime_error("exactly one pinned CPU required");
        const auto boards = load(argv[1], argv[2]);
        std::uint64_t expected_once = 0;
        for (std::size_t i = 0; i < boards.size(); ++i) {
            const bool candidate = actual(boards[i]), baseline = reference(boards[i]);
            if (candidate != baseline) throw std::runtime_error("differential mismatch at workload index" + std::to_string(i));
            expected_once += static_cast<std::uint64_t>(baseline) * (i + 1);
        }
        // Excluded warmups/calibration precede all AA/AB outcomes. Workload and
        // repeats then stay frozen, including when later measurements are noisy.
        if (workload(actual, boards, 1) != expected_once || workload(reference, boards, 1) != expected_once)
            throw std::runtime_error("warmup checksum mismatch");
        const auto calibration = sample(reference, boards, 1);
        if (calibration.cpu <= 0 || calibration.checksum != expected_once) throw std::runtime_error("invalid calibration");
        const unsigned repeats = static_cast<unsigned>(std::clamp<std::int64_t>(
            (20000000LL + calibration.cpu - 1) / calibration.cpu, 1, 1024));
        std::cout << "{\"kind\":\"configuration\",\"positions\":" << boards.size()
                  << ",\"repeats\":" << repeats << ",\"calls_per_block\":" << boards.size() * repeats
                  << ",\"expected_checksum\":" << expected_once * repeats
                  << ",\"calibration_reference_cpu_ns\":" << calibration.cpu
                  << ",\"aa_pairs\":6,\"ab_pairs\":24,\"measurement_wall_seconds\":" << seconds << "}\n" << std::flush;
        const auto started = wall_ns();
        unsigned blocks = 0;
        bool exceeded = false;
        for (const std::string phase : {"aa", "ab"}) {
            const unsigned pairs = phase == "aa" ? 6 : 24;
            for (unsigned pair = 0; pair < pairs; ++pair) {
                if (wall_ns() - started >= static_cast<std::int64_t>(seconds * 1e9)) { exceeded = true; break; }
                for (unsigned order = 0; order < 2; ++order) {
                    const bool first_variant = ((pair + order) % 2) == 0;
                    Function function = phase == "aa" || !first_variant ? reference : actual;
                    const char* label = phase == "aa" ? (first_variant ? "reference_a" : "reference_b")
                                                           : (first_variant ? "actual" : "reference");
                    const auto result = sample(function, boards, repeats);
                    if (result.checksum != expected_once * repeats) throw std::runtime_error("measured checksum mismatch");
                    std::cout << "{\"kind\":\"block\",\"phase\":\"" << phase << "\",\"pair\":" << pair
                              << ",\"order\":" << order << ",\"label\":\"" << label << "\",\"wall_ns\":" << result.wall
                              << ",\"process_cpu_ns\":" << result.cpu << ",\"checksum\":" << result.checksum << "}\n" << std::flush;
                    ++blocks;
                }
                if (wall_ns() - started >= static_cast<std::int64_t>(seconds * 1e9)) { exceeded = true; break; }
            }
            if (exceeded) break;
        }
        const auto elapsed = wall_ns() - started;
        const bool complete = blocks == 60 && !exceeded;
        std::cout << "{\"kind\":\"completion\",\"complete\":" << (complete ? "true" : "false")
                  << ",\"blocks\":" << blocks << ",\"measurement_wall_ns\":" << elapsed
                  << ",\"budget_exceeded\":" << (exceeded ? "true" : "false") << "}\n";
        return complete ? 0 : 2;
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n'; return 1;
    }
}
