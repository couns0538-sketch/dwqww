#!/usr/bin/env python3
"""One fresh attempt, fixed AA/AB schedule, no retries/trimming or engine claims."""
import argparse, datetime, hashlib, json, os, platform, statistics, subprocess, sys, time
from pathlib import Path
sys.dont_write_bytecode = True
p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--build', type=Path, required=True)
p.add_argument('--core', type=Path, required=True)
p.add_argument('--corpus', type=Path, required=True)
p.add_argument('--fixtures', type=Path, required=True)
p.add_argument('--out', type=Path, required=True)
p.add_argument('--cpu', type=int)
a = p.parse_args()
if not sys.platform.startswith('linux'): p.error('Linux native process-CPU clock required')
allowed = sorted(os.sched_getaffinity(0))
cpu = allowed[0] if a.cpu is None else a.cpu
if cpu not in allowed: p.error('requested CPU is not in inherited affinity')
a.build, a.core = a.build.resolve(strict=True), a.core.resolve(strict=True)
a.corpus, a.fixtures = a.corpus.resolve(strict=True), a.fixtures.resolve(strict=True)
a.out = a.out.resolve(); a.out.mkdir(parents=True, exist_ok=False)
here = Path(__file__).resolve().parent
binary = a.build / 'kernel'
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def save(name, obj): (a.out / name).write_text(json.dumps(obj, indent=2) + '\n')
inputs = {'binary': binary, 'build_record': a.build / 'build.json', 'core_archive': a.core,
          'corpus': a.corpus, 'fixtures': a.fixtures, 'driver_source': here / 'kernel.cpp',
          'runner_source': Path(__file__).resolve(), 'dispatch_checker': here / 'check_dispatch.py'}
frozen = {name: {'path': str(path), 'sha256': sha(path)} for name, path in inputs.items()}
build = json.loads(inputs['build_record'].read_text())
if build.get('exit_code') != 0 or build.get('binary_sha256') != frozen['binary']['sha256']:
    raise RuntimeError('binary does not match a successful recorded build')
for path in (here / 'kernel.cpp', a.core):
    if build['inputs_sha256'].get(str(path)) != sha(path):
        raise RuntimeError('source/archive differs from recorded build: ' + str(path))
command = [str(binary), str(a.corpus), str(a.fixtures), '8']
def host_context():
    fields = {}
    for line in Path('/proc/cpuinfo').read_text().splitlines():
        if ':' in line:
            name, value = (part.strip() for part in line.split(':', 1))
            if name in ('model name', 'flags') and name not in fields: fields[name] = value
    cgroup = {name: (Path('/sys/fs/cgroup') / name).read_text()
              for name in ('cpu.max', 'cpu.stat', 'cpu.pressure', 'cpuset.cpus.effective')
              if (Path('/sys/fs/cgroup') / name).is_file()}
    return {'platform': platform.platform(), 'cpu_fields': fields, 'cgroup': cgroup}
protocol = {'host_before': host_context(), 'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'scope': 'has_legal_move Boolean kernel on this frozen corpus/host only; no full-search/Ryzen/Elo claim',
            'inputs': frozen, 'command': command, 'build': build, 'inherited_affinity': allowed, 'pinned_cpu': cpu,
            'schedule': {'aa_pairs': 6, 'ab_pairs': 24, 'alternating_order': True, 'measurement_wall_cap_seconds': 8,
                         'entire_child_timeout_seconds': 12, 'target_reference_block_cpu_ns': 20000000,
                         'iteration_calibration': 'one reference pass before AA/AB; then freeze repeat count1..1024'},
            'aa_operational_noise_gate': {'median_process_cpu_A_over_B': [0.95, 1.05],
                                        'every_pair_process_cpu_A_over_B': [0.8, 1.25],
                                        'interpretation': 'Preregistered practical noise screen, not a significance test'},
            'policy': 'All60blocks required within cap; preserve incomplete attempts as inconclusive; no retry/trim/pooling/CI/speed claim'}
save('protocol.json', protocol)
result = {'status': 'running', 'scope': protocol['scope'], 'speed_claim_established': False}
save('result.json', result)
try:
    with (a.out / 'dispatch-check.log').open('w') as log:
        subprocess.run([sys.executable, '-B', str(here / 'check_dispatch.py'), str(binary)], stdout=log,
                       stderr=subprocess.STDOUT, check=True, timeout=10)
    os.sched_setaffinity(0, {cpu})
    started = time.monotonic()
    with (a.out / 'raw.jsonl').open('x') as stdout, (a.out / 'stderr.log').open('x') as stderr:
        completed = subprocess.run(command, stdout=stdout, stderr=stderr, timeout=12)
    result['exit_code'] = completed.returncode; result['entire_child_wall_seconds'] = time.monotonic() - started
    records = [json.loads(line) for line in (a.out / 'raw.jsonl').read_text().splitlines() if line.strip()]
    configs = [r for r in records if r.get('kind') == 'configuration']
    endings = [r for r in records if r.get('kind') == 'completion']
    if len(configs) != 1 or len(endings) != 1: raise RuntimeError('missing unique configuration/completion')
    config, ending = configs[0], endings[0]
    blocks = [r for r in records if r.get('kind') == 'block']
    result['configuration'] = config; result['completion'] = ending
    summary = {}
    full_schedule = True
    for phase, expected_pairs, labels in [('aa', 6, ('reference_a', 'reference_b')),
                                         ('ab', 24, ('actual', 'reference'))]:
        phase_records = [r for r in blocks if r['phase'] == phase]
        ratios = {'wall': [], 'process_cpu': []}
        for pair in range(expected_pairs):
            rows = [r for r in phase_records if r['pair'] == pair]
            if len(rows) != 2:
                full_schedule = False; continue
            by_label = {r['label']: r for r in rows}
            if set(by_label) != set(labels) or [r['order'] for r in rows] != [0, 1]:
                raise RuntimeError('invalid block labels/order')
            if rows[0]['label'] != labels[pair % 2]: raise RuntimeError('counterbalance order changed')
            for row in rows:
                if row['checksum'] != config['expected_checksum'] or row['wall_ns'] <= 0 or row['process_cpu_ns'] <= 0:
                    raise RuntimeError('bad checksum or timing sample')
            for timer in ratios:
                field = 'wall_ns' if timer == 'wall' else 'process_cpu_ns'
                ratios[timer].append(by_label[labels[0]][field] / by_label[labels[1]][field])
        summary[phase] = {'ratio_direction': labels[0] + '_time_over_' + labels[1] + '_time',
                          'raw_paired_ratios': ratios,
                          'descriptive': {timer: {'median': statistics.median(values), 'min': min(values), 'max': max(values)}
                                          for timer, values in ratios.items() if values}}
    save('paired-summary.json', summary)
    aa = summary['aa']['raw_paired_ratios']['process_cpu']
    aa_ok = len(aa) == 6 and .95 <= statistics.median(aa) <= 1.05 and all(.8 <= ratio <= 1.25 for ratio in aa)
    result['aa_operational_noise_gate_passed'] = aa_ok
    if completed.returncode == 2 or not ending['complete'] or not full_schedule or len(blocks) != 60:
        result.update(status='inconclusive_incomplete_protocol', error='full preregistered schedule/cap not satisfied')
    elif completed.returncode != 0: raise RuntimeError('kernel execution failed')
    else: result['status'] = 'completed_descriptive_only' if aa_ok else 'inconclusive_aa_noise_gate'
except (Exception, KeyboardInterrupt) as error:
    result.update(status='failed_or_interrupted', error=str(error) or type(error).__name__)
finally:
    result['host_after'] = host_context()
    changes = [name for name, path in inputs.items() if not path.is_file() or sha(path) != frozen[name]['sha256']]
    if changes: result.update(status='failed_or_interrupted', error='frozen inputs changed: ' + ','.join(changes))
    result['outputs_sha256'] = {path.name: sha(path) for path in a.out.iterdir() if path.is_file() and path.name != 'result.json'}
    save('result.json', result)
print(json.dumps(result, indent=2))
raise SystemExit(0 if result['status'] == 'completed_descriptive_only' else 1)
