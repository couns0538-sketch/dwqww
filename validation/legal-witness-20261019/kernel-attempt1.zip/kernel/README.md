# Prepared paired legal-move API kernel

Not compiled or run. Original legal-witness proposal/tests remain unchanged in the separate investigation directory. Linux only; no engine search, games, Wine, Elo or whole-engine speed claim.

After the differential and exact fixed-work1T gates pass, build once against the actual new tested forge_core archive (replace BUILD with that archive's directory):

```sh
python3 -B /workspace/.cloud-setup/legal-witness-kernel/build_kernel.py \
  --repo /workspace/dwqww --core BUILD/libforge_core.a \
  --out /workspace/.cloud-setup/legal-witness-kernel/build
python3 -B /workspace/.cloud-setup/legal-witness-kernel/run_kernel.py \
  --build /workspace/.cloud-setup/legal-witness-kernel/build \
  --core BUILD/libforge_core.a \
  --corpus /workspace/dwqww/tools/openings/forge-10000.epd \
  --fixtures /workspace/.cloud-setup/legal-witness-investigation/fixtures.tsv \
  --out /workspace/.cloud-setup/legal-witness-kernel/results
```

Optional --cpu selects one CPU from inherited affinity; default is its lowest available CPU. The runner pins itself before launching the measured child. No retry or resume; existing build/results directories are never overwritten. Build command/version/flags/source/archive/binary hashes are retained. Preserve the actual forge_core build provenance too; linking its hash does not independently prove how it was compiled.

## Workload and measurement

One executable links the actual new forge_core. `actual` calls Board::has_legal_move; `reference` is the exact old public full-pseudogeneration/is_legal loop. Both pass through noinline/noipa wrappers and the SAME volatile indirect dispatch workload; build uses -fno-lto. `check_dispatch.py` rejects missing wrapper symbols or an absent indirect workload call. This prevents dead-code elimination/loop hoisting; it does not assert cycle equivalence between wrapper implementations.

The workload contains all23 curated fixtures followed by frozen10000 original corpus positions. Expected fixture values and actual-versus-reference Boolean equality are checked before timing. Each block computes a weighted per-position checksum, verified against the initial complete differential result. Inputs/order never change.

Warm one pass per function, then measure ONE reference calibration pass before any AA/AB outcomes. Choose repeats=ceil(20ms/reference-processCPU-pass), clamped1..1024; then freeze repeats and position count. Calibration/configuration is retained. No adaptive sample count after seeing outcomes.

AA:6 pairs of exactly the same reference function, alternating A/B label order. AB:24 pairs actual/reference, alternating order (12 each way).60 blocks total, all required. Linux CLOCK_PROCESS_CPUTIME_ID records process CPU nanoseconds; steady_clock records wall nanoseconds. They are both retained, not substituted based on which favors a result. Weighted checksum work/volatile dispatch is identical on both paths and is part of this measured API workload.

All scheduled blocks must finish within the8s measurement wall cap. The cap is checked between indivisible paired blocks; an overrun or incomplete schedule is inconclusive, including a last-pair overrun. No quiet trimming/retry/pooling. The entire child, including corpus preparation, has a12s external timeout; it may therefore exceed the roughly10s normal total budget under severe VM starvation, but will retain the failed attempt rather than grow automatically. Raw JSONL and stderr survive failures.

## Interpretation

`paired-summary.json` reports all complete raw paired wall/CPU ratios and descriptive median/min/max. Direction is explicitly named: actual_time/reference_time for AB. AA's preregistered operational noise screen requires median CPU A/B within0.95..1.05 and every AA pair within0.8..1.25. This is a practical screen, not a significance test. A failed screen or incomplete protocol produces an inconclusive result. No bootstrap, confidence interval or automatic speed assertion is emitted. `speed_claim_established` stays false; the reviewer assesses the raw evidence. Process CPU reduces descheduling noise but retains frequency/cache/contention effects; host/cgroup context is recorded before/after.

A limitation: the public-helper reference lives in the benchmark translation unit, whereas actual has_legal_move lives in board.cpp. Helper implementations come from the same archive, but compiler inlining opportunities may differ across translation units. Thus this measures these two API kernels on this workload; it does not isolate only the new source fast path or establish full-search speed. A strictly same-translation-unit source-cost experiment would require another instrumented core build and is outside this artifact.
