#!/usr/bin/env python3
"""Prepared only: one fresh pinned-process AA screen, conditional descriptive AB.

No retries, trimming, pooling, confidence intervals, Elo or gain acceptance.
Every child receives exactly 'bench 11\nquit\n' and then exits. The local bench
uses Threads=1/Hash=16 regardless of outer UCI settings. End-to-end CPU/wall
include startup, Hash allocation/clears and lazy NNUE initialization.
"""
from __future__ import annotations
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import resource
import signal
import statistics
import subprocess
import sys
import time

sys.dont_write_bytecode = True
CAP_SECONDS = 30.0
EXPECTED_NODES = 419798
PAYLOAD = b'bench 11\nquit\n'
BENCH = re.compile(r'info string bench depth 11 nodes (\d+) time (\d+) nps (\d+)')


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def write(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')
    temporary.replace(path)


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def host():
    cpu = {}
    info = Path('/proc/cpuinfo')
    if info.is_file():
        for line in info.read_text().splitlines():
            if ':' in line:
                name, value = (part.strip() for part in line.split(':', 1))
                if name in ('model name', 'flags') and name not in cpu:
                    cpu[name] = value
    cgroup = {name: (Path('/sys/fs/cgroup') / name).read_text()
              for name in ('cpu.max', 'cpu.stat', 'cpu.pressure', 'cpuset.cpus.effective')
              if (Path('/sys/fs/cgroup') / name).is_file()}
    return {'platform': platform.platform(), 'python': sys.version, 'cpu': cpu,
            'affinity': sorted(os.sched_getaffinity(0)), 'cgroup': cgroup}


def children_cpu():
    usage = resource.getrusage(resource.RUSAGE_CHILDREN)
    return usage.ru_utime, usage.ru_stime


class AttemptStop(RuntimeError):
    pass


def paired(records, phase, pairs, labels):
    selected = [r for r in records if r['phase'] == phase]
    raw = {'process_cpu_seconds': [], 'external_wall_seconds': []}
    for pair in range(pairs):
        rows = [r for r in selected if r['pair'] == pair]
        if len(rows) != 2 or any(not row['valid'] for row in rows):
            raise AttemptStop(f'{phase}: incomplete/invalid pair {pair}')
        if [r['order'] for r in rows] != [0, 1] or rows[0]['label'] != labels[pair % 2]:
            raise AttemptStop(f'{phase}: changed counterbalance schedule')
        mapping = {r['label']: r for r in rows}
        if set(mapping) != set(labels):
            raise AttemptStop(f'{phase}: duplicate/unexpected label')
        for timer in raw:
            denominator = mapping[labels[1]][timer]
            if denominator <= 0:
                raise AttemptStop(f'{phase}: zero timing denominator')
            raw[timer].append(mapping[labels[0]][timer] / denominator)
    return {'ratio_direction': f'{labels[0]}_time_over_{labels[1]}_time', 'raw_paired_ratios': raw,
            'descriptive': {timer: {'median': statistics.median(values), 'min': min(values), 'max': max(values)}
                            for timer, values in raw.items()}}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline', type=Path,
                        default='/workspace/.cloud-setup/forge-rule50-context-release/forge')
    parser.add_argument('--candidate', type=Path,
                        default='/workspace/.cloud-setup/forge-legal-witness-release/forge')
    parser.add_argument('--cpu', type=int)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    if not sys.platform.startswith('linux'):
        parser.error('Linux sched affinity and RUSAGE_CHILDREN required')
    baseline, candidate = args.baseline.resolve(strict=True), args.candidate.resolve(strict=True)
    allowed = sorted(os.sched_getaffinity(0))
    cpu = allowed[0] if args.cpu is None else args.cpu
    if cpu not in allowed:
        parser.error('requested CPU not in inherited allowed affinity')
    before = host()
    os.sched_setaffinity(0, {cpu})  # Every later child inherits exactly this CPU.
    root = args.out.resolve()
    root.mkdir(parents=True, exist_ok=False)
    inputs = {'baseline': baseline, 'candidate': candidate, 'runner': Path(__file__).resolve()}
    frozen = {name: {'path': str(path), 'sha256': sha(path)} for name, path in inputs.items()}
    schedule = []
    for i, engine in enumerate(('baseline', 'candidate')):
        schedule.append({'id': f'warmup-{i:02}-{engine}', 'phase': 'warmup', 'pair': i,
                         'order': 0, 'label': engine, 'engine': engine,
                         'argv': [str(inputs[engine])], 'excluded_from_ratios': True})
    for phase, count, labels in [('aa', 3, ('baseline_a', 'baseline_b')),
                                 ('ab', 6, ('baseline', 'candidate'))]:
        for pair in range(count):
            for order in range(2):
                label = labels[(pair + order) % 2]
                engine = 'baseline' if phase == 'aa' else label
                schedule.append({'id': f'{phase}-p{pair:02}-o{order}-{label}', 'phase': phase,
                                 'pair': pair, 'order': order, 'label': label, 'engine': engine,
                                 'argv': [str(inputs[engine])], 'excluded_from_ratios': False})
    protocol = {'created_utc': utc(), 'inputs': frozen, 'host_before_pin': before,
                'host_after_pin': host(), 'pinned_cpu': cpu, 'schedule': schedule,
                'stdin_utf8': PAYLOAD.decode(), 'stdin_sha256': hashlib.sha256(PAYLOAD).hexdigest(),
                'expected_unique_signature': {'depth': 11, 'nodes': EXPECTED_NODES},
                'wall_cap_seconds_including_warmups': CAP_SECONDS,
                'timers': {'external_wall': 'perf_counter_ns before Popen through child reaped',
                           'process_cpu': 'RUSAGE_CHILDREN ru_utime+ru_stime delta per serial child; seconds'},
                'bench_settings': {'threads': 1, 'hash_mib': 16, 'clears': 8,
                                   'source': 'Forge local bench handler; no outer UCI setting commands'},
                'aa_gate': {'both_timers': True, 'median_ratio_inclusive': [.95, 1.05],
                            'every_ratio_inclusive': [.85, 1.15],
                            'meaning': 'Gross-instability screen only; passing does not prove noise <=5%'},
                'policy': 'One attempt; all planned blocks required unless AA rejects. AA failure means no AB. '
                          'Any incomplete/faulty block or cap overrun is inconclusive. No retries, trimming, pooling or CI.',
                'scope': 'Fresh-process end-to-end CPU and wall for bench11 only, including Hash16 allocation, '
                         'eight clears and lazy NNUE; AB descriptive only, no performance acceptance/Elo/hardware claim'}
    write(root / 'protocol.json', protocol)  # Must precede the very first warmup.
    frozen_protocol = sha(root / 'protocol.json')
    result = {'status': 'running', 'performance_gain_accepted': False, 'elo_gain_established': False,
              'protocol_sha256': frozen_protocol, 'records': [], 'scope': protocol['scope'],
              'ab_interpretation': 'DESCRIPTIVE ONLY: no performance acceptance or confidence interval'}
    write(root / 'result.json', result)
    started = time.monotonic()

    def verify_inputs():
        for name, path in inputs.items():
            if not path.is_file() or sha(path) != frozen[name]['sha256']:
                raise AttemptStop('input checksum changed: ' + name)
        if sha(root / 'protocol.json') != frozen_protocol:
            raise AttemptStop('frozen protocol changed')

    def block(item):
        verify_inputs()
        remaining = CAP_SECONDS - (time.monotonic() - started)
        if remaining <= 0:
            raise AttemptStop('global30s cap reached before ' + item['id'])
        directory = root / item['id']
        directory.mkdir()
        record = dict(item, started_utc=utc(), valid=False)
        child = None
        interrupted = False
        cpu_before = children_cpu()
        wall_before = time.perf_counter_ns()
        try:
            with (directory / 'stdout.bin').open('xb') as stdout, (directory / 'stderr.bin').open('xb') as stderr:
                child = subprocess.Popen(item['argv'], stdin=subprocess.PIPE, stdout=stdout, stderr=stderr)
                record['pid'] = child.pid
                try:
                    child.communicate(input=PAYLOAD, timeout=remaining)
                except subprocess.TimeoutExpired:
                    record['fault'] = 'remaining global-cap child timeout'
                    child.kill(); child.communicate()
                except KeyboardInterrupt:
                    interrupted = True
                    record['fault'] = 'interrupted'
                    if child.poll() is None: child.kill()
                    child.communicate()
                record['exit_code'] = child.returncode
        except Exception as error:
            record['fault'] = str(error)
            if child is not None and child.poll() is None:
                child.kill(); child.wait()
        finally:
            wall_after = time.perf_counter_ns()
            cpu_after = children_cpu()
            record['external_wall_ns'] = wall_after - wall_before
            record['external_wall_seconds'] = record['external_wall_ns'] / 1e9
            record['process_user_seconds'] = cpu_after[0] - cpu_before[0]
            record['process_system_seconds'] = cpu_after[1] - cpu_before[1]
            record['process_cpu_seconds'] = record['process_user_seconds'] + record['process_system_seconds']
            record['outputs_sha256'] = {path.name: sha(path) for path in directory.iterdir() if path.is_file()}
        try:
            verify_inputs()
            if interrupted or record.get('fault'):
                raise AttemptStop(record.get('fault', 'interrupted'))
            if record.get('exit_code') != 0:
                raise AttemptStop('child did not exit zero')
            if any(record[name] < 0 for name in ('external_wall_ns', 'process_user_seconds',
                                                'process_system_seconds', 'process_cpu_seconds')):
                raise AttemptStop('negative timer delta')
            lines = [line.strip() for line in (directory / 'stdout.bin').read_text(errors='replace').splitlines()
                     if line.strip().startswith('info string bench ')]
            match = BENCH.fullmatch(lines[0]) if len(lines) == 1 else None
            if not match or int(match.group(1)) != EXPECTED_NODES:
                raise AttemptStop('missing/duplicate/malformed/wrong bench11 signature')
            record['bench_signature'] = {'depth': 11, 'nodes': int(match.group(1)),
                                         'engine_time_ms': int(match.group(2)), 'engine_nps': int(match.group(3))}
            if time.monotonic() - started > CAP_SECONDS:
                raise AttemptStop('global30s cap exceeded after child')
            record['valid'] = True
        except AttemptStop as error:
            record['fault'] = str(error)
        write(directory / 'record.json', record)
        result['records'].append(record)
        write(root / 'result.json', result)
        if not record['valid']:
            raise AttemptStop(item['id'] + ': ' + record.get('fault', 'invalid'))

    def interrupted(signum, frame):
        raise KeyboardInterrupt('received signal ' + str(signum))
    signal.signal(signal.SIGTERM, interrupted)
    try:
        for item in schedule[:8]:  #2 warmups+6 AA blocks, all fresh child processes.
            block(item)
        aa = paired(result['records'], 'aa', 3, ('baseline_a', 'baseline_b'))
        result['aa'] = aa
        aa_ok = all(.95 <= statistics.median(ratios) <= 1.05 and
                    all(.85 <= ratio <= 1.15 for ratio in ratios)
                    for ratios in aa['raw_paired_ratios'].values())
        result['aa_gross_instability_screen_passed'] = aa_ok
        write(root / 'aa-summary.json', aa)
        if not aa_ok:
            result.update(status='inconclusive_aa_gate_failed',
                          reason='No AB executed; AA is a gross-instability screen, not a noise-bound proof')
        else:
            for item in schedule[8:]: block(item)
            ab = paired(result['records'], 'ab', 6, ('baseline', 'candidate'))
            result['ab_descriptive_only'] = ab
            write(root / 'ab-summary.json', ab)
            result['status'] = 'completed_descriptive_only'
    except (Exception, KeyboardInterrupt) as error:
        result.update(status='inconclusive_incomplete_or_fault', reason=str(error) or type(error).__name__)
    finally:
        result['host_after'] = host()
        result['total_wall_seconds_including_warmups'] = time.monotonic() - started
        try: verify_inputs()
        except AttemptStop as error:
            result.update(status='inconclusive_input_changed', reason=str(error))
        if result['total_wall_seconds_including_warmups'] > CAP_SECONDS:
            result.update(status='inconclusive_global_cap', reason='entire attempt exceeded30s wall cap')
        result['final_input_sha256'] = {name: sha(path) if path.is_file() else None for name, path in inputs.items()}
        result['outputs_sha256'] = {path.relative_to(root).as_posix(): sha(path) for path in root.rglob('*')
                                    if path.is_file() and path != root / 'result.json'}
        write(root / 'result.json', result)
    print(json.dumps(result, indent=2))
    return 0 if result['status'] == 'completed_descriptive_only' else 1


if __name__ == '__main__':
    raise SystemExit(main())
