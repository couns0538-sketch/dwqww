# Prospective pinned bench screen: method review

Review date: 2026-10-19 UTC. This report records a source-only method review. No engines, builds, games, benchmark scripts, or measurements were run for this review; repository and Git state were not changed.

## Decision and strict prior condition

**Prospective GO only if the separately frozen pinned-kernel A/A calibration passes its original noise gate.** That condition must be satisfied before executing any whole-engine bench screen. This was a conditional approval for a new bounded pilot, not approval to rescue or reinterpret the earlier noisy whole-engine A/A experiment.

**The condition was not met.** The root agent reports that the completed 60-block kernel calibration took approximately 0.98 seconds and produced A/A CPU ratios spanning 0.736 to 1.444, failing its noise gate. These kernel results are supplied by the root agent and were not independently recomputed in this report. The root agent will not execute the whole-engine screen. The prospective method below remains useful only for a future stable host after its prerequisites pass. There is no post-outcome change to the gate, reinterpretation of the failure, or whole-engine speed conclusion.

## Frozen prospective design

- Pin every engine process to the same selected CPU before execution. Use a fresh process for every command, with stdin `bench 11` followed by `quit`. Do not claim that outer UCI Threads or Hash options configure this built-in benchmark.
- Perform one symmetric excluded warmup for the frozen parent and one for the candidate, followed by three parent/parent A/A pairs. Only after the whole-engine A/A gate passes, perform six parent/candidate A/B pairs with three AB and three BA orders fixed before outcomes. This is 20 fresh process executions: two warmups and 18 measured benchmark commands.
- Require the expected 419798-node signature from every completed benchmark, including warmups. Retain exact commands, frozen executable/input hashes, raw stdout, process exit status, and every timing result. No retries, outlier removal, replacements, or outcome-dependent count changes.
- Record high-resolution external `perf_counter` wall time and sequential child-process user/system CPU deltas separately. Preserve the engine's own benchmark milliseconds and NPS as additional observations; do not substitute them for the external metrics.
- The whole-engine A/A gate applies to **both** process CPU and external wall time: median pair ratio in [0.95, 1.05], with every pair ratio in [0.85, 1.15]. Engine milliseconds are reported without becoming a convenient alternative gate.
- Enforce a fixed 30-second wall cap for the complete experiment, including warmups, child startup and shutdown. Any timeout, incomplete pair, missing required result, or signature mismatch makes the screen inconclusive; do not extend the cap or complete a partial schedule later.
- Freeze the A/B primary metric, minimum meaningful effect and decision rule before launch. If no performance acceptance rule is frozen, report the six A/B pairs descriptively and make no performance acceptance claim.

## Validity and limits

Source inspection found that `src/uci.cpp` starts the built-in bench timer before constructing its local `Searcher(16)`, then clears that searcher before each of eight fixed positions. The local searcher uses one thread and Hash16. NNUE weights initialize lazily on the first evaluation. Whole-process CPU and wall time additionally include the outer default Searcher, book startup and shutdown. Therefore engine benchmark time and whole-process time have different scopes and must remain separately labelled.

Fresh processes and symmetric excluded warmups address first-run asymmetry without silently adding warmups after outcomes. Each measured fresh process still pays its own lazy initialization and allocation costs. Those costs can dilute the legal-witness search effect, so a null whole-bench result cannot refute a kernel gain.

Three A/A pairs screen gross instability; a pass does not establish a precise noise bound or prove noise is at most five percent. Single-CPU pinning changes the earlier five-CPU protocol but cannot eliminate shared-host interference. Balanced A/B order helps with approximately linear drift and does not establish immunity to arbitrary host variation. Passing a kernel A/A gate would not replace the separate whole-engine A/A gate.

Any eventual result would concern this host, one pinned CPU, these eight positions and the stated timing scopes. It would not establish Elo, equal-clock playing strength, native Windows performance, or Ryzen performance. No implementation or review of the proposed `run_screen.py` script is included here.
