# Prepared legal-move witness (unbuilt/unrun)

`legal-witness.patch` changes only Board::has_legal_move; full proposed board.cpp and standalone differential test are under proposed/. Base commit/source/corpus hashes are in provenance.json. No repository edits, engine execution, builds or performance claims.

## Soundness

Generate a bitboard of single pawn-push destinations using existing pawn_push(side, own_pawns), intersect empty squares and exclude both promotion ranks. Select exactly one destination, construct Quiet/nonpromotion/from=to-push_delta, and ask existing exact Board::is_legal. Return true only for this proven legal witness. Otherwise execute the old full generator/is_legal loop unchanged. The witness is necessarily pseudo-legal on a valid Board: own pawn exists at from, one-step direction matches side, target is empty and nonpromoting. is_legal constructs resulting occupancy and tests own-king attacks, so file pins, diagonal pins, checks and double checks need no approximations. No separate check-mask cache or in_check branch is needed. EP rights cannot invalidate a legal quiet single push; EP-only, captures, promotions, castling and king moves are handled by the complete fallback. It never returns false based only on a failed witness.

One candidate instead of scanning every pawn keeps the hot path bounded. Failed/absent candidates fall back, accepting redundant work to minimize risk. No pawn move changes, move ordering, accumulator, evaluation or search-policy changes.

## Prepared verification

`fixtures.tsv`:23 explicit cases, both colors, terminal mate/stalemate, pinned-pawn stalemate with a pseudo-legal but illegal push, file pins permitting legal pushes, pawn check-block, double check, promotion/underpromotion fallback, forward-blocked EP, illegal EP rank discovery and castles.

`proposed/tests/legal_witness_tests.cpp`: compare has_legal_move with (1) exact old full-generator/is_legal implementation and (2) independently make each generated move on a board copy, check own king after make, unmake and verify FEN/Zobrist/pawn-key restoration. Run all23 fixtures, every frozen10000EPD opening (parse first4fields, append counters0/1), then72 deterministic seeded legal walks up to128plies. No engine search or games. Explicit pinned terminal witness assertions protect against accidentally skipping the intended branch. Every comparison also checks query state immutability.

Future command after root permits builds: link this test against candidate forge_core and run with `fixtures.tsv` and frozen `tools/openings/forge-10000.epd`; preserve actual comparison count and source/binary hashes. Baseline full-generator implementation should pass the same differential assertions; optimization is intended to alter cost only, so RED is a behavior-equivalence oracle rather than an expected failing correctness test.

Next: full normal CTest, sanitizers if applicable; then exact fixed-depth/10k-node Threads1 comparison of per-position nodes/score/bestmove/PV and bench11 against the SAME current TT/rule50-correct build, not9108 or old ZIP. Exclude time/NPS fields only. Any changed tree/signature is a blocker because the returned Boolean should be identical. Only after equivalence measure counterbalanced whole-search cost; no strength gain follows from this optimization alone.
