# Recovery instructions

This checkpoint preserves the exact tested unmerged COMPILED-JAVASCRIPT GrokChess candidate, NOT authoritative TypeScript. All source and evidence are under files/ in the ZIP; extract and change into files/.

The source/grokjs directory is a byte-for-byte extraction of the preceding checkpoint candidate, named forge-grokchess-hourly-20261020-1305-threads-warmup.zip (SHA256 0fd6f19531b8686c965df2e59098bd4071c2e6cafc53990e3d8446b90290611e). The full generated JavaScript engine is contained here; the old checkpoint ZIP is not nested.

From extracted files/:
    python3 tests/uci_stress.py
    python3 tests/audit_uci_stress.py
    GROKCHESS_USE_NNUE=1 node source/grokjs/tests/movegen.test.js
    GROKCHESS_USE_NNUE=1 node source/grokjs/tests/perft.test.js
    GROKCHESS_USE_NNUE=1 node source/bench/bench.js source/grokjs 9
    GROKCHESS_USE_NNUE=1 node source/bench/bench.js source/grokjs 10

The tests/uci_stress.py file has a patched local path lookup so it finds its sibling source/grokjs when run from files/; otherwise the test is unchanged. Logs from this run are under logs/.

Sol's original Forge code remains on GitHub, not duplicated into this GrokChess-only engine snapshot:
  https://github.com/couns0538-sketch/dwqww/tree/forge/6.4-hourly-20261019
  https://github.com/couns0538-sketch/dwqww/commit/af1941375111717f415a46d9ce0224c329034466
  https://github.com/couns0538-sketch/dwqww/commit/5101c2529d386b7c3a04ba9156a69ee34df6bb43
  https://github.com/couns0538-sketch/dwqww/actions/runs/39446498263
