"use strict";
/** Transposition table — packed entries; optional SharedArrayBuffer for Lazy SMP */
Object.defineProperty(exports, "__esModule", { value: true });
exports.MATE_BOUND = exports.MATE_SCORE = exports.TranspositionTable = exports.TT_SIZE = void 0;
exports.createSharedTTBundle = createSharedTTBundle;
exports.packMove = packMove;
exports.unpackMove = unpackMove;
exports.scoreToTT = scoreToTT;
exports.scoreFromTT = scoreFromTT;
/** Default 4M entries; shared SMP uses same. */
exports.TT_SIZE = 1 << 22;
function createSharedTTBundle(size = exports.TT_SIZE) {
    const depthsSab = new SharedArrayBuffer(size);
    new Int8Array(depthsSab).fill(-1);
    return {
        size,
        keysHiSab: new SharedArrayBuffer(size * 4),
        keysLoSab: new SharedArrayBuffer(size * 4),
        depthsSab,
        scoresSab: new SharedArrayBuffer(size * 2),
        flagsSab: new SharedArrayBuffer(size),
        agesSab: new SharedArrayBuffer(size),
        movesSab: new SharedArrayBuffer(size * 4),
        metaSab: new SharedArrayBuffer(4),
        // One 32-bit sequence counter per slot for coherent multiworker snapshots.
        seqSab: new SharedArrayBuffer(size * 4),
    };
}
/** Pack from/to/promo; 0 = null. sameMove only needs these fields. */
function packMove(m) {
    if (!m)
        return 0;
    return (1 + m.from + (m.to << 6) + ((m.promo & 15) << 12)) >>> 0;
}
function unpackMove(code) {
    if (!code)
        return null;
    const v = (code - 1) >>> 0;
    return {
        from: v & 63,
        to: (v >>> 6) & 63,
        promo: (v >>> 12) & 15,
        piece: 0 /* Piece.None */,
        captured: 0 /* Piece.None */,
        flags: 0,
    };
}
class TranspositionTable {
    constructor(size = exports.TT_SIZE, bundle) {
        /** Optional object cache for local TT only (unused when shared). */
        this.moves = null;
        this.age = 0;
        this.sharedMeta = null;
        this.seq = null;
        this.isShared = false;
        if (bundle) {
            this.size = bundle.size;
            this.keysHi = new Int32Array(bundle.keysHiSab);
            this.keysLo = new Int32Array(bundle.keysLoSab);
            this.depths = new Int8Array(bundle.depthsSab);
            this.scores = new Int16Array(bundle.scoresSab);
            this.flags = new Uint8Array(bundle.flagsSab);
            this.ages = new Uint8Array(bundle.agesSab);
            this.moveCodes = new Uint32Array(bundle.movesSab);
            this.sharedMeta = new Int32Array(bundle.metaSab);
            if (!(bundle.seqSab instanceof SharedArrayBuffer))
                throw new Error('Shared TT requires seqSab; incompatible bundle');
            this.seq = new Int32Array(bundle.seqSab);
            this.isShared = true;
            this.age = Atomics.load(this.sharedMeta, 0) & 255;
        }
        else {
            this.size = size;
            this.keysHi = new Int32Array(size);
            this.keysLo = new Int32Array(size);
            this.depths = new Int8Array(size);
            this.scores = new Int16Array(size);
            this.flags = new Uint8Array(size);
            this.ages = new Uint8Array(size);
            this.moveCodes = new Uint32Array(size);
            this.depths.fill(-1);
        }
    }
    clear() {
        this.depths.fill(-1);
        this.moveCodes.fill(0);
        this.keysHi.fill(0);
        this.keysLo.fill(0);
        this.scores.fill(0);
        this.flags.fill(0);
        this.ages.fill(0);
        this.age = 0;
        // The caller must quiesce all searching workers before a shared clear.
        if (this.seq)
            this.seq.fill(0);
        if (this.sharedMeta)
            Atomics.store(this.sharedMeta, 0, 0);
    }
    index(lo) {
        return lo & (this.size - 1);
    }
    probe(hi, lo) {
        const i = lo & (this.size - 1);
        // Cheap speculative miss check: a false negative during a write is safe.
        // Hits are validated again under the full sequence protocol below.
        if (this.seq && (this.keysLo[i] !== lo || this.keysHi[i] !== hi || this.depths[i] < 0))
            return null;
        // Shared readers may reject a racing slot. Rejecting a TT hit is safe;
        // returning a key paired with stale score/bounds is not.
        const ver = this.seq ? Atomics.load(this.seq, i) : 0;
        if (ver & 1)
            return null;
        if (this.keysLo[i] === lo && this.keysHi[i] === hi && this.depths[i] >= 0) {
            const depth = this.depths[i];
            const score = this.scores[i];
            const flag = this.flags[i];
            const moveCode = this.moveCodes[i];
            const age = this.ages[i];
            if (this.seq && Atomics.load(this.seq, i) !== ver)
                return null;
            return { hi, lo, depth, score, flag, bestMove: unpackMove(moveCode), age };
        }
        return null;
    }
    store(hi, lo, depth, score, flag, bestMove) {
        const i = lo & (this.size - 1);
        let claimed = -1;
        if (this.seq) {
            // A shared TT is advisory: skip a contended write rather than spin.
            // A worker may be terminated while holding an odd slot version;
            // an unbounded retry would then hang another search indefinitely.
            // A failed CAS performs *no* data writes, preserving reader safety.
            const v = Atomics.load(this.seq, i);
            if ((v & 1) || Atomics.compareExchange(this.seq, i, v, v + 1) !== v)
                return;
            claimed = v;
        }
        try {
            const curD = this.depths[i];
            const same = this.keysLo[i] === lo && this.keysHi[i] === hi && curD >= 0;
            if (same && depth < curD) {
                if (!this.moveCodes[i] && bestMove)
                    this.moveCodes[i] = packMove(bestMove);
                return;
            }
            // ttkeep: wrap-safe generation distance (age is 8-bit and now persists across go)
            if (!same && curD >= 0 && depth < curD && ((this.age - this.ages[i]) & 255) <= 2 && flag !== 0 /* TTFlag.Exact */) {
                return;
            }
            this.keysHi[i] = hi;
            this.keysLo[i] = lo;
            this.depths[i] = depth > 127 ? 127 : depth;
            this.scores[i] = score > 32767 ? 32767 : score < -32768 ? -32768 : score;
            this.flags[i] = flag;
            this.moveCodes[i] = packMove(bestMove);
            this.ages[i] = this.age & 255;
        }
        finally {
            if (this.seq)
                Atomics.store(this.seq, i, claimed + 2);
        }
    }
    prefetchAge() {
        if (this.sharedMeta) {
            // Approximate age bump; races are fine for replacement policy
            let a = (Atomics.load(this.sharedMeta, 0) + 1) & 255;
            Atomics.store(this.sharedMeta, 0, a);
            this.age = a;
        }
        else {
            this.age = (this.age + 1) & 255;
        }
    }
}
exports.TranspositionTable = TranspositionTable;
exports.MATE_SCORE = 30000;
exports.MATE_BOUND = 29000;
function scoreToTT(score, ply) {
    if (score > exports.MATE_BOUND)
        return score + ply;
    if (score < -exports.MATE_BOUND)
        return score - ply;
    return score;
}
function scoreFromTT(score, ply) {
    if (score > exports.MATE_BOUND)
        return score - ply;
    if (score < -exports.MATE_BOUND)
        return score + ply;
    return score;
}
//# sourceMappingURL=tt.js.map