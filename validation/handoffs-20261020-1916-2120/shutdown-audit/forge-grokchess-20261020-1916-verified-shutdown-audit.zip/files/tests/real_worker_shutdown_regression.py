#!/usr/bin/env python3
"""GrokChess 1.7.50 compiled-JS real-worker UCI shutdown/EOF regression.
Actual Node workers; finite, deadline bounded; no match or Elo claim.
"""
import hashlib, json, os, pathlib, queue, re, subprocess, threading, time, sys, platform
ROOT = pathlib.Path(__file__).resolve().parent.parent
ENGINE = ROOT/'source/grokjs/uci/main.js'
LOGS = ROOT/'shutdown_replay_logs'; LOGS.mkdir(exist_ok=True)
MODES = ('quit_active','eof_active','stop_then_quit','stop_then_search','isready_then_quit')
THREADS = (1,2,4,8)
results=[]
for mode in MODES:
  for th in THREADS:
    p=subprocess.Popen(['node',str(ENGINE)],cwd=ENGINE.parent.parent,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,bufsize=1,env={**os.environ,'GROKCHESS_USE_NNUE':'1'})
    q=queue.Queue();out=[];err=[];trans=[];failure=None
    def reader(f,dst,put=False):
      for s in f:
        s=s.rstrip('\r\n');dst.append(s)
        if put:q.put(s)
    ot=threading.Thread(target=reader,args=(p.stdout,out,True),daemon=True);ot.start()
    et=threading.Thread(target=reader,args=(p.stderr,err,False),daemon=True);et.start()
    def send(c):
      trans.append('> '+c);p.stdin.write(c+'\n');p.stdin.flush()
    def wait(prefix,timeout=8):
      end=time.monotonic()+timeout
      while True:
        n=end-time.monotonic()
        if n<=0:raise TimeoutError('waiting for '+prefix)
        try:s=q.get(timeout=n)
        except queue.Empty:raise TimeoutError('waiting for '+prefix) from None
        if s.startswith(prefix):return s
    start=time.monotonic()
    try:
      send('uci');wait('uciok');send('setoption name UseNNUE value true')
      send(f'setoption name Threads value {th}')
      if mode!='isready_then_quit':
        send('isready');wait('readyok')
        send('position startpos')
        send('go infinite')
        time.sleep(0.04)
        if mode=='quit_active':send('quit')
        elif mode=='eof_active':p.stdin.close()
        elif mode=='stop_then_quit':send('stop');send('quit')
        elif mode=='stop_then_search':
          send('stop');best=wait('bestmove ',timeout=6)
          assert re.fullmatch(r'bestmove [a-h][1-8][a-h][1-8][qrbn]?',best),best
          send('position startpos');send('go movetime 100')
          best=wait('bestmove ',timeout=6)
          assert re.fullmatch(r'bestmove [a-h][1-8][a-h][1-8][qrbn]?',best),best
          send('quit')
      else:
        send('isready');send('quit')
      p.wait(timeout=8)
      if p.returncode!=0:raise AssertionError('nonzero exit: '+str(p.returncode))
    except Exception as e:
      failure=type(e).__name__+': '+str(e)
    finally:
      if p.poll() is None:p.kill();p.wait(timeout=2)
      ot.join(timeout=1);et.join(timeout=1)
      transcript='\n'.join(trans+['# stdout']+['< '+x for x in out]+['# stderr']+['! '+x for x in err])+'\n'
      name=f'{mode}_threads{th}.log';(LOGS/name).write_text(transcript)
      results.append({'mode':mode,'threads':th,'status':'FAIL' if failure else 'PASS','failure':failure,'rc':p.returncode,'elapsed_ms':round((time.monotonic()-start)*1000,2),'stdout_lines':len(out),'stderr_lines':len(err),'bestmoves':sum(x.startswith('bestmove ') for x in out),'sha256':hashlib.sha256(transcript.encode()).hexdigest()})
      print(mode,th,'FAIL' if failure else 'PASS',p.returncode,round((time.monotonic()-start)*1000,2),flush=True)
summary={'platform':platform.platform(),'node':subprocess.check_output(['node','--version'],text=True).strip(),'engine_sha256':hashlib.sha256(ENGINE.read_bytes()).hexdigest(),'cases':len(results),'passed':sum(x['status']=='PASS' for x in results),'failed':sum(x['status']=='FAIL' for x in results),'results':results}
(ROOT/'shutdown_results.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='results'},indent=2))
sys.exit(0 if summary['failed']==0 else 1)
