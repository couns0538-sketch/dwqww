#!/usr/bin/env python3
"""Independent log-level verification for a startpos-only UCI SMP trial."""
import json,re,sys
from pathlib import Path
root=Path(__file__).resolve().parent
r=json.loads((root.parent/'logs'/'uci_stress_results.json').read_text())
t=(root.parent/'logs'/'uci_stress_transcript.log').read_text().splitlines()
cmd=[s[2:] for s in t if s.startswith('> ')]
lines=[s[2:] for s in t if s.startswith('< ')]
starts=[s for s in cmd if s=='position startpos']
go=[s for s in cmd if s.startswith('go ')]
best=[s for s in lines if s.startswith('bestmove ')]
legal=set()
for x in 'abcdefgh':
 legal.add(f'{x}2{x}3')
 legal.add(f'{x}2{x}4')
legal.update(['b1a3','b1c3','g1f3','g1h3'])
illegal=[x for x in best if x.removeprefix('bestmove ') not in legal]
assert r['status']=='PASS',r
assert len(go)==len(best)==len(starts)==len(r['trials'])==48,(len(go),len(best),len(starts),len(r['trials']))
assert len(illegal)==0,illegal
assert not any('warning' in x.lower() for x in lines)
assert all(x['bestmove'] in best and x['elapsed_ms']<=2500 for x in r['trials'])
print(json.dumps({'verification':'PASS','completed':48,'legal_startpos_bestmoves':len(best),'duplicate_or_missing_bestmoves':False,'warnings':0,'thread_settings':sorted({x['threads'] for x in r['trials']}),'stops':sum(x['stop'] for x in r['trials']),'max_ms':r['max_latency_ms']},indent=2))
