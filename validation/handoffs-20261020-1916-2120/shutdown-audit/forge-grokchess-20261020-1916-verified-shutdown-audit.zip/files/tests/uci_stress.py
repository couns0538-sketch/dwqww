#!/usr/bin/env python3
"""Real-worker UCI lifecycle probe against an unmerged compiled-JS GrokChess build.
No fault injection. Preserves transcript and structured results. Not an Elo test.
"""
import json, os, pathlib, queue, re, subprocess, sys, threading, time, hashlib
root=pathlib.Path(__file__).resolve().parent
eng=root.parent/'source'/'grokjs'
log=root.parent/'logs'/'uci_stress_transcript.log'
result=root.parent/'logs'/'uci_stress_results.json'
p=subprocess.Popen(['node',str(eng/'uci/main.js')],cwd=eng,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,bufsize=1,env={**os.environ,'GROKCHESS_USE_NNUE':'1'})
q=queue.Queue();entries=[];errs=[]
def reader(pipe,dst,put=False):
 for line in pipe:
  s=line.rstrip('\r\n');dst.append(s)
  if put:q.put(s)
threading.Thread(target=reader,args=(p.stdout,entries,True),daemon=True).start()
threading.Thread(target=reader,args=(p.stderr,errs,False),daemon=True).start()
commands=[];trials=[];failure=None

def send(x):
 commands.append(x);p.stdin.write(x+'\n');p.stdin.flush()
def wait(prefix,timeout=10):
 deadline=time.monotonic()+timeout
 while True:
  t=deadline-time.monotonic()
  if t<=0:raise TimeoutError(prefix)
  line=q.get(timeout=t)
  if line.startswith(prefix):return line
try:
 send('uci');wait('uciok')
 send('setoption name UseNNUE value true')
 send('setoption name Threads value 2')
 send('isready');wait('readyok')
 for i in range(48):
  th=(2,4,2,1,4,1)[i%6]
  send(f'setoption name Threads value {th}')
  send('isready');wait('readyok')
  send('position startpos')
  timing=(i%4!=0)
  command='go movetime 90' if timing else 'go depth 5'
  send(command)
  started=time.monotonic()
  if i%5==0:
   time.sleep(0.012)
   send('stop')
  best=wait('bestmove ',timeout=12)
  elapsed=(time.monotonic()-started)*1000
  if not re.fullmatch(r'bestmove (?:[a-h][1-8][a-h][1-8][qrbn]?)',best):
   raise AssertionError('invalid bestmove '+repr(best))
  if elapsed>2500:
   raise AssertionError(f'search latency {elapsed:.1f}ms exceeds 2500ms')
  trials.append({'iteration':i,'threads':th,'go':command,'stop':i%5==0,'bestmove':best,'elapsed_ms':round(elapsed,2)})
 send('quit');p.wait(timeout=8)
 if p.returncode!=0:raise AssertionError('quit rc '+str(p.returncode))
except Exception as exc:
 failure=type(exc).__name__+': '+str(exc)
finally:
 if p.poll() is None:
  p.kill();p.wait()
 log.write_text('\n'.join(['# commands']+['> '+s for s in commands]+['# stdout']+['< '+s for s in entries]+['# stderr']+['! '+s for s in errs])+'\n')
 result.write_text(json.dumps({'status':'FAIL' if failure else 'PASS','failure':failure,'node_version':subprocess.check_output(['node','--version'],text=True).strip(),'os':sys.platform,'rounds_target':48,'rounds_complete':len(trials),'exit_code':p.returncode,'max_latency_ms':max((t['elapsed_ms'] for t in trials),default=None),'warnings':[s for s in entries if 'warning' in s.lower()],'trials':trials,'transcript_sha256':hashlib.sha256(log.read_bytes()).hexdigest()},indent=2)+'\n')
 print(json.dumps({'status':'FAIL' if failure else 'PASS','failure':failure,'complete':len(trials),'exit':p.returncode,'max_ms':max((t['elapsed_ms'] for t in trials),default=None),'warnings':[s for s in entries if 'warning' in s.lower()][-8:]},indent=2))
