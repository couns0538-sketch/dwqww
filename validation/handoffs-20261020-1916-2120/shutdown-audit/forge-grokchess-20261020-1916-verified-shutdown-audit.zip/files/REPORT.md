# Forge and GrokChess independent run — 2026-10-20, ~19:12 Europe/Vienna

## Sol-first GitHub inspection (read-only evidence)
- Repository `couns0538-sketch/dwqww` default `main` SHA `5176ddf79ae15b76c08c4485d90ee5600ba30a1a`; **not** the active Forge source.
- Current Forge 6.4 source branch `forge/6.4-hourly-20261019`: `356e863dbd86d2ce24b8ee9486d7406f1d525480`. `forge/test-20261020-1830`, `forge/candidate-terminal-zero-nodes-20261020-1645`, and recent source-only researcher branches also point to that identical commit, not additional tested changes.
- Latest code on the main Forge development branch corrects clock-origin handling (`294cf1ba7d2e3e77a70a08578958a5faea3b54dd`); native CI run `39384192757` completed successfully. Earlier validation reported corrected clock timing; no new native timing was measured in this run.
- Sol-associated isolated branch contains `af1941375111717f415a46d9ce0224c329034466`, changing one source condition in `src/uci.cpp` from `(own_book || !book_file.empty())` to `own_book` alone. `5101c2529d386b7c3a04ba9156a69ee34df6bb43` adds a 156-line native UCI regression. The current Forge development branch **still has the original bug**, confirmed directly in fetched `src/uci.cpp` (original blob `debb80cbd2a0c4afb9dab381688ad81290b10471`). Previously independent native GitHub Actions run `39446498263` passed baseline reproduction + corrected-candidate regression (both 4/4 CTests); this run read the source and workflow, but did not re-execute them.
- Pull requests 1-6 remain open, including #6 evidence transport and #2-5 historical strength-claim work. No freshly accepted equal-time Elo gain was observed.
- NNUE hosted run `39348571407` was a completed CI job but the previously reviewed 2,048-game 427-1194-427 comparison was neutral, not an Elo gain. TT hosted run `39403471059` failed at the native SPRT step, **not** compilation or CTest: workflow log contains `RuntimeError: match_fail_fast: Fastchess warning/error in fastchess.log`. Both binaries passed their reported 9 tests in CI; original run artifact #12255979381 (32,486,957 bytes, SHA-256 `fa5ae91285b32cadbea1d9e8a3b68efb9be5f5e58338d3f34b8cb04ffaaa4501`) and results branch remain available. The warning's underlying UCI/engine cause was NOT resolved here.

## Intended integration and write limitation
An isolated branch `research/forge64-ownbook-integration-20261020-1908` was created from exact Forge 6.4 commit `356e863d` to integrate Sol's already tested one-line OwnBook repair. Attempting the authenticated `src/uci.cpp` update was **blocked by the connector safety checks**. No subsequent endpoint/alternate representation was used to bypass this denial; the branch remains byte-identical to 6.4 (GitHub compare ahead=0, behind=0). **No Forge source was changed or published in this run.** Further Forge integration requires a permitted source write, or an authorized integrator to apply the existing source patch.

## Disjoint executable GrokChess validation
Recovered prior immutable GrokChess experimental compiled-JavaScript 1.7.50 checkpoint, `forge-grokchess-cycle-20261020-1815.zip`, SHA-256 `4e2f545884e6548279fd302cd69595891b310e5f48dc0ef206474fbeaddd4d6e`. Original ZIP CRC test passed. Executed a NEW bounded real-worker UCI shutdown-race regression on a byte-identical compiled-JS distribution with production network.

Command: `python files/tests/real_worker_shutdown_regression.py` from the ZIP extraction root. Actual runtime: Linux x86_64, Node v22.16.0. Five scenarios x four thread counts (1, 2, 4, 8) = **20/20 passed**:
1. `quit` while `go infinite` is active;
2. stdin EOF while `go infinite` is active;
3. immediate `stop` followed by `quit`;
4. `stop`, wait for a legal `bestmove`, run a second genuine search, then `quit`;
5. `isready` followed immediately by `quit` during worker warmup.

All 20 processes exited with code 0 under an 8-second bound. No emitted `bestmove` was missing in scenario 4; other scenarios test shutdown, not a guaranteed bestmove. The highest observed end-to-end case duration was 1,031.3 ms (startup included, **not** an NPS or speed comparison). All raw stdout/stderr traces, timing and test script are saved under `logs/` and `tests/`.

A 20/20 pass is **targeted reliability evidence only**. It does not prove absence of other SMP issues, and cannot be generalized to authoritative TypeScript, native Windows, a different Node version, or the Ryzen 7 9850X3D. No new code fix was necessary or implemented. This task was disjoint from prior 48+48 search test because it exercises cancellation during actual process shutdown and EOF.

## Separate verdicts
- **Sol correctness:** Forge clock-origin and OwnBook fixes have credible native GitHub Actions evidence. The OwnBook integration into the 6.4 development branch remains outstanding.
- **GrokChess correctness:** PASS on 20 new real-worker Linux UCI shutdown scenarios; experimental compiled JS only.
- **Speed:** Not measured; do not interpret exit duration as search performance.
- **Equal-time playing strength:** Not measured. No new accepted Elo gain.
- **Publication:** GitHub attempted isolated source update was blocked; only a zero-diff isolated branch exists. Complete new test source, original compiled-JS baseline/network, and raw logs are preserved in this downloadable checkpoint, NOT claimed uploaded to GitHub.

## Next action
A permitted integrator should apply Sol's existing minimal OwnBook fix and native test on top of the exact Forge 6.4 SHA, run CTest and independent native regression, then consider integration while preserving Sol's branch. For GrokChess, secure authoritative matching TypeScript source and port the accumulated SMP fixes there before production acceptance and Windows runtime trials.

### Restored-checkpoint independent replay
After creating and verifying an intermediate manifest-protected archive, I extracted it into a fresh directory and executed its **packaged** regression script. The restored engine source/network and test produced **another 20/20 passing real-worker cases**, with Node v22.16.0 and all process exit codes 0. Its raw output and 20 transcripts are included under `logs/restore_retest/` in this final archive. The final staging changes after that replay are only this report and inclusion of replay evidence; executable engine/test source bytes were not changed.
