# Recovery and replay

Extract checkpoint ZIP with a safe ZIP reader; all payloads are below `files/`. Verify the checkpoint with the included `CHECKPOINT_MANIFEST.json` or the Chess Engine Coordinator's `scripts/checkpoint.py verify` utility. Work from the extracted `files/` root. Ensure the native engine binaries are executable on compatible Linux x86-64; they are not Windows executables. Run these commands using Python 3.10+:

```sh
python3 -m unittest -v diagnostic.test_uci_clock_trace
python3 diagnostic/analyze_uci_clock_trace.py original-sprt/fastchess.log --json regenerated-summary.json --csv regenerated-searches.csv
chmod +x original-binaries/baseline-forge original-binaries/candidate-forge
python3 diagnostic/replay_timeout_fixture.py --log original-sprt/fastchess.log --engine original-binaries/baseline-forge --rounds 20 --journal replay-baseline.jsonl --result replay-baseline.json
python3 diagnostic/replay_timeout_fixture.py --log original-sprt/fastchess.log --engine original-binaries/candidate-forge --rounds 20 --journal replay-candidate.jsonl --result replay-candidate.json
```

Local timing results are environment-dependent; do not expect identical nanosecond timestamps, PVs, move choices, or median milliseconds when replayed on a different CPU. Search-count and log-derived timestamps from the archived **original** Fastchess log should be identical. The test fixture uses original `position fen ... moves ...` from log line 276630; the final clock command is at line 276633. The full command/options and per-search artifacts are preserved. Do not treat these 40 UCI probes as strength games or the prior incomplete Fastchess match as resumable.

Original frozen GitHub experiment: https://github.com/couns0538-sketch/dwqww/actions/runs/39403471059 ; original native artifacts preserved with source revision identities as documented in REPORT-20261020-clock-gap.md. Full source is supplied as TAR snapshots in this package, and both archived executables are byte-verified against the frozen experiment's SHA-256 manifest.
