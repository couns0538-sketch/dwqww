# Forge/GrokChess independent cycle: native timeout gap, 20 October 2026

UTC time window: 19:11-19:20 UTC. Environment: Linux x86-64, AMD EPYC 9V74 cloud CPU (5 available logical CPUs), Python 3.11+, baseline and candidate ELF binaries archived by the original GitHub Actions run. No Windows or Ryzen runtime.

## Live Sol-first repository review

Source-of-truth repository: `couns0538-sketch/dwqww`. The default branch is `main`. Inspected via the connected GitHub connector: current integration head `forge/6.4-hourly-20261019` = `356e863dbd86d2ce24b8ee9486d7406f1d525480`; candidate terminal-zero-nodes `forge/candidate-terminal-zero-nodes-20261020-1645`, researcher `forge/research-20261020-1315` and tester `forge/test-20261020-1530` all point to this **same SHA**. Names alone represent no new code. The integrator OwnBook branch points to `5101c2529d386b7c3a04ba9156a69ee34df6bb43`; tested fix commit `af1941375111717f415a46d9ce0224c329034466`. Reviewed recent commits, open PRs, 12 available GitHub Actions runs, branch heads, and frozen STATE.json. Did not inspect every historical branch or full multi-hundred-file PR diff.

Sol-attributed actual work: native OwnBook=false external Polyglot book repair with added test, plus UCI command-dispatch clock-origin patch on integration branch (commit `294cf1ba7d2e3e77a70a08578958a5faea3b54dd`). The OwnBook baseline-versus-fix Actions run `39446498263` finished SUCCESS on native Linux. Forge clock-origin native run `39384192757` finished SUCCESS. Its previously archived controlled 440-ms pthread-create admission probe demonstrated bounded end-to-end time after the repair. These are **correctness/timing contract improvements**, not engine speed or equal-time Elo gains. The hosted TT experiment Actions run `39403471059` failed after an actual Fastchess time forfeit, not after an SPRT decision. The 2,048-game NNUE hosted test has no verified positive H1 acceptance in the inspected summary; no new strength gain is claimed. The GrokChess research branch `research/grokchess-nnueinfo-worker-exit-20261020-1609` points to `3c1e8477d5997f9d0de9fa1ffc6f7b9a956f1728`; authoritative TS integration and Windows runtime remain unverified. The research branch name is not itself an implementation.

Native links: https://github.com/couns0538-sketch/dwqww/actions/runs/39446498263 ; https://github.com/couns0538-sketch/dwqww/actions/runs/39384192757 ; https://github.com/couns0538-sketch/dwqww/actions/runs/39403471059 .

## Scope and novelty

An earlier forensic audit located one original warning: `Engine Baseline loses on time by 45ms`, with a Go-to-bestmove logger interval of 108.696 ms versus last UCI `info time 24`. That prior audit checked only the final occurrence. This cycle **independently audited every `go`/`bestmove` pair** in the original 45,765,601-byte Fastchess communication log, parsed the complete last depth info for each search, and replayed the exact failing UCI position using the two **unchanged original ELF executables**. It did not rerun or resume any strength match.

## New comprehensive evidence

The original communication trace has 11,229 completed search responses with no unmatched bestmove or unclosed command (Baseline 5,616; Candidate 5,613). Every completed search had a depth-info time. Define `info_timestamp_lag_ms = (Fastchess-log timestamp of the last depth-info line - Fastchess-log timestamp of the go line) - engine-reported last-info time`. This is a **diagnostic of timestamp disagreement**, not direct CPU time, and engine `info time` can be earlier than actual bestmove publication. Decimal millisecond timing derived from original logged times; UCI-reported time is millisecond-granular.

| Metric | Baseline | Candidate |
| --- | ---: | ---: |
| Completed searches | 5,616 | 5,613 |
| Median last-info timestamp lag | 0.525 ms | 0.530 ms |
| P99 last-info lag (nearest rank) | 1.039 ms | 1.034 ms |
| Maximum lag | **84.647 ms** | 7.031 ms |
| Searches with lag >=20 ms | **1** | **0** |
| Searches with lag >=50 ms | **1** | **0** |

**The exact timeout is the only >=20 ms baseline last-info timestamp discrepancy in 5,616 baseline searches.** It is at original log `go` line 276633, last info line 276643, `bestmove` line 276644, with go `wtime 423 btime 63 winc 20 binc 20`. Go-to-bestmove log wall 108.696 ms, engine last-info `time 24`, last-info timestamp lag 84.647 ms, last-info-to-bestmove log gap **0.049 ms**. Thus the large discrepancy was already present **when the final depth-info line arrived**, not introduced by a long pause between its arrival and the bestmove line. Another baseline search had 19.139 ms last-info lag (line 90452); next-largest recorded candidate lag was 7.031 ms. A single extreme outlier is consistent with host descheduling or output/logging transport delay, but alone does not prove any specific root cause or exclude a rare engine lock stall.

### Important source differentiation

The **exact failed-match** Forge 6.4.11/6.4.12 source exports ALREADY pass the UCI go dispatch timestamp into the search clock: both have `limits.request_start = command_start` in `src/uci.cpp`, `SearchLimits.request_start` in `include/forge/search.hpp`, and `start_ = limits.request_start ...` in `Worker::search` (`src/search.cpp`). These statements were verified in both frozen source tarballs included here. Consequently, explaining **this particular** historical 45ms timeout solely as uncounted pre-search worker admission is not consistent with its actual archived source. Sol's current separate integration-clock repair uses a similarly intended `start_time` field but is in a different branch lineage; its own regression remains meaningful. No code change is justified from the current evidence.

## New exact-binary replay

Recovered original `position fen ... moves ...` fixture at Fastchess log line 276630. It starts with White to move and contains **99 legal-notation move tokens**, implying Black to move at the failing command; hence `btime 63`. The replay starts original baseline `6.4.11` and candidate `6.4.12` Linux ELF processes separately, applies `OwnBook=false`, `Book Depth=0`, `Ponder=false`, `Threads=1`, `Hash=32`, `Move Overhead=10`, `UseNNUE=true`, waits for readiness, and issues the original `go wtime 423 btime 63 winc 20 binc 20` command **20 times per engine** without reconstructing or changing source. This is a local diagnostic, not a sample of independent strength games. Search TT is warmed across iterations.

| Local replay | Original baseline ELF | Original candidate ELF |
| --- | ---: | ---: |
| Complete UCI searches | 20/20 | 20/20 |
| Process exit | 0 | 0 |
| Median go-to-bestmove wall | 28.124 ms | 27.645 ms |
| Maximum go-to-bestmove wall | 32.016 ms | 31.744 ms |
| Maximum timestamp disagreement | 1.083 ms | 1.294 ms |

Both binaries' SHA-256 matched the hashes frozen by the original experiment. The exact 108.696 ms historical delay was **not reproduced** on this cloud host in 40 searches. Since the historical failure was a one-off under a different OS scheduler/CPU and the replay does not reconstruct its previous concurrent process state, this neither clears the engine nor establishes that the original environment caused the failure.

New diagnostic utility unit tests: **2/2 PASS**. Outputs include complete per-search CSV, summary JSON, native-executable stdout JSONL journals, results, exact source tarballs/binaries, original Fastchess log/PGN and original command settings. The original 84 completed games/42 color-swapped pairs remain **invalidated for strength acceptance** by the next-game time forfeit. No new Fastchess games or Elo computation were performed.

## Verdict and next action

Correctness: a one-off real match time-forfeit remains established; exact root cause **inconclusive**. No search or engine bug fix introduced. Speed: **not tested with controlled comparative methodology**. Equal-time Elo: **no newly accepted H1 improvement** (old test invalid/inconclusive). Forge/grokchess source was not modified and no collaborator branch was touched. This cycle improves diagnostic evidence and distinguishes the failed-match source clock mechanism from Sol's related clock patch in another lineage.

Next highest-value task: build a bounded *one-host one-process* timeout stress harness for the **actual latest integration revision** `356e863d` with kernel scheduling statistics or a controlled worker-output stall, and record per-command monotonic timestamps and CPU scheduling delays before proposing a fix. A protected time budget alone cannot guarantee on-time `bestmove` if a process is descheduled for ~85 ms near a ~63 ms clock; do not blindly add stricter pruning or rerun failed strength SPRT. In parallel, authoritative GrokChess TypeScript SMP integration remains the highest separate GrokChess engineering priority.

## Limitations and preservation

Original source/binary hashes are verified against the frozen original experiment. The original original-source tar exports are distinct from current primary Forge head; no native test of that newest branch was conducted here. Original log clock timestamps represent the Fastchess logging process and may not be the exact kernel write times of its child engine. The replay host is not the archived Ubuntu GitHub runner. PGN move-by-move legality, Windows/AMD Ryzen runtime, and independent noise-controlled NPS were not assessed. Full trace data and exact reproduction scripts are checkpointed separately; SHA-256 integrity demonstrates byte preservation, not that reported conclusions are automatically true. Full unrelated Forge and GrokChess PR diffs were not reviewed. No public upload of the previously blocked separate TT-tag first-attempt raw archive has been attempted.
