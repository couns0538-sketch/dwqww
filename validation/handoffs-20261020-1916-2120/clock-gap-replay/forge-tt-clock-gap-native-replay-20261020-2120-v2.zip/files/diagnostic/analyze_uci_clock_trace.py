#!/usr/bin/env python3
"""Audit per-go wall/engine-info timing from original Fastchess UCI logs.

This does not measure CPU time and cannot distinguish scheduling delay from IO
or engine work; it only reconciles observed logger timestamps with published
UCI times. No search or game is replayed.
"""
import argparse
import csv
import datetime as dt
import json
import re
import statistics
from pathlib import Path

LINE = re.compile(r'^\[Engine\] \[([0-9:.]+)\].*?\b(Baseline|Candidate) (<---|--->) (.*)$')
INFO_TIME = re.compile(r'\btime (\d+)\b')

def ms(clock):
    h, m, s = clock.split(':')
    return (int(h) * 3600 + int(m) * 60 + float(s)) * 1000.0

def _numbered_lines(path):
    with Path(path).open(encoding="utf-8", errors="replace") as f:
        yield from enumerate(f,1)

def scan(path):
    ongoing = {}
    completed = []
    unmatched_bestmove = 0
    unclosed = []
    for lineno, line in _numbered_lines(path):
        match = LINE.match(line.rstrip('\n'))
        if not match:
            continue
        when, engine, direction, payload = match.groups()
        t = ms(when)
        if direction == '<---' and payload.startswith('go '):
            if engine in ongoing:
                unclosed.append(ongoing[engine])
            ongoing[engine] = {'engine': engine, 'go_line': lineno,
                               'go_timestamp': when, 'go_ms': t, 'go_command': payload,
                               'last_info_elapsed_ms': None, 'last_info_log_ms': None,
                               'first_info_log_ms': None, 'info_count': 0}
        elif direction == '--->' and engine in ongoing and payload.startswith('info depth '):
            obj = ongoing[engine]
            info = INFO_TIME.search(payload)
            if info:
                obj['last_info_elapsed_ms'] = int(info.group(1))
                obj['last_info_log_ms'] = t
                obj['last_info_line'] = lineno
                obj['info_count'] += 1
                if obj['first_info_log_ms'] is None:
                    obj['first_info_log_ms'] = t
        elif direction == '--->' and payload.startswith('bestmove '):
            if engine not in ongoing:
                unmatched_bestmove += 1
                continue
            obj = ongoing.pop(engine)
            obj['bestmove'] = payload.split()[1]
            obj['bestmove_line'] = lineno
            obj['bestmove_timestamp'] = when
            obj['wall_go_to_bestmove_ms'] = round(t - obj['go_ms'], 3)
            if obj['last_info_elapsed_ms'] is not None:
                obj['last_info_lag_ms'] = round(obj['last_info_log_ms'] - obj['go_ms'] - obj['last_info_elapsed_ms'], 3)
                obj['last_info_to_bestmove_ms'] = round(t - obj['last_info_log_ms'], 3)
                obj['wall_minus_reported_ms'] = round(obj['wall_go_to_bestmove_ms'] - obj['last_info_elapsed_ms'], 3)
            else:
                obj['last_info_lag_ms'] = None
                obj['last_info_to_bestmove_ms'] = None
                obj['wall_minus_reported_ms'] = None
            completed.append(obj)
    unclosed.extend(ongoing.values())
    return completed, unclosed, unmatched_bestmove

def percentile(values, p):
    if not values:
        return None
    ordered = sorted(values)
    index = min(len(ordered)-1, max(0, int((len(ordered)-1)*p/100)))
    return round(ordered[index], 3)

def summarize(rows):
    out = {}
    for engine in ('Baseline', 'Candidate'):
        curr = [x for x in rows if x['engine'] == engine]
        lags = [x['last_info_lag_ms'] for x in curr if x['last_info_lag_ms'] is not None]
        d = {'searches': len(curr), 'with_info': len(lags), 'max_lag_ms': max(lags) if lags else None,
             'lag_p50_ms': percentile(lags,50),'lag_p90_ms':percentile(lags,90),
             'lag_p99_ms':percentile(lags,99),'lag_ge_20ms':sum(x>=20 for x in lags),
             'lag_ge_50ms':sum(x>=50 for x in lags), 'lag_ge_80ms':sum(x>=80 for x in lags)}
        d['top_10_lags'] = [{k:x[k] for k in ('go_line','bestmove_line','last_info_line','go_command','bestmove','wall_go_to_bestmove_ms','last_info_elapsed_ms','last_info_lag_ms','wall_minus_reported_ms')} for x in sorted(curr,key=lambda y:y['last_info_lag_ms'] if y['last_info_lag_ms'] is not None else -float('inf'),reverse=True)[:10]]
        out[engine]=d
    return out

def main():
    p=argparse.ArgumentParser()
    p.add_argument('log')
    p.add_argument('--json',required=True)
    p.add_argument('--csv',required=True)
    args=p.parse_args()
    rows,unclosed,unmatched=scan(args.log)
    header=['engine','go_line','bestmove_line','last_info_line','go_timestamp','bestmove_timestamp','go_command','bestmove','info_count','wall_go_to_bestmove_ms','last_info_elapsed_ms','last_info_lag_ms','last_info_to_bestmove_ms','wall_minus_reported_ms']
    with open(args.csv,'w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=header,extrasaction='ignore');w.writeheader();w.writerows(rows)
    obj={'log':str(args.log),'completed_searches':len(rows),'unclosed_count':len(unclosed),'unmatched_bestmove':unmatched,'by_engine':summarize(rows)}
    with open(args.json,'w') as f:json.dump(obj,f,indent=2)
    print(json.dumps({k:v for k,v in obj.items() if k!='by_engine'},indent=2))
    for k,v in obj['by_engine'].items():
        print(k,{name:value for name,value in v.items() if name!='top_10_lags'})
        print(' largest:',v['top_10_lags'][:3])

if __name__=='__main__':main()
