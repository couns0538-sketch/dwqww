#!/usr/bin/env python3
"""Diagnostic-only replay of one previously time-forfeited Fastchess UCI position.

Not a strength match. The fixture is recovered verbatim from original communications.
The local CPU/OS clock differs from the original GitHub Actions runner.
"""
import argparse
import datetime as dt
import json
import queue
import re
import subprocess
import threading
import time
from pathlib import Path

LINE = re.compile(r'^\[Engine\] \[([0-9:.]+)\].*?\bBaseline <--- (position fen .*)$')
INFO = re.compile(r'\btime (\d+)\b')

def fixture(log):
    current=None
    for line in Path(log).open(encoding='utf-8',errors='replace'):
        m=LINE.match(line)
        if m: current=m.group(2)
        if 'Baseline <--- go wtime 423 btime 63 winc 20 binc 20' in line:
            assert current and 'moves ' in current
            return current
    raise RuntimeError('Historical position not found in original log')

def run(engine_path, position, rounds, outpath):
    engine_path=str(Path(engine_path).resolve())
    proc=subprocess.Popen([engine_path],cwd=str(Path(engine_path).parent),stdin=subprocess.PIPE,
                          stdout=subprocess.PIPE,stderr=subprocess.PIPE,bufsize=0)
    q=queue.Queue()
    trace=[]
    def reader():
        while True:
            data=proc.stdout.readline()
            if not data:
                break
            record={'timestamp_utc':dt.datetime.now(dt.timezone.utc).isoformat(),
                    'timestamp_ns':time.monotonic_ns(),'direction':'out','text':data.decode('utf8','replace').rstrip()}
            trace.append(record)
            q.put(record)
    t=threading.Thread(target=reader,daemon=True);t.start()
    def send(cmd):
        rec={'timestamp_utc':dt.datetime.now(dt.timezone.utc).isoformat(),
             'timestamp_ns':time.monotonic_ns(),'direction':'in','text':cmd}
        trace.append(rec)
        proc.stdin.write((cmd+'\n').encode('utf-8'));proc.stdin.flush()
        return rec['timestamp_ns']
    def until(prefix, timeout=6.0):
        limit=time.monotonic()+timeout
        while time.monotonic()<limit:
            try:rec=q.get(timeout=max(0.01,limit-time.monotonic()))
            except queue.Empty:continue
            if rec['text'].startswith(prefix):return rec
        raise RuntimeError(f'No {prefix} by deadline; pid={proc.pid} rc={proc.poll()}')
    results=[]
    try:
        send('uci');until('uciok')
        for cmd in ['setoption name OwnBook value false','setoption name Book Depth value 0',
                    'setoption name Ponder value false','setoption name Threads value 1',
                    'setoption name Hash value 32','setoption name Move Overhead value 10',
                    'setoption name UseNNUE value true','isready']:
            send(cmd)
        until('readyok')
        for trial in range(rounds):
            send(position); send('isready');until('readyok')
            start_ns=send('go wtime 423 btime 63 winc 20 binc 20')
            last_info=None
            limit=time.monotonic()+5
            while time.monotonic()<limit:
                try: r=q.get(timeout=max(0.01,limit-time.monotonic()))
                except queue.Empty:continue
                if r['text'].startswith('info depth '):
                    m=INFO.search(r['text'])
                    if m:last_info={'ms':int(m.group(1)),'event':r}
                if r['text'].startswith('bestmove '):
                    wall=(r['timestamp_ns']-start_ns)/1e6
                    results.append({'trial':trial,'wall_ms':round(wall,3),'bestmove':r['text'],
                         'last_info_ms':last_info['ms'] if last_info else None,
                         'info_wall_lag_ms':round((last_info['event']['timestamp_ns']-start_ns)/1e6-last_info['ms'],3) if last_info else None})
                    break
            else: raise RuntimeError('UCI search did not finish')
        send('quit');proc.wait(timeout=8)
        assert proc.returncode==0,proc.returncode
        assert len(results)==rounds,len(results)
        return {'engine':engine_path,'exit_code':proc.returncode,'rounds':rounds,'results':results}
    finally:
        if proc.poll() is None:proc.kill();proc.wait(timeout=4)
        with open(outpath,'w') as f:
            for x in trace:f.write(json.dumps(x)+'\n')

def main():
    p=argparse.ArgumentParser();p.add_argument('--log',required=True);p.add_argument('--engine',required=True)
    p.add_argument('--rounds',type=int,default=16);p.add_argument('--journal',required=True);p.add_argument('--result',required=True)
    a=p.parse_args()
    pos=fixture(a.log)
    result=run(a.engine,pos,a.rounds,a.journal)
    result['fixture']=pos
    Path(a.result).write_text(json.dumps(result,indent=2))
    print('Exit',result['exit_code'],'finished',len(result['results']))
    print('wall_ms',min(x['wall_ms'] for x in result['results']),max(x['wall_ms'] for x in result['results']))
    print('lag_ms',max(x['info_wall_lag_ms'] for x in result['results'] if x['info_wall_lag_ms'] is not None))

if __name__=='__main__':main()
