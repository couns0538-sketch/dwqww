import tempfile
import unittest
from pathlib import Path
try:
    from analyze_uci_clock_trace import scan, summarize
except ModuleNotFoundError:
    from diagnostic.analyze_uci_clock_trace import scan, summarize

class AuditTests(unittest.TestCase):
    def test_pair_and_latency(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'x.log'
            p.write_text('''[Engine] [09:00:00.100000] <     1>  Baseline <--- go wtime 300 btime 60 winc 0 binc 0
[Engine] [09:00:00.104000] <     1>  Baseline ---> info depth 1 time 3 nodes 100
[Engine] [09:00:00.111000] <     1>  Baseline ---> bestmove e2e4
[Engine] [09:00:00.112000] <     1>  Candidate <--- go movetime 30
[Engine] [09:00:00.121000] <     1>  Candidate ---> bestmove d2d4
''')
            rows,unclosed,unmatched=scan(p)
            self.assertEqual((len(rows),len(unclosed),unmatched),(2,0,0))
            self.assertAlmostEqual(rows[0]['wall_go_to_bestmove_ms'],11,places=3)
            self.assertAlmostEqual(rows[0]['last_info_lag_ms'],1,places=3)
            self.assertIsNone(rows[1]['last_info_lag_ms'])
    def test_missing_bestmove_retained(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'x.log'
            p.write_text('''[Engine] [00:00:01.000000] <     1>  Baseline <--- go movetime 2
[Engine] [00:00:01.001000] <     1>  Candidate ---> bestmove b1c3
''')
            rows,unclosed,unmatched=scan(p)
            self.assertEqual((len(rows),len(unclosed),unmatched),(0,1,1))

if __name__=='__main__':unittest.main()
