#!/usr/bin/env python3
"""Native Windows20pairedNPS comparison; stdlib only, no games/Elo inference.

Keep both binaries, this script and every result. Run in an otherwise idle PC.
The default baseline hash identifies exact shipped Forge6.4.24 Zen5 Windows.
"""
from __future__ import annotations
import argparse,datetime,hashlib,json,math,os,pathlib,platform,random,re,statistics,subprocess,sys,time
BASELINE_SHA256='b58058055615e299ed49279929ee71fced5d505845d8049dabaeed57aa07269c'
PATTERN=re.compile(rb'^info string bench depth (\d+) nodes (\d+) time (\d+) nps (\d+)\s*$',re.M)
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(path):
 d=hashlib.sha256()
 with pathlib.Path(path).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):d.update(b)
 return d.hexdigest()
def write(path,data):
 with pathlib.Path(path).open('x',encoding='utf-8') as f:json.dump(data,f,indent=2,allow_nan=False);f.write('\n')
def parse_benches(raw,depth,repetitions):
 rows=[{'depth':int(d),'nodes':int(n),'engine_ms':int(t),'engine_nps':int(s)} for d,n,t,s in PATTERN.findall(raw)]
 if len(rows)!=repetitions or any(r['depth']!=depth or r['nodes']<=0 or r['engine_ms']<=0 for r in rows):raise ValueError('Expected every declared positive benchmark line, no omissions')
 return rows
def orders(pairs,seed):
 if pairs!=20:raise ValueError('This preregistered helper uses exactly20pairs')
 values=[('baseline','candidate')]*10+[('candidate','baseline')]*10;random.Random(seed).shuffle(values);return values
def set_affinity(child,mask):
 if mask is None:return
 if os.name!='nt':raise ValueError('Affinity mask supported on nativeWindows only')
 import ctypes
 from ctypes import wintypes
 k=ctypes.WinDLL('kernel32',use_last_error=True);k.GetActiveProcessorGroupCount.restype=wintypes.WORD
 if k.GetActiveProcessorGroupCount()!=1:raise ValueError('MultipleWindowsCPUgroups: refuse automaticgroupguess; omitmask and documentmanualpolicy')
 k.SetProcessAffinityMask.argtypes=[wintypes.HANDLE,ctypes.c_size_t];k.SetProcessAffinityMask.restype=wintypes.BOOL
 if not k.SetProcessAffinityMask(wintypes.HANDLE(int(child._handle)),ctypes.c_size_t(mask)):raise ctypes.WinError(ctypes.get_last_error())
def run_process(argv,payload,prefix,depth,repetitions,timeout,affinity_mask):
 prefix=pathlib.Path(prefix);stdin=prefix.with_suffix('.stdin');stdout=prefix.with_suffix('.stdout');stderr=prefix.with_suffix('.stderr')
 with stdin.open('xb') as f:f.write(payload)
 record={'argv':argv,'started_utc':utc(),'affinity_mask':affinity_mask,'actual_exit':None,'timed_out':False,'valid':False};start=time.perf_counter_ns();child=None
 try:
  child=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  record['pid']=child.pid;set_affinity(child,affinity_mask)
  try:out,err=child.communicate(payload,timeout=timeout)
  except subprocess.TimeoutExpired:
   record['timed_out']=True;child.kill();out,err=child.communicate()
  record['actual_exit']=child.returncode
 except BaseException as error:
  record['error']=repr(error)
  if child is not None:
   if child.poll() is None:child.kill()
   out,err=child.communicate();record['actual_exit']=child.returncode
  else:out,err=b'',b''
 record['wall_ns']=time.perf_counter_ns()-start
 for p,b in ((stdout,out),(stderr,err)):
  with p.open('xb') as f:f.write(b)
 record.update(closed_utc=utc(),stdout_sha256=sha(stdout),stderr_sha256=sha(stderr),stdin_sha256=sha(stdin))
 try:
  rows=parse_benches(out,depth,repetitions);record['bench_rows']=rows;record['total_nodes']=sum(r['nodes'] for r in rows);record['total_engine_ms']=sum(r['engine_ms'] for r in rows)
  record['wall_nps']=record['total_nodes']*1e9/record['wall_ns'];record['engine_nps_aggregate']=record['total_nodes']*1000/record['total_engine_ms']
  record['valid']=record['actual_exit']==0 and not record['timed_out'] and not record.get('error') and len(set(r['nodes'] for r in rows))==1
 except ValueError as error:record['parse_error']=str(error);record['bench_rows']=[]
 write(prefix.with_suffix('.json'),record);return record
def percentile(sorted_values,q):
 x=(len(sorted_values)-1)*q;lo=math.floor(x);hi=math.ceil(x);return sorted_values[lo]+(sorted_values[hi]-sorted_values[lo])*(x-lo)
def compare(rows,pairs,draws,seed):
 measured=[r for r in rows if r.get('pair',-1)>=0];result={'status':'INCOMPLETE_OR_FAILED_NO_PAIR_EXCLUSIONS','pairs_attempted':len(set(r['pair'] for r in measured)),'measured_rows':len(measured),'all_attempted_rows_retained':True}
 if len(measured)!=pairs*2 or any(not r['valid'] for r in measured):return result
 grouped={}
 for r in measured:
  key=(r['pair'],r['role'])
  if key in grouped:return result
  grouped[key]=r
 if set(grouped)!={(p,role) for p in range(pairs) for role in ('baseline','candidate')}:return result
 signatures={tuple(x['nodes'] for x in r['bench_rows']) for r in measured}
 if len(signatures)!=1:result['status']='DIFFERENT_LOGICAL_WORK_NO_NPS_ACCEPTANCE';return result
 logs=[math.log(grouped[p,'candidate']['wall_nps']/grouped[p,'baseline']['wall_nps']) for p in range(pairs)]
 rng=random.Random(seed);boot=sorted(math.exp(sum(logs[rng.randrange(pairs)] for _ in range(pairs))/pairs) for _ in range(draws));point=math.exp(statistics.mean(logs));ci=[percentile(boot,.025),percentile(boot,.975)]
 result.update(status='NPS_GATE_PASS_NOT_ELO' if point>=.95 and ci[0]>=.95 else 'NPS_UNRESOLVED_OR_OVER5PCT_NOT_ELO',pairs=pairs,ratio_geometric_mean=point,ci95_ratio=ci,paired_ratios=[math.exp(x) for x in logs],draws=draws,bootstrap_seed=seed,primary_metric='totalnodes/actualwallseconds includingprocessstartup,8benchrepetitions amortizeoverhead',original_gate='geomean>=.95 ANDpairedbootstrap95%lower>=.95',logical_node_signature=list(next(iter(signatures))))
 return result
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--baseline',required=True,type=pathlib.Path);p.add_argument('--candidate',required=True,type=pathlib.Path);p.add_argument('--candidate-sha256',required=True);p.add_argument('--out',required=True,type=pathlib.Path);p.add_argument('--affinity-mask',type=lambda s:int(s,0));p.add_argument('--timeout',type=float,default=120);a=p.parse_args()
 if os.name!='nt':p.error('Run this comparison on nativeWindows; no Wine or Linuxperformanceclaim')
 if not re.fullmatch('[0-9a-f]{64}',a.candidate_sha256) or a.timeout<=0 or (a.affinity_mask is not None and a.affinity_mask<=0):p.error('ExpectedcandidateSHA256,positive timeout and optionalpositivemask')
 binaries={'baseline':a.baseline.resolve(strict=True),'candidate':a.candidate.resolve(strict=True)};expected={'baseline':BASELINE_SHA256,'candidate':a.candidate_sha256}
 if binaries['baseline']==binaries['candidate']:p.error('Distinctbaseline/candidatepathsrequired')
 for role,exe in binaries.items():
  if exe.read_bytes()[:2]!=b'MZ' or sha(exe)!=expected[role]:p.error(role+' is notexactexpectedWindowsPE/hash')
 a.out.mkdir(parents=True,exist_ok=False);seed=2026102308;sequence=orders(20,seed);payload=('uci\nsetoption name Threads value 1\nsetoption name Hash value 16\nsetoption name OwnBook value false\nsetoption name Ponder value false\nsetoption name Move Overhead value 100\nisready\n'+('bench 11\n'*8)+'quit\n').encode('ascii')
 protocol={'status':'FROZEN_BEFORE_ANY_ENGINE_LAUNCH','utc':utc(),'pairs':20,'warmups_per_engine':2,'bench_repetitions_per_process':8,'depth':11,'hash_mib':16,'threads':1,'OwnBook':False,'Ponder':False,'MoveOverhead':100,'seed':seed,'bootstrap_draws':10000,'bootstrap_seed':2026102310,'primary_metric':'sumallbenchnodes/wallseconds; processstartupincluded','acceptance':'geomeanratio>=.95 ANDpairedbootstrap95%lower>=.95; all20validpairs andidenticallogicalworkrequired; noexclusions/retries','order':sequence,'affinity_mask':a.affinity_mask,'affinity_policy':'Unchangedifomitted; explicitmaskonlyonsinglegroupWindows, rejectmultiplegroupsratherthanguess','binaries':{role:{'path':str(exe),'sha256':expected[role]} for role,exe in binaries.items()},'helper_sha256':sha(__file__),'platform':platform.platform(),'python':sys.version,'processor':platform.processor(),'logical_cpus':os.cpu_count(),'stdin_sha256':hashlib.sha256(payload).hexdigest(),'purpose':'EXPERIMENTAL-NPS-UNRESOLVED8bucketshippedduplicatedheads physicalPCcomparison,NOTlearnedepoch7; no games/Elo; closeotherCPUheavywork'}
 write(a.out/'PROTOCOL.json',protocol);rows=[];failure=None
 try:
  schedule=[(-2,('baseline','candidate')),(-1,('candidate','baseline'))]+list(enumerate(sequence))
  for pair,order in schedule:
   for ordinal,role in enumerate(order):
    if any(sha(exe)!=expected[k] for k,exe in binaries.items()):raise ValueError('Frozenbinarychanged; nofurtherlaunch')
    stem=('warmup'+str(pair+2) if pair<0 else 'pair%02d'%pair)+'-'+str(ordinal)+'-'+role
    row=run_process([str(binaries[role])],payload,a.out/stem,11,8,a.timeout,a.affinity_mask);row.update(pair=pair,role=role,order=ordinal);rows.append(row)
    with (a.out/'rows.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(row,allow_nan=False)+'\n');f.flush();os.fsync(f.fileno())
    print(json.dumps({'pair':pair,'role':role,'valid':row['valid'],'wall_nps':row.get('wall_nps')}),flush=True)
    if not row['valid']:raise ValueError('Failedactualrunretained; stopwithoutretryorpairreplacement')
 except BaseException as error:failure=repr(error)
 result=compare(rows,20,10000,2026102310);result.update(closed_utc=utc(),failure=failure,all_rows=rows,protocol_sha256=sha(a.out/'PROTOCOL.json'),playing_strength='unproven; nomatches/noElo',baseline_sha256=expected['baseline'],candidate_sha256=expected['candidate'],helper_sha256=sha(__file__))
 write(a.out/'RESULT.json',result);write(a.out/'SHA256SUMS.json',{x.name:{'sha256':sha(x),'bytes':x.stat().st_size} for x in sorted(a.out.iterdir()) if x.is_file()});print(json.dumps({k:v for k,v in result.items() if k!='all_rows'},indent=2));return 0 if failure is None and result['status']=='NPS_GATE_PASS_NOT_ELO' else 2
if __name__=='__main__':raise SystemExit(main())
