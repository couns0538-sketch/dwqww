#!/usr/bin/env python3
"""Close audit evidence only after the verifier's own process has exited."""
import pathlib,json,hashlib,datetime
H=pathlib.Path('/workspace/forge-buckets8-20261023');A=H/'windows-audit';O=H/'windows';B=pathlib.Path('/workspace/.cloud-setup/forge-buckets8-windows-20261023/build')
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def rec(p):p=pathlib.Path(p);return {'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size,'mtime_ns':p.stat().st_mtime_ns,'mode':oct(p.stat().st_mode&0o777)}
def load(p):return json.loads(pathlib.Path(p).read_text())
r=load(A/'verification-exec/result.json');assert r['actual_exit']==0 and r['status']=='COMPLETED'
for s in ('stdout','stderr'):assert sha(A/'verification-exec'/s)==r[s+'_sha256'] and (A/'verification-exec'/s).stat().st_size==r[s+'_bytes']
old=load(H/'WINDOWS-CLOSED-PROOF.json');changed=[p for p,v in old['files'].items() if sha(p)!=v['sha256']]
assert changed==[str(A/'verification-exec/stdout')],changed
original=load(H/'WINDOWS-ACTUAL-VALIDATION.json');assert not original['failures'] and all(c['pass'] for c in original['all_checks'].values())
for artifact in original['delivered_artifacts'].values():assert sha(artifact['path'])==artifact['sha256']
for p,v in load(O/'SOURCE-PINS.json')['files'].items():assert sha(p)==v['sha256']
files={p:rec(p) for p in old['files']}
for p in sorted(A.rglob('*')):
 if p.is_file():files[str(p)]=rec(p)
files[str(H/'verify_windows_actual.py')]=rec(H/'verify_windows_actual.py');files[str(H/'close_windows_audit.py')]=rec(H/'close_windows_audit.py')
proof={'status':'CLOSED_AFTER_ACTUAL_VERIFIER_EXIT_ZERO_ALL_STREAM_HASHES_CURRENT','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'first_proof_preserved':rec(H/'WINDOWS-CLOSED-PROOF.json'),'first_proof_limitation':'Originalauditorincludeditsownstdoutbeforeprintingfinalsummary; its0byteprefixwasnotclosed. Preservev1andreplaceclosedclaimwiththispost-exitreadback. Onlychangedearliermemberistheexpectedownstdout; allactualWindowsbuild/test/toolstreamsunchanged.','earlier_snapshot_changed_paths':changed,'actual_verifier_exit_receipt':rec(A/'verification-exec/result.json'),'files':files}
with (H/'WINDOWS-CLOSED-PROOF-v2.json').open('x') as f:json.dump(proof,f,indent=2);f.write('\n')
v2=dict(original);v2['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();v2['closed_proof']=rec(H/'WINDOWS-CLOSED-PROOF-v2.json');v2['post_exit_verification_actual_exit']=0;v2['previous_result_preserved']=rec(H/'WINDOWS-ACTUAL-VALIDATION.json');v2['self_closure_correction']='Usev2closedproof: originalverifierincludeditsownstdoutbeforeexit; post-exitreadbackverifiedoriginalactualexit0/streamhashes, all47checks andallartifact/sourcehashesunchanged. Firstattemptretained.';v2['closure_helper']=rec(__file__)
with (H/'WINDOWS-ACTUAL-VALIDATION-v2.json').open('x') as f:json.dump(v2,f,indent=2,allow_nan=False);f.write('\n')
print(json.dumps({'status':v2['status'],'checks':len(v2['all_checks']),'failures':v2['failures'],'engine_sha256':v2['delivered_artifacts']['forge.exe']['sha256'],'result_v2_sha256':sha(H/'WINDOWS-ACTUAL-VALIDATION-v2.json'),'closed_v2_sha256':sha(H/'WINDOWS-CLOSED-PROOF-v2.json'),'original_verifier_actual_exit':0}))
