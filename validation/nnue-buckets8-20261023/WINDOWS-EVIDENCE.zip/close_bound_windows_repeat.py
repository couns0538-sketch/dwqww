#!/usr/bin/env python3
"""Close fresh Windows provenance repeat after both actual processes exit."""
import pathlib,json,hashlib,datetime,re
H=pathlib.Path('/workspace/forge-buckets8-20261023');O=H/'windows';D=O/'bound-repeat';B=pathlib.Path('/workspace/.cloud-setup/forge-buckets8-windows-20261023/build');S=H/'source'
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(pathlib.Path(p).read_text())
def rec(p):p=pathlib.Path(p);return {'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size,'mode':oct(p.stat().st_mode&0o777),'mtime_ns':p.stat().st_mtime_ns}
before=load(D/'BEFORE.json');spec=load(D/'commands.json');after={p:rec(p) for p in before['files']};changed=[p for p,r in before['files'].items() if any(after[p][k]!=r[k] for k in ('sha256','bytes','mode','mtime_ns'))];checks={};failures=[]
def check(name,v,detail=None):
 checks[name]={'pass':bool(v),'detail':detail}
 if not v:failures.append(name)
check('all119actualbinary_core_source_toolbindings_unchanged',not changed,{'files':len(after),'changed':changed})
receipts={}
for c in spec['commands']:
 p=D/'steps'/c['name'];r=load(p/'result.json');receipts[c['name']]=r;valid=r['actual_exit']==0 and r['status']=='COMPLETED' and r['argv']==c['argv'] and r['spec_sha256']==sha(D/'commands.json') and r['env_overrides']=={'PYTHONDONTWRITEBYTECODE':'1',**c['environment']}
 for s in ('stdout','stderr'):valid=valid and sha(p/s)==r[s+'_sha256'] and (p/s).stat().st_size==r[s+'_bytes']
 check(c['name']+'_actual_exit_and_streams',valid,{'result':rec(p/'result.json'),'actual_exit':r['actual_exit']})
par=load(O/'parity-bound/RESULT.json');check('fresh_actual_Windows_10000_exact_all8_and_reference',par['status']=='PASS' and par['positions']==10000 and par['exact_integer_matches']==10000 and par['maximum_integer_cp_error']==0 and par['feature_mismatch_count']==0 and par['reference_shipped_records_equal'] is True and len(par['bucket_positions'])==8 and all(par['bucket_positions'].values()) and len(par['bucket_turn_positions'])==16 and all(par['bucket_turn_positions'].values()),{'result':rec(O/'parity-bound/RESULT.json'),'positions':par['positions'],'exact_integer_matches':par['exact_integer_matches'],'maximum_integer_cp_error':par['maximum_integer_cp_error'],'feature_mismatch_count':par['feature_mismatch_count'],'all8_bothturns':par['bucket_turn_positions'],'reference_shipped_records_equal':par['reference_shipped_records_equal']})
check('all_parityfrozen_inputs_match_before_and_after',all(p in before['files'] and before['files'][p]['sha256']==v==after[p]['sha256'] for p,v in par['frozen_inputs_sha256'].items()))
rows=re.findall(r'^info string bench depth 11 nodes (\d+) time (\d+) nps (\d+)\s*$',(D/'steps/bench-bound/stdout').read_text(),re.M);check('one_fresh_bench11_same_Windows334752_signature',len(rows)==1 and int(rows[0][0])==334752,{'actual_rows':[list(map(int,r)) for r in rows],'scope':'Logicalworkandbinaryprovenanceonly,notNPSmeasurementoracceptance'})
start=datetime.datetime.fromisoformat(receipts['windows-parity-bound10000']['started_utc']);pre=datetime.datetime.fromisoformat(before['utc']);finish=datetime.datetime.fromisoformat(receipts['bench-bound']['closed_utc']);now=datetime.datetime.now(datetime.timezone.utc);check('real_before_and_after_temporally_enclose_both_runs',pre<start<finish<now,{'before_utc':before['utc'],'parity_actual_start':start.isoformat(),'bench_actual_closed':finish.isoformat(),'after_utc':now.isoformat()})
result={'status':'PASS_FRESH_HASH_BOUND_WINDOWS_PARITY10000_AND_ONE_BENCH_NOT_SPEED_OR_ELO' if not failures else 'FAIL_FRESH_BOUND_WINDOWS_REPLAY','closed_utc':now.isoformat(),'source_commit':before['source_commit'],'before':rec(D/'BEFORE.json'),'after_files':after,'checks':checks,'failures':failures,'exact_source_files_compared_to_git':len(before['git_source_files_sha256']),'actual_underlying_PE_before_after':{name:{'before':before['files'][str(B/name)],'after':after[str(B/name)]} for name in ('forge.exe','forge_nnue_probe.exe','libforge_core.a')},'actual_step_receipts':{k:rec(D/'steps'/k/'result.json') for k in receipts},'earlier_runs_preserved':True,'old_missing_pre_run_PE_hash_reconstructed':False,'old_gap_resolution':'ThisnewrunexplicitlypinsactualunderlyingPEs/core/source/toolsbeforeandafter. Historicalrunsretaintheiroriginalmissingbeforehashlimitation.','scope':'Winefunctional/provenanceonly; duplicatedshippedheadsNOTtrainedepoch7; NPSacceptanceunproven; noElo','closure_helper':rec(__file__)}
for p in (D/'RESULT.json',H/'WINDOWS-BOUND-REPEAT-VALIDATION.json'):
 with p.open('x') as f:json.dump(result,f,indent=2,allow_nan=False);f.write('\n')
print(json.dumps({'status':result['status'],'failures':failures,'result_sha256':sha(D/'RESULT.json'),'root_receipt_sha256':sha(H/'WINDOWS-BOUND-REPEAT-VALIDATION.json'),'engine_sha256':sha(B/'forge.exe')}));raise SystemExit(0 if not failures else 1)
