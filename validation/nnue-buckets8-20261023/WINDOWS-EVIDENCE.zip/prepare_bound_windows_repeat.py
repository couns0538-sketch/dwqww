#!/usr/bin/env python3
"""Freeze existing Windows PE/core/source before one targeted provenance replay."""
import pathlib,json,hashlib,subprocess,datetime
H=pathlib.Path('/workspace/forge-buckets8-20261023');O=H/'windows';D=O/'bound-repeat';S=H/'source';B=pathlib.Path('/workspace/.cloud-setup/forge-buckets8-windows-20261023/build');R=pathlib.Path('/workspace/dwqww');COMMIT='a1fcc36acbacc5f78a17ecfd5377068d738f9191'
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def rec(p):p=pathlib.Path(p);return {'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size,'mode':oct(p.stat().st_mode&0o777),'mtime_ns':p.stat().st_mtime_ns}
spec=json.loads((H/'windows-research-commands-v2.json').read_text());D.mkdir(exist_ok=False);commands=[]
for oldname,newname in [('windows-bucket-parity10000','windows-parity-bound10000'),('bench-first','bench-bound')]:
 c=json.loads(json.dumps(next(c for c in spec['commands'] if c['name']==oldname)));c['name']=newname
 if oldname=='windows-bucket-parity10000':c['argv'][c['argv'].index('--out')+1]=str(O/'parity-bound')
 commands.append(c)
plan={'status':'FRESH_TARGETED_PROVENANCE_REPLAY_NOT_SPEED_TRIAL','source_commit':COMMIT,'commands':commands};(D/'commands.json').write_text(json.dumps(plan,indent=2)+'\n')
paths={str(p) for p in S.rglob('*') if p.is_file() and not p.name.endswith('.pyc')}
for r in [*spec['tools_sha_size_verified'].values(),*spec['extra_tools'].values(),*spec['support_files'].values()]:paths.add(r['path'])
paths.update(str(p) for p in [B/'forge.exe',B/'forge_nnue_probe.exe',B/'libforge_core.a',B/'CMakeFiles/forge_core.dir/src/nnue.cpp.obj',B/'compile_commands.json',B/'CMakeCache.txt',O/'forge-wine',O/'forge-probe-wine',D/'commands.json',H/'WINDOWS-ACTUAL-VALIDATION-v2.json',R/'releases/forge-6.4.24-candidate-windows-zen5/forge-6.4.24-ryzen-9850x3d.exe'])
source_git={}
for p in sorted(S.rglob('*')):
 if not p.is_file() or p.name.endswith('.pyc'):continue
 name=p.relative_to(S).as_posix();data=subprocess.check_output(['git','show',COMMIT+':'+name],cwd=R);expected=hashlib.sha256(data).hexdigest();assert sha(p)==expected,name;source_git[name]=expected
before={'status':'FROZEN_BEFORE_FRESH_PARITY_AND_BENCH','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_commit':COMMIT,'git_source_files_sha256':source_git,'files':{p:rec(p) for p in sorted(paths)},'old_missing_pre_run_PE_hash_not_reconstructed':True,'purpose':'Bindactualunderlyingforge.exe/probe.exe/core/source/toolsbeforeandafterfresh10kWineparity+onebench; noNPSclaim'}
(D/'BEFORE.json').write_text(json.dumps(before,indent=2)+'\n');print(json.dumps({'status':before['status'],'files':len(paths),'source_files_compared_to_commit':len(source_git),'before_sha256':sha(D/'BEFORE.json'),'spec_sha256':sha(D/'commands.json')}))
