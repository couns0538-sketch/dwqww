#!/usr/bin/env python3
"""Read-only verification of closed Windows research build/evidence."""
import pathlib,json,hashlib,re,shlex,datetime,importlib.util,os
H=pathlib.Path('/workspace/forge-buckets8-20261023');O=H/'windows';A=H/'windows-audit';B=pathlib.Path('/workspace/.cloud-setup/forge-buckets8-windows-20261023/build');S=H/'source';R=pathlib.Path('/workspace/dwqww');SPEC=H/'windows-research-commands-v2.json'
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(pathlib.Path(p).read_text())
def ident(p):
 p=pathlib.Path(p);return {'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size,'mtime_ns':p.stat().st_mtime_ns,'mode':oct(p.stat().st_mode&0o777)}
checks={};failures=[]
def check(name,test,detail=None):
 checks[name]={'pass':bool(test),'detail':detail}
 if not test:failures.append(name)
spec=load(SPEC);check('root_execution_spec_pinned',sha(SPEC)=='fcc5e45a0e250276dcf312eb3ab1cbb12fdb6ece88e5a9a05f8ab86f3aeebde2')
receipts={}
def check_steps(plan,path):
 for c in plan['commands']:
  d=path/c['name'];r=load(d/'result.json');q=load(d/'command.json');ok=r['actual_exit']==0 and r['status']=='COMPLETED' and r['spec_sha256']==sha(SPEC if path==O/'steps' else A/'commands.json') and r['argv']==c['argv'] and r['step']==c['name'] and r['cwd']=='/workspace/dwqww' and q['pid']==r['pid'] and q['argv']==r['argv']
  expected={'PYTHONDONTWRITEBYTECODE':'1',**c.get('environment',{})};ok=ok and r['env_overrides']==expected
  for stream in ('stdout','stderr'):ok=ok and sha(d/stream)==r[stream+'_sha256'] and (d/stream).stat().st_size==r[stream+'_bytes']
  check(('root_' if path==O/'steps' else 'audit_')+c['name'],ok,{'receipt':ident(d/'result.json'),'actual_exit':r['actual_exit']});receipts[str(d)]=r
check_steps(spec,O/'steps');check_steps(load(A/'commands.json'),A/'steps')
cpp=[c['name'] for c in spec['commands'] if c['name'].startswith('test-') and c['argv'][0].endswith('/wine64')];python=[c['name'] for c in spec['commands'] if c['name'].startswith('test-') and not c['argv'][0].endswith('/wine64')]
check('all15_original_tests',len(cpp)==10 and len(python)==5 and 'test-nnue-buckets' in cpp,{'Wine_CPP':cpp,'host_Python':python})
pins=load(O/'SOURCE-PINS.json')['files'];source_names={str(p) for p in S.rglob('*') if p.is_file() and not p.name.endswith('.pyc')};changed=[p for p,r in pins.items() if sha(p)!=r['sha256'] or oct(pathlib.Path(p).stat().st_mode&0o777)!=r['mode']]
check('every_frozen_source_hash_mode_and_file_set',not changed and source_names==set(pins),{'files':len(pins),'changed':changed})
check('all_tool_pins',all(sha(r['path'])==r['sha256'] for r in [*spec['tools_sha_size_verified'].values(),*spec['extra_tools'].values()]))
check('prepared_wrappers_adapter_and_sourcepins_unchanged',all(sha(r['path'])==r['sha256'] for r in spec['support_files'].values()))
compile_rows=load(B/'compile_commands.json');required={'-march=znver5','-mtune=znver5','-fno-fast-math','-ffp-contract=off','-fno-lto','-O3','-DNDEBUG','-std=gnu++20'};bad=[]
for row in compile_rows:
 tokens=shlex.split(row['command']);forbidden=[x for x in tokens if x in ('-march=native','-ffast-math','-Ofast','-ffp-contract=fast','-ffp-contract=on','-mfma') or x.startswith('-flto')]
 if not required<=set(tokens) or forbidden or not pathlib.Path(row['file']).is_relative_to(S):bad.append({'file':row['file'],'missing':sorted(required-set(tokens)),'forbidden':forbidden})
check('all_compile_commands_strict_Zen5_CXX20_Release',bool(compile_rows) and not bad,{'translation_units':len(compile_rows),'bad':bad,'compile_commands':ident(B/'compile_commands.json')})
links={};badlinks=[]
for p in sorted((B/'CMakeFiles').glob('*.dir/link.txt')):
 lines=p.read_text().splitlines();last=lines[-1];tokens=shlex.split(last)
 if any(t.endswith('.exe') for t in tokens):
  links[str(p)]=ident(p)
  if not {'-static','-fno-lto','-ffp-contract=off','-fno-fast-math','-march=znver5','-mtune=znver5'}<=set(tokens) or any(x.startswith('-flto') for x in tokens):badlinks.append(str(p))
check('all_executable_links_static_strict_no_LTO',len(links)>=13 and not badlinks,{'executables':len(links),'bad':badlinks})
for target in ('forge','forge_nnue_probe'):
 linklibs=B/('CMakeFiles/'+target+'.dir/linkLibs.rsp');check(target+'_actual_link_binds_actual_core','libforge_core.a' in linklibs.read_text().split(),ident(linklibs))
obj=B/'CMakeFiles/forge_core.dir/src/nnue.cpp.obj';coremember=A/'steps/core-nnue-member/stdout';check('actual_core_nnue_member_equals_actual_compiled_object',sha(obj)==sha(coremember),{'object':ident(obj),'member':ident(coremember),'core':ident(B/'libforge_core.a')})
allowed={'kernel32.dll','advapi32.dll','user32.dll','shell32.dll','ws2_32.dll','ntdll.dll','msvcrt.dll','ucrtbase.dll','bcrypt.dll','ole32.dll'};pe={}
for role,p in [('engine',O/'steps/pe-imports/stdout'),('probe',A/'steps/probe-pe-imports/stdout')]:
 text=p.read_text();imports=re.findall(r'^\s*Name: (\S+\.dll)\s*$',text,re.M|re.I);unknown=[i for i in imports if i.lower() not in allowed and not i.lower().startswith('api-ms-win-')]
 check(role+'_AMD64_PE_allowlisted_system_imports','Machine: IMAGE_FILE_MACHINE_AMD64 (0x8664)' in text and bool(imports) and not unknown,{'imports':imports,'unknown':unknown,'raw':ident(p)});pe[role]=imports
objasm=(A/'steps/nnue-coff-disassembly/stdout').read_text();match=re.search(r'^[0-9a-fA-F]+ <forge::nnue::evaluate\([^\n]*>:\n(.*?)(?=\n[0-9a-fA-F]+ <|\Z)',objasm,re.M|re.S);body=match.group(1) if match else '';vector={op:bool(re.search(r'\b'+op+r'\b[^\n]*%ymm',body)) for op in ('vminps','vmaxps','vmulps','vaddps')};fma=re.findall(r'\b(?:vfmadd|vfmsub|vfnmadd|vfnmsub)\w*\b',body)
check('anchored_actual_COFF_evaluate_AVX2_no_fused_arithmetic',bool(match) and all(vector.values()) and not fma,{'vector256':vector,'fused_mnemonics':fma,'existing_checker_stdout':(A/'steps/nnue-existing-simd-check/stdout').read_text(),'scope':'ActualcompiledCOFFNNUEevaluatebody; rawwholeobjectdisassemblyretained'})
with (A/'evaluate-symbol.txt').open('x') as f:f.write(match.group(0) if match else 'NO_SYMBOL')
full=(O/'steps/strict-no-fma-disassembly/stdout').read_text();mnemonics=re.findall(r'^\s*[0-9a-fA-F]+:\s*([a-z][a-z0-9.]*)\b',full,re.M);fullfma=sorted(set(x for x in mnemonics if re.match(r'v(?:fmadd|fmsub|fnmadd|fnmsub)',x)))
check('full_static_PE_instruction_inventory_no_FMA',bool(mnemonics) and not fullfma,{'instructions_parsed':len(mnemonics),'fused_mnemonics':fullfma,'scope':'Allinstructionsincompletedllvm-objdump-dPEtextdump,notimportedDLLruntimeorundisassembleddata','raw':ident(O/'steps/strict-no-fma-disassembly/stdout')})
bench={}
for name in ('bench-first','bench-repeat'):
 text=(O/'steps'/name/'stdout').read_text();rows=re.findall(r'^info string bench depth 11 nodes (\d+) time (\d+) nps (\d+)\s*$',text,re.M);bench[name]=[list(map(int,r)) for r in rows]
oldprov=R/'releases/forge-6.4.24-candidate-windows-zen5/provenance.json';old=load(oldprov)['bench11_nodes'];check('same_platform_shipped_Windows_signature_repeats',old==334752 and all(len(x)==1 and x[0][0]==old for x in bench.values()),{'actual':bench,'accepted_Windows_nodes':old,'accepted_Windows_provenance':ident(oldprov),'Linux_shipped_nodes':292545,'scope':'Samenodeslogicalworkonly; WineNPSisnotnativeRyzenperformance'})
par=load(O/'parity-shipped10000/RESULT.json');changed_inputs=[p for p,v in par['frozen_inputs_sha256'].items() if sha(p)!=v];check('parity_10000_all8_bothturns_exact_features_reference',par['status']=='PASS' and par['positions']==10000 and par['exact_integer_matches']==10000 and par['maximum_integer_cp_error']==0 and par['feature_mismatch_count']==0 and par['reference_shipped_records_equal'] is True and len(par['bucket_positions'])==8 and all(par['bucket_positions'].values()) and len(par['bucket_turn_positions'])==16 and all(par['bucket_turn_positions'].values()) and not changed_inputs and par['weights_sha256']==sha(S/'src/nnue_weights.inc'),{'positions':par['positions'],'exact_integer_matches':par['exact_integer_matches'],'maximum_integer_cp_error':par['maximum_integer_cp_error'],'feature_mismatch_count':par['feature_mismatch_count'],'bucket_positions':par['bucket_positions'],'bucket_turn_positions':par['bucket_turn_positions'],'reference_shipped_records_equal':par['reference_shipped_records_equal'],'changed_inputs':changed_inputs,'result':ident(O/'parity-shipped10000/RESULT.json')})
ps=importlib.util.spec_from_file_location('readonly_bucket_parser',S/'tools/nnue/include_parser.py');parser=importlib.util.module_from_spec(ps);ps.loader.exec_module(parser);new=parser.load_include(S/'src/nnue_weights.inc',expected_hidden=128);oldweights=parser.load_include(R/'src/nnue_weights.inc',expected_hidden=128)
import numpy as np
same=np.array_equal(new['w1'],oldweights['w1']) and np.array_equal(new['b1'],oldweights['b1']) and new['output_buckets']==8 and oldweights['output_buckets']==1 and all(np.array_equal(new['bucket_w2'][i],oldweights['bucket_w2'][0]) and new['bucket_b2'][i]==oldweights['bucket_b2'][0] for i in range(8))
check('all8_heads_and_shared_layer_exactly_shipped_not_learned',same,{'eighthead_include':ident(S/'src/nnue_weights.inc'),'shipped_singlehead_include':ident(R/'src/nnue_weights.inc'),'parser':ident(S/'tools/nnue/include_parser.py'),'no_neural_model_execution':'Onlystaticincludeparser/numpyparametercomparisons; no optimizer/modelsearch/training'})
check('underlying_probe_exe_mtime_precedes_actual_parity', (B/'forge_nnue_probe.exe').stat().st_mtime < datetime.datetime.fromisoformat(receipts[str(O/'steps/windows-bucket-parity10000')]['started_utc']).timestamp(),{'limitations':'OriginalparitytoolpinswrapperSHA,notunderlyingPEbeforelaunch. ThisauditaddsactualcurrentPE/corehash,unchangedwrappertarget,actualfreshbuild/link/dependencyrecords,andPEmtimebeforeparity. Doesnotinventmissingpre-runPEhash.'})
proof_files=[*sorted(p for p in O.rglob('*') if p.is_file()),*sorted(p for p in A.rglob('*') if p.is_file()),B/'compile_commands.json',B/'CMakeCache.txt',B/'CMakeFiles/forge_core.dir/src/nnue.cpp.obj.d',B/'CMakeFiles/forge_nnue_probe.dir/tools/nnue/engine_probe.cpp.obj.d',*map(pathlib.Path,links)]
manifest={'status':'CLOSED_ALL_ROOT_AND_READONLY_AUDIT_STREAM_HASHES_BOUND','files':{str(p):ident(p) for p in proof_files}}
with (H/'WINDOWS-CLOSED-PROOF.json').open('x') as f:json.dump(manifest,f,indent=2);f.write('\n')
result={'status':'PASS_WINDOWS_RESEARCH_WINE15_PARITY10000_AND_STRICT_CODE_CHECKS_NOT_NPS_ACCEPTED' if not failures else 'BLOCKED_WINDOWS_RESEARCH_VALIDATION','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_parent':'1ab50b2dd64d9b2f752f7f1285f6968cad2fd792','network':'Eightduplicatedshippedheads;NOTindependentteacherlearnedepoch7','actual_root_steps':len(spec['commands']),'actual_readonly_tool_steps':len(load(A/'commands.json')['commands']),'tests':15,'cpp_tests':10,'host_python_tests':5,'all_checks':checks,'failures':failures,'delivered_artifacts':{p.name:ident(p) for p in [B/'forge.exe',B/'forge_nnue_probe.exe',B/'libforge_core.a',obj]},'closed_proof':ident(H/'WINDOWS-CLOSED-PROOF.json'),'auditor_source':ident(__file__),'runtime':'Wine onLinux,notnativeWindows/Ryzen','performance_acceptance':'UNPROVEN: originalpairedNPSlower.933831<.95,20pairsretained','release_status':'EXPERIMENTAL-NPS-UNRESOLVED comparisonartifactonly; NOTaccepted<=5%release','playing_strength':'unproven; no games/Elo','bindings_limitations':['CurrentPE/core/probehashes+actualbuild/link/dependency/sourcepins+wrapper/parityproof retained; originalstandalonepre-parityPEhashwasnotcaptured. No historicalhashisfabricated.']}
with (H/'WINDOWS-ACTUAL-VALIDATION.json').open('x') as f:json.dump(result,f,indent=2,allow_nan=False);f.write('\n')
print(json.dumps({'status':result['status'],'checks':len(checks),'failures':failures,'engine_sha256':sha(B/'forge.exe'),'probe_sha256':sha(B/'forge_nnue_probe.exe'),'core_sha256':sha(B/'libforge_core.a'),'closed_proof_sha256':sha(H/'WINDOWS-CLOSED-PROOF.json'),'result_sha256':sha(H/'WINDOWS-ACTUAL-VALIDATION.json')}))
raise SystemExit(0 if not failures else 1)
