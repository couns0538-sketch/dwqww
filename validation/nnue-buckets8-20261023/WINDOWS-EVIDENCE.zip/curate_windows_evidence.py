"""Seal original closed Windows research evidence; never runs engines or scores."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,stat
H=Path('/workspace/forge-buckets8-20261023');rows=[]
def sha(p):
 d=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):d.update(b)
 return d.hexdigest()
def add(path,group,member=None):
 p=Path(path) if Path(path).is_absolute() else H/path
 assert p.is_file() and not p.is_symlink(),str(p)
 assert p.suffix not in ('.exe','.dll','.a','.lib','.o','.obj','.inc','.bin','.zip','.tar'),str(p)
 name=member or str(p.relative_to(H));assert name not in {r['member'] for r in rows}
 rows.append({'source':str(p),'member':name,'sha256':sha(p),'bytes':p.stat().st_size,'mode':stat.S_IMODE(p.stat().st_mode),'group':group})
closure=H/'WINDOWS-BOUND-REPEAT-VALIDATION.json';assert sha(closure)=='eae2f9c7471a8f2ad7a5118eff4737c6218dda2680115c941d8b2396491a0744'
result=json.loads(closure.read_bytes());assert result['status']=='PASS_FRESH_HASH_BOUND_WINDOWS_PARITY10000_AND_ONE_BENCH_NOT_SPEED_OR_ELO' and not result['failures'];assert len(result['after_files'])==119
assert (H/'windows/bound-repeat/RESULT.json').read_bytes()==closure.read_bytes()
# Authenticated original proof is metadata only; do not copy bound binaries/source.
for path,record in result['after_files'].items():
 p=Path(path);assert sha(p)==record['sha256'] and p.stat().st_size==record['bytes']
steps=[]
for group in ['windows/steps','windows-audit/steps','windows/bound-repeat/steps']:
 for directory in sorted((H/group).iterdir()):
  assert directory.is_dir() and not directory.is_symlink()
  r=json.loads((directory/'result.json').read_bytes());assert r['actual_exit']==0 and r['closed_utc']
  steps.append({'path':str(directory.relative_to(H)),'actual_exit':r['actual_exit'],'result_sha256':sha(directory/'result.json')})
  for name in ['command.json','result.json','stdout','stderr']:
   if name in ('stdout','stderr'):assert sha(directory/name)==r[name+'_sha256']
   add(directory/name,'actual_closed_original_Windows_Wine_and_tool_steps')
for group in ['windows-audit/verification-exec']:
 r=json.loads((H/group/'result.json').read_bytes());assert r['actual_exit']==0 and r['closed_utc']
 for name in ['command.json','result.json','stdout','stderr']:add(group+'/'+name,'actual_closed_readonly_auditor_invocation')
for group in ['windows/parity-shipped10000','windows/parity-bound']:
 for p in sorted((H/group).iterdir()):
  assert p.is_file() and not p.is_symlink();add(p,'original_Windows10000_parity_corpus_expectedCP_and_raw_streams')
for p in sorted((H/'windows/bound-repeat').iterdir()):
 if p.is_file():add(p,'fresh119identity_before_after_replay_and_protocol')
for p in sorted((H/'windows').iterdir()):
 if p.is_file():add(p,'original_windows_sourcepins_inert_adapters_and_transcripts')
for name in ['WINDOWS-ACTUAL-VALIDATION.json','WINDOWS-ACTUAL-VALIDATION-v2.json','WINDOWS-CLOSED-PROOF.json','WINDOWS-CLOSED-PROOF-v2.json','WINDOWS-BOUND-REPEAT-VALIDATION.json','WINDOWS-RESEARCH-BUILD-AUTHORITY.json','WINDOWS-RESEARCH-README.md','WINDOWS-BENCHMARK-HELPER-VALIDATION.json','windows-commands-original-02bc83d5d3a29f24.json','windows-commands.json','windows-research-commands.json','windows-research-commands-v2.json','windows-plan-original-98c02dab25401375.md','windows-plan.md','windows-research-plan.md','prepare_windows_support.py','test_windows_support.py','windows-support-validation.json','verify_windows_actual.py','close_windows_audit.py','prepare_bound_windows_repeat.py','close_bound_windows_repeat.py','benchmark_windows_comparison.py','test_windows_benchmark_helper.py','publish_windows_checkpoint.py','windows-loop.stdout','windows-loop.stderr','windows-audit/commands.json','windows-audit/verification-command.json','windows-audit/evaluate-symbol.txt','windows-audit/bin/objdump','CPU-TIME-DIAGNOSTIC.json','CPU-TIMING-270-FILE-INVENTORY.json','WINDOWS-EVIDENCE-PENDING.json']:
 add(name,'original_protocol_support_replay_helpers_drafts_historical_proofs_and_timing_diagnostic')
for stem in ['windows-support-red','windows-support-prepare','windows-support-green','windows-support-final','benchmark-helper-red','benchmark-helper-red02','benchmark-helper-green']:
 for ext in ['stdout','stderr']:add(stem+'.'+ext,'preserved_original_support_helper_RED_GREEN_and_setup_failure')
for p in sorted((H/'public-readback-a1fcc36/http-receipts').rglob('*.json')):add(p,'immutable_public_source19_file_SHA_HTTP_receipts_no_response_duplicates')
add('public-readback-a1fcc36/RESULT.json','immutable_public_source19_file_verification_result')
compile_commands=Path('/workspace/.cloud-setup/forge-buckets8-windows-20261023/build/compile_commands.json');add(compile_commands,'actual_windows_compiler_commands_no_objects',member='windows-build/compile_commands.json')
add('curate_windows_evidence.py','curation_source')
curation={'schema_version':1,'utc':datetime.now(timezone.utc).isoformat(),'status':'CLOSED_WINDOWS_RESEARCH_WINE_FUNCTIONAL_AND_FRESH_HASH_BOUND_REPLAY_NOT_SPEED_ACCEPTED','source_commit':'a1fcc36acbacc5f78a17ecfd5377068d738f9191','root_and_producer_explicit_closed_signal':True,'fresh_bound_receipt_sha256':sha(closure),'fresh_bound_count':119,'source_files_matched_exactGit':result['exact_source_files_compared_to_git'],'actual_closed_step_receipts':steps,'scope':'Original24Windowsrootsteps+5readonlytoolsteps+2freshboundrepeatsteps+post-exitauditor; allactualreceiptsincluded. Winefunctional/provenancevalidation only. Duplicatedshippedheads, no learnedmainnet.','historical_proof_limits':'Originalv1selfstdoutprefixclosureflaw andv2correction retained. Historicalinitialrunsmissingpre-runPEhash not reconstructed. NewBEFORE/AFTER119binds freshactual10000parity+onebench toexactPEs/core/source/tools; earlierproofs remainhistorical.','performance_gate':'UNPROVEN; CPU-timeposthocdiagnostic doesnot establishwallclock95percentacceptance. All270originaltimingfileSHAinventoryincluded; rawtimingsalreadyNATIVE-EVIDENCE,notduplicated.','native_Windows_hardware_run':False,'accepted_engine_or_elo_claim':False,'Windows_comparison_artifact_only':True,'excluded':['ALL PE/testbinaries/libraries/buildobjects','CopiedruntimeC++sourcetrees/Wineprefix','Other evidenceZIPduplicates includingNATIVE','Raw270timingfilesalreadydurableNATIVEcontainer','Publicresponsebodies includingcodeweights/archive duplicates','Mainindependentteacherlearnednet/data/SFpayloads','Publicationstagingfuturewriterdirectories'],'no_engine_tests_scoring_builds_matches_git_or_source_edits_executed_by_curator':True,'source_count_before_curation':len(rows),'raw_bytes_before_curation':sum(r['bytes'] for r in rows),'declarations':rows}
p=H/'WINDOWS-EVIDENCE-CURATION.json';assert not p.exists();p.write_text(json.dumps(curation,indent=2)+'\n');add(p,'final_curation_receipt')
for r in rows:assert sha(Path(r['source']))==r['sha256']
p=H/'WINDOWS-EVIDENCE-FILES.json';assert not p.exists();p.write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps({'declarations':str(p),'files':len(rows),'raw_bytes':sum(r['bytes'] for r in rows),'curation_sha256':sha(H/'WINDOWS-EVIDENCE-CURATION.json'),'actual_closed_steps':len(steps),'proof_status':result['status']}))
