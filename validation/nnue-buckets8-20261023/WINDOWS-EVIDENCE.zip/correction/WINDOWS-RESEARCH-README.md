# Experimental Windows comparison

This artifact adds eight piece-count output heads initialized as copies of the shipped Forge 6.4.24 network. It does not contain the new learned epoch7 network. It is a research candidate, not an accepted speed or playing-strength release.

The shared-host speed tests were inconclusive. The eight-repeat test retained all20pairs: NPS ratio1.1572340986388305,95%interval[0.9338312669679539,1.5062910530259082]. The original requirement (ratio and95%lower both>=0.95) remains unproven. Original scripts, protocols, every row and raw output remain indexed in TIMING-EVIDENCE-PRESERVATION.json. No rows were removed.

Run the optional comparison on your physical Windows Ryzen7 9850X3D while the PC is otherwise idle. Python3.10+ is sufficient; no packages or network access are needed. Keep the original baseline, experimental executable and all results. Use the exact baseline forge-6.4.24-ryzen-9850x3d.exe, SHA256 b58058055615e299ed49279929ee71fced5d505845d8049dabaeed57aa07269c. Use the candidate SHA256 from the package manifest, not an unrelated engine.

PowerShell example (replace the candidate hash string with the published64hex value):

```powershell
py -3 benchmark_windows_comparison.py --baseline .\forge-6.4.24-ryzen-9850x3d.exe --candidate .\forge-6.4.24-buckets8-EXPERIMENTAL-NPS-UNRESOLVED-windows-zen5.exe --candidate-sha256 'PASTE_64_HEX_FROM_PACKAGE_MANIFEST' --out .\nps-results-new
```

The helper freezes20counterbalancedpairs, seed2026102308, two warm-up processes per engine and eight depth11bench calls per process. Both use Threads1, Hash16MiB, OwnBook=false, Ponder=false and MoveOverhead100. Every attempt saves original stdin/stdout/stderr, actual exit, wall time and hashes. The primary metric sums ALLbench nodes over process wall time; aggregate internal engine NPS is also retained. Each of10,000bootstrap draws resamples complete pairs. A failed run stops without retries or pair replacement and remains incomplete. Different logical node signatures prevent acceptance. No timeout, crash or bad output is silently excluded.

Affinity remains unchanged unless you explicitly supply --affinity-mask (for example0x1). The helper rejects automatic affinity on machines with multiple Windows processor groups; it does not guess a group. Apply the same deliberate policy to both engines.

RESULT.json reports the physical-PC result and uncertainty. A successful performance result does not establish Elo, fix the inconclusive VM experiment retroactively or accept this network for play. Playing strength remains unproven; the independent userPC game gate is still required. NativeWindows execution of this helper has not been tested here; unit checks used fake subprocesses only.

Helper status and scope: every status explicitly says NOT_EXISTING_BENCH_NPS_GATE. A process-wall threshold result never accepts the existing internal bench-NPS gate. PROTOCOL.json and RESULT.json always set existing_bench_nps_gate_acceptance=false. The numerical threshold is unchanged; the primary metric differs. Raw engine_nps_aggregate values are retained for a separate analysis of the original bench-NPS metric. No such analysis or automatic acceptance is performed here.
