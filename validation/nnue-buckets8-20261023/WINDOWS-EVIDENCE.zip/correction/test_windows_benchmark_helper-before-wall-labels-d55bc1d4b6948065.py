import unittest,pathlib,importlib.util,tempfile,sys,json,hashlib
H=pathlib.Path('/workspace/forge-buckets8-20261023')
class Exists(unittest.TestCase):
 def test_helper_exists(self):self.assertTrue((H/'benchmark_windows_comparison.py').is_file(),'portable benchmark helper not implemented')
class Helper(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  p=H/'benchmark_windows_comparison.py';assert p.is_file(),'portable benchmark helper not implemented'
  s=importlib.util.spec_from_file_location('benchmark_helper',p);cls.m=importlib.util.module_from_spec(s);s.loader.exec_module(cls.m)
 def test_parser_retains_every_bench_line_and_rejects_short_stream(self):
  raw=b'uciok\r\ninfo string bench depth 11 nodes 100 time 20 nps 5000\r\ninfo string bench depth 11 nodes 100 time 30 nps 3333\r\n'
  a=self.m.parse_benches(raw,11,2);self.assertEqual(len(a),2);self.assertEqual(sum(r['nodes'] for r in a),200)
  with self.assertRaises(ValueError):self.m.parse_benches(raw,11,3)
 def test_counterbalanced_schedule_and_all20paired_bootstrap(self):
  a=self.m.orders(20,2026102308);self.assertEqual(a.count(('baseline','candidate')),10);self.assertEqual(a.count(('candidate','baseline')),10)
  rows=[]
  for pair in range(20):
   for role,nps in [('baseline',100),('candidate',97)]:rows.append({'pair':pair,'role':role,'valid':True,'wall_nps':nps,'bench_rows':[{'nodes':100}]})
  r=self.m.compare(rows,20,1000,42);self.assertEqual(r['status'],'NPS_GATE_PASS_NOT_ELO');self.assertAlmostEqual(r['ratio_geometric_mean'],.97);self.assertEqual(r['pairs'],20)
  rows[-1]['valid']=False;self.assertEqual(self.m.compare(rows,20,1000,42)['status'],'INCOMPLETE_OR_FAILED_NO_PAIR_EXCLUSIONS')
 def test_fake_process_keeps_raw_outputs_and_actual_exit(self):
  with tempfile.TemporaryDirectory(prefix='forge-fake-bench-') as d:
   p=pathlib.Path(d);f=p/'fake.py';f.write_text('import sys\nraw=sys.stdin.read()\nprint("info string bench depth 11 nodes 100 time 20 nps 5000")\nprint("info string bench depth 11 nodes 100 time 30 nps 3333")\nprint("FAKE_ONLY",file=sys.stderr)\nsys.exit(7)\n')
   r=self.m.run_process([sys.executable,str(f)],b'bench 11\nbench 11\nquit\n',p/'fake-attempt',11,2,10,None)
   self.assertEqual(r['actual_exit'],7);self.assertFalse(r['valid']);self.assertEqual(len(r['bench_rows']),2);self.assertEqual(r['total_nodes'],200)
   self.assertEqual(r['stdout_sha256'],hashlib.sha256((p/'fake-attempt.stdout').read_bytes()).hexdigest());self.assertIn('FAKE_ONLY',(p/'fake-attempt.stderr').read_text())
if __name__=='__main__':unittest.main(verbosity=2)
