"""Copy every immutable v1 ZIP member, then append explicitly closed corrections."""
import argparse,copy,hashlib,json,os,stat,zipfile
from pathlib import Path
from datetime import datetime,timezone

def digest(p):
 d=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):d.update(b)
 return d.hexdigest()
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--files',type=Path,required=True);a=ap.parse_args()
 h=Path('/workspace/forge-buckets8-20261023');old=h/'WINDOWS-EVIDENCE.zip';out=h/'WINDOWS-EVIDENCE-v2.zip';old_sha='1fdd764fabca36171c2011bb8ac0e030f63766f68feca5b3eb294d2388a97026'
 assert digest(old)==old_sha and not out.exists()
 declarations=json.loads(a.files.read_bytes());new={}
 for r in declarations:
  p=Path(r['source']);name=r['member'];assert p.is_file() and not p.is_symlink();assert name.startswith('correction/') and '..' not in Path(name).parts
  assert name not in new and digest(p)==r['sha256'] and p.stat().st_size==r['bytes'];new[name]={**r,'mode':stat.S_IMODE(p.stat().st_mode)}
 previous={};temp=out.with_suffix('.zip.tmp');assert not temp.exists()
 with zipfile.ZipFile(old) as src,zipfile.ZipFile(temp,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as dst:
  assert len(src.infolist())==265 and src.testzip() is None
  for info in src.infolist():
   assert info.filename not in previous and info.filename not in new and not info.is_dir()
   raw=src.read(info.filename);previous[info.filename]={'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'mode':stat.S_IMODE(info.external_attr>>16),'crc32':info.CRC}
   dst.writestr(copy.copy(info),raw)
  for name,r in sorted(new.items()):dst.write(r['source'],name)
  manifest={'schema_version':1,'utc':datetime.now(timezone.utc).isoformat(),'status':'APPEND_ONLY_HELPER_LABEL_CORRECTION_NO_OLD_EVIDENCE_DROPPED','original_archive':{'path':str(old),'sha256':old_sha,'members':265},'old_members':previous,'appended_members':new,'declarations_sha256':digest(a.files),'correction_scope':'Original comparisonhelper mislabelled processwallclockratio as existing benchNPS gate. Correctedhelper/protocol/readme/tests retain diagnostic scope; old artifact/evidence preserved. Noengineexecution.','acceptance':'Experimentalcomparisononly; existingNPSperformancegateUNPROVEN,EloUNPROVEN; no nativeWindowshardwareverification.'}
  dst.writestr('APPEND_MANIFEST-v2.json',json.dumps(manifest,indent=2)+'\n')
 with zipfile.ZipFile(old) as original,zipfile.ZipFile(temp) as z:
  assert len(z.infolist())==len(previous)+len(new)+1 and z.testzip() is None
  for name,r in previous.items():
   raw=z.read(name);assert raw==original.read(name) and hashlib.sha256(raw).hexdigest()==r['sha256'];assert stat.S_IMODE(z.getinfo(name).external_attr>>16)==r['mode'] and z.getinfo(name).CRC==r['crc32']
  for name,r in new.items():
   assert hashlib.sha256(z.read(name)).hexdigest()==r['sha256']==digest(Path(r['source']))
   assert z.getinfo(name).file_size==r['bytes'] and stat.S_IMODE(z.getinfo(name).external_attr>>16)==r['mode']
 with temp.open('rb') as f:os.fsync(f.fileno())
 os.replace(temp,out);assert digest(old)==old_sha
 receipt={'path':str(out),'sha256':digest(out),'bytes':out.stat().st_size,'members':len(previous)+len(new)+1,'old_members':len(previous),'new_members':len(new),'status':'PASS_ALL265_OLD_MEMBERS_BYTE_CRC_MODE_IDENTICAL_PLUS_NEW_STABLE_SHA_ZIP_CRC','old_archive_unchanged_sha256':old_sha,'declarations_sha256':digest(a.files),'appended_manifest_name':'APPEND_MANIFEST-v2.json'}
 out.with_suffix('.zip.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
 assert receipt['bytes']<32*(1<<20)
if __name__=='__main__':main()
