# EXPERIMENTAL — NPS UNRESOLVED

This Windows comparison artifact uses eight duplicate shipped heads, not the learned epoch7 network. It is research-only and is not an accepted <=5% speed release. The original NPS threshold and all20pairs remain intact. Batch8 geomean1.157234,95%CI[0.933831,1.506291] does not satisfy lower>=.95; no speed or Elo gain is established.

Use windows-research-commands.json: the original24actualcommands, sources, toolflags and support are unchanged. Root may build this comparisonartifact after nativecorrectness/sanitizer/parity gates. Windows15checks and10kparity stillmustpass. Do not run concurrentlywithNPSmeasurements. Label delivered executable EXPERIMENTAL-NPS-UNRESOLVED and include all original failed/inconclusive timing logs.

The original plan and notes are preserved under their exactSHA filenames. A portable Python helper will separately let the user compare this PE against exact existing6.4.24 on their physicalWindows9850X3D. That comparison is performance only; no automatic Elo claim.
