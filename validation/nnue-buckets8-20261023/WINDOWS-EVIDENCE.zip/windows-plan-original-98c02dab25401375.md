# Eight-bucket Windows candidate plan

Inert support and ordered commands are in `windows-commands.json`. Use only this optional source: Forge6.4.24 plus eight piece-count output heads initialized as duplicates of the shipped net. The main independent-teacher research net and its blocked 13/14 native result are unrelated and must not satisfy these gates.

Before Windows starts, root must confirm actual Release15/perft/UCI, shipped10000+distinct10000 parity, ASan/UBSan15, and the preregistered paired NPS criterion (geomean and95%lower both>=.95). Run NPS alone. This preparation asserts none of those results. Crossbuild in the specified fresh directory only after root clearance. Reverify all source/tool/support hashes.

Execute every command sequentially with the existing recorded-step helper; percommand environment and cwd are explicit. Ten actual C++ binaries run through Wine; five Python suites use the prepared engine wrapper and the path-only OwnBook adapter. CMake already builds the bucketed probe. The10k Wine parity compares the eight-head trainer to the delivered actual core, and full records to the pinned old single-head Linux probe. The actual tool permits1cp; report exact count and maximum error as observed. Preserve first/repeat bench signatures without speed inference.

All preparation is static or fake-loader only: no real compiler, Wine, engine, model, build or match runs. No nativeWindows/Ryzen orElo claim. A tested package remains a candidate of unchanged shipped behavior; only userPC games can establish strength.
