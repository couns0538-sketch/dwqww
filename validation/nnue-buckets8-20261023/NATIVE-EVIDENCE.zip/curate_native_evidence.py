"""Preserve closed optional8 evidence, including original inconclusive timings."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,stat,subprocess,sys,shutil
H=Path('/workspace/forge-buckets8-20261023');MAIN=Path('/workspace/forge-independent-teacher-20261023');PACK=MAIN/'package_closed_evidence.py'
def sha(p):
 d=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):d.update(b)
 return d.hexdigest()
def record(p,member,group):
 assert p.is_file() and not p.is_symlink(),str(p)
 return {'source':str(p),'member':member,'sha256':sha(p),'bytes':p.stat().st_size,'mode':stat.S_IMODE(p.stat().st_mode),'group':group}
# Preserve every original timing file in two explicit stable nested archives.
nested=[]
for directory in ['performance-20pairs','performance-20pairs-batch8']:
 root=H/directory;paths=sorted(root.iterdir());assert all(p.is_file() and not p.is_symlink() for p in paths)
 files=[record(p,p.name,'original_performance_file_unfiltered') for p in paths]
 declaration=H/(directory+'-raw-files.json');assert not declaration.exists();declaration.write_text(json.dumps(files,indent=2)+'\n')
 archive=H/(directory+'-raw-evidence.zip');assert not archive.exists()
 subprocess.run([sys.executable,'-B',str(PACK),'--files',str(declaration),'--out',str(archive)],check=True)
 info=json.loads(archive.with_suffix('.zip.json').read_bytes());nested.append({'directory':directory,'original_files':len(files),'run_result_json_files':sum(p.name.startswith(('pair-','warmup-')) and p.suffix=='.json' for p in paths),'archive':info,'declarations_sha256':sha(declaration),'original_directory_untouched':True})
rows=[]
def add(rel,group):
 p=H/rel
 assert not any(x in p.parts for x in ['CMakeFiles','source-1ab.tar']) and p.suffix not in ('.o','.a','.exe','.bin','.tar'),str(p)
 row=record(p,rel,group);assert row['member'] not in {r['member'] for r in rows};rows.append(row)
for name in ['SOURCE-BASELINE.json','CONTRACT.json','CPP-BUILD-INPUTS-FROZEN.json','SECONDARY-BUILDS-CLOSED.json','release-commands.json','secondary-commands.json','parity-commands.json','PERFORMANCE-PREREGISTRATION.json','PERFORMANCE-BATCH8-PREREGISTRATION.json','performance-command.json','performance-batch8-command.json','paired_uci_bench.py','paired_uci_bench_batched.py','performance-batch8-changes.diff','release-loop.stdout','release-loop.stderr','secondary-builds.stdout','secondary-builds.stderr','final-native-loop.stdout','final-native-loop.stderr','extended-uci.log']:
 add(name,'source_protocol_exact_commands_and_closed_native_loops')
for directory in ['cpp-agent','review-agent','parity-agent']:
 for p in sorted((H/directory).iterdir()):
  if p.is_file():add(str(p.relative_to(H)),directory+'_closed_source_checks_reviews_and_original_failures')
for directory in ['cpp-agent/override-configure-red','cpp-agent/override-configure-green']:
 for p in sorted((H/directory).iterdir()):
  if p.is_file():add(str(p.relative_to(H)),'original_missing_and_false_like_export_override_red_green')
# Trainer metadata and original failed harness sources retained; .bin and redundant original weights omitted.
for p in sorted((H/'trainer-agent').iterdir()):
 if p.is_file() and p.suffix!='.bin' and p.name!='shipped-original.inc':add(str(p.relative_to(H)),'trainer_exporter_unit_tests_provenance_review_and_static_fixtures')
for rel in ['source/tools/nnue/train_bucketed_nnue.py','source/tools/nnue/include_parser.py','source/tools/nnue/bucketed_protocol.example.json','source/tools/nnue/tests/test_bucketed_training.py','source/tools/nnue/tests/test_bucketed_engine_parity.py','source/tools/nnue/tests/test_bucketed_parity_contract.py']:
 # Only explicit small support-tool source files, never copied runtime source trees.
 p=H/rel;row=record(p,rel,'bounded_original_trainer_parser_parity_tool_sources');assert row['member'] not in {r['member'] for r in rows};rows.append(row)
step_results=[]
for group in ['release-steps','secondary-steps','parity-steps']:
 for directory in sorted((H/group).iterdir()):
  assert directory.is_dir() and not directory.is_symlink()
  r=json.loads((directory/'result.json').read_bytes());assert r['actual_exit']==0 and r['closed_utc']
  step_results.append({'path':str(directory.relative_to(H)),'actual_exit':r['actual_exit'],'result_sha256':sha(directory/'result.json')})
  for name in ['command.json','result.json','stdout','stderr']:
   p=directory/name
   if name in ['stdout','stderr']:assert sha(p)==r[name+'_sha256']
   add(str(p.relative_to(H)),group+'_actual_closed_zero_exit_original_streams')
for group in ['performance-exec','performance-batch8-exec']:
 r=json.loads((H/group/'result.json').read_bytes());assert r['actual_exit']==0 and r['closed_utc']
 for name in ['command.json','result.json','stdout','stderr']:add(group+'/'+name,'original_closed_performance_runner_execution')
for directory in ['build-release','build-asan']:
 for rel in ['compile_commands.json','Testing/Temporary/LastTest.log','uci-regression.log','ownbook-regression.json']:add(directory+'/'+rel,'actual_release_sanitizer_compiler_and_ctest_logs_no_build_objects')
add('build-diagnostic/compile_commands.json','actual_diagnostic_compiler_commands')
for group in ['parity-shipped','parity-distinct']:
 for p in sorted((H/group).iterdir()):
  assert p.is_file() and not p.is_symlink();add(str(p.relative_to(H)),'actual10000_cpp_parity_original_corpus_expected_cp_and_streams')
for n in nested:
 archive=Path(n['archive']['path']);add(archive.name,'nested_complete_original_performance_archive')
 add(archive.name+'.json','nested_performance_archive_verification_receipt')
 add(n['directory']+'-raw-files.json','nested_original_performance_file_declarations')
add('SKILL-MAINTENANCE-RESULT.json','existing_skill_reused_no_duplicate_or_installation_claim')
add('skill-before-buckets-de2a45a61789.md','preserved_prior_existing_skill_body')
skill=Path('/workspace/dwqww/.agents/skills/validating-chess-simd/SKILL.md');assert sha(skill)=='73516c049078521648ce94276b3284459fc820af65a1de11d2ddca2947e16c4a'
after=H/'skill-after-buckets-73516c049078.md';assert not after.exists();shutil.copyfile(skill,after);assert sha(after)==sha(skill);add(after.name,'current_existing_skill_body_exact_copy')
p=MAIN/'public-readback-e44e20f/RESULT.json';rows.append(record(p,'main-source-public-readback-e44e20f-RESULT.json','main_job_publication_reference_only_no_archive_duplication'))
add('curate_native_evidence.py','original_curation_source')
curation={'schema_version':1,'utc':datetime.now(timezone.utc).isoformat(),'status':'CLOSED_OPTIONAL8_IMPLEMENTATION_NATIVE_PASS_PERFORMANCE_GATE_UNPROVEN','parent':'1ab50b2dd64d9b2f752f7f1285f6968cad2fd792','root_explicit_closed_producer_signal':True,'step_results':step_results,'root_reported_native':'Release15/15,extendedUCI0,duplicateanddistinct10000CPPparityexactCP0,ASanUBSan15/15leaksdisabled; originalreceiptsincluded','performance_status':'INCONCLUSIVE_ALL_ORIGINAL_SAMPLES_RETAINED_NPS95PERCENT_GATE_UNPROVEN','performance_observations_as_reported_not_reestimated':{'cpu0_20pairs_ratio':0.84094,'cpu0_ci95':[0.60518,1.03684],'cpu4_batch8_ratio':1.15723,'cpu4_ci95':[0.93383,1.50629],'stall_samples':'Retained,notdiscarded'},'nested_performance_archives':nested,'no_acceptance_or_elo_or_Windows_release_claim':True,'no_model_scoring_build_matches_git_or_engine_source_edits_by_curator':True,'excluded':['Windowsplans/tools/runtime still pendingfutureclosure','Oldmain30MBarchive/globaldataset/SFpayloads','Mainuniquelearnedweights','RuntimeC++fullsourcecopies/sourcearchive','Buildobjects/binaries/libraries','MutableRUNNING_STATE','Redundanttrainerbinaryfixtures/originalshippedinclude; declaredhashes/provenancepreserved'],'bounded_support_sources':'Only six explicitlynamedtrainer/parser/test Python/protocol files included to preserveoriginal tools; no runtime source tree snapshot.','source_count_before_curation':len(rows),'raw_bytes_before_curation':sum(r['bytes'] for r in rows),'declarations':rows}
p=H/'NATIVE-EVIDENCE-CURATION.json';assert not p.exists();p.write_text(json.dumps(curation,indent=2)+'\n');add(p.name,'curation_receipt')
for r in rows:assert sha(Path(r['source']))==r['sha256']
p=H/'NATIVE-EVIDENCE-FILES.json';assert not p.exists();p.write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps({'declarations':str(p),'members_without_manifest':len(rows),'raw_bytes':sum(r['bytes'] for r in rows),'curation_sha256':sha(H/'NATIVE-EVIDENCE-CURATION.json'),'nested':nested}))
