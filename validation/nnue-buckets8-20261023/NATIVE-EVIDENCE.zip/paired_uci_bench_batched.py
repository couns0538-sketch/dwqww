"""Fixed20pair native bench experiment; no matches or playing-strength inference."""
import hashlib
import json
import math
import os
import re
import resource
import statistics
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path
import numpy as np

h = Path('/workspace/forge-buckets8-20261023')
out = h / 'performance-20pairs-batch8'
out.mkdir(exist_ok=False)
engines = {
    'shipped': Path('/workspace/.cloud-setup/nnue-pipeline-20261023-baseline-build/forge'),
    'buckets8': h / 'build-release/forge',
}
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(engines['shipped']) == '02d6ba2690c8dc5873bca78931d54a39421e95d7a4b1846b0e960ca11acfbdd6'
cpu = max(os.sched_getaffinity(0))
os.sched_setaffinity(0, {cpu})
stdin = b'uci\nsetoption name Threads value 1\nsetoption name Hash value 16\nsetoption name OwnBook value false\nsetoption name UseNNUE value true\nisready\n' + b'bench 11\n' * 8 + b'quit\n'
(out/'original.stdin').write_bytes(stdin)
protocol = {'utc_before_any_timing': datetime.now(timezone.utc).isoformat(),
    'pairs': 20, 'warmups_per_engine': 2, 'benches_per_process':8, 'noise_control':'CPU4 and eight repeated benches per process; all samples retained; process CPU time recorded', 'order': 'shipped,buckets8 on even pairs; reverse on odd',
    'cpu_affinity': [cpu], 'input_sha256': hashlib.sha256(stdin).hexdigest(),
    'binaries': {name:{'path':str(p),'sha256':sha(p)} for name,p in engines.items()},
    'runner_sha256': sha(__file__), 'expected_nodes_each_run':292545,
    'primary': 'geometric mean of paired buckets8/shipped engine-reported bench NPS',
    'uncertainty': '10000 paired log-ratio bootstrap draws; seed2026102309; linear percentile95%CI',
    'acceptance': 'primary ratio>=0.95 and95%CI lower>=0.95; otherwise inconclusive/overbudget, never Elo',
    'other_compute': 'Root requires builds/training/tests finished before launch', 'strength':'unproven'}
(out/'PROTOCOL-BEFORE-TIMING.json').write_text(json.dumps(protocol,indent=2)+'\n')
rows=[]
env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1'}
def run(name, label, pair=None, order=None):
    binary=engines[name];assert sha(binary)==protocol['binaries'][name]['sha256']
    before=resource.getrusage(resource.RUSAGE_CHILDREN)
    start=time.perf_counter_ns()
    process=subprocess.run([str(binary)],input=stdin,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,timeout=60)
    ns=time.perf_counter_ns()-start
    after=resource.getrusage(resource.RUSAGE_CHILDREN)
    prefix=out/label
    prefix.with_suffix('.stdout').write_bytes(process.stdout)
    prefix.with_suffix('.stderr').write_bytes(process.stderr)
    record={'engine':name,'pair':pair,'order':order,'argv':[str(binary)],'actual_exit':process.returncode,
            'wall_ns':ns,'child_cpu_seconds':(after.ru_utime+after.ru_stime)-(before.ru_utime+before.ru_stime),'stdout_sha256':hashlib.sha256(process.stdout).hexdigest(),
            'stderr_sha256':hashlib.sha256(process.stderr).hexdigest()}
    matches=re.findall(rb'info string bench depth 11 nodes (\d+) time (\d+) nps (\d+)',process.stdout)
    assert process.returncode==0 and len(matches)==8,record
    values=[tuple(map(int,row)) for row in matches]
    assert all(v[0]==292545 and v[1]>0 and v[2]>0 for v in values)
    milliseconds=sum(v[1] for v in values)
    record.update(nodes=292545,engine_ms=milliseconds,engine_nps=(292545*8*1000)//milliseconds,bench_repetitions=values)
    prefix.with_suffix('.json').write_text(json.dumps(record,indent=2)+'\n')
    assert record['nodes']==292545 and record['engine_nps']>0,record
    return record
for warm in range(2):
    for name in engines: run(name,f'warmup-{warm}-{name}')
for pair in range(20):
    names=list(engines) if pair%2==0 else list(reversed(engines))
    for order,name in enumerate(names): rows.append(run(name,f'pair-{pair:02}-{order}-{name}',pair,order))
    print('PAIR_CLOSED',pair,flush=True)
logs=[]
for pair in range(20):
    p={r['engine']:r for r in rows if r['pair']==pair}
    logs.append(math.log(p['buckets8']['engine_nps']/p['shipped']['engine_nps']))
ratio=math.exp(statistics.mean(logs))
rng=np.random.default_rng(2026102309)
samples=np.exp(np.asarray(logs)[rng.integers(0,20,size=(10000,20))].mean(axis=1))
ci=np.quantile(samples,[.025,.975]).tolist()
for name,binary in engines.items(): assert sha(binary)==protocol['binaries'][name]['sha256']
result={'status':'PASS_WITHIN5PCT_NPS_OVERHEAD_NOT_ELO' if ratio>=.95 and ci[0]>=.95 else 'INCONCLUSIVE_OR_OVER5PCT_NPS_OVERHEAD_NOT_ELO',
    'pairs':20,'ratio_geometric_mean':ratio,'ci95_ratio':ci,'overhead_fraction':1-ratio,
    'median_nps':{name:statistics.median(r['engine_nps'] for r in rows if r['engine']==name) for name in engines},
    'all_nodes':sorted(set(r['nodes'] for r in rows)),'rows':rows,'protocol_sha256':sha(out/'PROTOCOL-BEFORE-TIMING.json'),
    'runner_sha256':sha(__file__),'binaries':protocol['binaries'],'cpu_affinity':[cpu],
    'strength':'unproven; no matches','closed_utc':datetime.now(timezone.utc).isoformat()}
(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='rows'}),flush=True)
