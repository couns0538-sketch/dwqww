"""An explicitly requested missing NNUE export must fail actual CMake configure."""
import argparse
import hashlib
import json
import subprocess
from pathlib import Path

p = argparse.ArgumentParser(); p.add_argument('--phase', choices=['red', 'green'], required=True)
a = p.parse_args()
h = Path('/workspace/forge-buckets8-20261023/cpp-agent')
s = Path('/workspace/forge-buckets8-20261023/source')
cmake = '/workspace/.cloud-setup/venv/lib/python3.12/site-packages/cmake/data/bin/cmake'
out = h / ('override-configure-' + a.phase); out.mkdir(exist_ok=False)
rows = []
for name, requested in [('false-string', 'OFF'), ('missing-absolute', str(h / 'definitely-missing.inc'))]:
    argv = [cmake, '-S', str(s), '-B', str(out / name), '-DCMAKE_CXX_COMPILER=/usr/bin/g++-14',
            '-DFORGE_NNUE_WEIGHTS_FILE:STRING=' + requested]
    result = subprocess.run(argv, capture_output=True, text=True)
    (out / (name + '.stdout')).write_text(result.stdout)
    (out / (name + '.stderr')).write_text(result.stderr)
    rows.append({'name': name, 'argv': argv, 'actual_exit': result.returncode,
                 'requested_export': requested, 'expected_nonzero': True})
receipt = {'phase': a.phase, 'cmake_source_sha256': hashlib.sha256((s / 'CMakeLists.txt').read_bytes()).hexdigest(),
           'checks': rows, 'status': 'PASS' if all(r['actual_exit'] != 0 for r in rows) else 'FAIL_MISSING_EXPORT_CONFIGURED'}
(out / 'RESULT.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
raise SystemExit(0 if receipt['status'] == 'PASS' else 1)
