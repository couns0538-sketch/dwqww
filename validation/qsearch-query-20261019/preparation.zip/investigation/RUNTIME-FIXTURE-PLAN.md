# Minimal runtime comparison plan; no new harness required

Existing full tests plus the existing one-thread baseline/candidate parity driver
are sufficient correctness coverage for this pure query relocation. Do not build an
instrumentation framework or a Boolean test that repeats the guard. Runtime speed
still requires separately controlled measurements; correctness tests cannot prove it.
This plan was prepared statically only: no test, build or engine run was started.

## Existing meaningful coverage

- `tests/rule50_tests.cpp` invokes actual Worker qsearch on checked KR/K positions.
  Cold clock90/98/99 searches traverse legal evasions; the changed call is omitted
  there. Existing bound/reverse-context/terminal/reset tests protect their results.
- `tests/tests.cpp` compares actual `Board::gives_check(move)` with resulting
  `board.in_check()` after legal moves along deterministic walks. Its generation
  tests cover ordinary/capture promotions and legal/pinned en passant; search tests
  cover winning underpromotion versus queen-promotion stalemate and promotion mate.
- Canonical perfts, full search parity, UCI and pondering protect legal state,
  principal variations and externally visible behavior. Existing legal-witness
  differential tests protect the has-legal-move work being finished separately.

The existing Board query checks have broad coverage but do not guarantee every
special move is selected by a random walk. If the parity corpus lacks these cases,
add only the following input FENs to its existing fixture list; no new test program.
Verify their suggested witness moves as legal before treating a case as coverage.

| Purpose | FEN / witness |
|---|---|
| Actual checked evasions; skipped query | `7k/8/8/8/8/8/8/K6R b - - 0 80`; h8g7/h8g8. Already covered by rule50 tests with legal clock variants. |
| Checking/nonchecking quiet and capture promotions | `1r2k3/P7/8/8/8/8/8/4K3 w - - 0 1`; a7a8 and a7b8 promotions. Existing generator fixture. |
| EP with discovered rook check | `8/8/8/R2pP2k/8/8/8/K7 w - d6 0 1`; e5d6 clears the fifth rank. Suggested parity input, not runtime-validated here. |
| Discovered check by capture | `k7/8/8/8/8/1p6/B7/R6K w - - 0 1`; a2b3 clears the rook's a-file. Suggested parity input, not runtime-validated here. |
| Castling query support, general Board/main-search regression | `r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1`; legal castles. Not a qsearch-loop coverage claim. |

Use the existing parity mechanism to compare exact scores, complete PV, bestmove,
depth and node count at the same deterministic limits, one search thread, matching
network, options and warm/cold TT procedure. Prefer full windows for any direct
Worker qsearch fixture so an earlier stand-pat fail-high does not skip its noisy
move loop. A FEN's witness move existing does not itself prove the search visited it;
if explicit path proof is required, reuse the existing Worker accessor rather than
fabricating a mock search. No additional path harness is necessary for acceptance
of the simple relocation if full suite and representative parity already pass.

## Castling scope and exact source-use proof

In qsearch the local gives_check variable has exactly one use: the futility
condition inside `!in_check && best_score > -MateInMaxPly`. Main search has a
different variable of the same name with several uses; this patch does not move it.

Castling cannot be an actual legal qsearch move here: outside check the quiescence
picker filters quiet nonpromotion TT moves and generates only noisy moves; in check,
castling is illegal. Board/main-search castling tests remain worthwhile general
coverage but must not be advertised as traversing the changed qsearch path.

`Board::gives_check` calls king_square/occupied/pieces array reads, bitboard helpers,
and attacks pawn/knight/bishop/rook lookups. Those access initialized attack tables
and compute local integer values; no recursion, move mutation, allocation, I/O,
floating-point operation, RNG, TT/cache write or explicit exception occurs anywhere
in this query chain for valid positions. EP/castling/promotion adjust local values
only. The existing valid-position initialization invariant remains unchanged.

Consequently an unused call can be omitted for checked evasions/mating-loss context
without changing move/state/order, while every original used value is still computed
on the identical board and move. Compiler code generation and the frequency of the
skipped paths determine whether measurable performance changes.
