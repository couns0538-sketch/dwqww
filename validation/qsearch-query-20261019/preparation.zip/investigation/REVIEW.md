# qsearch gives_check: static equivalence review and next validation

## Fresh upstream source reused

Fresh candidate `origin/forge/candidate-qsearch-check-20261019-2245`, full commit
`3dddd864d45288787b6e949dca5528e88be9f535`, directly parents accepted upstream
`9108d012526be80c6d163f7cab684e6acd9abf8d`. Its entire change is moving one
declaration inside its existing use guard: one insertion/one deletion in search.cpp.
The applicable patch prepared against current local HEAD82cd2c has **identical
changed lines**; only surrounding line numbers/base context differ. Reuse this
actual new upstream change, not its whole older baseline source or branch checkout.

Saved original upstream diff, older1845 patch and research2215 report separately.
`origin/forge/test-20261019-2230` still points to9108; it supplies no new candidate
test result. Research2215 calls the older16-case model PASS and reports zero speed
measurements. The2245 source commit adds no tests/evidence. Static source verification
is complete; functional identity and speed on the current engine are untested.
Completed rule50 work is not repeated here.

## Smallest exact change

Use `qsearch-gives-check-current.patch`. It moves
`const bool gives_check = board.gives_check(move);` into
`if (!in_check && best_score > -MateInMaxPly)`, immediately before its sole use.
No other expression, branch, move selection, TT logic, network, search constant,
state mutation or move order changes. More aggressive promotion/futility-condition
short circuiting is a different experiment and is deliberately absent.

## Why it preserves search semantics

The existing sequence remains: picker.next, legality filter, move_count increment,
guarded futility/SEE logic, record state, make move, recurse, unmake, update score/PV.
The declaration's value is read only inside the unchanged outer guard.

`Board::gives_check` is const and computes on local bitboards from board pieces,
occupancy, side and king square. Its en-passant/castling/promotion cases alter only
local occupancy/type values. It does not make/unmake moves, mutate histories, touch
TT, update accumulators, consume RNG or perform floating-point evaluation. Omitting
the call when its result is unused therefore removes no search-visible state
transition for valid legal moves/positions. Where the guard is true, the call occurs
at the same board/move state before the same futility decision.

Both `in_check` and `best_score` are checked before use in the original guarded
block. `in_check` is fixed for the node; `best_score` may improve after each child.
The moved declaration uses the current per-move value of the same guard, so an
initial mating-loss score improving later does not cause a stale eligibility choice.

## Calls actually avoided

- Every legal evasion when the qsearch node is in check. The picker generates quiet
  evasions as well as captures there; this is a real normal path, not a synthetic
  Boolean-only demonstration. Checkmate with zero legal moves avoids no call.
- Legal qsearch moves while best_score is at or below the mating-loss threshold.
  In a nonchecked node a usable TT mate score can populate best_score; ordinary
  clamped raw evaluations are above that threshold. This path may be uncommon;
  prove reachability/counts rather than claim its frequency.

Illegal pseudo-legal moves already skip the declaration. Stand-pat/direct-TT exits
and terminal draw/mate returns happen before the loop and gain nothing from this
change. Promotions within the true outer guard still query gives_check, as before.

## Meaningful execution gate, not run here

1. Build unchanged current candidate and the one-line-movement candidate with the
   same source export/compiler/flags/network; retain source/binary hashes. Preserve
   upstream accepted9108 versus local current provenance rather than equating them.
2. Run full relevant CTest/UCI/ponder and terminal/rule50/underpromotion regressions.
   Existing `tests/tests.cpp` verifies gives_check against actual resulting board
   check status along legal walks; retain this, but it alone does not test call
   scheduling. Add no tautological Boolean test mirroring this code movement.
3. Compare per-position score, best move, complete PV, depth and nodes with one
   thread and deterministic depth/node budgets, cold and matched warm hashes.
   Include checked evasions, captures, en passant, checking/nonchecking promotions,
   mate/loss contexts, and ordinary tactical/endgame positions. Bench signature
   must match the **current** unchanged build, not historical417491 by assumption.
4. In separate disposable diagnostic builds, count executed gives_check calls and
   eligible outer-guard states in qsearch on identical workloads. Confirm avoided
   calls equal legal moves for which the outer guard is false, and search outputs
   remain identical. Instrument both identically; counters are not release timing.
5. Inspect final disassembly: compiler interprocedural optimization might already
   sink/remove the original call. Count reductions alone are not speed evidence.
   When other jobs stop, counterbalance paired AB/BA timings with warmups, identical
   allocations and raw repetitions; require repeatability beyond observed noise.

This session prepared/reviewed source only: no patch application, engine build,
measurement or strength result. Functional identity would establish safe omitted
work; runtime improvement needs measurement, and equal-clock Elo needs separate
games in a reliable environment. No new strength or native Ryzen claim is implied.
