"""Verify actual candidate counters against independent root-child trace sums."""
import argparse
from collections import defaultdict
import json
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('trace', type=Path)
parser.add_argument('--signatures', required=True, type=Path)
args = parser.parse_args()
root = Path(__file__).resolve().parent
checks = []
for line in args.trace.read_text().splitlines():
    fields = line.split(',')
    if fields[0] == 'TRACE_CASE':
        case = int(fields[1])
        independent, stored = defaultdict(int), {}
    elif fields[0] == 'TRACE_MOVE':
        independent[fields[3]] += int(fields[4])
    elif fields[0] == 'TRACE_STORED':
        assert fields[2] not in stored, 'duplicate stored move identity'
        stored[fields[2]] = int(fields[3])
    elif fields[0] == 'TRACE_STABLE_ITER':
        depth, best, total = int(fields[1]), fields[2], int(fields[3])
        assert set(independent) <= set(stored), 'actual searched move absent from stable map'
        assert all(value == independent[move] for move, value in stored.items()), 'stored counts differ from independent actual child deltas'
        assert best in stored, 'selected move absent from stable map'
        effort = independent[best] / total
        checks.append({'case': case, 'depth': depth, 'best': best,
                       'independent_best_nodes': independent[best], 'stored_best_nodes': stored[best],
                       'total_nodes': total, 'effort': effort,
                       'effort_factor_at_depth6plus': min(max(1.55 - effort, .6), 1.4) if depth >= 6 else None})
        stored = {}
assert len(checks) == 28 and len({row['case'] for row in checks}) == 4, 'expected four cases x seven completed iterations'
assert args.signatures.read_bytes() == (root/'baseline.stdout').read_bytes(), 'candidate node/PV/score output differs from untouched baseline'
print(json.dumps({'status': 'passed', 'every_iteration_counters_match_independent_actual_trace': True,
                  'untimed_exact_baseline_parity': True, 'checks': checks}, indent=2))
