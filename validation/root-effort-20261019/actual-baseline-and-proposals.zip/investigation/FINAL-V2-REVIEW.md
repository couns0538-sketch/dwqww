# Final outside-only v2 review

Use **stable-root-effort-fixed-capacity-v2.patch** and matching
**candidate-trace-overlay-v2.patch**. Earlier vector/v1 drafts are preserved and
superseded. New v2 hashes/source provenance are in fixed-capacity-v2-provenance.json.
Nothing was applied, built or run for this new candidate.

Both requested fixes are present: root_effort_index initializes0 but end construction,
std::find and index conversion occur only inside `if (root_node)`. The actual counter
write separately requires index<count even under NDEBUG, preventing idx==256 OOB
on an unexpected miss. Debug assertion remains to expose violations early.

## Why ordinary root lookup finds its identity

Worker's public search computes canonical `board.legal_moves()` once for this exact
unchanged root, then appends each legal move once to root_candidates. It iterates
the legal list rather than the searchmoves list, so duplicate requested restrictions
do not duplicate candidates. A restriction uses the same full Move equality in
candidate filtering and the main root loop's rejection filter. Promotions have
separate promotion fields; castling/en-passant/double-push/capture flags come from
legal canonical moves.

The picker validates a TT move pseudo-legally and the root loop filters legality
before accounting. Ordinary generated/accepted TT moves therefore match a canonical
legal entry. Board unmake restores the same root before processing the next move;
the stable list is not reordered with picker/history/TT changes. Full Move equality
is used for both accumulation and the final result.best_move lookup.

Potential malformed/corrupted noncanonical TT identities are not a reason to rely
on release assertions: the write guard handles a missing identity conservatively,
and a missing final best identity leaves the existing other timing factors intact.
This fallback drops unmatched effort instead of inventing another bucket; no legal
move selection, pruning or PV publication is changed.

## Setup and early exits

Normal public Worker search initializes the stable list/count and zeroes cumulative
nodes immediately before iterative deepening. Helpers each initialize their own
Worker state. Terminal/empty restricted roots, explicit zero nodes and already-expired
hard budgets return before both root recursion and effort-factor consumption, so
they need no new map. Existing book handling/fallback bestmove paths are untouched.

Existing private tests call Worker::search with stack ply1, and rule50 fixtures call
qsearch/nonroot search; they do not create an uninitialized ply0 root. Their new
root-only code path stays inactive. A future private ply0 diagnostic must establish
the same root setup as public Worker search or explicitly expect the debug assertion.

The denominator remains local_nodes_, including original overhead; deltas remain
between original nodes_before/after child search, excluding aborted unfinished
children exactly as before. Counters remain cumulative over iterations and aspiration
retries and reset once per root search. No stopwatch/NNUE/order/search constants changed.

Acceptance still requires actual candidate trace-oracle agreement every iteration,
the full suites and exact untimed node/PV parity. Hosted647 evidence remains exclusive
to frozen647; no candidate648 Elo, timeout or performance claim is supported yet.
