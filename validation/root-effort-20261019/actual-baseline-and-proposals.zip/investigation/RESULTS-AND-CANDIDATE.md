# Actual root-effort misattribution; outside-only candidate

## Observed engine evidence

Existing research2215 correctly hypothesized cumulative ordinal attribution but
provided no real trace. This investigation copied actual current search.cpp outside
the checkout and added only root-child/iteration stderr records. It linked that
object ahead of the exact6.4.7 core archive; an untouched comparison driver linked
the original archive. Both ran the same four FENs at depth7, Threads1, Hash32 and
no clocks. Exact score/depth/nodes/bestmove/full-PV output matched all four cases.
The traces reconstruct every original cumulative ordinal bucket exactly.

At middlegame depth7, selected c3d5 occupies ordinal0. The production bucket contains
1,355 nodes, accumulated for a2a3, h2h3, c4b3 and c3d5; actual c3d5 child deltas sum
to601. Total local nodes3,355. Source effort multiplier is1.1461251863 versus
1.3708643815 using stable chosen-Move attribution. With the same stability/drop
terms, full-factor arithmetic is1.6045752608 versus1.9192101341.

Seven of eight depth6/7 iteration samples differ after the real clamps. Start and
endgame examples also contain multiple unrelated moves in the chosen ordinal's
cumulative bucket. Actual raw traces and all iteration results are retained, not
only the largest difference. `analysis.json` contains each observation and constants.

These are **actual search counters plus source factor arithmetic evaluated offline**.
The time-managed branch was intentionally inactive. No changed real timed stop,
deadline, timeout, performance or Elo outcome was observed or claimed. Hosted647
games/results do not transfer to this separate candidate.

## Smallest fixed-capacity proposal

Use `stable-root-effort-fixed-capacity.patch` (the earlier vector draft is superseded
and retained). Parallel256 Move/node arrays plus count are initialized once per
search from original legal root_candidates, including searchmoves restriction.
Full Move equality distinguishes promotions and flags. Lookup occurs for root moves
only; identical child-node deltas accumulate across all depths/aspiration retries.
Final published result.best_move selects its stable counter for the unchanged time
formula. root_best_index_ is removed; no ordinal participates in this attribution.

Preserved: picker/move order, root move_count for pruning/history/LMR, score/PV updates,
TT policy, network, search constants, child accounting boundaries, total local-node
denominator, reset-per-search and cumulative-retry semantics. No timer retuning.
The fixed arrays add approximately1KB per Worker; linear root lookup has a cost to
measure separately. RootMove count is bounded by the existing256-capacity MoveList;
debug assertions detect a missing canonical legal Move. Rebuild all affected ABI
components; the proposal was not applied or built in this investigation.

## Meaningful regression gate for owner

`candidate-trace-overlay.patch` is diagnostic only, applied atop the proposed source:
it records actual child deltas and each stored stable-Move count at every completed
iteration. Reuse driver.cpp unchanged. Then run:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 verify-candidate-trace.py candidate.trace \
  --signatures candidate.stdout > candidate-counter-verification.json
```

The verifier sums independent actual child events by UCI Move identity, compares
**all** stored counters every iteration, checks chosen identity and effort, and
requires exact untouched-baseline output parity for all28 iterations/four final
signatures. This is not a test of a standalone mapping helper. Promotion identity
includes the UCI promotion suffix; flags are canonical for legal moves at this root.
These four cases establish changing root orders and aspiration-search accounting;
also retain existing searchmoves and all-underpromotion tests, all eight suites and
the established exact untimed node/PV parity driver. Timed stopping intentionally
may change only after this new candidate is tested separately.

All original production/archive/source fingerprints, commands, compile outputs,
binary hashes, baseline/traced outputs and parser are preserved. No production or
Git file was modified; no candidate build or integration was performed here.
