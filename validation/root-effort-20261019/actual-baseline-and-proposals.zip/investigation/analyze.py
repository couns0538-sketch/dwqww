"""Analyze actual root trace; no simulated search or timing measurement."""
from collections import defaultdict
import json
from pathlib import Path
import re

root = Path(__file__).resolve().parent
source = (root / 'search-trace.cpp').read_text()
names = ['TmStableFactor', 'TmSemiStableFactor', 'TmUnstableFactor', 'TmEffortBase',
         'TmFallingEvalPercent', 'TmMinFactorPercent']
tune = {name: int(re.search(r'int ' + name + r' = (\d+);', source).group(1)) for name in names}
cases, rows = [], []
for line in (root / 'trace.stderr').read_text().splitlines():
    fields = line.split(',')
    if fields[0] == 'TRACE_CASE':
        case = int(fields[1])
        ordinal, stable, owners = defaultdict(int), defaultdict(int), defaultdict(set)
        cases.append({'case': case, 'fen': fields[2]})
    elif fields[0] == 'TRACE_MOVE':
        depth, index, move, delta, total = int(fields[1]), int(fields[2]), fields[3], int(fields[4]), int(fields[5])
        ordinal[index] += delta
        stable[move] += delta
        owners[index].add(move)
    elif fields[0] == 'TRACE_ITER':
        depth, index, best, total, observed, stable_iters, score, previous = (
            int(fields[1]), int(fields[2]), fields[3], *map(int, fields[4:]))
        assert ordinal[index] == observed, 'trace does not reconstruct production ordinal accounting'
        assert total > 0
        ordinal_effort, stable_effort = observed / total, stable[best] / total
        def factors(effort):
            factor = 1.0
            if stable_iters >= 6: factor = tune['TmStableFactor'] / 100.0
            elif stable_iters >= 3: factor = tune['TmSemiStableFactor'] / 100.0
            elif stable_iters == 0 and depth >= 6: factor = tune['TmUnstableFactor'] / 100.0
            effort_factor = min(max(tune['TmEffortBase'] / 100.0 - effort, .6), 1.4)
            if index >= 0 and depth >= 6: factor *= effort_factor
            if previous != 32002 and abs(score) < 31872 and score < previous:
                factor *= 1.0 + min(previous - score, 150) * tune['TmFallingEvalPercent'] / 10000.0
            return effort_factor, max(factor, tune['TmMinFactorPercent'] / 100.0)
        old_effort_factor, old_factor = factors(ordinal_effort)
        new_effort_factor, new_factor = factors(stable_effort)
        row = {'case': case, 'depth': depth, 'best_move': best, 'best_ordinal': index,
               'total_nodes': total, 'observed_ordinal_nodes': observed,
               'stable_move_nodes': stable[best], 'ordinal_bucket_move_owners': sorted(owners[index]),
               'ordinal_effort': ordinal_effort, 'stable_effort': stable_effort,
               'source_effort_factor': old_effort_factor, 'stable_effort_factor': new_effort_factor,
               'source_full_factor_if_time_managed': old_factor,
               'stable_full_factor_if_time_managed': new_factor,
               'factor_differs_at_active_depth': depth >= 6 and abs(old_factor - new_factor) > 1e-12,
               'score': score, 'previous_score': previous, 'stable_iterations': stable_iters}
        rows.append(row)
result = {'kind': 'actual fixed-depth traces; source time-factor arithmetic applied offline',
          'timed_stop_observed': False, 'elo_or_speed_claim': None, 'constants': tune,
          'source_ordinal_accounting_reconstructed_exactly': True,
          'baseline_trace_exact_output_parity': (root/'baseline.stdout').read_bytes() == (root/'trace.stdout').read_bytes(),
          'cases': cases, 'iterations': rows,
          'active_depth_factor_differences': [row for row in rows if row['factor_differs_at_active_depth']]}
(root/'analysis.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result['active_depth_factor_differences'], indent=2))
