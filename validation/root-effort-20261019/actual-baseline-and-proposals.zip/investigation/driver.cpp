#include "forge/search.hpp"
#include <array>
#include <iostream>
#include <string_view>

int main() {
    constexpr std::array<std::string_view, 4> fens{
        forge::Board::StandardStartFen,
        "r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1",
        "r4rk1/1pp1qppp/p1np1n2/8/2B1P1b1/2N2N2/PPP1QPPP/2KR3R w - - 0 10",
        "8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1"
    };
    for (std::size_t i = 0; i < fens.size(); ++i) {
        forge::Board board;
        if (!board.set_fen(fens[i])) return 2;
        std::cerr << "TRACE_CASE," << i << "," << fens[i] << '\n';
        forge::Searcher searcher(32, 1);
        forge::SearchLimits limits;
        limits.depth = 7;
        const auto result = searcher.search(board, limits);
        std::cout << "SIGNATURE," << i << ',' << result.depth << ',' << result.nodes
                  << ',' << result.score << ',' << forge::Board::move_to_uci(result.best_move);
        for (auto move : result.pv) std::cout << ',' << forge::Board::move_to_uci(move);
        std::cout << '\n';
    }
}
