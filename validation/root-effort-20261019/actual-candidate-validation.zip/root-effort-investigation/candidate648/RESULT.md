# Candidate 6.4.8 actual trace verification: PASS

Frozen source `7125b3379a850de34041d42529cf95993607f93c`; exact headers and search.cpp
exported into this directory. After the owner's Release8/8 GO, the instrumented
search TU was compiled and linked with fresh6.4.8 core library SHA256
`7719912f773e34fdd7174e71e2fe60e2263684cf0cc384824cfaffb56fc63860`.
No6.4.7 object/library was linked into this candidate.

Both compile/link commands succeeded, trace exited0, independent verifier exited0.
All stable root-Move counters match independently summed actual root child-node
deltas at **every one of28 completed iterations** across the original four FENs.
At middlegame depth7, selected c3d5 correctly has601nodes rather than the original
unrelated ordinal bucket's1355. Fixed-depth scores, best moves, full PVs and node
counts are byte-identical to the untouched original6.4.7 baseline output.

Commands/compiler flags, exact library/header/source/trace/binary hashes, raw logs,
candidate counters and verification results are retained here. Instrumentation is
logging only; diagnostic elapsed times are not performance measurements. The
time-managed stop branch remains inactive in this fixed-depth check. This verifies
the accounting correction and untimed search identity, not actual deadline changes,
speed, timeout reduction or Elo. Hosted6.4.7 match evidence does not transfer.

No production source or Git state was modified by this diagnostic. Candidate
instrumentation, frozen export and original6.4.7 evidence remain separate.
