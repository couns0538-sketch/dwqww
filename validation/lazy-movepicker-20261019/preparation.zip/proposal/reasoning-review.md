# Lazy MovePicker check masks: unapplied proposal

This proposal changes only `src/search.cpp` and has not been applied, compiled or measured. The source basis is legal-witness commit `82cd2c24062d07cbacbe5b722b6ec0b718981abd`; reviewed HEAD `8954d5d92f19792a064785647e4b0f72e8123cbf` has the same MovePicker. A separate qsearch `gives_check` guard deferral touches a different block and does not change this proof.

## Minimal change

Move the exact six assignments and their side/king/occupancy queries out of the constructor into `init_check_squares()`. Call it at the entry of `generate_quiets()` and `generate_evasions()`. The existing zero-initialized seven-element array stays unchanged; no new flag, member, branch, ordering policy or scoring expression is introduced. No mask is read before initialization.

## Control-flow proof (base source lines)

| Constructor route | Reachable chain | Mask initialization |
| --- | --- | --- |
| Main, not in check | MainTT (optional) -> GenerateCaptures -> GoodCaptures -> Killer1 -> Killer2 -> CounterMove -> GenerateQuiets -> QuietMoves -> BadCaptures | Once if GenerateQuiets is reached with skip_quiets=false, otherwise zero |
| Quiescence, not in check | QsTT (optional) -> QsGenerate -> QsCaptures -> terminal return | Zero |
| Any mode, in check | EvasionTT (optional) -> EvasionGenerate -> Evasions -> terminal return | Once if EvasionGenerate is reached, otherwise zero |

Constructor route selection is at 277–279. The optional TT stage increments only to its own family's generation stage. Main GenerateQuiets advances unconditionally to QuietMoves at 338–340; even a later change to skip_quiets cannot revisit generation. EvasionGenerate advances to Evasions at 369–371. Each terminal family returns rather than falling through to another family. Thus the two generators are mutually exclusive and each executes at most once per picker. The precise claim is zero-or-one initialization, not one initialization for every picker.

`direct_check` at 413–415 is the only array reader, and its only callers are quiet scoring at 470 and noncapture/nonpromotion evasion scoring at 487. TT returns, capture scoring, SEE selection, killers and counter-move filtering do not read it. Both calls are preceded by the new helper. The array's NoPieceType slot remains zero as before.

## Board-state and scoring proof

Masks depend only on side to move, enemy king square and occupancy. The picker retains a const reference to the current Worker's Board, not a cached child board. Before another `next`, qsearch restores its move at 773, ProbCut at 940, and main search at 1074; abort checks follow unmake. Main singular verification at 1012 searches the same parent without making a parent move and restores its own descendants. Null-move searches restore before main picker construction. `Board::unmake_move` restores side, king squares, pieces, captures, promotions, en passant and castling (696 onward). Each Worker searches a Board passed by value. Generation, legality/check queries and attack lookups are reads of that restored state.

Consequently the deferred helper computes the same mask values as the constructor for every actual consumer. The same pseudo-legal buffer, quiet/evasion history queries, +12000 check bonus, capture/promotion formulas, TT/killers/counter exclusions, selection/sort comparator and tie behavior remain in the same order. History may change during recursion, but its scoring queries were already deferred to generation and remain there.

## Independent static review and limits

A separate read-only reviewer (`/root/match_forensics/github_readonly_access`) independently checked all consumers, disjoint stage chains, the three search callers and restoration paths against HEAD8954d5d. No source-level blocker found. This is a source-level equivalence argument under the engine's existing Board restoration invariant, not a runtime test or proof against unrelated pre-existing undefined behavior.

If adopted after the current two experiments finish: apply to the next isolated candidate, run the full current CTest suite and exact one-thread cold/warm node/score/PV/bestmove parity, including checked TT evasions, capture-only quiescence, killer/counter returns and skipped quiet generation. Preserve all failures. Runtime correctness, compiler output and speed remain untested; shared-VM calibration cannot establish a small whole-engine gain, and no Elo claim follows from this proposal.
