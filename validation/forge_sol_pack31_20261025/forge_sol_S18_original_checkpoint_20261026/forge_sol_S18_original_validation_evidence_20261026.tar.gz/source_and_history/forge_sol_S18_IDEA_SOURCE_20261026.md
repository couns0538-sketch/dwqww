# S18 idea sources — 2026-10-26

Idea sources only: the user-supplied S18 threshold-sweep specification, its f006-recipe rework note, the supplied training logs and current Forge HCE material-phase definition. No other engine implementation, tuned constant or network is copied or adopted.

The existing S16 filter/record codec is reused unchanged under its original filenames and full SHA256 pins. The new histogram, boundary protection and finite data-case glue are independently written. Phase weights are read from the supplied Forge header rather than guessed. Training preparation reuses the original v3b main/reader/targets/optimizer source and existing sealed-Torch loading workflow; no NNUE architecture or optimizer change is made.
