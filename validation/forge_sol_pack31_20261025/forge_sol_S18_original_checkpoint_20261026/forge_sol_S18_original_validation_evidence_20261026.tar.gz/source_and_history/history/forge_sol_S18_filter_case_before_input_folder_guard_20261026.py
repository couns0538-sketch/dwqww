"""One finite S18 threshold data case, using the unchanged S16 CLI."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import sys
import time
from types import ModuleType

HERE=Path(__file__).resolve().parent
TOOL=HERE/'forge_sol_datafilter_v2_20261026.py'
TOOL_SHA='5dd0c009566bc5a8c8e06300a8541c5d130d458ca75266a432d1477d1d156332'

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def members(group):
    found=[]
    for path in Path('/proc').glob('[0-9]*/stat'):
        try:
            fields=path.read_text().rsplit(')',1)[1].split()
            if int(fields[2])==group:found.append(int(path.parent.name))
        except (ProcessLookupError,FileNotFoundError):pass
    return found

def child_setup():
    os.sched_setaffinity(0,{4});os.nice(19)
    resource.setrlimit(resource.RLIMIT_AS,(1073741824,1073741824))

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute-data',action='store_true')
    p.add_argument('--sample',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    p.add_argument('--threshold',type=int,choices=(200,400,500),required=True);a=p.parse_args()
    if not a.execute_data:p.error('explicit data-only execution flag required')
    if sha(TOOL)!=TOOL_SHA:raise ValueError('S16 source pin changed')
    out=a.out.absolute()
    if not out.is_relative_to('/tmp') or '..' in out.parts or any(x.is_symlink() for x in (out,*out.parents)):
        raise ValueError('new nonsymlink /tmp output required')
    guard=ModuleType('forge_sol_S18_output_guard');guard.__file__=str(TOOL)
    exec(compile(TOOL.read_bytes(),str(TOOL),'exec'),guard.__dict__)
    if guard._protected(out) or guard._protected(out.resolve()):raise ValueError('protected output directory')
    sample=a.sample.resolve(strict=True);paths=sorted(sample.glob('*.pos'))+sorted(sample.glob('*.hce'))
    before={path.name:sha(path) for path in paths}
    out.mkdir(exist_ok=False);scratch=out/'scratch';scratch.mkdir();output=out/'sealed'
    args=[sys.executable,'-B',str(TOOL),'--train',*[str(sample/n) for n in ('t00000.pos','t01000.pos','t02000.pos','t03000.pos')],
          '--holdout-pos',str(sample/'h000.pos'),'--hce-dir',str(sample),'--out',str(output),'--work-dir',str(scratch),
          '--seed','20261025','--diagnostic-mode','--disagreement-threshold',str(a.threshold)]
    result={'status':'RUNNING','scope':'S18 synthetic data preparation only','args':args,'threshold':a.threshold,'filter_seed':20261025,
            'controller_sha256':sha(__file__),'S16_source_sha256':TOOL_SHA,'inputs_before':before,
            'cpu':4,'nice':19,'maximum_seconds':120,'child_RLIMIT_AS_bytes':1073741824,'training_performed':False}
    child=None;start=time.monotonic()
    try:
        with (out/'forge_sol_S18_filter_20261026.stdout').open('xb') as so,(out/'forge_sol_S18_filter_20261026.stderr').open('xb') as se:
            child=subprocess.Popen(args,stdin=subprocess.DEVNULL,stdout=so,stderr=se,start_new_session=True,preexec_fn=child_setup,
                env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
            result['pid']=child.pid;child.wait(timeout=120)
        result['returncode']=child.returncode
        if child.returncode!=0 or (out/'forge_sol_S18_filter_20261026.stderr').stat().st_size:raise ValueError('filter did not finish cleanly')
        summary=output/'forge_sol_datafilter_summary_20261026.json';s=json.loads(summary.read_text())
        if s['totals']['input']!=200000 or s['totals']['kept']+s['totals']['dropped']!=200000:
            raise ValueError('200k input accounting mismatch')
        if s['supplied_holdout_overlap']!=0 or s['output_duplicate_positions']!=0 or s['production_eligible'] or s['sealed_for_training']:
            raise ValueError('diagnostic output isolation/approval mismatch')
        if s['disagreement_threshold']!=a.threshold or s['seed']!=20261025:raise ValueError('wrong threshold/seed')
        after={path.name:sha(path) for path in paths}
        if before!=after or sha(TOOL)!=TOOL_SHA:raise ValueError('input/source changed')
        result.update(status='PASS_DIAGNOSTIC_DATA',summary=s,summary_sha256=sha(summary),inputs_after=after,
            outputs={path.name:{'sha256':sha(path),'bytes':path.stat().st_size,'readonly':not bool(path.stat().st_mode&0o222)} for path in sorted(output.iterdir()) if path.is_file()})
        if not all(x['readonly'] for x in result['outputs'].values()) or list(scratch.iterdir()):raise ValueError('unsealed output or leftover scratch')
    except BaseException as error:
        result.update(status='FAIL',failure=repr(error));raise
    finally:
        if child is not None:
            if child.poll() is None:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=3)
            result.update(returncode=child.returncode,remaining_owned_group=members(child.pid))
            if result['remaining_owned_group']:result['status']='FAIL_OWNED_GROUP_REMAINS'
        result['elapsed_seconds']=time.monotonic()-start
        result['peak_child_RSS_KiB']=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
        (out/'forge_sol_S18_filter_case_result_20261026.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'status':result['status'],'counts':result.get('summary',{}).get('totals'),'threshold':a.threshold},sort_keys=True))
    return int(result['status']!='PASS_DIAGNOSTIC_DATA')

if __name__=='__main__':raise SystemExit(main())
