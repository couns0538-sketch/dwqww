"""Read-only threshold-arm histograms; no Torch, trainer or engine execution."""
from __future__ import annotations
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
from types import ModuleType

HERE=Path(__file__).resolve().parent
CODEC=HERE/'forge_sol_datafilter_v2_20261026.py'
CODEC_SHA='5dd0c009566bc5a8c8e06300a8541c5d130d458ca75266a432d1477d1d156332'
source=CODEC.read_bytes()
if hashlib.sha256(source).hexdigest()!=CODEC_SHA:raise ValueError('S16 codec source changed')
codec=ModuleType('forge_sol_S18_pinned_codec');codec.__file__=str(CODEC)
exec(compile(source,str(CODEC),'exec'),codec.__dict__)
DATE='20261026'
THRESHOLDS=(200,300,400,500)

def sha(path):
    digest=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1048576),b''):digest.update(block)
    return digest.hexdigest()

def phase_definition(path):
    data=Path(path).read_text();maxima=re.findall(r'constexpr\s+int\s+MaxPhase\s*=\s*([0-9]+)\s*;',data)
    arrays=re.findall(r'constexpr\s+std::array<int,\s*7>\s+PhaseValue\s*\{([0-9,\s]+)\}\s*;',data)
    if len(maxima)!=1 or len(arrays)!=1:raise ValueError('one exact current Forge phase definition required')
    weights=[int(x.strip()) for x in arrays[0].split(',')];maximum=int(maxima[0])
    if len(weights)!=7 or maximum<=0 or weights[0]!=0:raise ValueError('invalid phase weights')
    return {'maximum':maximum,'weights':weights,'source_sha256':sha(path),'meaning':'current Forge HCE material phase, clamped at MaxPhase; no new evaluation value'}

def new_histogram():
    return {'rows':0,'phase':{},'piece_count':{},'white_result':{},'stm_result':{},'score_sign':{},'absolute_score_band':{},
            'disagreement':{str(t):{} for t in THRESHOLDS}}

def bump(mapping,key):
    key=str(key);mapping[key]=mapping.get(key,0)+1

def observe(hist,row,phase):
    if codec.invalid_reason(row):raise ValueError('invalid record in histogram input')
    pieces=material=0
    for byte in row.board:
        for code in (byte&15,byte>>4):
            if code:
                pieces+=1;material+=phase['weights'][(code-1)%6+1]
    white=row.meta>>1;stm=2-white if row.meta&1 else white
    value=abs(row.score)
    band='lt200' if value<200 else ('200to299' if value<300 else ('300to399' if value<400 else ('400to499' if value<500 else 'ge500')))
    hist['rows']+=1;bump(hist['phase'],min(material,phase['maximum']));bump(hist['piece_count'],pieces)
    bump(hist['white_result'],white);bump(hist['stm_result'],stm);bump(hist['score_sign'],'negative' if row.score<0 else ('positive' if row.score>0 else 'zero'))
    bump(hist['absolute_score_band'],band)
    for threshold in THRESHOLDS:bump(hist['disagreement'][str(threshold)],codec.disagreement(row,threshold) or 'consistent')

def describe_files(files,phase):
    hist=new_histogram()
    for path in files:
        path=Path(path);hce=path.with_suffix('.hce')
        for row in codec.read_records(path,hce if hce.exists() else None):observe(hist,row,phase)
    return hist

def combined(histograms):
    result=new_histogram()
    for hist in histograms:
        result['rows']+=hist['rows']
        for field in ('phase','piece_count','white_result','stm_result','score_sign','absolute_score_band'):
            for key,value in hist[field].items():result[field][key]=result[field].get(key,0)+value
        for threshold in map(str,THRESHOLDS):
            for key,value in hist['disagreement'][threshold].items():
                target=result['disagreement'][threshold];target[key]=target.get(key,0)+value
    return result

def checked_manifest(folder):
    manifest=folder/('forge_sol_datafilter_manifest_'+DATE+'.md5');declared={}
    for line in manifest.read_text().splitlines():
        match=re.fullmatch(r'([0-9a-f]{32})  ([^/\\]+)',line)
        if not match or match[2] in declared or match[2] in ('.','..'):raise ValueError('bad original MD5 manifest entry')
        path=folder/match[2]
        if path.is_symlink() or not path.is_file() or codec.md5(path)!=match[1]:raise ValueError('original manifest digest mismatch')
        if path.stat().st_mode&0o222:raise ValueError('unsealed original arm file')
        declared[match[2]]=match[1]
    if set(declared)!={p.name for p in folder.iterdir() if p.is_file() and p!=manifest}:raise ValueError('original manifest does not cover exact file set')
    return {'sha256':sha(manifest),'entries':len(declared),'file_md5':declared}

def describe_arm(folder,sample,phase):
    folder,sample=Path(folder),Path(sample);proof=checked_manifest(folder)
    summary_file=folder/('forge_sol_datafilter_summary_'+DATE+'.json');summary=json.loads(summary_file.read_text())
    for name,digest in summary['outputs'].items():
        if Path(name).name!=name or codec.md5(folder/name)!=digest:raise ValueError('summary output digest mismatch')
    training=sorted(sample.glob('t*.pos'))
    if not training:raise ValueError('original training sample files missing')
    original={path.stem:path for path in training}
    input_files=[*training,*(p.with_suffix('.hce') for p in training),sample/'h000.pos',sample/'h000.hce']
    before={p.name:sha(p) for p in input_files}
    for name,digest in summary['input_md5'].items():
        if Path(name).name!=name or codec.md5(sample/name)!=digest:raise ValueError('arm original input digest mismatch')
    if summary['production_eligible'] or summary['sealed_for_training'] or summary['supplied_holdout_overlap']!=0 or summary['output_duplicate_positions']!=0:
        raise ValueError('unexpected diagnostic arm isolation/approval')
    input_hist=describe_files(training,phase);kept=describe_files(sorted(folder.glob('*.pos')),phase)
    readers={};reasons={};reason_counts=Counter()
    try:
        readers={stem:codec.Reader(path,path.with_suffix('.hce')) for stem,path in original.items()}
        ledger=folder/('forge_sol_S16_removals_'+DATE+'.jsonl');seen=set()
        with ledger.open(encoding='utf-8') as stream:
            for line in stream:
                entry=json.loads(line);stem,index=entry['stem'],entry['row']
                if stem not in readers or type(index) is not int or (stem,index) in seen:raise ValueError('invalid or duplicate removal ledger location')
                seen.add((stem,index));row=readers[stem].row(index);digest,_=codec.identity(row)
                if digest.hex()!=entry['position_sha256']:raise ValueError('removal ledger position hash mismatch')
                reason=entry['reason']
                if reason.startswith('result_') and codec.disagreement(row,summary['disagreement_threshold'])!=reason:
                    raise ValueError('removal ledger reason disagrees with original score/result')
                observe(reasons.setdefault(reason,new_histogram()),row,phase);reason_counts[reason]+=1
    finally:
        for reader in readers.values():reader.close()
    dropped=combined(reasons.values());expected=Counter()
    for shard in summary['shards']:expected.update(shard['dropped'])
    if reason_counts!=expected or input_hist['rows']!=summary['totals']['input'] or kept['rows']!=summary['totals']['kept'] or dropped['rows']!=summary['totals']['dropped']:
        raise ValueError('original arm accounting/histogram mismatch')
    if combined([kept,dropped])!=input_hist:raise ValueError('kept+dropped histograms do not reconstruct original input')
    if before!={p.name:sha(p) for p in input_files} or checked_manifest(folder)!=proof:raise ValueError('input/arm changed during description')
    return {'scope':'synthetic supplied sample data pipeline only','threshold':summary['disagreement_threshold'],'filter_seed':summary['seed'],
        'phase_definition':phase,'input':input_hist,'kept':kept,'dropped':dropped,'dropped_per_reason':reasons,
        'all_histograms_reconcile':True,'dedupe':{'input_position_overlap':summary['input_position_overlap'],
            'output_duplicate_positions':summary['output_duplicate_positions'],'conflicting_label_duplicates':summary['conflicting_label_duplicates'],
            'dropped_reason_counts':dict(reason_counts)},'supplied_holdout_overlap':summary['supplied_holdout_overlap'],
        'authentic_game_overlap':'UNVERIFIED_NO_GAME_IDS','real013014':'UNVERIFIED_ABSENT',
        'source_summary_sha256':sha(summary_file),'source_output_manifest':proof,'original_sample_sha256':before,
        'training_performed':False,'source_inputs_unchanged':True}

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--arm',type=Path,required=True)
    parser.add_argument('--sample',type=Path,required=True);parser.add_argument('--phase-header',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True);args=parser.parse_args()
    if args.out.exists():parser.exit(1,'output must be a new file\n')
    out=args.out.absolute()
    if ('..' in out.parts or any(p.is_symlink() for p in (out,*out.parents)) or
            codec._protected(out) or codec._protected(out.resolve()) or not out.parent.is_dir()):
        parser.exit(1,'new nonprotected output with existing parent required\n')
    if any(out.resolve().is_relative_to(source.resolve(strict=True)) for source in (args.arm,args.sample)):
        parser.exit(1,'output must be outside original arm/sample directories\n')
    result=describe_arm(args.arm,args.sample,phase_definition(args.phase_header))
    with out.open('x') as stream:json.dump(result,stream,indent=2,sort_keys=True);stream.write('\n')
    out.chmod(0o444);print(json.dumps({'rows':result['kept']['rows'],'threshold':result['threshold'],'status':'PASS_HISTOGRAMS'}))

if __name__=='__main__':main()
