# S18 source/data checkpoint — 2026-10-26

S18 is **not complete**. Source preparation and five successful new filter invocations are preserved. The registered t500 repeat failed at120 seconds; its partial data remains UNSEALED. No final DATA_READY index, training run, postscore or loss table is claimed. The lead agent paused further heavy work while S10 continues.

| Arm | Input | Kept | Dropped | Evidence |
|---|---:|---:|---:|---|
| none | 200000 | 200000 | 0 | Reuse original S16 full OFF pipeline; binary files equal input exactly; no additional run |
| t200 | 200000 | 132421 | 67579 | Two complete runs; all11 output files identical |
| t300 | 200000 | 157666 | 42334 | Reuse S16 first/repeat full-pipeline evidence; no additional run |
| t400 | 200000 | 175673 | 24327 | Two complete runs; all11 output files identical |
| t500 | 200000 | 187141 | 12859 | First run complete; registered repeat TIMEOUT/FAIL, equality UNVERIFIED |

All completed arms use unchanged S16 v2 SHA256 `5dd0c009566bc5a8c8e06300a8541c5d130d458ca75266a432d1477d1d156332`, filter seed20261025 and the original four synthetic shards. Outputs are diagnostic only. Real013/014 and authentic game IDs are absent; no production approval is inferred. Original h000.pos/hce remain unfiltered with MD5 `b263af9969f8ace979e25db061eb37ef` / `f248959bc791424407a37af5ac60752a`.

The failed t500 repeat exited−9 after120.133951752 seconds, with no remaining owned group. It has three POS/HCE pairs and a partial removal ledger; no final summary or MD5 manifest exists. No database inspection, resumption or reconstruction was performed. File presence does not prove a pair is complete. Timing cause and exact processing phase remain UNDETERMINED. Previous observed durations23/27,26/58 and77seconds show variability but do not establish its cause; the failed controller retained no per-PID CPU/scheduling telemetry. Child raw stdout/stderr, structured supervisor failure, partial outputs and SQLite main/WAL/SHM are preserved. The supervisor's outer console traceback was returned by the execution tool but was not captured in its own raw file; it is not reconstructed here. Nothing rescues that failed attempt.

The new read-only histogram tool uses the existing codec and reads material-phase weights from the supplied Forge header. It can produce phase, piece-count, WHITE/STM result, score-band and per-threshold disagreement histograms; removal reasons and kept/dropped counts must reconcile with original inputs. It verifies the original arm MD5 manifest and row identities. Its13 tests pass, including five new RED/GREEN controls protecting baseline and input directories. Histograms for the full200k arms are **UNVERIFIED_NOT_RUN** because the coordinator paused heavy work. No values were fabricated.

The separate CPU trainer runner is SOURCE-ONLY. Its latest14 AST/stdlib dry checks pass without importing Torch or NumPy; original v3b reader/targets/training loop and QA optimizer remain unchanged. It uses the observed f006 settings (H256 residual, bs8192, displayed lr7.07e−4, warmup300, blend-end0.6, seed25), with the explicit epoch48→2/deviceCPU/sample-data exceptions. Missing old settings remain unknown; current inherited defaults are labelled as such. All small arms remain in warmup; these are pipeline checks. Native trainer validation at bs8192 covers49152/50000 rows and drops848; it is never relabelled full50000.

Before any training outcome, a separate post-training metric was preregistered: the final epoch2 checkpoint only, all50000 original h000 rows, batches6×8192+848, row-weighted FP64 SSE/50000 for net and HCE at blends1/.6/.8. It reuses original forward/targets without weight/optimizer/export updates, and checks model/checkpoint/input/RNG state. This postscore has **NOT RUN**. No Torch runtime, actual staging, GPU operation or engine experiment has run for S18. The old150-second Torch failure remains separate and failed.

The exact next action is the UNRUN protocol in `forge_sol_S18_NEXT_DIAGNOSTIC_UNRUN_20261026.json`. The lead agent must first release a safe resource window. One new, separately named finite case can then observe per-PID CPU/scheduling/blocking/output progress; it must preserve the original timeout. Failed SQLite evidence may be inspected only after copying main+WAL+SHM, verifying original hashes, and querying the copy. No blind retry, budget relaxation or source modification has been performed here. After data qualification, collect the still-unrun histograms and validate the final arm index. Actual training/postscore still require a separate root grant.

This is a recoverable SOURCE/DATA checkpoint, not a completed-job delivery or remote-publication claim. No job count, accepted lock, network or engine code changed. Original S16/S17 artifacts remain unchanged.
