import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT))
import forge_sol_datafilter_v2_20261026 as codec
tool=None;path=ROOT/'forge_sol_S18_describe_20261026.py'
if path.exists():
    spec=importlib.util.spec_from_file_location('s18_describe',path);tool=importlib.util.module_from_spec(spec);spec.loader.exec_module(tool)

class Describe(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(tool,'S18 histogram tool missing')
        self.root=Path(tempfile.mkdtemp(prefix='forge_sol_S18_fixture_',dir=ROOT));self.sample=self.root/'sample';self.sample.mkdir();self.work=self.root/'scratch';self.work.mkdir()
        self.header=self.root/'eval.hpp';self.header.write_text('constexpr int MaxPhase = 10;\nconstexpr std::array<int, 7> PhaseValue{0, 0, 2, 3, 5, 7, 0};\n')
    def tearDown(self):
        if hasattr(self,'root'):
            for p in self.root.rglob('*'):
                if p.is_file():p.chmod(0o600)
            shutil.rmtree(self.root)
    def row(self,tag=0,score=-300,meta=4):
        board=bytearray(32);board[0]=6;board[31]=12<<4
        square=8+tag;board[square//2]|=2<<(4*(square%2))
        return codec.Record(bytes(board),score,meta,27)
    def shard(self,stem,records):
        path=self.sample/(stem+'.pos');codec.write_records(path,path.with_suffix('.hce'),records);return path
    def arm(self,threshold=300):
        train=self.shard('t00000',[self.row(0,-300,4),self.row(1,10,4),self.row(2,300,2),self.row(3,300,5)])
        hold=self.shard('h000',[self.row(10,0,2)])
        out=self.root/'arm';codec.filter_data([train],[hold],self.sample,out,threshold=threshold,work_dir=self.work)
        return out
    def test_phase_weights_are_read_from_own_header(self):
        phase=tool.phase_definition(self.header);self.assertEqual(phase['weights'],[0,0,2,3,5,7,0]);self.assertEqual(phase['maximum'],10)
        h=tool.new_histogram();tool.observe(h,self.row(),phase)
        self.assertEqual(h['phase'],{'2':1});self.assertEqual(h['piece_count'],{'3':1})
    def test_ambiguous_or_missing_phase_definition_rejected(self):
        self.header.write_text('constexpr int MaxPhase=24;\nconstexpr int MaxPhase=24;\n')
        with self.assertRaises(ValueError):tool.phase_definition(self.header)
    def test_white_result_is_converted_to_STM_before_disagreement(self):
        h=tool.new_histogram();phase=tool.phase_definition(self.header)
        for r in [self.row(0,-300,4),self.row(1,300,2),self.row(2,300,5)]:tool.observe(h,r,phase)
        self.assertEqual(h['disagreement']['300'],{'result_win_score_negative':1,'result_draw_score_large':1,'result_loss_score_positive':1})
    def test_full_kept_and_reason_histograms_reconcile_input(self):
        arm=self.arm();report=tool.describe_arm(arm,self.sample,tool.phase_definition(self.header))
        self.assertEqual((report['input']['rows'],report['kept']['rows'],report['dropped']['rows']),(4,1,3))
        self.assertTrue(report['all_histograms_reconcile']);self.assertEqual(report['supplied_holdout_overlap'],0)
    def test_modified_sealed_output_rejected_by_original_manifest(self):
        arm=self.arm();p=next(arm.glob('*.pos'));p.chmod(0o600);p.write_bytes(p.read_bytes()[:-1]+b'\x05');p.chmod(0o444)
        with self.assertRaisesRegex(ValueError,'manifest|digest'):tool.describe_arm(arm,self.sample,tool.phase_definition(self.header))
    def test_unfiltered_holdout_read_without_filtering(self):
        self.arm();p=self.sample/'h000.pos';before=p.read_bytes()
        h=tool.describe_files([p],tool.phase_definition(self.header))
        self.assertEqual(h['rows'],1);self.assertEqual(p.read_bytes(),before)
    def test_dropped_ledger_wrong_position_hash_rejected(self):
        arm=self.arm();p=arm/'forge_sol_S16_removals_20261026.jsonl';p.chmod(0o600)
        lines=p.read_text().splitlines();row=json.loads(lines[0]);row['position_sha256']='0'*64;lines[0]=json.dumps(row,sort_keys=True);p.write_text('\n'.join(lines)+'\n');p.chmod(0o444)
        summary=arm/'forge_sol_datafilter_summary_20261026.json';s=json.loads(summary.read_text());s['outputs'][p.name]=codec.md5(p)
        summary.chmod(0o600);summary.write_text(json.dumps(s,indent=2,sort_keys=True)+'\n');summary.chmod(0o444)
        # Update only a NEW fixture's manifest to isolate semantic ledger checking.
        q=arm/'forge_sol_datafilter_manifest_20261026.md5';q.chmod(0o600)
        q.write_text(''.join(codec.md5(x)+'  '+x.name+'\n' for x in sorted(arm.iterdir()) if x!=q));q.chmod(0o444)
        with self.assertRaisesRegex(ValueError,'position|ledger'):tool.describe_arm(arm,self.sample,tool.phase_definition(self.header))
    def test_two_descriptions_equal_and_inputs_unchanged(self):
        arm=self.arm();before={p.name:p.read_bytes() for p in arm.iterdir()};phase=tool.phase_definition(self.header)
        self.assertEqual(tool.describe_arm(arm,self.sample,phase),tool.describe_arm(arm,self.sample,phase))
        self.assertEqual(before,{p.name:p.read_bytes() for p in arm.iterdir()})
    def test_histogram_cli_refuses_protected_output_before_writing(self):
        arm=self.arm();protected=self.root/'baseline';protected.mkdir();out=protected/'new.json'
        result=subprocess.run([sys.executable,'-B',str(path),'--arm',str(arm),'--sample',str(self.sample),
                               '--phase-header',str(self.header),'--out',str(out)],capture_output=True,timeout=10)
        self.assertNotEqual(result.returncode,0);self.assertFalse(out.exists())
    def test_filter_case_refuses_protected_output_before_creating_directory(self):
        protected=self.root/'baseline';protected.mkdir();out=protected/'new_case'
        result=subprocess.run([sys.executable,'-B',str(ROOT/'forge_sol_S18_filter_case_20261026.py'),
            '--execute-data','--sample',str(self.sample),'--out',str(out),'--threshold','200'],capture_output=True,timeout=10)
        self.assertNotEqual(result.returncode,0)
        self.assertFalse(out.exists(),'protected directory must not receive even failure metadata')
    def test_histogram_cli_does_not_add_file_to_original_arm(self):
        arm=self.arm();out=arm/'new_histogram.json'
        result=subprocess.run([sys.executable,'-B',str(path),'--arm',str(arm),'--sample',str(self.sample),
            '--phase-header',str(self.header),'--out',str(out)],capture_output=True,timeout=10)
        self.assertNotEqual(result.returncode,0);self.assertFalse(out.exists())
    def test_histogram_cli_does_not_add_file_to_original_sample(self):
        arm=self.arm();out=self.sample/'new_histogram.json'
        result=subprocess.run([sys.executable,'-B',str(path),'--arm',str(arm),'--sample',str(self.sample),
            '--phase-header',str(self.header),'--out',str(out)],capture_output=True,timeout=10)
        self.assertNotEqual(result.returncode,0);self.assertFalse(out.exists())
    def test_filter_case_does_not_add_output_folder_to_original_sample(self):
        out=self.sample/'new_case'
        result=subprocess.run([sys.executable,'-B',str(ROOT/'forge_sol_S18_filter_case_20261026.py'),
            '--execute-data','--sample',str(self.sample),'--out',str(out),'--threshold','200'],capture_output=True,timeout=10)
        self.assertNotEqual(result.returncode,0);self.assertFalse(out.exists())

if __name__=='__main__':unittest.main()
