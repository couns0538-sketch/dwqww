"""Read-only comparison of ONE completed diagnostic against old t500_first.
No filter, SQL, failed-partial inspection, training or engine execution.
"""
from collections import Counter
import hashlib
import importlib.util
import json
from pathlib import Path
import stat
import sys

PREP=Path('/tmp/forge_sol_S18_instrument_prep_20261026')
OLD=Path('/tmp/forge_sol_S18_data_20261026/t500_first/sealed')
NEWROOT=Path('/tmp/forge_sol_S18_instrument_case_new_20261026')
NEW=NEWROOT/'sealed'
OUT=Path('/tmp/forge_sol_S18_instrument_outer_new_20261026')

def digests(path):
    a=hashlib.sha256();b=hashlib.md5()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(65536),b''):a.update(block);b.update(block)
    return {'sha256':a.hexdigest(),'md5':b.hexdigest(),'bytes':path.stat().st_size,'readonly':not bool(path.stat().st_mode&0o222)}

def manifests(root):
    entries={}
    for line in (root/'forge_sol_datafilter_manifest_20261026.md5').read_text().splitlines():
        h,n=line.split('  ',1)
        if n in entries or Path(n).name!=n or len(h)!=32:raise ValueError('unsafe/duplicate manifest row')
        entries[n]=h
    if set(entries)!={p.name for p in root.iterdir()}-{'forge_sol_datafilter_manifest_20261026.md5'}:raise ValueError('MD5 inventory mismatch')
    return entries

def main():
    receipt=json.loads((NEWROOT/'forge_sol_S18_instrument_result_20261026.json').read_text())
    if receipt['status']!='DIAGNOSTIC_PROCESS_EXITED' or receipt['returncode']!=0 or receipt['acceptance']:
        raise ValueError('normal closed non-acceptance producer required')
    if not receipt['leader_reaped'] or receipt['all_owned_group_members_after_close'] or not receipt['child_streams_fully_drained']:
        raise ValueError('unclosed producer')
    if list((NEWROOT/'scratch').iterdir()):raise ValueError('scratch not empty')
    names={p.name for p in NEW.iterdir()}
    if len(names)!=11 or names!={p.name for p in OLD.iterdir()}:raise ValueError('eleven-file inventory mismatch')
    pairs={}
    oldmd5=manifests(OLD);newmd5=manifests(NEW)
    for name in sorted(names):
        if (NEW/name).is_symlink() or (OLD/name).is_symlink():raise ValueError('output symlink')
        a=digests(OLD/name);b=digests(NEW/name)
        if a!=b or not a['readonly']:raise ValueError('file byte hash/size/seal mismatch: '+name)
        if name in oldmd5 and (a['md5']!=oldmd5[name] or b['md5']!=newmd5[name]):raise ValueError('manifest MD5 mismatch')
        pairs[name]={'original':a,'new':b,'identical':True}
    summary=json.loads((NEW/'forge_sol_datafilter_summary_20261026.json').read_text())
    if summary['totals']!={'input':200000,'kept':187141,'dropped':12859}:raise ValueError('actual counts differ from first reference')
    if summary['seed']!=20261025 or summary['disagreement_threshold']!=500:raise ValueError('configuration mismatch')
    if summary['supplied_holdout_overlap']!=0 or summary['output_duplicate_positions']!=0:raise ValueError('diagnostic overlap/dedupe issue')
    if summary['production_eligible'] or summary['sealed_for_training']:raise ValueError('synthetic output approval changed')
    codec=PREP/'forge_sol_datafilter_20261025.py'
    if digests(codec)['sha256']!='6ccf78c864c44155cea22044fe05d0584bec5241acdc5ebb2b71e23886007ab3':raise ValueError('reader source pin changed')
    spec=importlib.util.spec_from_file_location('S18_unchanged_record_reader',codec)
    module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
    headercounts={};reasons=Counter()
    for row in summary['shards']:
        stem=row['stem']+'_filtered_20261026'
        with module.Reader(NEW/(stem+'.pos'),NEW/(stem+'.hce')) as reader:count=reader.n
        if count!=row['kept'] or count+row['dropped_total']!=row['input'] or sum(row['dropped'].values())!=row['dropped_total']:
            raise ValueError('paired POS/HCE header/shard accounting mismatch')
        headercounts[row['stem']]=count;reasons.update(row['dropped'])
    if sum(headercounts.values())!=187141 or sum(reasons.values())!=12859:raise ValueError('header/reason totals mismatch')
    samples=[]
    for line in (NEWROOT/'forge_sol_S18_diagnostic_telemetry_20261026.jsonl').open():samples.append(json.loads(line))
    if any(b['monotonic_ns']<=a['monotonic_ns'] for a,b in zip(samples,samples[1:])):raise ValueError('nonmonotonic sample timestamps')
    own=[r['owned_child'] for r in samples if r['owned_child'].get('identity_verified')]
    cpu=[c['stat']['value']['utime_ticks']+c['stat']['value']['stime_ticks'] for c in own]
    if any(b<a for a,b in zip(cpu,cpu[1:])):raise ValueError('decreasing own CPU ticks')
    sched=[c['schedstat']['value'] for c in own if c.get('schedstat',{}).get('available')]
    result={'schema':'forge-S18-completed-diagnostic-comparison-v1','status':'PASS_READONLY_SYNTHETIC_OUTPUT_COMPARISON',
      'producer_session_id':82744,'producer_receipt_sha256':digests(NEWROOT/'forge_sol_S18_instrument_result_20261026.json')['sha256'],
      'original_failed_repeat_status':'FAIL_UNCHANGED','diagnostic_acceptance':False,'training_approval':False,'real013014_and_authentic_games':'UNVERIFIED',
      'original':str(OLD),'new':str(NEW),'all_11_files_byte_identical':True,'all_10_MD5_manifest_rows_verified':True,
      'paired_POS_HCE_headers_valid':True,'paired_header_counts':headercounts,'totals':summary['totals'],'dropped_reasons':dict(reasons),
      'supplied_synthetic_holdout_overlap':summary['supplied_holdout_overlap'],'synthetic_output_duplicate_positions':summary['output_duplicate_positions'],
      'file_comparisons':pairs,'telemetry_summary':{'samples':len(samples),'all_samples_owned_identity':len(own)==len(samples),
      'first_elapsed_seconds':samples[0]['elapsed_seconds'],'last_elapsed_seconds':samples[-1]['elapsed_seconds'],
      'last_cpu_ticks':cpu[-1],'SC_CLK_TCK':receipt['clock_ticks_per_second'],
      'last_sample_CPU_seconds':cpu[-1]/receipt['clock_ticks_per_second'],
      'last_schedstat':sched[-1] if sched else None,
      'current_cgroup_available_counts':{n:sum(bool(r['cgroup'].get(n,{}).get('available')) for r in samples) for n in ['cpu.stat','cpu.pressure','memory.pressure','io.pressure']},
      'causal_conclusion':'UNDETERMINED; these observations describe the new case only and do not explain the original timeout'},
      'writes':'NEW comparison JSON and stdout log only; no original/sealed/scratch/failed input writes'}
    q=OUT/'forge_sol_S18_completed_t500_comparison_20261026.json'
    with q.open('x') as stream:json.dump(result,stream,indent=2,sort_keys=True);stream.write('\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ['file_comparisons']},sort_keys=True))

if __name__=='__main__':main()
