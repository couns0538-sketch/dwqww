import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent
TOOL=Path('/tmp/forge_sol_S17_work_20261026/forge_sol_S17_gamesplit_20261026.py')
source_sha=hashlib.sha256(TOOL.read_bytes()).hexdigest()
protocol=ROOT/'forge_sol_S17_actual916_protocol_20261026.json'
result={'status':'RUNNING','tool_sha256':source_sha,'protocol_sha256':hashlib.sha256(protocol.read_bytes()).hexdigest(),
        'controller_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'cases':[],
        'no_engine_or_training':True,'authentic_game_overlap':'UNVERIFIED_NO_GAME_IDS','real013014':'UNVERIFIED_ABSENT'}

def child_setup():
    os.sched_setaffinity(0,{4});os.nice(19)
    resource.setrlimit(resource.RLIMIT_AS,(1073741824,1073741824))

def members(group):
    values=[]
    for path in Path('/proc').glob('[0-9]*/stat'):
        try:
            fields=path.read_text().rsplit(')',1)[1].split()
            if int(fields[2])==group:values.append(int(path.parent.name))
        except (FileNotFoundError,ProcessLookupError):pass
    return values

try:
    for label in ('first','repeat','with_sealed'):
        args=[sys.executable,'-B',str(TOOL),'--config',str(ROOT/('forge_sol_S17_'+label+'_config_20261026.json')),'--diagnostic-mode']
        stdout=ROOT/('forge_sol_S17_'+label+'_actual_20261026.stdout');stderr=stdout.with_suffix('.stderr')
        row={'case':label,'argv':args,'cpu':4,'nice':19,'timeout_seconds':120};child=None;start=time.monotonic()
        try:
            with stdout.open('xb') as so,stderr.open('xb') as se:
                child=subprocess.Popen(args,stdin=subprocess.DEVNULL,stdout=so,stderr=se,start_new_session=True,preexec_fn=child_setup,
                    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
                row['pid']=child.pid
                child.wait(timeout=120)
        finally:
            if child is not None:
                if child.poll() is None:
                    os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=3)
                row.update(returncode=child.returncode,remaining_group_members=members(child.pid))
            row['elapsed_seconds']=time.monotonic()-start
            row['raw']={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in (stdout,stderr)}
            result['cases'].append(row)
        if row['returncode']!=0 or stderr.stat().st_size or row['remaining_group_members']:
            raise RuntimeError('failed actual case '+label)
        out=ROOT/('output_'+label);summary=json.loads((out/'forge_sol_S17_summary_20261026.json').read_text())
        assert summary['groups']==12 and summary['input_rows']==916
        assert summary['cross_split_defined_groups']==summary['cross_split_position_overlap']==0
        assert not summary['game_overlap_verified'] and not summary['training_approved'] and not summary['HCE_values_invented']
        assert summary['binary_output_status']=='UNVERIFIED_MISSING_HCE'
        assert summary['retained_rows']+summary['dropped_rows']==916
        row['summary']=summary
        row['outputs']={p.name:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'md5':hashlib.md5(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size,'mode':oct(p.stat().st_mode&0o777)} for p in sorted(out.iterdir()) if p.is_file()}
        assert all(item['mode']=='0o444' for item in row['outputs'].values())
        if label=='with_sealed':assert summary['sealed_manifest']['files']==5 and summary['sealed_manifest']['records']==158582
    assert result['cases'][0]['outputs']==result['cases'][1]['outputs']
    assert hashlib.sha256(TOOL.read_bytes()).hexdigest()==source_sha
    result.update(status='PASS_DIAGNOSTIC_DEFINED_GROUP_SPLIT',first_repeat_all_files_byte_identical=True,
        peak_child_RSS_KiB=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,tool_unchanged=True)
except BaseException as error:
    result.update(status='FAIL',failure=repr(error));raise
finally:
    (ROOT/'forge_sol_S17_actual916_result_20261026.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(result['status'])
