# Forge S11 closed baseline evidence audit, 2026-10-26

FAIL_AUDIT

Read-only audit: 18 checks passed, 1 issues. The actual 77 source files and 12 artifacts match; the new baseline oracle compile/link map is bound to the original archive and actual searched source. No archive search object is pulled; the real archive NNUE object is pulled.

FIRST, full 14-test Std and four known diagnostics remain explicitly REUSE_NOT_NEW_RUN; there is no new main build, FIRST, full Std or JUnit. New raw typed T1/T2 UCI and object/scoped/whole-ELF FMA0 evidence, EOF/exit and owned cleanup were checked. No compiler or engine was run by this audit.

Million-position parity, active candidate results, speed, Elo and publication are outside this audit. Historical system-header byte identity remains UNVERIFIED.

Issues: ["TypeError: 'NoneType' object is not subscriptable"]

Audit JSON SHA256: `bb54ca68b9eb409ac973164c5cb2d1fa089f0c657583791c8ed6b753c9a2c693`.
