# S11 B candidate closed Release audit

PASS_CLOSED_B_RELEASE_BUILD_FIRST_FULL_AUDIT. 152 checks passed; 0 issues.

Actual source/artifact closure, original fresh bare11, five fixed benches, both perft5, typed T1/T2, full15 JUnit zero failures/exact prior known4 and all FMA0 scopes checked. No native work executed by this audit. ASAN/parity/speed/Elo outside scope. JSON SHA256: `252510bf7441863fdbc93bf291594ff5815993465a43e51ad025f903b74ac427`.
