# Forge S11 closed baseline audit v3, 2026-10-26

PASS_CLOSED_BASELINE_REUSE_AND_NEW_LIGHT_AUDIT. 163 read-only checks passed; 0 issues.

Actual 77 source files, 12 artifacts and seven archive members match. The newly compiled baseline oracle uses the pinned actual search.cpp, strict Release flags and closed observed compiler argv; its map pulls archive NNUE and excludes archive search. FIRST, five fixed benches, both perft5 references and full14 Std with four known lines remain REUSE_NOT_NEW_RUN. Fresh typed T1/T2 UCI and object/scoped/whole-ELF FMA0 raw captures, EOF, exit and owned cleanup are verified.

No compiler, engine or timing was run by this audit. Earlier audit-only schema errors (stdin=null and GNU ar long-name /0) remain preserved. Candidate, million parity, speed/Elo and publication are outside scope; historical system-header byte identity remains UNVERIFIED.

Audit JSON SHA256: `64eb673b89e05aabc553ee1add689c0b58b0517e4a122c2414f85f8b3975bfea`.
