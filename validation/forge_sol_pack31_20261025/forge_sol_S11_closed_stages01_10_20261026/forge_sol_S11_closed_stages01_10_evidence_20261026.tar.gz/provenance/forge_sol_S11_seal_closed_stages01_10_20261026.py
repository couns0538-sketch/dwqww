"""One-off S11 data-only checkpoint using the existing S10 archive workflow.

No engine/compiler/native test is launched. Originals are retained. This is
not a new native controller; the only child is the old owned GNU tar decoder.
"""
from pathlib import Path
import gzip, hashlib, importlib.util, io, json, os, tarfile
from types import ModuleType

S10 = Path('/workspace/forge-pack24-20261026/S10_delivery_20261026/forge_sol_S10_seal_evidence_20261026.py')
NATIVE = Path('/tmp/forge_sol_S11_native_20261026')
OPERATOR = Path('/tmp/forge_sol_S11_operator_recovery_20261026')
OUTPUT = Path('/tmp/forge_sol_S11_closed_stages01_10_checkpoint_20261026')
LEDGER = OPERATOR / 'forge_sol_S11_closed_stages01_10_ledger_frozen_20261026.jsonl'
SNAPSHOT = OPERATOR / 'forge_sol_S11_closed_stages01_10_operator_snapshot_20261026.json'
LEDGER_SHA = '131eadf663b2e807fc820c588bb20fe3cbc985bab597ebbe2d97086b4806a4bf'
SNAPSHOT_SHA = '3438ebdbb4e067255dcf65751d9fa5ccc92db1b5b612910c0fee61a41fa501ff'
PREFIX = 'forge_sol_S11_closed_stages01_10'

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''): h.update(block)
    return h.hexdigest()

def require(ok, message):
    if not ok: raise ValueError(message)

def json_new(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n'); stream.flush(); os.fsync(stream.fileno())

def compiled_reason(path):
    with path.open('rb') as stream: magic = stream.read(4)
    if magic == b'\x7fELF': return magic, 'ELF executable/object bytes, regardless of filename suffix'
    if magic == b'!<ar': return magic, 'ar archive bytes, regardless of filename suffix'
    if magic[:2] == b'MZ': return magic, 'PE executable/object container bytes'
    if magic in (b'BC\xc0\xde', b'\xde\xc0\x17\x0b'): return magic, 'LLVM compiled bitcode bytes'
    if magic[:2] == b'PK' or magic[:2] == b'\x1f\x8b' or magic in (b'\xfd7zX', b'7z\xbc\xaf', b'(\xb5/\xfd'):
        return magic, 'compressed/archive bytes excluded from data-only payload'
    if path.suffix.lower() in ('.o','.obj','.a','.lib','.exe','.dll','.so','.pch','.gch','.pyc','.tar','.gz','.xz','.zip','.7z','.zst'):
        return magic, 'compiled artifact, compiler cache or archive filename'
    return magic, None

def main():
    require(sorted(os.sched_getaffinity(0)) == [4] and os.getpriority(os.PRIO_PROCESS, 0) == 19, 'CPU4 nice19 required')
    require(not OUTPUT.exists() and OUTPUT.resolve() == OUTPUT, 'new literal output only')
    require(sha(LEDGER) == LEDGER_SHA and sha(SNAPSHOT) == SNAPSHOT_SHA, 'root-frozen stage10 boundary changed')
    closed = [json.loads(line) for line in LEDGER.read_text().splitlines()]
    require([row['stage'] for row in closed] == list(range(1,11)), 'exact ten closed ledger rows required')
    require(all(row['status'].startswith('PASS') and sha(row['result']) == row['sha256'] for row in closed), 'stage result hash/status differs')
    frozen = json.loads(SNAPSHOT.read_text())
    granted_path = OPERATOR / 'forge_sol_S11_operator_granted_sequence_20261026.json'
    require(sha(granted_path) == frozen['granted_sequence_sha256'], 'granted sequence changed')
    granted = json.loads(granted_path.read_text())
    roots = [Path(row['output_path']) for row in granted['steps'] if row['index'] <= 10]
    require(len(roots) == 10 and all(p.is_relative_to(NATIVE) and p.resolve() == p for p in roots), 'wrong closed stage roots')
    require(all(Path(row['result']).parent == roots[index] for index,row in enumerate(closed)), 'closed result/root mismatch')
    spec = importlib.util.spec_from_file_location('s11_reused_s10_archive', S10)
    old = importlib.util.module_from_spec(spec); spec.loader.exec_module(old)
    require(old.digest(old.CONTROLLER) == old.CONTROLLER_SHA, 'S10 frozen owned helper changed')
    helper = ModuleType('s11_checkpoint_reuses_s10_owned_commands'); helper.__file__ = str(old.CONTROLLER)
    exec(compile(old.CONTROLLER.read_bytes(),str(old.CONTROLLER),'exec'), helper.__dict__)
    deps = json.loads(helper.DEPENDENCIES.read_text())
    net = helper.load_checked(deps['ctest'],'ctest'); shared = helper.load_checked(deps['subreaper'],'subreaper')
    OUTPUT.mkdir(); snapshots = OUTPUT / 'metadata_snapshots'; snapshots.mkdir()
    rows, excluded, original_pins = [], [], {}

    def include(path, member, provenance=None):
        require(path.is_file() and not path.is_symlink(), 'regular payload required: '+str(path))
        require(not Path(member).is_absolute() and '..' not in Path(member).parts, 'unsafe archive name')
        magic, reason = compiled_reason(path)
        item = {'original':str(path),'member':member,'bytes':path.stat().st_size,'sha256':sha(path),'first_four_hex':magic.hex()}
        if provenance: item['snapshot_source'] = provenance
        if reason:
            item.update(classification='EXCLUDED_BUT_HASH_BOUND',reason=reason); excluded.append(item)
        else: rows.append(item)

    for index,root in enumerate(roots,1):
        for path in sorted(root.rglob('*')):
            require(not path.is_symlink(), 'unexpected evidence symlink: '+str(path))
            if not path.is_file(): continue
            relative = path.relative_to(root)
            selected = old.selected(relative) or ('build' in relative.parts and path.name == 'forge_sol_S11_materialkey_oracle.map')
            magic, reason = compiled_reason(path)
            if selected or reason:
                include(path, f'stage_{index:02d}_{root.name}/'+relative.as_posix())

    # Snapshot only explicit stable operator metadata. The active ledger is never read.
    for path in sorted(OPERATOR.iterdir()):
        if path.name == 'forge_sol_S11_operator_stage_ledger_20261026.jsonl': continue
        if path.is_file() and path.suffix in ('.json','.jsonl','.md'):
            raw = path.read_bytes(); original_pins[str(path)] = {'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
            target = snapshots / path.name
            with target.open('xb') as stream: stream.write(raw); stream.flush(); os.fsync(stream.fileno())
            include(target, 'operator/'+path.name, provenance=str(path))

    # Original reused FIRST/full Std and numeric raw wrappers, without old binaries.
    for base in ('Lprime','B'):
        reuse = json.loads((NATIVE/(base+'_baseline_Release_reuse_oracle_once_20261026')/'forge_sol_S11_baseline_reuse_result_20261026.json').read_text())['evidence']
        for kind,path in [('current_known4_FULL_FIRST',Path(reuse['original_receipt'])),('numeric_original_receipt',Path(reuse['fixed_gates']['original_receipt']))]:
            include(path, 'original_reused/'+base+'/'+kind+'/'+path.name)
        for gate in reuse['fixed_gates']['fixed_gates']:
            path = Path(gate['raw_stdout_wrapper']); include(path, 'original_reused/'+base+'/numeric_raw/'+path.name)
    include(Path(__file__), 'provenance/'+Path(__file__).name)
    include(S10, 'provenance/'+S10.name)
    require(rows and len({r['member'] for r in rows}) == len(rows), 'empty or duplicate payload map')
    mapping = {'schema':'forge.S11.closed_stages_data_only.v1','scope':'CLOSED stages01-10 only; ASAN stage11+ and parity/speed not included',
        'frozen_ledger_sha256':LEDGER_SHA,'operator_snapshot_sha256':SNAPSHOT_SHA,'closed_stages':closed,
        'publication_scope':'Selected original data payloads INCLUDED; compiled artifacts EXCLUDED_BUT_HASH_BOUND. Never all original files included.',
        'payload_files':len(rows),'payload_bytes':sum(r['bytes'] for r in rows),'files':rows,
        'excluded_compiled_artifacts':excluded,'excluded_but_hash_bound_count':len(excluded),'excluded_but_hash_bound_bytes':sum(r['bytes'] for r in excluded),
        'operator_snapshot_originals':original_pins,'active_ledger':'NOT_READ_NOT_ARCHIVED; use root-frozen ten-row ledger only',
        'all_originals_retained':True,'new_native_tests':0,'workflow':'Existing S10 deterministic gzip6/PAX + Python and owned GNU exact member proofs'}
    map_path = OUTPUT/(PREFIX+'_mapping_20261026.json'); json_new(map_path,mapping)
    expected = {r['member']:{'sha256':r['sha256'],'bytes':r['bytes']} for r in rows}
    expected[map_path.name] = {'sha256':sha(map_path),'bytes':map_path.stat().st_size}
    archive = OUTPUT/(PREFIX+'_evidence_20261026.tar.gz')
    with archive.open('xb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0,compresslevel=6) as gz,tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as tar:
        for item in [{'original':str(map_path),'member':map_path.name,'bytes':map_path.stat().st_size,'sha256':sha(map_path)},*rows]:
            require(sha(item['original']) == item['sha256'] and Path(item['original']).stat().st_size == item['bytes'], 'input changed before archive')
            info = tarfile.TarInfo(item['member']); info.size=item['bytes']; info.mode=0o444; info.mtime=0
            with Path(item['original']).open('rb') as stream: tar.addfile(info,stream)
    archive_sha = sha(archive); decoded = {}
    with tarfile.open(archive,'r:gz') as tar:
        for item in tar.getmembers():
            require(item.isreg() and item.name in expected and item.name not in decoded, 'unexpected archive member')
            h=hashlib.sha256(); size=0
            with tar.extractfile(item) as stream:
                for block in iter(lambda:stream.read(1<<20),b''):h.update(block);size+=len(block)
            decoded[item.name]={'sha256':h.hexdigest(),'bytes':size}
    require(decoded == expected, 'Python decoder differs from original bytes')
    restore = OUTPUT/(PREFIX+'_GNU_roundtrip_20261026'); restore.mkdir()
    commands = helper.guarded_commands(net,shared,OUTPUT,net.ResourceGuard(),180)
    commands.run(['/usr/bin/tar','--no-same-owner','--no-same-permissions','-xzf',str(archive),'-C',str(restore)],'GNU_tar_decode')
    actual = {str(p.relative_to(restore)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(restore.rglob('*')) if p.is_file()}
    require(not any(p.is_symlink() for p in restore.rglob('*')) and actual == expected, 'GNU decoder differs from original bytes')
    for item in rows+excluded:
        require(sha(item['original']) == item['sha256'] and Path(item['original']).stat().st_size == item['bytes'], 'original changed after encoding')
    for path,item in original_pins.items():require(sha(path)==item['sha256'] and Path(path).stat().st_size==item['bytes'], 'stable operator source changed')
    require(sha(archive)==archive_sha, 'archive changed')
    receipt = {'status':'PASS_LOSSLESS_ENCODING_ONLY','scope':mapping['scope'],'archiver_sha256':sha(__file__),'reused_S10_archiver_sha256':sha(S10),
        'archive':{'path':str(archive),'sha256':archive_sha,'bytes':archive.stat().st_size},'mapping':{'path':str(map_path),'sha256':sha(map_path),'bytes':map_path.stat().st_size},
        'payload_files':len(rows),'payload_bytes':mapping['payload_bytes'],'archive_members':len(expected),'excluded_but_hash_bound_count':len(excluded),'excluded_but_hash_bound_bytes':mapping['excluded_but_hash_bound_bytes'],
        'python_decoder':'PASS_ALL_MEMBER_BYTES','GNU_decoder':'PASS_ALL_MEMBER_BYTES','GNU_commands':commands.records,'all_originals_retained_unchanged':True,'new_engine_compiler_native_test_runs':0,'cpu':sorted(os.sched_getaffinity(0)),'nice':os.getpriority(os.PRIO_PROCESS,0)}
    receipt_path=OUTPUT/(PREFIX+'_archive_receipt_20261026.json');json_new(receipt_path,receipt)
    print(json.dumps(receipt,indent=2),flush=True)

if __name__=='__main__':main()
