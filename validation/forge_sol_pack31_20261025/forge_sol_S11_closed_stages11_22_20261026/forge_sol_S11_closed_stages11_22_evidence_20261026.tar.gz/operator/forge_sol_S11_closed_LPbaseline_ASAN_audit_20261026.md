# S11 LP baseline ASAN stages 11–13 audit

PASS_CLOSED_LP_BASELINE_ASAN_STAGES11_13_AUDIT. 154 read-only checks passed; 0 issues.

Fresh full O2/g strict ASan+UBSan source/target/link recipes and actual FIRST bare11 verified. Effective LeakSanitizer ON, UBSan halt and unlimited runtime virtual AS are receipt-bound; operator closed records identify escaped launches. Original d11, perft4 both, typed T1/T2, full JUnit14 with no failures/exact known4, FMA0, raw sanitizer diagnostics and owned cleanup pass.

No native action was executed by this audit. Candidate ASAN and later work remain outside scope. First10 checkpoint remains untouched. Escaped caller attribution comes from the parent operator record, not an independent host sandbox probe. JSON SHA256: `ad1c18336d5af53b5b0509c3fd82427d57973740a07d1e704fcbfb100d978395`.
