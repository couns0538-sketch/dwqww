# S18 none-only smoke — 2026-10-27

Overall original status is **FAIL_S18_TRAINING**, unchanged. The sole granted case ran once; the other four arms remain HELD. No retry or past-failure rescue occurred. Producer session18302, actual child PID/group273895, CPU4/nice19. Source469f341a, indexfb5d2575 and grantd756f327 were verified and recorded before launch; original parent stdout/stderr were opened before execution.

The original trainer completed two epochs /48 optimizer steps, returned0, saved its local epoch artifacts, and completed the separate full50000-row postscore. It emitted MAIN_RETURN and both Torch atexit markers. The observer recorded child return0, no observer error/deadline stop, normal leader reaping and an empty owned group. The strict resource guard nevertheless recorded `RSS_UNAVAILABLE: ValueError: owned VmRSS unavailable`, so the controller marked the arm FAIL. Raw status at that exact unavailable observation was not captured. Its cause is UNDETERMINED; an exiting `/proc` transition is a hypothesis to investigate separately, not a finding about this original case.

Observer elapsed97.931741756seconds. Maximum sampled owned RSS581804032bytes; actual child peak568004KiB. Minimum sampled free /tmp space13161267200bytes. Parent and child stderr are both empty. Limits stayed300s work/360s hard,4GiB AS,3GiB sampled RSS and6.5GiB free-disk floor; none was changed during/after the run.

Original native FINAL FULL evaluates49152rows and drops848. Its raw six-decimal net/HCE losses are:

| Blend | Native net | Native HCE |
|---|---:|---:|
|1.0|0.021841|0.021840|
|0.6|0.045537|0.045537|
|0.8|0.023707|0.023707|

Separate preregistered weighted postscore covers ALL50000rows in6x8192+848, with FP64 per-row SSE divided by50000:

| Blend | Net | HCE |
|---|---:|---:|
|1.0|0.02186266321728358|0.021862312406668114|
|0.6|0.04558630099854697|0.04558598687997589|
|0.8|0.023746301048879447|0.02374596858268229|

A read-only audit re-executed only the frozen stdlib endpoint validator on these ORIGINAL closed artifacts. It passed all row/tail/blend/finite-loss/checkpoint/source/protocol/holdout/state/RNG identity checks, with postscore updates0/exports0. No Torch/model/targets/scoring recomputation ran. This separate contract pass does not relabel the original failed smoke. The trained final epoch2 checkpoint SHA is399a47fd3782b796e1c3f2dfac1df84f3d2ccbc6c94f9e36f4deaa7535e062bc; before/after RNG SHA is2f9abfca3682ce6db124c25f1c23901500e7de8feb20181a0a11d4e017cc4e0b.

All original-source/accepted-network/trainer/helper/grant/index fingerprints and all independent copied inputs remain unchanged. Original h000 POS MD5b263af9969f8ace979e25db061eb37ef and HCE MD5f248959bc791424407a37af5ac60752a are exact. Exports stayed in NEW trainer-run; accepted weights were not installed or changed. These are synthetic pipeline diagnostics, with real013/014/authentic game isolation UNVERIFIED and no training-quality or Elo claim.

Next action: source-only investigation of the RSS observer limitation, optionally one tiny NEW own non-Torch/non-engine child under the parent's separate diagnostic authorization. Preserve this failure and all original scripts/results, add a minimal reviewed successor only after demonstrating the observer limitation, and obtain a fresh grant before any later Torch work.
