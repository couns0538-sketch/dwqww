"""Read closed ORIGINAL failed-smoke artifacts only; never rerun or rescue it."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

ROOT=Path('/tmp/forge_sol_S18_TRAIN_RUN_20261026/none_smoke_v2_new_20261026')
OUT=Path('/tmp/forge_sol_S18_none_smoke_outer_new_20261027')
SOURCE=Path('/tmp/forge_sol_S18_TRAIN_SMOKE_V2_PREP_20261026/forge_sol_S18_train_selected_v2_20261026.py')

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    if sha(SOURCE)!='469f341ac5b5d1a3859c8bc9ad3815757bf93d048ba24ff30413e84010433b35':raise ValueError('frozen consumer changed')
    spec=importlib.util.spec_from_file_location('S18_original_closed_endpoint_validator',SOURCE)
    tool=importlib.util.module_from_spec(spec);spec.loader.exec_module(tool)
    r=json.loads((ROOT/'forge_sol_S18_training_result_20261026.json').read_text());arm=r['arms']['none']
    child=json.loads((ROOT/'none'/'child_result.json').read_text())
    closure=json.loads((ROOT/'none'/'forge_sol_S18_owned_resource_receipt_20261026.json').read_text())
    if r['status']!='FAIL_S18_TRAINING' or arm['status']!='FAIL':raise ValueError('original failed status unexpectedly changed')
    if closure['returncode']!=0 or not closure['leader_reaped'] or closure['all_owned_group_members_after_close']:
        raise ValueError('normal closed child artifacts required for read-only endpoint audit')
    if child['work_complete'] is not True or child['trainer_returncode']!=0:raise ValueError('actual trainer work did not complete')
    full=tool.validate_postscore_result(child['separate_post_training_all50000'],ROOT/'none'/'trainer-run',200000,ROOT/'none'/'data')
    native=tool.native_final_metric((ROOT/'none'/'stdout').read_text())
    current_pins=tool.verify_pins()
    all_input_checks={path:tool.fingerprint(path)==meta for path,meta in r['inputs_before'].items()}
    copied=json.loads((ROOT/'copied_views.json').read_text())['none']['inventory']
    copied_checks={path:tool.fingerprint(path)==meta for path,meta in copied.items()}
    if not all(all_input_checks.values()) or not all(copied_checks.values()):raise ValueError('original or independent-copy input changed')
    events=arm['observer']['phase_events'];first=events[0]['monotonic_ns'];markers=[]
    for row in events:
        if row['event'] in ['BOOT','S18_TRAINER_MAIN_BEGIN','S18_TRAINER_MAIN_DONE','S18_POSTSCORE_BEGIN','S18_POSTSCORE_DONE','S18_TRAIN_AND_POSTSCORE_DONE','MAIN_RETURN','PY_ATEXIT_BEFORE_TORCH','PY_ATEXIT_AFTER_TORCH']:
            markers.append({**row,'seconds_since_BOOT':(row['monotonic_ns']-first)/1e9})
    result={'schema':'forge-S18-closed-failed-none-smoke-audit-v1','status':'PASS_READONLY_POSTSCORE_CONTRACT_ONLY',
      'overall_smoke_status_UNCHANGED':'FAIL_S18_TRAINING','arm_status_UNCHANGED':'FAIL','producer_session_id':18302,
      'producer_pid':closure['pid'],'frozen_consumer_sha256':sha(SOURCE),'original_controller_result_sha256':sha(ROOT/'forge_sol_S18_training_result_20261026.json'),
      'original_child_result_sha256':sha(ROOT/'none'/'child_result.json'),'original_owned_receipt_sha256':sha(ROOT/'none'/'forge_sol_S18_owned_resource_receipt_20261026.json'),
      'root_grant_sha256':r['inputs_before']['/tmp/forge_sol_S18_TRAIN_GRANTS_20261027/forge_sol_S18_none_smoke_v2_root_grant_20261027.json']['sha256'],
      'training':{'epochs':2,'steps':arm['total_steps'],'rows':arm['rows'],'steps_per_epoch':arm['steps_per_epoch'],'native_trainer_returncode':child['trainer_returncode'],
        'native_raw_metric':native,'exports':'Original trainer wrote local per-epoch .pt/.inc/.bin/.json in NEW trainer-run only; no accepted network installed'},
      'separate_weighted_full50000':full,'endpoint_audit':'Frozen v2 endpoint function rechecked closed original artifacts read-only; no Torch/model/targets/postscore recomputation',
      'shutdown':{'child_returncode':closure['returncode'],'leader_reaped':closure['leader_reaped'],'owned_members':closure['all_owned_group_members_after_close'],
        'observer_elapsed_seconds':arm['observer']['elapsed_seconds'],'observer_stop_reason':arm['observer']['stop_reason'],'observer_error':arm['observer']['observer_error'],
        'phase_markers':markers,'resource_guard':arm['RSS_guard'],'peak_child_RSS_KiB':arm['peak_children_RSS_KiB']},
      'controller_recorded_inputs_unchanged':r.get('inputs_unchanged'),'original_input_checks':all_input_checks,'independent_copied_input_checks':copied_checks,
      'source_pin_actual_hashes_after':current_pins,'h000_original_MD5':{s:tool.fingerprint(tool.HOLDOUT/('h000.'+s))['md5'] for s in ['pos','hce']},
      'raw_stderr_bytes':{'parent':(OUT/'forge_sol_S18_none_smoke_parent_original_20261027.stderr').stat().st_size,'child':(ROOT/'none'/'stderr').stat().st_size},
      'Torch_imports_for_audit':int('torch' in sys.modules),'NumPy_imports_for_audit':int('numpy' in sys.modules),
      'historical_guard_failure_cause':'UNDETERMINED: raw status at RSS_UNAVAILABLE was not recorded; an exit transition is only a hypothesis',
      'other_arms':'HELD; not run','real013014_authentic_games':'UNVERIFIED','training_quality_or_Elo_claim':False}
    if result['Torch_imports_for_audit'] or result['NumPy_imports_for_audit']:raise ValueError('audit imported a runtime framework')
    with (OUT/'forge_sol_S18_none_closed_readonly_audit_20261027.json').open('x') as stream:json.dump(result,stream,indent=2,sort_keys=True);stream.write('\n')
    print(json.dumps({'overall_smoke_status':r['status'],'readonly_endpoint':result['status'],'native49152':native,'weighted50000':{'net_MSE':full['net_MSE'],'HCE_baseline_MSE':full['HCE_baseline_MSE']},'shutdown':{k:v for k,v in result['shutdown'].items() if k!='phase_markers'},'input_hash_checks_all':all(all_input_checks.values()) and all(copied_checks.values()),'Torch_imports':0},sort_keys=True))

if __name__=='__main__':main()
