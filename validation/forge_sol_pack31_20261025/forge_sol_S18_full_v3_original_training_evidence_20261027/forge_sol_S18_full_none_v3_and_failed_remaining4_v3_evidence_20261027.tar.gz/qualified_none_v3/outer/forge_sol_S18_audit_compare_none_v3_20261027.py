"""Read-only closed v3 audit and reproducibility comparison; never rerun Torch."""
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

NEW=Path('/tmp/forge_sol_S18_TRAIN_RUN_20261026/none_smoke_v3_new_20261027')
OLD=Path('/tmp/forge_sol_S18_TRAIN_RUN_20261026/none_smoke_v2_new_20261026')
OUT=Path('/tmp/forge_sol_S18_none_smoke_v3_outer_new_20261027')
SOURCE=Path('/tmp/forge_sol_S18_RSS_SCOPE_V3_PREP_20261027/forge_sol_S18_train_selected_v3_20261027.py')

def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(65536),b''):h.update(b)
 return h.hexdigest()

def emitted_losses(path):
 result={'baseline':[],'epoch_summaries':{},'final_native':[],'time_triggered_progress':{}}
 for line in path.read_text().splitlines():
  if line.startswith('BASELINE HCE-alone holdout subset'):result['baseline'].append(line)
  elif line.startswith('FINAL FULL HOLDOUT n='):result['final_native'].append(line)
  elif line.startswith('EPOCH '):
   n=re.match(r'EPOCH ([0-9]+)/([0-9]+)',line)
   if not n or 'train_mse=' not in line:raise ValueError('unrecognized original epoch loss line')
   result['epoch_summaries'][n[1]]=line[line.index('train_mse='):]
  elif line.startswith('ep') and 'train_mse=' in line:
   n=re.search(r'^ep([0-9]+) step ([0-9,]+)/([0-9,]+).*?train_mse=([^ ]+)',line)
   if n:result['time_triggered_progress'][n[1]+':'+n[2].replace(',','')]=n[4]
 return result

def main():
 if sha(SOURCE)!='ab02ac6a4579bf37b3ea65f2bb07c4d5d08a33bd6b19d6130bc3f8d1369f1e76':raise ValueError('frozen v3 consumer changed')
 spec=importlib.util.spec_from_file_location('S18_closed_v3_readonly_validator',SOURCE);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 before_status={label:sha(root/'forge_sol_S18_training_result_20261026.json') for label,root in [('old',OLD),('new',NEW)]}
 old=json.loads((OLD/'forge_sol_S18_training_result_20261026.json').read_text());new=json.loads((NEW/'forge_sol_S18_training_result_20261026.json').read_text())
 if old['status']!='FAIL_S18_TRAINING':raise ValueError('original failed status must stay unchanged')
 if new['status']!='PASS_SELECTED_SYNTHETIC_PIPELINE_ARMS' or new['requested_arms']!=['none'] or new['all_five_arms_completed']:
  raise ValueError('closed none-only success required')
 a=new['arms']['none'];closure=json.loads((NEW/'none'/'forge_sol_S18_owned_resource_receipt_20261026.json').read_text())
 if a['status']!='PASS_PIPELINE_ONLY' or a['observer']['returncode']!=0 or a['observer']['stop_reason'] or a['observer']['observer_error'] or a['RSS_guard']['stop_reason']:
  raise ValueError('unclean observed success')
 if not closure['leader_reaped'] or closure['all_owned_group_members_after_close']:raise ValueError('owned child not closed')
 full={}
 for label,root in [('old',OLD),('new',NEW)]:
  child=json.loads((root/'none'/'child_result.json').read_text())
  full[label]=m.validate_postscore_result(child['separate_post_training_all50000'],root/'none'/'trainer-run',200000,root/'none'/'data')
 native=m.native_final_metric((NEW/'none'/'stdout').read_text())
 pins=m.verify_pins();inputs={p:m.fingerprint(p)==meta for p,meta in new['inputs_before'].items()}
 copies=json.loads((NEW/'copied_views.json').read_text())['none']['inventory'];copied={p:m.fingerprint(p)==meta for p,meta in copies.items()}
 if not all(inputs.values()) or not all(copied.values()):raise ValueError('source/input/copy changed')
 loss={k:emitted_losses(root/'none'/'stdout') for k,root in [('old',OLD),('new',NEW)]}
 checks={key:full['old'][key]==full['new'][key] for key in ['model_state_sha256_before','model_state_sha256_after','Torch_RNG_sha256_before','Torch_RNG_sha256_after','net_MSE','HCE_baseline_MSE','checkpoint_sha256_before','checkpoint_sha256_after']}
 checks.update({key:loss['old'][key]==loss['new'][key] for key in ['baseline','epoch_summaries','final_native']})
 progress_old=loss['old']['time_triggered_progress'];progress_new=loss['new']['time_triggered_progress'];common=set(progress_old)&set(progress_new)
 progress={'old':progress_old,'new':progress_new,'common_ep_step_values_match':all(progress_old[k]==progress_new[k] for k in common),
    'unmatched_old':sorted(set(progress_old)-set(progress_new)),'unmatched_new':sorted(set(progress_new)-set(progress_old)),
    'scope':'Wall-time-triggered progress may differ in alignment; only same epoch/step values are compared. Timing/throughput is not compared.'}
 files={}
 names={p.name for p in (OLD/'none'/'trainer-run').glob('epoch*') if p.is_file()}
 if names!={p.name for p in (NEW/'none'/'trainer-run').glob('epoch*') if p.is_file()}:raise ValueError('epoch artifact inventory differs')
 for name in sorted(names):
  x=OLD/'none'/'trainer-run'/name;y=NEW/'none'/'trainer-run'/name
  files[name]={'old_sha256':sha(x),'new_sha256':sha(y),'identical':sha(x)==sha(y)}
 unchanged={label:sha(root/'forge_sol_S18_training_result_20261026.json')==before_status[label] for label,root in [('old',OLD),('new',NEW)]}
 if not all(unchanged.values()):raise ValueError('original case result changed during comparison')
 r={'schema':'forge-S18-closed-none-v3-audit-and-repro-v1','status':'PASS_CLOSED_NONE_SYNTHETIC_PIPELINE','producer_session_id':98765,'pid':closure['pid'],
  'source_sha256':sha(SOURCE),'original_v2_status_UNCHANGED':old['status'],'new_v3_status':new['status'],'other_arms':'HELD',
  'native49152':native,'separate_weighted50000':full['new'],'read_only_reproducibility':{'exact_checks':checks,'all_exact_checks_match':all(checks.values()),
  'epoch_artifacts':files,'all_epoch_artifacts_byte_identical':all(f['identical'] for f in files.values()),'emitted_fixed_loss_values':loss,'time_triggered_progress':progress,
  'old_and_new_result_files_unchanged':unchanged,'meaning':'Same-seed synthetic pipeline reproducibility only, not quality/strength or old-run reclassification'},
  'closure':closure,'observer':{k:v for k,v in a['observer'].items() if k!='phase_events'},'RSS_guard':a['RSS_guard'],'peak_child_RSS_KiB':a['peak_children_RSS_KiB'],
  'source_pins_actual_after':pins,'original_input_identity_checks':inputs,'independent_copied_input_checks':copied,'controller_inputs_unchanged':new['inputs_unchanged'],
  'stderr_bytes':{'parent':(OUT/'forge_sol_S18_none_v3_parent_original_20261027.stderr').stat().st_size,'child':(NEW/'none'/'stderr').stat().st_size},
  'Torch_imports_for_audit':int('torch' in sys.modules),'NumPy_imports_for_audit':int('numpy' in sys.modules),
  'fallback_note':'This Torch run recorded0 fallback samples; actual fallback activation/enforcement is separately demonstrated by tiny owned controls, not this run.',
  'real013014_authentic_games':'UNVERIFIED','NPS_Elo_or_training_quality_claim':False}
 if r['Torch_imports_for_audit'] or r['NumPy_imports_for_audit']:raise ValueError('read-only audit imported framework')
 with (OUT/'forge_sol_S18_none_v3_closed_audit_repro_20261027.json').open('x') as f:json.dump(r,f,indent=2,sort_keys=True);f.write('\n')
 print(json.dumps({'status':r['status'],'original_v2_status':old['status'],'exact_reproducibility':checks,'all_epoch_artifacts_byte_identical':r['read_only_reproducibility']['all_epoch_artifacts_byte_identical'],'time_triggered_progress':progress,'source_inputs_copies_unchanged':all(inputs.values()) and all(copied.values()),'no_framework_imports':True},sort_keys=True))

if __name__=='__main__':main()
