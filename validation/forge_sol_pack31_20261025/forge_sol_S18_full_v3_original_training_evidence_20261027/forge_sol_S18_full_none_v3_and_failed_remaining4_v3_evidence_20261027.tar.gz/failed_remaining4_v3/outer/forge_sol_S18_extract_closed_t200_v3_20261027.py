"""Read ORIGINAL closed failed t200 artifacts only; no retry/reclassification."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

ROOT=Path('/tmp/forge_sol_S18_TRAIN_RUN_20261026/remaining4_rss_v3_new_20261027')
OUT=Path('/tmp/forge_sol_S18_remaining4_v3_outer_new_20261027')
SOURCE=Path('/tmp/forge_sol_S18_RSS_SCOPE_V3_PREP_20261027/forge_sol_S18_train_selected_v3_20261027.py')

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
 if sha(SOURCE)!='ab02ac6a4579bf37b3ea65f2bb07c4d5d08a33bd6b19d6130bc3f8d1369f1e76':raise ValueError('consumer changed')
 spec=importlib.util.spec_from_file_location('S18_closed_t200_only_validator',SOURCE);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 result_path=ROOT/'forge_sol_S18_training_result_20261026.json';before=sha(result_path);r=json.loads(result_path.read_text())
 if r['status']!='FAIL_S18_TRAINING' or list(r['arms'])!=['t200']:raise ValueError('original stopped failed batch status changed')
 arm=r['arms']['t200'];child=json.loads((ROOT/'t200'/'child_result.json').read_text());closure=json.loads((ROOT/'t200'/'forge_sol_S18_owned_resource_receipt_20261026.json').read_text())
 if closure['returncode']!=0 or not closure['leader_reaped'] or closure['all_owned_group_members_after_close']:raise ValueError('closed natural child required')
 full=m.validate_postscore_result(child['separate_post_training_all50000'],ROOT/'t200'/'trainer-run',132421,ROOT/'t200'/'data')
 native=m.native_final_metric((ROOT/'t200'/'stdout').read_text());pins=m.verify_pins()
 inputs={p:m.fingerprint(p)==v for p,v in r['inputs_before'].items()}
 views=json.loads((ROOT/'copied_views.json').read_text());copies={name:{p:m.fingerprint(p)==v for p,v in view['inventory'].items()} for name,view in views.items()}
 if not all(inputs.values()) or not all(all(v.values()) for v in copies.values()):raise ValueError('original/staged data changed')
 unrun={name:{'events_exists':(ROOT/name/'events.jsonl').exists(),'child_result_exists':(ROOT/name/'child_result.json').exists(),'trainer_run_exists':(ROOT/name/'trainer-run').exists(),'data_staged_only':(ROOT/name/'data').is_dir()} for name in ['t300','t400','t500']}
 if any(v['events_exists'] or v['child_result_exists'] or v['trainer_run_exists'] for v in unrun.values()):raise ValueError('unexpected later arm execution')
 observation=arm['RSS_guard']['last_rss_observation'];raw=observation['leader_status_original']
 extracted=OUT/'forge_sol_S18_t200_unavailable_leader_EXTRACTED_20261027.status'
 with extracted.open('x') as f:f.write(raw)
 fields={line.split(':',1)[0]:line.split(':',1)[1].strip() for line in raw.splitlines() if ':' in line}
 status_fields={k:fields.get(k,'ABSENT') for k in ['Name','State','Tgid','Pid','PPid','TracerPid','Kthread','Threads','VmPeak','VmSize','VmRSS','RssAnon','SigPnd','ShdPnd']}
 rnew={'schema':'forge-S18-closed-failed-t200-audit-v1','status':'PASS_READONLY_POSTSCORE_CONTRACT_ONLY','overall_batch_status_UNCHANGED':'FAIL_S18_TRAINING','producer_session_id':19566,
  'actual_arm':'t200','pid':closure['pid'],'trained_rows':132421,'epochs':2,'steps':arm['total_steps'],'native49152':native,'separate_weighted50000':full,
  'resource_guard':arm['RSS_guard'],'captured_original_unavailable_status_fields':status_fields,'captured_status_extracted_file':extracted.name,'captured_status_bytes_sha256':sha(extracted),
  'status_provenance':'Exact string from ORIGINAL controller JSON last_rss_observation.leader_status_original; not a new /proc observation or reconstructed historical state',
  'resource_failure_scope':'This actual t200 observation was StateR withVmRSS absent. No task status or /proc/stat PF_EXITING snapshot was captured because v3 intentionally rejected unproven live-leader fallback. Exact kernel transition remains unestablished.',
  'closure':closure,'observer':{k:v for k,v in arm['observer'].items() if k!='phase_events'},'original_input_identity_checks':inputs,'all_staged_copy_identity_checks':copies,
  'source_pins_actual_after':pins,'not_run_arms':unrun,'controller_recorded_inputs_unchanged':r.get('inputs_unchanged'),
  'result_sha256_before':before,'result_sha256_after':sha(result_path),'postscore_audit':'Frozen stdlib-only endpoint rechecked actual closed artifacts; no Torch/model/score recomputation',
  'Torch_imports_for_audit':int('torch' in sys.modules),'NumPy_imports_for_audit':int('numpy' in sys.modules),'no_quality_Elo_claim':True,'old_failures':'All retained unchanged'}
 if rnew['Torch_imports_for_audit'] or rnew['NumPy_imports_for_audit'] or before!=rnew['result_sha256_after']:raise ValueError('audit scope/source violation')
 with (OUT/'forge_sol_S18_t200_v3_closed_readonly_audit_20261027.json').open('x') as f:json.dump(rnew,f,indent=2,sort_keys=True);f.write('\n')
 print(json.dumps({k:v for k,v in rnew.items() if k in ['status','overall_batch_status_UNCHANGED','pid','native49152','captured_original_unavailable_status_fields','not_run_arms']},sort_keys=True))
 print(json.dumps({'weighted50000_net':full['net_MSE'],'weighted50000_HCE':full['HCE_baseline_MSE'],'model_state':full['model_state_sha256_after'],'RNG':full['Torch_RNG_sha256_after']},sort_keys=True))

if __name__=='__main__':main()
