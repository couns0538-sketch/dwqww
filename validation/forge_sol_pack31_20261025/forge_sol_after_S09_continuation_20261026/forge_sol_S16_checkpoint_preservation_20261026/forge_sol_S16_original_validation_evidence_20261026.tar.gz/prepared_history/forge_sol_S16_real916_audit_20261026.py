"""Bounded diagnostic audit of supplied real text; all generated rows use test HCE0."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import tempfile
import forge_sol_datafilter_v2_20261026 as tool


def run(source):
    before = hashlib.sha256(source.read_bytes()).hexdigest()
    lines = source.read_text().splitlines()
    assert len(lines) == 916
    temporary = Path(tempfile.mkdtemp(prefix='forge_sol_S16_real916_', dir=Path(__file__).parent))
    try:
        inputs = temporary / 'inputs'; inputs.mkdir()
        text_map = {}; paths = {}; rows_by_stem = {}
        for stem, selected in [('real_t000', lines[:301]), ('real_h000', lines[301:475]), ('real_t001', lines[475:])]:
            records = []
            for line in selected:
                row, _ = tool.text_record(line)
                records.append(tool.Record(row.board, row.score, row.meta, 0))
            p = inputs / (stem + '.pos'); tool.write_records(p, p.with_suffix('.hce'), records)
            assert list(tool.read_records(p, p.with_suffix('.hce'))) == records
            paths[stem] = p; rows_by_stem[stem] = len(records)
            text_map[stem] = inputs / (stem + '.txt')
            text_map[stem].write_text('\n'.join(selected) + '\n')
        train = [paths['real_t000'], paths['real_t001']]; holdout = [paths['real_h000']]
        reports = {}; md5s = {}
        for name, threshold, grouped, expected in [('off', None, False, 742), ('t300', 300, False, 735),
                                                    ('off_groups', None, True, 589), ('t300_groups', 300, True, 582),
                                                    ('t300_groups_repeat', 300, True, 582)]:
            out = temporary / name
            summary = tool.filter_data(list(reversed(train)) if name.endswith('repeat') else train,
                                       holdout, inputs, out, threshold=threshold, work_dir=temporary,
                                       text_map=text_map if grouped else None,
                                       ordered_stems=list(paths) if grouped else None, production=False)
            assert summary['totals']['kept'] == expected
            assert summary['production_eligible'] is False and summary['game_overlap_verified'] is False
            reports[name] = summary
            md5s[name] = {p.name: tool.md5(p) for p in out.iterdir() if p.is_file()}
        assert md5s['t300_groups'] == md5s['t300_groups_repeat']
        after = hashlib.sha256(source.read_bytes()).hexdigest(); assert before == after
        return {'source_sha256_before': before, 'source_sha256_after': after,
                'source_unchanged': True, 'source_rows': 916, 'split_rows': rows_by_stem,
                'HCE': 'QA_TEST_PLACEHOLDER_ZERO_ONLY; actual HCE absent and UNVERIFIED',
                'authentic_game_ids': 'ABSENT; all grouping diagnostic only',
                'real_013_014': 'ABSENT_UNVERIFIED', 'v2_sha256': hashlib.sha256(Path(tool.__file__).read_bytes()).hexdigest(),
                'output_md5': md5s, 'repeat_outputs_identical': True,
                'reports': reports,
                'artifacts': 'Generated diagnostic inputs/outputs deleted from owned temporary directory after validation; original text untouched'}
    finally:
        for p in temporary.rglob('*'):
            if p.is_file(): p.chmod(0o600)
        shutil.rmtree(temporary)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source_text', type=Path)
    args = parser.parse_args()
    print(json.dumps(run(args.source_text), indent=2, sort_keys=True))
