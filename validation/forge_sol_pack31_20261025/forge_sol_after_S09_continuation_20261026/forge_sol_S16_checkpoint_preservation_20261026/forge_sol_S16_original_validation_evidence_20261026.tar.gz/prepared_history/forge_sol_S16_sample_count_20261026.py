"""Read-only count reproduction; does not create filtered shards or SQLite."""
import argparse
import gc
import hashlib
import json
from pathlib import Path
import resource
import forge_sol_datafilter_v2_20261026 as tool


def run(folder):
    tool_sha = hashlib.sha256(Path(tool.__file__).read_bytes()).hexdigest()
    train = [folder / name for name in ['t00000.pos', 't01000.pos', 't02000.pos', 't03000.pos']]
    held = folder / 'h000.pos'
    inputs = train + [held] + [p.with_suffix('.hce') for p in train + [held]]
    before = {p.name: tool.md5(p) for p in inputs}
    holdout = {}
    for row in tool.read_records(held):
        if tool.invalid_reason(row): raise ValueError('invalid sample holdout')
        digest, key = tool.identity(row)
        if digest in holdout and holdout[digest] != key: raise ValueError('hash collision')
        holdout[digest] = key
    reports = {}
    for label, threshold in [('off', None), ('t300', 300)]:
        seen = {}; total = kept = 0; dropped = {}; per_shard = {}
        order = sorted(train, key=lambda p: (tool.hashlib.sha256(('20261025\0' + p.stem).encode()).digest(), p.name))
        for p in order:
            shard_kept = 0
            for row in tool.read_records(p, p.with_suffix('.hce')):
                total += 1; digest, key = tool.identity(row); reason = tool.invalid_reason(row)
                for table in (holdout, seen):
                    if digest in table and table[digest] != key: raise ValueError('hash collision')
                if reason is None and digest in holdout: reason = 'holdout_position'
                if reason is None and digest in seen: reason = 'duplicate_position'
                if reason is None: reason = tool.disagreement(row, threshold)
                if reason: dropped[reason] = dropped.get(reason, 0) + 1
                else: seen[digest] = key; kept += 1; shard_kept += 1
            per_shard[p.stem] = shard_kept
        reports[label] = {'input': total, 'kept': kept, 'dropped': dropped,
                          'dropped_total': total - kept, 'kept_per_shard': per_shard}
        del seen; gc.collect()
    after = {p.name: tool.md5(p) for p in inputs}
    assert before == after, 'sample inputs changed'
    assert reports['off']['kept'] == 200000
    assert reports['t300']['kept'] == 157666
    assert hashlib.sha256(Path(tool.__file__).read_bytes()).hexdigest() == tool_sha
    return {'scope': 'READ_ONLY_COUNT_REPRODUCTION; full 200k v2 output pipeline deferred',
            'v2_sha256': tool_sha, 'base_parser_sha256': tool.BASE_SHA256,
            'synthetic_sample': True, 'input_md5_before': before, 'input_md5_after': after,
            'source_unchanged': True, 'counts': reports,
            'peak_rss_platform_units': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            'real_013_014': 'UNVERIFIED_ABSENT', 'game_overlap': 'UNVERIFIED_NO_GAME_IDS'}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('sample_root', type=Path)
    args = parser.parse_args()
    print(json.dumps(run(args.sample_root), indent=2, sort_keys=True))
