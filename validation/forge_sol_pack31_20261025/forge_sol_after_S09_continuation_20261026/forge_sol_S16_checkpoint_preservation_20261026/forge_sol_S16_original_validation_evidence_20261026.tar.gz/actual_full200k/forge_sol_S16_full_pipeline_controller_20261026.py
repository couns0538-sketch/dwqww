"""Finite S16 qualification; never modifies provided code or input shards."""
import ctypes
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
PROVIDED = ROOT / 'provided'
SAMPLE = Path(sys.argv[1]).resolve(strict=True)
LIMIT = 1024 * 1024 * 1024
PREREG = ROOT / 'forge_sol_S16_full_pipeline_preregistration_20261026.json'
assert not (ROOT / 'forge_sol_S16_full_pipeline_result_20261026.json').exists()
assert ctypes.CDLL(None).prctl(36, 1, 0, 0, 0) == 0


def digest(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(chunk)
    return value.hexdigest()


def members(group):
    rows = []
    for p in Path('/proc').iterdir():
        if not p.name.isdecimal():
            continue
        try:
            fields = (p / 'stat').read_text().rsplit(')', 1)[1].split()
            if int(fields[2]) != group:
                continue
            pages = int((p / 'statm').read_text().split()[1])
            rows.append({'pid': int(p.name), 'state': fields[0], 'rss': pages * os.sysconf('SC_PAGE_SIZE')})
        except (FileNotFoundError, ProcessLookupError):
            continue
    return rows


def child_setup():
    os.sched_setaffinity(0, {4})
    os.nice(19)
    resource.setrlimit(resource.RLIMIT_AS, (LIMIT, LIMIT))


def run(label, argv, env):
    stdout, stderr = ROOT / (label + '.stdout'), ROOT / (label + '.stderr')
    receipt = {'label': label, 'argv': argv, 'cwd': str(PROVIDED), 'timeout_seconds': 600,
               'cpu': 4, 'nice': 19, 'max_observed_group_rss': 0, 'stop_reason': None}
    child = None
    start = time.monotonic()
    try:
        with stdout.open('xb') as so, stderr.open('xb') as se:
            child = subprocess.Popen(argv, cwd=PROVIDED, env=env, stdout=so, stderr=se,
                                     start_new_session=True, preexec_fn=child_setup)
            receipt['pid'] = child.pid
            while child.poll() is None:
                rss = sum(r['rss'] for r in members(child.pid))
                receipt['max_observed_group_rss'] = max(receipt['max_observed_group_rss'], rss)
                if rss > LIMIT or time.monotonic() - start > 600:
                    receipt['stop_reason'] = 'RSS_LIMIT' if rss > LIMIT else 'TIMEOUT'
                    raise RuntimeError(receipt['stop_reason'])
                time.sleep(0.05)
            receipt['returncode'] = child.wait()
    finally:
        if child is not None:
            if child.poll() is None:
                os.killpg(child.pid, signal.SIGTERM)
                try:
                    child.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, signal.SIGKILL)
                    child.wait(timeout=3)
            residual = members(child.pid)
            if residual:
                # This process created only this group; never signal another job.
                os.killpg(child.pid, signal.SIGKILL)
            reaped = []
            while True:
                try:
                    pid, status = os.waitpid(-1, os.WNOHANG)
                    if pid == 0:
                        break
                    reaped.append({'pid': pid, 'status': status})
                except ChildProcessError:
                    break
            receipt['reaped_descendants'] = reaped
            receipt['remaining_group_members'] = members(child.pid)
            receipt['returncode'] = child.returncode
        receipt['elapsed_seconds'] = time.monotonic() - start
        receipt['raw'] = {p.name: {'bytes': p.stat().st_size, 'sha256': digest(p)}
                          for p in (stdout, stderr) if p.exists()}
        (ROOT / (label + '.receipt.json')).write_text(json.dumps(receipt, indent=2) + '\n')
    if receipt.get('returncode') != 0 or receipt.get('remaining_group_members'):
        raise RuntimeError('failed operation ' + label)
    return receipt


inputs = sorted(SAMPLE.glob('*.pos')) + sorted(SAMPLE.glob('*.hce'))
before = {str(p): digest(p) for p in inputs}
source_before = {p.name: digest(p) for p in PROVIDED.iterdir() if p.is_file()}
assert source_before == json.loads(PREREG.read_text())['source_copies']
environment = dict(os.environ, PYTHONDONTWRITEBYTECODE='1',
                   FILTER_TEST_TOOL_PATH=str(PROVIDED / 'forge_sol_datafilter_v2_20261026.py'))
result = {'status': 'IN_PROGRESS', 'preregistration_sha256': digest(PREREG),
          'controller_sha256': digest(__file__), 'sample_is_synthetic': True,
          'real_013_014': 'UNVERIFIED_ABSENT', 'authentic_game_overlap': 'UNVERIFIED_NO_GAME_IDS',
          'runtime': sys.version, 'steps': [], 'source_before': source_before, 'inputs_before': before}
try:
    result['steps'].append(run('forge_sol_S16_all41_repeat_20261026',
        [sys.executable, '-B', '-m', 'unittest', 'discover', '-s', '.', '-p', '*tests*.py', '-v'], environment))
    for label, threshold in [('off', None), ('t300_first', 300), ('t300_repeat', 300)]:
        scratch = ROOT / ('scratch_' + label)
        scratch.mkdir()
        output = ROOT / ('sealed_' + label)
        argv = [sys.executable, '-B', str(PROVIDED / 'forge_sol_datafilter_v2_20261026.py'),
                '--train'] + [str(SAMPLE / name) for name in ('t00000.pos', 't01000.pos', 't02000.pos', 't03000.pos')]
        argv += ['--holdout-pos', str(SAMPLE / 'h000.pos'), '--hce-dir', str(SAMPLE), '--out', str(output),
                 '--work-dir', str(scratch), '--seed', '20261025', '--diagnostic-mode']
        if threshold is not None:
            argv += ['--disagreement-threshold', str(threshold)]
        receipt = run('forge_sol_S16_' + label + '_full200k_20261026', argv, environment)
        summary = json.loads((output / 'forge_sol_datafilter_summary_20261026.json').read_text())
        assert summary['totals'] == {'input': 200000, 'kept': 200000 if threshold is None else 157666,
                                    'dropped': 0 if threshold is None else 42334}
        assert summary['supplied_holdout_overlap'] == 0 and summary['output_duplicate_positions'] == 0
        assert not summary['sealed_for_training'] and not summary['game_overlap_verified']
        assert not list(scratch.iterdir())
        for p in output.iterdir():
            assert p.stat().st_mode & 0o222 == 0, 'output not sealed'
        receipt['summary'] = summary
        receipt['output_sha256'] = {p.name: digest(p) for p in sorted(output.iterdir()) if p.is_file()}
        result['steps'].append(receipt)
    assert result['steps'][-2]['output_sha256'] == result['steps'][-1]['output_sha256'], 'full output/manifest repeat mismatch'
    result['full_repeat_byte_identity'] = True
    result['source_after'] = {p.name: digest(p) for p in PROVIDED.iterdir() if p.is_file()}
    result['inputs_after'] = {str(p): digest(p) for p in inputs}
    assert result['source_after'] == source_before and result['inputs_after'] == before
    result['status'] = 'PASS_DIAGNOSTIC_SYNTHETIC_FULL_PIPELINE'
except BaseException as error:
    result['status'] = 'FAIL'
    result['error'] = repr(error)
    raise
finally:
    (ROOT / 'forge_sol_S16_full_pipeline_result_20261026.json').write_text(json.dumps(result, indent=2) + '\n')
print(result['status'])
