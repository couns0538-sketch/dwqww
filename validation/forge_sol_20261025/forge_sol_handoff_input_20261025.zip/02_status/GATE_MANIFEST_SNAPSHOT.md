# PC gate manifest snapshot (read-only copy, Engine QA)
Source: C:\Users\Administrator\grok-pc\forge_push\autorestart\forge_gates.json on grok-pc, sha256 5BEB6F7887D35BD5F41761ED0841BA695E8C87DDC938AB211C309EC76D1C56FF, read 2026-10-24 ~17:45 Europe/Vienna (CEST). 82 entries, listed in run order.
All post-lock gates: candidate vs h256_e12, fastchess 1.8.2, 10+0.1, Threads 1, Hash 16, OwnBook off, 8moves_v3 book (order=random, srand separates gates), SPRT nElo [0,10] a=b=0.05, cap 1500, no pooling, r4 driver auto-confirm on H1. Gates 12-25 are pre-lock (vs ep10), finished or DROPPED_post_lock_h256.
State at the 17:14 Vienna tick: G88 (e16g90) running at ~609 g, -0.0 +/-12.5, LLR -0.25. G78 e16l ended H0 (-44.5 +/-18.1). G13 h256_e12 vs ep10 = H1 +37.95 (the lock).
Not in the manifest yet, pending Code Review: e24n and e16o net packs (to go right after G90), timepack3 TmDecisiveWin=60 (takes G91's slot; G91 DEC70 then held), P29 run f ep12 blend 0.5 (own gate ahead of o/q nets).

gate | folder | candidate | options | srand | status
12|gate12_packb_epa_vs_ep10|cand_packb_epa|ReSearchAdjust=1 FiftyDamp=1|20261027|done (capped +3.8)
13|gate13_h256_e12_vs_ep10|cand_h256_e12|-|20261028|H1 +37.95 (LOCK)
14|gate14_packa_epa_vs_ep10|cand_packa_epa|NonPawnCorr=1 PawnHist=1|20261029|
13b|gate13b_h256e12_vs_5101c252|cand_h256_e12|-|20261111|
15|gate15_packc_epa_vs_ep10|cand_packc_epa|AspFailHighReduce=1 AspFailHighMaxReduce=3 EvalSwingMult=24 EvalSwingMax=200|20261030|
16|gate16_p7_epa_vs_ep10|cand_p7_epa|LmrCorrThreshold=30|20261031|
17|gate17_timepack_vs_ep10|cand_timepack|TmPlyBonus=6 TmPlyEnd=100 SingleMoveStop=1 SingleMoveDepth=6|20261101|capped -0.0
18-25|ep10-era gates (packa_gateb, packc_p10, packd_p11, int16, packf2_p16a, sol_teacher, packe_cont4, packe_evalstore)|-|-|-|DROPPED_post_lock_h256
26|gate26_h256e16h_vs_h256e12|cand_h256_e16h|-|20261112|-4.2
30|gate30_h256e16j_vs_h256e12|cand_h256_e16j|-|20261116|-11.1
27|gate27_timepack_h256e12_vs_h256e12|cand_timepack_h256e12|TmPlyBonus=6 TmPlyEnd=100 SingleMoveStop=1 SingleMoveDepth=6|20261113|
78|gate78_e16l_vs_h256e12|cand_h256_e16l|-|20261164|H0 -44.5
88|gate88_e16g90_vs_h256e12|cand_h256_e16g90|-|1602516321|RUNNING
89|gate89_e16s_sol_vs_h256e12|cand_h256_e16s_sol|-|1921068996|next
90|gate90_e16m_vs_h256e12|cand_h256_e16m|-|1166240132|
28|gate28_packc_h256_vs_h256e12|cand_packc_h256|AspFailHighReduce=1 AspFailHighMaxReduce=3 EvalSwingMult=24 EvalSwingMax=200|20261114|
34|gate34_packa_w60_vs_h256e12|cand_packa_w60|NonPawnCorr=1 PawnHist=1 NonPawnCorrWeight=60|20261120|
35|gate35_packb_fs20_vs_h256e12|cand_packb_fs20|ReSearchAdjust=1 FiftyDamp=1 FiftyDampenStart=20|20261121|
86|gate86_rfpavg25_vs_h256e12|cand_rfpavg25_h256e12|RfpReturnBlend=25|20261172|
87|gate87_contcorr60_vs_h256e12|cand_contcorr60_h256e12|ContCorrectionWeight=60|20261173|
29|gate29_pawnhist_h256_vs_h256e12|cand_pawnhist_h256|PawnHist=1|20261115|
31|gate31_packe2_ch85_vs_h256e12|cand_packe2_ch85|ContHist4Pct=85|20261117|
32|gate32_packe2_ch70_vs_h256e12|cand_packe2_ch70|ContHist4Pct=70|20261118|
33|gate33_packe2_ch45_vs_h256e12|cand_packe2_ch45|ContHist4Pct=45|20261119|
36|gate36_p11r_k3_vs_h256e12|cand_p11r_k3|FailHighBlend=1 FailHighBlendSoft=3|20261122|
37|gate37_pawnhist_div4_vs_h256e12|cand_pawnhist_div4|PawnHist=1 PawnHistDivisor=4|20261123|
38|gate38_packa_w55_vs_h256e12|cand_packa_w55|NonPawnCorr=1 PawnHist=1 NonPawnCorrWeight=55|20261124|
39|gate39_packa_w65_vs_h256e12|cand_packa_w65|NonPawnCorr=1 PawnHist=1 NonPawnCorrWeight=65|20261125|
40|gate40_packb_fs10_vs_h256e12|cand_packb_fs10|ReSearchAdjust=1 FiftyDamp=1 FiftyDampenStart=10|20261126|
41|gate41_packb_fs40_vs_h256e12|cand_packb_fs40|ReSearchAdjust=1 FiftyDamp=1 FiftyDampenStart=40|20261127|
42|gate42_p11r_k16_vs_h256e12|cand_p11r_k16|FailHighBlend=1 FailHighBlendSoft=16|20261128|
43|gate43_packa_w50_vs_h256e12|cand_packa_w50|NonPawnCorr=1 PawnHist=1 NonPawnCorrWeight=50|20261129|
44|gate44_pawnhist_div1_vs_h256e12|cand_pawnhist_div1|PawnHist=1 PawnHistDivisor=1|20261130|
45|gate45_timepack_v1_vs_h256e12|cand_timepack_v1|TmPlyBonus=8 TmPlyEnd=100 SingleMoveStop=1 SingleMoveDepth=6|20261131|HELD (dropped P13)
46|gate46_timepack_inc90_vs_h256e12|cand_timepack_inc90|TmIncrementPercent=90|20261132|
47|gate47_packf2_c80_vs_h256e12|cand_packf2_c80|CaptSeeDiv=80|20261133|
48|gate48_packf2_c120_vs_h256e12|cand_packf2_c120|CaptSeeDiv=120|20261134|
49|gate49_packe2r_v1_vs_h256e12|cand_packe2r_v1|EvalOnlyStore=1 EvalOnlyStoreMinDepth=2|20261135|
50|gate50_packe2r_v2_vs_h256e12|cand_packe2r_v2|EvalOnlyStore=1 EvalOnlyStoreMinDepth=4|20261136|
51|gate51_packd_l1_vs_h256e12|cand_packd_l1|Hindsight=1 HindsightMargin=240 HindsightDeepRed=3 HindsightShallowRed=1|20261137|
52|gate52_packd_l3_vs_h256e12|cand_packd_l3|Hindsight=1 HindsightMargin=240 HindsightDeepRed=5 HindsightShallowRed=2|20261138|
53|gate53_packd_l4_vs_h256e12|cand_packd_l4|Hindsight=1 HindsightMargin=240 HindsightDeepRed=5 HindsightShallowRed=1|20261139|
54|gate54_packd_l2_vs_h256e12|cand_packd_l2|Hindsight=1 HindsightMargin=300 HindsightDeepRed=3 HindsightShallowRed=1|20261140|
55|gate55_h256e20i_vs_h256e12|cand_h256_e20i|-|20261141|
56|gate56_h256auto000_vs_h256e12|cand_h256_auto000|-|20261142|
57|gate57_tmdiv18_vs_h256e12|cand_tmdiv18|TmSoftDivisor=18|20261143|
58|gate58_gcx_qsqpromo_vs_h256e12|cand_gcx_qsqpromo|QsQueenPromoOnly=1|20261144|
59|gate59_gcx_chkcap8_vs_h256e12|cand_gcx_chkcap8|CheckExtDepthCap=8|20261145|
60|gate60_gcx_lmpoffkp_vs_h256e12|cand_gcx_lmpoffkp|LmpOffKP=1|20261146|
61|gate61_h256kep16_vs_h256e12|cand_h256_k_ep16|-|20261147|
62|gate62_omnis_s11b_vs_h256e12|cand_omnis_s11b|RfpOppWorse=40|20261148|
63|gate63_omnis_s1a_vs_h256e12|cand_omnis_s1a|CorrUpdateMode=1|20261149|
64|gate64_omnis_s3b_vs_h256e12|cand_omnis_s3b|ThreatHist=1 ThreatHistDiv=2|20261150|
65|gate65_omnis_s13c_vs_h256e12|cand_omnis_s13c|CheckOrderSee=1 CheckOrderBonus=16000|20261151|
66|gate66_omnis_s15a_vs_h256e12|cand_omnis_s15a|PawnEgPrune=1|20261152|
67|gate67_omnis_s12b_vs_h256e12|cand_omnis_s12b|HistMalusPct=125|20261153|
68|gate68_omnis_s1c_vs_h256e12|cand_omnis_s1c|CorrUpdateMode=1 CorrDiffClampCp=12|20261154|
69|gate69_omnis_s10a_vs_h256e12|cand_omnis_s10a|QuietBadThreshold=-12000|20261155|
70|gate70_omnis_s6a_vs_h256e12|cand_omnis_s6a|AspFailHighAlpha=1|20261156|
71|gate71_omnis_s11a_vs_h256e12|cand_omnis_s11a|RfpOppWorse=20|20261157|
72|gate72_omnis_s12c_vs_h256e12|cand_omnis_s12c|HistMalusPct=90|20261158|
73|gate73_omnis_s15b_vs_h256e12|cand_omnis_s15b|PawnEgPrune=2|20261159|
74|gate74_omnis_s10b_vs_h256e12|cand_omnis_s10b|QuietBadThreshold=-6000|20261160|
75|gate75_omnig_p20a_vs_h256e12|cand_omnig_p20a|SmallPcMargin=350 SmallPcDepthGap=3|20261161|
76|gate76_omnig_p21b_vs_h256e12|cand_omnig_p21b|QsFutSee=1|20261162|
77|gate77_omnig_p24c_vs_h256e12|cand_omnig_p24c|FutHistDiv=256 FutHistMode=1|20261163|
79|gate79_omnieval_mcw100_vs_h256e12|cand_omnieval_mcw100|MinorCorrWeight=100|20261165|
80|gate80_omnitm_nip75_vs_h256e12|cand_omnitm_nip75|TmNewIterPct=75|20261166|
81|gate81_omnitm_fall_vs_h256e12|cand_omnitm_fall|TmPrevMoveFall=1|20261167|
82|gate82_omnitm_fall50_vs_h256e12|cand_omnitm_fall50|TmPrevMoveFall=1 TmPrevMoveFallScale=50|20261168|
83|gate83_omnig_p27a_vs_h256e12|cand_omnig_p27a|QsEvasionSee=1|20261169|
85|gate85_buckets8_vs_h256e12|cand_buckets8_b8ep8_h256e12|-|20261171|
84|g84_c_ptype_pext_nnuemem3b|cand_c_ptype_pext_nnuemem3b|-|20261170|
91|gate91_tp2_dec70_vs_h256e12|cand_timepack2_h256e12|TmDecisivePct=70|1754428259|to be replaced by timepack3 TmDecisiveWin=60 after CR
92|gate92_tp2_fd6_vs_h256e12|cand_timepack2_h256e12|TmForcedDepth=6|899825575|last

## Update 2026-10-24 18:10 Europe/Vienna (from QUEUE_PENDING.md, not a fresh PC read)
- forge_gates.json now sha256 7640BAFD39B3B1311D8DEC256631D031E8D529F2443B0DA5B5FC89A339CEB4CC, 85 entries.
- New: G93 gate93_e24n_vs_h256e12 (net-only, blend-end 0.75, CR PASS) and G94 gate94_e16o_vs_h256e12 (net-only, blend-end 0.8, CR PASS), placed after G84.
- New: G91b gate91b_tp3_dwin60_vs_h256e12 (timepack3, candidate option TmDecisiveWin=60, CR PASS d8c8f4b6), moved by crew vote to right after G90. G91 DEC70 is HELD (replaced by G91b).
- Run order: G88 (running) -> G89 -> G90 -> G91b -> G28 -> G34 -> G35 -> G86 -> ... -> G85 -> G84 -> G93 -> G94 -> G92 FD6 -> [G91 held]. 63 runnable, ~173 h at the 1500 cap.
- G88 e16g90 at 1000 games (17:52): -1.74 +/-10.17, LLR -0.72, running on to the 1500 cap.
- 6-day install verified 17:52 (driver r4, watchdog, 8 scheduled tasks).

## Update 2026-10-24 20:05 Europe/Vienna (Engine QA)
- Lock unchanged: h256_e12 (exe 456743D9…FDFA).
- G88 e16g90: capped 1500 g, no decision, +2.78 ±8.52, LLR 0.09, clean -> rework list.
- G89 e16s_sol running since 18:41 (last logged 40 g, no signal yet).
- Newly queued net-only gates (all CR PASS, bench/perft/FMA/oracle checked on PC): G95 e12f b0.5 (after G90, ahead of G91b), G98 e12rec b0.4 (after G95; demoted if G95 ends H0/clearly minus), G96 e16p b0.7, G99 f001 b0.7, G97 e16q b0.85 (late queue).
- Manifest forge_gates.json sha256 B3736882D50FA090CBAC7A79E85FF0F6DBF139F3938CA3ECB2191A9F202EBEB4, 90 entries, ~184 h runnable at the cap.
- Speed packs CR PASS 19:50 (node-identical, not yet gated/nps-measured on PC): fc_speedmp (MovePicker scoring hoist + piece_type table) and fc_speedtt (early TT prefetch). See 04_cr.
- NNUE f003 ep32 b0.6 (md5 80a35e2f) is being packed for CR.

## Update 2026-10-24 22:00 Europe/Vienna
- Manifest now B1C49259CDD58437AD442B240E444BEBC74281C6E45CFB38687B572891D34EE0 (93 entries, ~190 h runnable).
- Order: G90 e16m (running) -> G95 e12f b0.5 -> G100 e32f003 -> G102 e24f005 -> G98 e12rec b0.4 -> G91b -> G101 speedmp2 -> G28 ...
- G101 speedmp2 = node-identical MovePicker speed patch (bench = lock), PC nps +4.30% [3.87,4.72] at d16 and +4.55% [3.98,5.13] at d20 vs lock. speedtt was neutral at d20 (+0.80%, CI incl. 0) -> rework list.

## Delta to 2026-10-25 00:05 Vienna (see QUEUE_PENDING.md tail for exact entries)
Manifest now 47F38276EA6C18176F0635D0201F0DDA5F66DF02422A660E83558E1273CD2840, 94 entries. Added since this snapshot: G98 e12rec, G99 f001, G100 e32f003, G101 speedmp2, G102 e24f005, G103 e16f004. Results: G89 e16s_sol capped no decision (-6.5), G90 e16m H0 (-10.48). Running: G95 e12f.

## Update 2026-10-25 02:10 CEST (01:10 CET; clocks went back at 03:00 CEST today) (from QUEUE_PENDING.md, not a fresh PC read)
- Lock unchanged: h256_e12 (exe 456743D9…FDFA). No lock since 2026-10-24 17:33.
- G95 e12f (blend-end 0.5) capped at 1500 g, no decision: +0.23 +/-8.53, LLR -0.56, clean -> rework list.
- G100 e32f003 running since 01:45 (game ~226/1500 at 02:06).
- Newly queued net-only gates (all CR PASS; bench/perft/FMA/oracle verified on PC): G104 e48f006, G105 e16f007, G106 e20f008, G107 e16f009, G108 e20f011, G109 e16f010. G105/G107/G109 move to the rework tail if G100 and G102 both end H0.
- Manifest forge_gates.json now 09DC6645174BCAB7E75FED3C083A5B16B134742890CEB51701BC8CD6F456E16F, 100 entries, 74 runnable (~203.5 h at the cap).
- Order: G100 (running) -> G102 -> G103 -> G104 -> G98 -> G91b -> G101 speedmp2 -> G105 -> G106 -> G107 -> G108 -> G109 -> G28 ...
- Daily 10:00 prune rule: at most two blend-end 0.6 nets per epoch count until G100 and G102 report (f012, f013 count); the rest go to the rework tail, nothing dropped.

## Update 2026-10-25 04:10 CET (Europe/Vienna)
forge_gates.json sha256 B4ECEB62FD4194FE34E4A0E17FBD7F154E4D9C2F79E15CA2AA26490FAEF6A318, 103 entries.
100|gate100_e32f003_vs_h256e12|cand_h256_e32f003|-|1050264640|capped, no decision, +8.34 +/-8.45, LLR 1.54, CLEAN (rework list)
102|gate102_e24f005_vs_h256e12|cand_h256_e24f005|-|1180590640|RUNNING (560 g: -6.83 +/-14.94, LLR -0.84)
103|gate103_e16f004_vs_h256e12|cand_h256_e16f004|-|-|next
Then G98, G91b, G101 speedmp2, G104-G112 (nets f006-f014; G110 f013, G111 f012 conditional, G112 f014), G28 ...
The 10:00 CET daily prune keeps at most two blend-end 0.6 nets per epoch count; QA's e20 pick is f008 (Sol) + f014, with f011/f013 to the rework tail.
