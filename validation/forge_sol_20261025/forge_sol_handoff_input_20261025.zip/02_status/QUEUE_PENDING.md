- contcorr-6424 (CR_PASS 2026-10-23 11:24 PT, built on 6.4.24 net, bench differs -> gain route, 1000g SPRT [0,10] vs locked base). Prefer rebasing onto ep10 tree (Strength) after lock; else gate vs 6.4.24 after Gate 10. Needs game-time tactics check before any lock.
- contcorr-epa (CR_PASS 2026-10-23 12:3x PT, same-diff of contcorr-6424 on ep10 tree, gain route, 1000g SPRT [0,10] vs plain ep10 after Gate 10; supersedes contcorr-6424 slot if ep10 locks).

- 2026-10-23 21:29 Vienna CR_PASS contcorr-epa (ep10 tree, net da65098c) -> Gate 11: contcorr-epa vs plain ep10, 1000g cap SPRT [0,10], no pooling; after Gate 10 on PC or on the box when the contcorr-6424 gate ends. Record PC bench nps vs ep10. Game-time tactics run needed before any lock. Note: CR_PASS_contcorr-epa_ep10-1ab50b2d.txt
- 2026-10-23 21:50 Vienna Gate 11 QUEUED on PC (chain_gates7.ps1, PID 10392, BelowNormal): contcorr-epa (forge_contcorr_epa.exe sha256 BEE44D7F5BA19836CD9B69B08C26D1C9E0AF7ED48DB4164DC9E12795F4F7B461, built on PC from CR-verified source zip; PC bench d11/13 383221/1096659 = CR) vs plain ep10 (forge_nnue_ep10.exe 42D387C6...95B0B). Starts automatically after chain_gates6b.ps1 (Gate 10) exits and no fastchess is running (+20 s settle). srand 20261026, 1000-game cap, SPRT normalized [0,10] a=b=0.05, frozen gate1b settings, concurrency 5, no pooling. Folder D:\grok-pc-data\forge_push\gate11_contcorr_epa_vs_ep10; log D:\grok-pc-data\forge_push\chain_gates7.log. Fastchess command line verified token-for-token against Gate 10's. Note: CR_PASS_contcorr-epa_ep10-1ab50b2d.txt; game-time tactics run still needed before any lock.
- 2026-10-23 21:5x Vienna CR_PASS packb-epa (ep10 net-a da65098c tree, P2+P4, options default off): off-state bench == ep10 (identity); ON-state is GAIN route -> 1000g cap SPRT [0,10] vs plain net-a ep10 (fc_nnue_ep10_1ab50b2d build, NOT forge-strength/base-ep10 which is the runb net), no pooling, one machine, after Gate 11. Candidate side must set option.ReSearchAdjust=1 option.FiftyDamp=1 (record exact lines); sanity bench d11 must read 298934 (off 315955). Record PC bench nps vs ep10; game-time tactics before any lock. Note: CR_PASS_packb-epa_ep10-1ab50b2d.txt
- 2026-10-23 21:55 Vienna Gate 12 QUEUED on PC (chain_gates8.ps1, PID 10904, BelowNormal): packb-epa (forge_packb_epa.exe sha256 4E8E8A3E5298C0389E580AB54FAE244DDDAF50D13FC627E41ED4BD7CFB5B0BDF, built on PC with -DFORGE_EXPOSE_TUNABLES=1 from the CR-verified source zip: 20 files sha256-checked, only src\search.cpp and include\forge\search.hpp differ from the PC ep10 tree, nnue_weights.inc md5 da65098c) vs plain ep10 (forge_nnue_ep10.exe 42D387C6...95B0B). Candidate side sets option.ReSearchAdjust=1 option.FiftyDamp=1 (others default), base side sets none. PC bench (Threads=1 Hash=16): options off d11/13 315955/851522 (= ep10), options on 298934/839255 (= CR); nps see D:\grok-pc-data\forge_push\nnue_cand\build_packb_epa.log. Starts automatically after chain_gates7.ps1 (Gate 11, PID 10392) exits and no fastchess is running (+20 s settle). srand 20261027, 1000-game cap, SPRT normalized [0,10] a=b=0.05, frozen gate1b settings, concurrency 5, no pooling. Folder D:\grok-pc-data\forge_push\gate12_packb_epa_vs_ep10; log D:\grok-pc-data\forge_push\chain_gates8.log. Note: CR_PASS_packb-epa_ep10-1ab50b2d.txt; game-time tactics run still needed before any lock.
- 2026-10-23 22:14 Vienna CR_PASS fc_nonpawnkey_ep10 (P1 non-pawn board key, ep10 net-a da65098c tree, SPEED/BOARD route, bench d11/13/20/22 identical to ep10, nothing reads the keys yet): needs PC A/A then >=30 alternating nps pairs vs plain ep10 (fc_nnue_ep10_1ab50b2d build, NOT forge-strength/base-ep10 = runb net) on a quiet machine, no pooling with box numbers; CR_PASS covers correctness and node identity only. No strength gate by itself; best used as the base for the non-pawn correction-history consumer build. Note: CR_PASS_nonpawnkey_ep10-1ab50b2d.txt
- 2026-10-23 22:41 Vienna CR_PASS nnue_h256_e12_ep12_ep10base (ep10 tree + Engine NNUE run e epoch 12 H256 net md5 6d22f612, ONLY src/nnue_weights.inc differs, build needs -DFORGE_NNUE_HIDDEN=256; bench Threads=1 Hash=16 d11/13/20/22 308972/745494/11901452/31111774, reproduced exactly; GAIN route, UNPROVEN): 1000g cap SPRT [0,10] vs LOCKED plain ep10 (/workspace/forge-coder/fc_nnue_ep10_1ab50b2d, net da65098c, d11 315955 / d13 851522; NOT forge-strength/base-ep10 = runb net), no pooling, one machine, PC exe built with the FULL ep10 flag set plus -DFORGE_NNUE_HIDDEN=256 (a -DCMAKE_CXX_FLAGS on tools/windows-zen5.cmake REPLACES its -march/-fno-fast-math INIT flags: record compile flags + exe sha256, check_nnue_simd on exe), pre-gate d11 308972 vs 315955, record PC bench nps (box ~0.85x ep10). Game-time tactics run before any lock; lock rule with forge_tests 13/14 (4 known lines) applies. Note: CR_PASS_nnue_h256_e12_ep12_ep10base.txt
- 2026-10-23 22:46 Vienna Gate 13 QUEUED on PC (chain_gates9.ps1, PID 4256, BelowNormal): fc_nnue_h256_e12_ep12_ep10base (forge_h256_e12.exe sha256 456743D9C065D2DEC2D9A52EF23992F36908EFC1243B6916EDAB9A8AB3C7FDFA, built on PC with direct g++ 15.2.0 `-std=c++20 -O3 -DNDEBUG -DFORGE_NNUE_HIDDEN=256 -ffp-contract=off -fno-fast-math -march=znver5 -static -pthread`; CR's 73-file manifest sha256-verified on the PC, 20 compile files differ from the PC ep10 tree only in src\nnue_weights.inc md5 6d22f612) vs plain ep10 (forge_nnue_ep10.exe 42D387C6...95B0B, same flags without the 256 define, per build_ep10.log). No UCI options on either side beyond Threads=1 Hash=16 OwnBook=false. PC bench (Threads=1 Hash=16): candidate d11/13 308972/745494 (= CR), ep10 d11/13 315955/851522 (= CR). PC nps single runs while Gate 10 is running (noisy): ep10 d11 2.11M, d13 2.01/1.93/2.07M; H256 d11 1.79M, d13 2.03/2.03/1.98M. check_nnue_simd.py: FAILS on the H256 exe/object AND identically on an ep10 H128 object built with the same flags: checker looks for vmaxps but -march=znver5 (AVX-512VL) lowers max(0,x) to vcmpgtps+masked zeroing; evaluate still uses 256-bit vminps/vmulps/vaddps, no FMA; it is a checker limitation under znver5, not an H256 problem. Starts automatically after chain_gates8.ps1 (Gate 12, PID 10904) exits and no fastchess is running (+20 s settle; max wait 24 h; requires CR_PASS_h256_e12.ok, present). srand 20261028, 1000-game cap, SPRT normalized [0,10] a=b=0.05, frozen gate1b settings, concurrency 5, no pooling. Folder D:\grok-pc-data\forge_push\gate13_h256_e12_vs_ep10; log D:\grok-pc-data\forge_push\chain_gates9.log. Fastchess args compared token-for-token with the running Gate 10 command line: differ only in candidate name/exe, srand, event, pgnout. Note: CR_PASS_nnue_h256_e12_ep12_ep10base.txt; game-time tactics run still needed before any lock; trainer-script origin is still an open item for Couns before any net lock.
- 2026-10-23 22:50 Vienna Gate 13 addendum (CR request): FMA check done on the PC with objdump -Cd of both exes: vfmadd/vfnmadd/vfmsub/vfnmsub (all variants) count inside forge::nnue::evaluate = 0 for BOTH forge_h256_e12.exe (sha 456743D9...7FDFA) and forge_nnue_ep10.exe (sha 42D387C6...95B0B); whole-exe count also 0 for both (raw substring grep 0; positive control vmulps present). Record: D:\grok-pc-data\forge_push\gate13_h256_e12_vs_ep10\FMA_CHECK.txt (folder pre-created; chain_gates9's New-Item -Force is unaffected; gate not started, no running gate touched); disassemblies in D:\grok-pc-data\forge_push\nnue_cand\fma_check\.
- 2026-10-23 22:5x Vienna CR_PASS packa-epa (ep10 net-a da65098c tree + CR-passed non-pawn key + P1 NonPawnCorr + P3 PawnHist + P7 LmrCorrThreshold, options default off = bench identical to ep10; ON = GAIN route). Gate A: P1+P3 only, option.NonPawnCorr=1 option.PawnHist=1, pre-gate bench d11/13 298872/765252 (off 315955/851522), 1000g cap SPRT [0,10] vs plain ep10 (fc_nnue_ep10_1ab50b2d, NOT forge-strength/base-ep10), one machine, no pooling, after Gate 12; record PC nps; tactics before any lock. P7 SPLIT OUT (no threshold gives 10-15% trigger at both d13 and d20; T=40 d20 50%, +69% nodes alone): do not queue LmrCorrThreshold>0. King-less variant (NonPawnKeyIncludesKing=0, bench d11/13 331091/933250) is its own later gate. Note: CR_PASS_packa_epa_ep10-1ab50b2d.txt
- 2026-10-23 22:56 Vienna Gate 14 QUEUED on PC (chain_gates10.ps1, PID 10712, BelowNormal): packa-epa (Pack A: P1 NonPawnCorr + P3 PawnHist, CR-passed key tree over ep10 net da65098c; forge_packa_epa.exe sha256 F53518132973892B3DFA700D2AD31194D9C9E93CC00712059E28D3F6F0263708, built on the PC with direct g++ 15.2.0 `-std=c++20 -O3 -DNDEBUG -DFORGE_EXPOSE_TUNABLES=1 -ffp-contract=off -fno-fast-math -march=znver5 -static -pthread`, no FORGE_NNUE_HIDDEN; all 20 compile files sha256-checked vs the box tree /workspace/forge-strength/packa-epa after unzip: search.cpp 5f9e6f25, search.hpp 72d54f6e, board.cpp ed01612b, board.hpp 11689694, nnue_weights.inc md5 da65098c; exactly those 4 files differ from the PC ep10 tree) vs plain ep10 (forge_nnue_ep10.exe 42D387C6...95B0B). Candidate side sets option.NonPawnCorr=1 option.PawnHist=1 (LmrCorrThreshold=0, NonPawnKeyIncludesKing=1 default); base side sets none. PC bench (Threads=1 Hash=16): options off d11/13 315955/851522 (= ep10); options on 298872/765252 (= CR); options advertised in uci. PC nps single runs while Gate 10 runs (noisy): ep10 d13 2.06/1.99/1.98M; packa off d11 1.83M, d13 1.86/1.96/2.06M; packa on d11 2.03M, d13 1.84/1.69/1.81M (about 8-10% lower than off at d13, noise caveat). FMA in nnue::evaluate = 0 and whole exe = 0 (FMA_CHECK.txt in the gate14 folder). Starts automatically after chain_gates9.ps1 (Gate 13, PID 4256) exits and no fastchess is running (+20 s settle; max wait 36 h; requires CR_PASS_packa_epa.ok, present). srand 20261029, 1000-game cap, SPRT normalized [0,10] a=b=0.05, frozen gate1b settings, concurrency 5, no pooling. Folder D:\grok-pc-data\forge_push\gate14_packa_epa_vs_ep10; log D:\grok-pc-data\forge_push\chain_gates10.log. Fastchess args compared token-for-token with the running Gate 10 command line: differ only in candidate name/exe, the two candidate options, srand, event, pgnout. Note: CR_PASS_packa_epa_ep10-1ab50b2d.txt. Gate B (king-less) and P7 (LmrCorrThreshold) are separate later gates, NOT queued; game-time tactics run still needed before any lock.
- 2026-10-24 00:05 Vienna CR_PASS nnue_h256_e11_ep10base (ep10 tree + Engine NNUE run e epoch 11 H256 net md5 0f0c51f0, ONLY src/nnue_weights.inc differs, build needs -DFORGE_NNUE_HIDDEN=256; bench Threads=1 Hash=16 d11/13/20/22 316030/840165/10367496/33329206, reproduced exactly; ep11 export parity VERIFIED on PC 10000/10000 + byte-identical re-export; GAIN route, UNPROVEN): queue ONLY if Gate 13 (H256 e12) shows H256 is worth it; then 1000g cap SPRT [0,10] vs LOCKED plain ep10 (/workspace/forge-coder/fc_nnue_ep10_1ab50b2d, net da65098c, d11 315955 / d13 851522; NOT forge-strength/base-ep10), no pooling, one machine, PC exe with FULL flag set (-march=znver5 -mtune=znver5 -fno-fast-math -ffp-contract=off -DFORGE_NNUE_HIDDEN=256; record line + sha256), pre-gate d11 316030 vs 315955 (308972 = e12 net), record PC nps (box ~0.84x ep10), objdump FMA=0 in nnue::evaluate instead of check_nnue_simd (fails under znver5). Game-time tactics before any lock; trainer-script origin open for Couns. Note: CR_PASS_nnue_h256_e11_ep10base.txt
- 2026-10-24 00:17 Vienna CR_PASS packc-epa (ep10 net-a da65098c tree, ONLY src/search.cpp differs; Pack C P8 AspFailHighReduce + P9 EvalSwingMult + P10 TtCutoffHistory, all default off = bench identical to ep10; ON = GAIN route, UNPROVEN). RECOMMENDED GATE = P8+P9 ONLY (P10 off): option.AspFailHighReduce=1 option.AspFailHighMaxReduce=3 option.EvalSwingMult=24 option.EvalSwingMax=200; pre-gate bench d11/13/20/22 238580/645666/8159096/18418826 (off 315955/851522/12374513/22765028); 1000g cap SPRT [0,10] vs plain ep10 (fc_nnue_ep10_1ab50b2d, d11 315955, base sets no options), one machine, no pooling, build with FORGE_EXPOSE_TUNABLES=ON, record PC nps, tactics before any lock. P10 (TtCutoffHistory=1; +14..60% nodes, Gate 10 pattern; bench 403358/1051151/14062563/36438078) = later separate gate or drop; do not gate the full 5-option bundle. P8 alone delays mate finds (WAC 001 d13->d16; P8+P9 finds it d7). Note: CR_PASS_packc_epa_ep10.txt
- 2026-10-24 00:2x Vienna CR_PASS p7_epa (ep10 net-a da65098c tree, P7 ALONE = LmrCorrThreshold, default 0 = OFF is bench-identical to ep10; ON = GAIN route, UNPROVEN): queue after Gate 14 per QA terms. Candidate side option.LmrCorrThreshold=30 (one fixed option set), build with -DFORGE_EXPOSE_TUNABLES=1; pre-gate bench d11/13 312404/920831 (off 315955/851522); 1000g cap SPRT [0,10] vs plain ep10 (fc_nnue_ep10_1ab50b2d, NOT forge-strength/base-ep10), no pooling, one machine, record PC nps vs ep10; node growth in saturated-correction positions is a known risk, TL not expected. Note: CR_PASS_p7_epa_ep10.txt
- 2026-10-24 00:21 Vienna QUEUED GATE 15 packc-epa (P8 AspFailHighReduce + P9 EvalSwingMult only; ep10 net-a da65098c tree, only src/search.cpp differs, sha f0213cbe, patch 59509f66; CR_PASS_packc_epa_ep10 recommends P8+P9 only; GAIN route, UNPROVEN) vs plain ep10 (forge_nnue_ep10.exe). Built on grok-pc: g++ 15.2.0 direct, -std=c++20 -O3 -DNDEBUG -DFORGE_EXPOSE_TUNABLES=1 -ffp-contract=off -fno-fast-math -march=znver5 -static -pthread, no FORGE_NNUE_HIDDEN; forge_packc_epa.exe sha256 F4EC41875F8114A1D5454AB15C2C9E774274CBBC4A45A645217CDEA9B05A1E71. Source sha check 20 files 0 problems; tree compare vs PC ep10: exactly src\search.cpp differs. PC bench (Threads=1 Hash=16 OwnBook=false): options off d11/13 315955/851522 (= ep10); AspFailHighReduce=1 AspFailHighMaxReduce=3 EvalSwingMult=24 EvalSwingMax=200 d11/13 238580/645666 (= CR). uci advertises AspFailHighReduce,AspFailHighMaxReduce,EvalSwingMult,EvalSwingMax,TtCutoffHistory. FMA (vfmadd family) in nnue::evaluate 0, whole exe 0 (FMA_CHECK.txt in gate15 folder). Runner chain_gates11.ps1 PID 13960 (hidden, BelowNormal), waits for chain_gates10.ps1 (Gate 14, PID 10712) then no fastchess + 20 s settle; candidate option.AspFailHighReduce=1 option.AspFailHighMaxReduce=3 option.EvalSwingMult=24 option.EvalSwingMax=200, base sets none; srand 20261030 (start=1 only inside openings arg); frozen gate1b settings, 500 rounds x2 = 1000-game cap; fastchess args token-compared with chain_gates10: only exe path, options, srand differ. Folder D:\grok-pc-data\forge_push\gate15_packc_epa_vs_ep10, log D:\grok-pc-data\forge_push\chain_gates11.log, 36 h wait abort. P10 (TtCutoffHistory=1) is a SEPARATE LATER gate (bench 403358/1051151) and NOT queued; full bundle not recommended. NOTE: the p7_epa line above also says "queue after Gate 14"; no runner for it exists yet, whoever queues it must chain behind chain_gates11.
- 2026-10-24 00:3x Vienna CR_PASS timepack_ep10 (/workspace/forge-coder/fc_timepack_ep10; ep10 net-a da65098c tree; P13 TmPlyBonus + P5 SingleMoveStop, all default off = bench-identical to ep10, re-verified d11/13 315955/851522; ON = GAIN route (time management), UNPROVEN): 1000g cap SPRT [0,10] vs plain ep10, no pooling, one machine. Candidate side option.TmPlyBonus=6 option.TmPlyEnd=100 option.SingleMoveStop=1 option.SingleMoveDepth=6; PC exe with full ep10 flag set (record line + sha256, confirm options accepted). Gate must report TL=0 and a move-time-by-ply summary. Game-time tactics before any lock. Note: CR_PASS_timepack_ep10.txt
- 2026-10-24 00:23 Vienna QUEUED GATE 16 p7-epa (P7 ALONE = LmrCorrThreshold correction-magnitude LMR, default 0 = off; ep10 net-a da65098c tree, only src/search.cpp + include/forge/search.hpp differ, sha d898b65a / ec15c9a6, patch 5a0da6d2; CR_PASS_p7_epa_ep10; GAIN route, UNPROVEN; H0 = UNPROVEN; P1 / Pack A / Gate B NOT mixed) vs plain ep10 (forge_nnue_ep10.exe). Built on grok-pc: g++ 15.2.0 direct, -std=c++20 -O3 -DNDEBUG -DFORGE_EXPOSE_TUNABLES=1 -ffp-contract=off -fno-fast-math -march=znver5 -static -pthread, no FORGE_NNUE_HIDDEN; forge_p7_epa.exe sha256 70E5D6220F24DC999A1753D19E23ADA4E002FBA71654279FD3F8C3679920CCC2. Source sha check 20 files 0 problems; tree compare vs PC ep10: exactly src\search.cpp + include\forge\search.hpp differ. PC bench (Threads=1 Hash=16 OwnBook=false): options off d11/13 315955/851522 (= ep10); LmrCorrThreshold=30 d11/13 312404/920831 (= CR). uci advertises LmrCorrThreshold. FMA (vfmadd family) in nnue::evaluate 0, whole exe 0 (FMA_CHECK.txt in gate16 folder). Runner chain_gates12.ps1 PID 11784 (hidden, BelowNormal) waits for chain_gates11.ps1 (Gate 15, PID 13960), then no fastchess + 20 s settle; candidate option.LmrCorrThreshold=30 only, base sets none; srand 20261031 (start=1 only inside openings arg); frozen gate1b settings, 500 rounds x2 = 1000-game cap; fastchess args token-compared with chain_gates11: only exe path, option, srand differ. Folder D:\grok-pc-data\forge_push\gate16_p7_epa_vs_ep10, log D:\grok-pc-data\forge_push\chain_gates12.log, 36 h wait abort. Order now: G13 (chain_gates9) -> G14 (10) -> G15 (11) -> G16 (12).
- 2026-10-24 00:26 Vienna QUEUED GATE 17 timepack_ep10 (P13 TmPlyBonus/TmPlyEnd + P5 SingleMoveStop/SingleMoveDepth, defaults off; ep10 net-a da65098c tree; compiled files differing from ep10: src/search.cpp 5a4e015d + include/forge/search.hpp 838be7f8; CMakeLists.txt 875a55f3 and tests/time_pack_tests.cpp not compiled into the exe; diff 6c6b6912; CR_PASS_timepack_ep10 = PASS safe to test; time-management GAIN route, UNPROVEN; H0 = UNPROVEN; P5 alone unlikely decidable in book games, tested only as the pack) vs plain ep10 (forge_nnue_ep10.exe). Built on grok-pc: g++ 15.2.0 direct, -std=c++20 -O3 -DNDEBUG -DFORGE_EXPOSE_TUNABLES=1 -ffp-contract=off -fno-fast-math -march=znver5 -static -pthread, no FORGE_NNUE_HIDDEN; forge_timepack.exe sha256 263DECDCEFBAB1843F56184DB395F10F2F3C8A8A1D34C1EC3C2337EF65243275. Source sha check 20 files 0 problems; tree compare vs PC ep10: exactly src\search.cpp + include\forge\search.hpp differ. PC bench (Threads=1 Hash=16 OwnBook=false), fixed depth: options off d11/13 315955/851522 AND all four on (TmPlyBonus=6 TmPlyEnd=100 SingleMoveStop=1 SingleMoveDepth=6) 315955/851522 = ep10. uci advertises TmPlyBonus,TmPlyEnd,SingleMoveStop,SingleMoveDepth (needs -DFORGE_EXPOSE_TUNABLES=1). FMA 0 in nnue::evaluate, 0 whole exe (FMA_CHECK.txt in gate17 folder). Runner chain_gates13.ps1 PID 12588 (hidden, BelowNormal) waits for chain_gates12.ps1 (Gate 16, PID 11784), then no fastchess + 20 s settle; candidate option.TmPlyBonus=6 option.TmPlyEnd=100 option.SingleMoveStop=1 option.SingleMoveDepth=6 only, base sets none; srand 20261101 (start=1 only inside openings arg); frozen gate1b settings, 500 rounds x2 = 1000-game cap; fastchess args token-compared with chain_gates12: only exe path, options, srand differ, plus -pgnout ... timeleft=true (arg parse checked with a no-engine dry run; per-move times are in PGN comments by default). RECORD: time losses (must be 0; RESULT.md says NOT CLEAN otherwise) and move time by ply (movetime_by_ply.py on gate17_timepack_vs_ep10.pgn, vs ep10 side). Folder D:\grok-pc-data\forge_push\gate17_timepack_vs_ep10, log D:\grok-pc-data\forge_push\chain_gates13.log, 36 h wait abort. Order: G13 (chain_gates9) -> G14 (10) -> G15 (11) -> G16 (12) -> G17 (13).
- 2026-10-24 00:32 Vienna QUEUED GATE 18 = Gate B (packa-epa king-less option set; EXISTING forge_packa_epa.exe sha256 F53518132973892B3DFA700D2AD31194D9C9E93CC00712059E28D3F6F0263708, no rebuild) vs plain ep10 (forge_nnue_ep10.exe). Candidate side only: option.NonPawnCorr=1 option.PawnHist=1 option.NonPawnKeyIncludesKing=0 (LmrCorrThreshold untouched = 0). CR: CR_PASS_packa_epa_ep10-1ab50b2d section 7 lists GATE B as its own separate gate (bench 331091/933250/13756273/25728788; king-less config was sanitizer/legality-checked) + CR steering update 00:28. PC pre-gate bench (Threads=1 Hash=16 OwnBook=false) d11/13/20/22: options off 315955/851522/12374513/22765028 (= ep10); Gate B set 331091/933250/13756273/25728788 (= CR, d11 +4.8%, d13 +9.6%); uci advertises NonPawnCorr, PawnHist, NonPawnKeyIncludesKing, LmrCorrThreshold; log gate18 folder pregate_bench.log. Runner chain_gates14.ps1 PID 9512 (hidden, BelowNormal) waits for chain_gates13.ps1 (Gate 17, PID 12588) then no fastchess + 20 s; srand 20261102 (start=1 only in openings); frozen gate1b settings, 1000-game cap; fastchess args token-compared with chain_gates13 (incl. -pgnout timeleft=true): only exe path, options, srand differ. Folder D:\grok-pc-data\forge_push\gate18_packa_gateb_vs_ep10, log chain_gates14.log. H0 = UNPROVEN for this exact option set; no mixing, no pooling with Gate 14 (Gate A). Flag CR_PASS_packa_gateb.ok.
- 2026-10-24 00:32 Vienna QUEUED GATE 19 = P10 ALONE (packc-epa; EXISTING forge_packc_epa.exe sha256 F4EC41875F8114A1D5454AB15C2C9E774274CBBC4A45A645217CDEA9B05A1E71, no rebuild) vs plain ep10. Candidate side only: option.TtCutoffHistory=1 (AspFailHighReduce/AspFailHighMaxReduce/EvalSwingMult/EvalSwingMax left at default). CR: CR_PASS_packc_epa_ep10 section 8 (P10 only = later separate gate; bench 403358/1051151/14062563/36438078) + CR steering update 00:28. NOTE CR flagged P10 node growth +14..60% at fixed depth, same pattern as failed Gate 10; expect H0. PC pre-gate bench d11/13/20/22: options off 315955/851522/12374513/22765028 (= ep10); TtCutoffHistory=1 403358/1051151/14062563/36438078 (= CR, d11 +27.7%, d13 +23.4%); uci advertises TtCutoffHistory (and AspFailHighReduce, EvalSwingMult); log gate19 folder pregate_bench.log. Runner chain_gates15.ps1 PID 9796 (hidden, BelowNormal) waits for chain_gates14.ps1 (Gate 18, PID 9512) then no fastchess + 20 s; srand 20261103 (start=1 only in openings); same frozen settings, token-compared with chain_gates13: only exe path, option, srand differ. Folder D:\grok-pc-data\forge_push\gate19_packc_p10_vs_ep10, log chain_gates15.log. H0 = UNPROVEN for this exact option set; no mixing, no pooling with Gate 15 (P8+P9). Flag CR_PASS_packc_p10.ok. Order: G13 (chain_gates9) -> G14 (10) -> G15 (11) -> G16 (12) -> G17 (13) -> G18 (14) -> G19 (15).
- 2026-10-24 00:52 Vienna CR_PASS packd-epa (ep10 net-a da65098c tree + Pack D: P11 FailHighBlend, P12 Hindsight/HindsightMargin, options default off = bench identical to ep10; ON = GAIN route, UNPROVEN; only src/search.cpp 19455f9b + include/forge/search.hpp 145872d3 differ, patch 0bf69582). Two separate gates, never together: GATE P11 ALONE option.FailHighBlend=1, pre-gate bench d11/13/20/22 366148/803698/11704979/20733023 (off 315955/851522/12374513/22765028); GATE P12 ALONE option.Hindsight=1 option.HindsightMargin=170, QUEUE ONLY AFTER GATE 12 (Pack B) VERDICT, pre-gate bench 360459/885509/11961569/28781229; P12 risk = d22 +26% nodes (time-to-depth), record time losses. Each: 1000g cap SPRT [0,10] vs plain ep10 (fc_nnue_ep10_1ab50b2d, NOT forge-strength/base-ep10), one machine, no pooling, PC exe built with direct g++ -std=c++20 -O3 -DNDEBUG -DFORGE_EXPOSE_TUNABLES=1 -ffp-contract=off -fno-fast-math -march=znver5 -static -pthread (no FORGE_NNUE_HIDDEN), source sha check + FMA check as Gates 14-19. Wording "no measurable regression"/H1, never "stronger"; game-time tactics before any lock. Note: CR_PASS_packd_epa_ep10.txt
- 2026-10-24 00:57 Vienna QUEUED GATE 20 (runner chain_gates16.ps1, PID 3092, waits for chain_gates15 = Gate 19, then no fastchess + 20 s settle): packd-epa P11 ALONE (option.FailHighBlend=1 on candidate side only; Hindsight/HindsightMargin NOT set; P12 NOT queued, waits for Gate 12 verdict; never P11+P12) forge_packd_epa.exe sha256 E76C37932C709468BBB388B7FEDD992FA549F6C1426E8F30E9A7D08F3C4B7D2E vs plain locked ep10 forge_nnue_ep10.exe (42D387C6...5B0B), ep10 tree + only search.cpp 19455f9b + search.hpp 145872d3 (patch 0bf69582...a818, net da65098c), CR PASS CR_PASS_packd_epa_ep10.txt. g++ 15.2.0 znver5 direct build on PC, FMA 0 (vmulps control 8). PC bench exact numeric compare: options off d11/13/20/22 = 315955/851522/12374513/22765028 (= ep10), FailHighBlend=1 = 366148/803698/11704979/20733023 (= CR). Frozen settings fastchess 1.8.2 10+0.1 timemargin=1000 Threads=1 Hash=16 OwnBook=false 8moves_v3 random SPRT nElo [0,10] a=b=0.05 cap 1000 games conc 5 BelowNormal -recover, srand 20261104, PGN timeleft=true. Folder D:\grok-pc-data\forge_push\gate20_packd_p11_vs_ep10, log chain_gates16.log. Gain route: UNPROVEN until verdict, H0 = UNPROVEN for this exact option set; no mixing, no pooling.
- 2026-10-24 01:05 Vienna CR_PASS fc_int16_ep10 (net a ep10 da65098c + FORGE_NNUE_INT16 integer NNUE inference: int32 accumulator, int16 weights, AVX2 integer output layer; OFF exe byte-identical to ep10 sha f94f6778): LOW PRIORITY, queue only with a spare slot behind Packs B-D (Coder's own view: small gain, NNUE part ~35% cheaper = ~4-5% of node time, bench nps inconclusive). GAIN route, UNPROVEN: fresh 1000g cap SPRT [0,10] a=b=0.05 vs plain ep10 (fc_nnue_ep10_1ab50b2d, NOT forge-strength/base-ep10), one machine, no pooling, one option set; no UCI options beyond Threads=1 Hash=16 OwnBook=false (compile-time build, not a runtime option). PC exe = SEPARATE build with the full ep10 flags via direct g++ `-std=c++20 -O3 -DNDEBUG -ffp-contract=off -fno-fast-math -march=znver5 -static -pthread` PLUS `-DFORGE_NNUE_INT16` (never with -DFORGE_NNUE_HIDDEN=256: H256 nets abort at start-up, output bound > 2^31); record compile line + exe sha256; tools/check_nnue_int16_simd.py must PASS on the exe and FMA count in forge::nnue::evaluate must be 0. Pre-gate bench d11/13 must read 312803/720332 (ep10 315955/851522); record PC bench nps. H1 = no measurable regression/gain at [0,10] for this build only; H0 = UNPROVEN; no Elo claims. Game-time tactics run before any lock. Note: CR_PASS_int16_ep10.txt
- 2026-10-24 01:07 Vienna QUEUED GATE 21 (runner chain_gates17.ps1, PID 3056, waits for chain_gates16 = Gate 20, then no fastchess + 20 s settle): fc_int16_ep10 (compile-time FORGE_NNUE_INT16 integer NNUE on locked ep10; only CMakeLists.txt, nnue.hpp, nnue.cpp changed + new nnue_int16.inc and tools; search.cpp 44680416 and net da65098c unchanged; diff 6a9d2392...1ccb; CR PASS CR_PASS_int16_ep10.txt, priority LOW) forge_int16_ep10.exe sha256 9D09252959EE7808E3343B308B014F659845A9B54E65EE90F16C066A886742E9 vs plain locked ep10 forge_nnue_ep10.exe (42D387C6...5B0B). NO UCI options on either side (Threads=1 Hash=16 OwnBook=false only). PC direct g++ 15.2.0 znver5 -ffp-contract=off -fno-fast-math -DFORGE_NNUE_INT16 (no FORGE_NNUE_HIDDEN); FMA 0 whole exe and all forge::nnue code (vmulps control 8 in reference::evaluate); check_nnue_int16_simd.py PASS on PC exe; forge_nnue_int16_check lanes 500000 seed 4242 max 1 cp, 0 flips (exit 0); uciok present. PC bench exact int64 compare d11/13/20/22 = 312803/720332/9635943/22553956 (= CR). Frozen settings fastchess 1.8.2 10+0.1 timemargin=1000 8moves_v3 random SPRT nElo [0,10] a=b=0.05 cap 1000 games conc 5 BelowNormal -recover, srand 20261105, PGN timeleft=true. Folder D:\grok-pc-data\forge_push\gate21_int16_vs_ep10, log chain_gates17.log. Gain route: UNPROVEN until verdict, H0 = UNPROVEN; H1 = no measurable regression/gain at [0,10] for this build only; no Elo claim; no mixing, no pooling.
- 2026-10-24 01:13 Vienna CR_PASS packf-epa, CR checked, NOT QUEUED (ep10 net-a da65098c tree + Pack F P16a CaptSeeDiv, P16b NoisyLmrDiv, default off = bench identical to ep10; only src/search.cpp e3db9059 differs, patch 7d165595). Gate ONLY if Strategist picks NoisyLmrDiv: option.NoisyLmrDiv=8000 alone, pre-gate bench d11/13/16/20/22 352700/868670/3019559/12146354/33174831 (off 315955/851522/3134013/12374513/22765028), d22 +45.7% nodes = time-to-depth risk. CaptSeeDiv NOT cleared for gating as proposed. GAIN route, 1000g cap SPRT [0,10] vs plain ep10, no pooling, build -DFORGE_EXPOSE_TUNABLES=1 + g++ -std=c++20 -O3 -DNDEBUG -ffp-contract=off -fno-fast-math -march=znver5 -static -pthread. UNPROVEN; wording H1 = "no measurable regression". Note: CR_PASS_packf_epa_ep10.txt
- 2026-10-24 01:26 Vienna CR_PASS packf2-epa (ep10 net-a da65098c tree + Pack F2: P16a' CaptSeeDiv relax-only floor min(0,-score/div), default off = bench identical to ep10; only src/search.cpp 542a8343 (+IDEA_SOURCE.md) differ, patch a6a882a6). GATE option.CaptSeeDiv=40 ALONE, QUEUE BEHIND P12 per QA; NoisyLmrDiv NOT set. Pre-gate bench d11/13/16/20/22 333686/843891/3032709/11591546/24824770 (off 315955/851522/3134013/12374513/22765028). Risk: WAC 001 mate d13 -> d15, d22 +9.0% nodes. GAIN route, fresh 1000g cap SPRT [0,10] vs plain ep10 (fc_nnue_ep10_1ab50b2d), no pooling, build -DFORGE_EXPOSE_TUNABLES=1 + g++ -std=c++20 -O3 -DNDEBUG -ffp-contract=off -fno-fast-math -march=znver5 -static -pthread, source sha + FMA check. UNPROVEN; wording H1 = "no measurable regression". Note: CR_PASS_packf2_epa_ep10.txt
- 2026-10-24 01:30 Vienna QUEUED GATE 22 (runner chain_gates18.ps1, PID 7056, waits for chain_gates17 = Gate 21, then no fastchess + 20 s settle): packf2-epa P16a ALONE (option.CaptSeeDiv=40 on candidate side only; NoisyLmrDiv NOT set) forge_packf2_epa.exe sha256 244392B9FD2528822E6B9D00E21FCA750426C57B0ADC782838B2CAE011095480 vs plain locked ep10 forge_nnue_ep10.exe (42D387C6...5B0B, no opponent options). ep10 tree + only search.cpp 542a8343 (IDEA_SOURCE.md a9209f19 not a build input; search.hpp = ep10; patch a6a882a6...1179; net da65098c), CR PASS CR_PASS_packf2_epa_ep10.txt. g++ 15.2.0 znver5 direct PC build -DFORGE_EXPOSE_TUNABLES=1, FMA 0 (vmulps control 8). PC bench exact int64 compare: off d11/13/16/20/22 = 315955/851522/3134013/12374513/22765028 (= ep10), CaptSeeDiv=40 = 333686/843891/3032709/11591546/24824770 (= CR). Frozen settings fastchess 1.8.2 10+0.1 timemargin=1000 Threads=1 Hash=16 OwnBook=false 8moves_v3 random SPRT nElo [0,10] a=b=0.05 cap 1000 games conc 5 BelowNormal -recover, srand 20261106, PGN timeleft=true. Folder D:\grok-pc-data\forge_push\gate22_packf2_p16a_vs_ep10, log chain_gates18.log. Gain route: UNPROVEN until verdict, H0 = UNPROVEN for this exact option set; H1 = no measurable regression, never Elo; no mixing, no pooling. NOTE MEDIUM (CR): WAC 001 M2 found at d15 not d13 with CaptSeeDiv=40 -> game-time tactics run required before any lock. (CR text says 'queue behind P12 per QA'; P12 is not queued, chained behind Gate 21 as instructed.)
- 2026-10-24 01:55 Vienna CR_PASS_RESEARCH sol_teacher_6424 (Sol branch forge/nnue-independent-teacher-RESEARCH-20261023-1ffd149bd0b8 @2b3038f5; ONLY src/nnue_weights.inc differs, sha256 1ffd149b / md5 a0de6adc; 768->128x2 SCReLU format unchanged; warm-started from shipped net; labels Stockfish 19 d3 + 40% result). GAIN route, NOT lockable as-is. Gate: 1000g cap SPRT [0,10] vs plain 6.4.24 (1ab50b2d), no pooling, no options, both built g++ -std=c++20 -O3 -DNDEBUG -ffp-contract=off -fno-fast-math -march=znver5 -static -pthread. Pre-gate bench d11/13/16/20/22 338337/664864/2084092/9604305/27804211 (6.4.24 292545/862693/3246414/14268114/22963178). ctest 13/14 (tests.cpp:501 underpromotion x2). Before any lock: Couns OK on SF-label provenance, game-time tactics (M2 finds delayed d3->d10, WAC001 d9->d11). UNPROVEN. Note: CR_PASS_RESEARCH_sol_teacher_6424.txt
- 2026-10-24 01:55 Vienna CR_PASS_RESEARCH sol_buckets8_6424 (Sol branch forge/nnue-buckets8-EXPERIMENTAL-20261023-0e1585e2 @bde3dc9d; 8 piece-count heads all = shipped net, bench IDENTICAL to 6.4.24 d11-22; bucket selection verified incl. distinct-head mutation). SPEED route only: PC paired nps vs plain 6.4.24 (box -1.0%, within noise); a [0,10] game gate is expected H0 by design, low priority. Not lockable: 7.8 MB binary zips (2 Windows exes) committed; train_nnue.py relabelled MIT with origin undetermined (Couns). UNPROVEN. Note: CR_PASS_RESEARCH_sol_buckets8_6424.txt
- Gate 23 (chained 2026-10-24 01:58 Europe/Vienna): Sol independent-teacher RESEARCH net, branch forge/nnue-independent-teacher-RESEARCH-20261023-1ffd149bd0b8 @ 2b3038f5 (1ab50b2d + src/nnue_weights.inc only, sha256 1ffd149b / md5 a0de6adc), exe forge_sol_teacher.exe sha256 F09A076B0476F7AC2781D9EAC052253FBD96A0B640403F625AC1454B79F91B17, no options, vs plain ep10 forge_nnue_ep10.exe (42D387C6...5B0B; CR proposed 6.4.24, ep10 chosen by instruction). Runner chain_gates19.ps1 PID 12680 (waits on chain_gates18/Gate 22 PID 7056 then no fastchess), srand 20261107, folder D:\grok-pc-data\forge_push\gate23_sol_teacher_vs_ep10, log chain_gates19.log. Pre-gate bench exact int64 match d11/13/16/20/22 338337/664864/2084092/9604305/27804211; FMA 0 (vmulps 8). RESEARCH net, NOT lockable as-is: Stockfish-19-label provenance needs Couns's OK before any lock; game-time tactics required before lock (underpromotion mate-in-2 delayed to d10, WAC 001 to d11). UNPROVEN until verdict.
- 2026-10-24 02:05 Vienna CR_PASS packe-ep10, gate lines only (ep10 net-a da65098c tree + Pack E P14/P15/P18/P17, all default off = bench identical to ep10; changed: search.cpp 90e48ed9, search.hpp 82b8103d, CMakeLists f98c9bd7, new tests/pack_e_tests.cpp; patch 33dd9d3f). GAIN route, fresh 1000g cap SPRT [0,10] vs plain ep10 (fc_nnue_ep10_1ab50b2d), no pooling, one option set per gate, build g++ -std=c++20 -O3 -DNDEBUG -ffp-contract=off -fno-fast-math -march=znver5 -static -pthread -DFORGE_EXPOSE_TUNABLES=1, source sha + FMA check. Lines: PAIR option.ContHist4Pct=100 option.EvalOnlyStore=1 pre-gate d11/13/16/20/22 337624/745566/3275721/12188645/28600539; SOLO option.ContHist4Pct=100 337624/758437/3237178/16294091/29039539; SOLO option.EvalOnlyStore=1 315955/851533/2998360/10830987/25185447. Node spread for QA/Strategist: pair d13 -12.4% d22 +25.6%. LOCK-BLOCKING: P14/P18 carry Stockfish tuned constants (threat 144/144/256/517 -95/+100; low-ply 8/(1+ply)) -> strip or re-derive before any lock or P14/P18 gate. WAC 001 M2 d13 in all lines. UNPROVEN; H1 = "no measurable regression". Note: CR_PASS_packe_ep10.txt
- Gate 24 (chained 2026-10-24 02:09 Europe/Vienna): Pack E Solo A option.ContHist4Pct=100 (candidate side only), fc_packe_ep10 (diff 33dd9d3f applies clean to fresh ep10; Coder gate binary 51be5a77 verified), PC exe forge_packe_ep10.exe sha256 8EE46CE82D2CB7C4C0DCB9FD9F1C2FDB859680DC9C7C4FABC9AE474E072D328C (-DFORGE_EXPOSE_TUNABLES=1, FMA 0, vmulps 8) vs plain ep10 forge_nnue_ep10.exe. Runner chain_gates20.ps1 PID 6200 (waits on chain_gates19/Gate 23 PID 12680), srand 20261108, folder gate24_packe_cont4_vs_ep10. Pre-gate bench exact match: OFF = ep10 315955/851522/3134013/12374513/22765028; Solo A 337624/758437/3237178/16294091/29039539. GAIN route, UNPROVEN. LOCK HOLD until Coder removes or re-derives the P14/P18 copied SF constants (CR HIGH) and a bench shows this line unchanged. PAIR and P14/P18 NOT gated.
- Gate 25 (chained 2026-10-24 02:09 Europe/Vienna): Pack E Solo B option.EvalOnlyStore=1 (candidate side only), same exe forge_packe_ep10.exe sha256 8EE46CE8...328C vs plain ep10. Runner chain_gates21.ps1 PID 13356 (waits on chain_gates20/Gate 24 PID 6200), srand 20261109, folder gate25_packe_evalstore_vs_ep10. Pre-gate bench exact match: Solo B 315955/851533/2998360/10830987/25185447. GAIN route, UNPROVEN. LOCK HOLD until Coder removes or re-derives the P14/P18 copied SF constants (CR HIGH) and a bench shows this line unchanged.
- 2026-10-24 02:3x Vienna CR_PASS packe2-ep10 (fc_packe2_ep10 = Pack E minus P14/P18, provenance-clean; ContHist4Pct/EvalOnlyStore code byte-identical to packe; CR rebuild bench matches packe Solo A/Solo B/PAIR lines exactly, OFF = ep10). No new gate needed: Gates 24/25 verdicts carry over; any lock ships the packe2 exe (EXPOSE build, sha + FMA + pre-gate bench). CR lock hold on Gates 24/25 lifted. Game-time tactics before lock. UNPROVEN. Note: CR_PASS_packe2_ep10.txt
- 2026-10-24 02:23 Vienna: CR PASS packe2-ep10 (P14/P18 removed, benches identical). Gate 24/25 verdicts carry over; CR lock hold lifted. Any lock ships the packe2 EXPOSE build (PC sha, FMA check, pre-gate bench match) plus a game-time tactics run. Note: /workspace/forge-hashes/CR_PASS_packe2_ep10.txt
- 2026-10-24 02:50 Vienna GATE 12 VERDICT (packb-epa, option.ReSearchAdjust=1 option.FiftyDamp=1 vs ep10, chain_gates8, srand 20261027, started 01:00:41 PC): 1000 games capped with NO decision. W/L/D 133/122/745 (50.55 %), Ptnml [9, 87, 293, 106, 5], Elo +3.82 +/- 10.74, nElo +7.66 +/- 21.53, LOS 75.72 %, LLR +0.22 inside (-2.94, 2.94). CLEAN (0 time losses, 0 crashes/stalls/illegal, 0 orphan games). UNPROVEN; not a Pack B fail; nothing claimed. Fastchess has moved on to Gate 13.
- 2026-10-24 02:50 Vienna P12 (packd-epa option.Hindsight=1 option.HindsightMargin=170, proposed Gate 26): PARKED by choice (owner Strength), not failed. Gate 12 capped with no decision, leaning positive (+3.8, LLR +0.22). Strategist may revive it. NOT chained: no chain_gates22.ps1, no CR_PASS_packd_p12.ok, no change to the autorestart gate list (nothing was written, so nothing to rename to .PARKED). If revived: CR pre-gate bench d11/13/16/20/22 = 360459/885509/3024024/11961569/28781229, and never gate it together with P11.
- 2026-10-24 03:55 Vienna CR_PASS nnue_h256_e16h_ep16_ep10base (net-only H256, .inc md5 57a30ece): gain route, 1000g SPRT [0,10] vs plain locked ep10, no pooling, no options, after Gate 13. PC flags -march=znver5 -static ... -DFORGE_NNUE_HIDDEN=256, FMA=0, pre-gate bench 396902/943495/3098231/13483475/30910402. Lock needs trainer-origin cleared with Couns + 8-0 rule. UNPROVEN. Note: CR_PASS_nnue_h256_e16h_ep16_ep10base.txt
- 2026-10-24 03:55 Vienna, Strategist plan IF h256_e12 locks (passes Gate 13b and lock checks): start no new ep10-based gate after the lock; drop Gate 21 (int16 can't run with H256) and Gate 16 (P7); park Gate 23 (Sol H128 net). Next: h_ep16 vs the h256_e12 lock, then search packs rebuilt on h256, each 1000g vs the lock, in this order: Pack A, time pack, ContHist4, Pack C, Pack B combined, P11, EvalOnlyStore, P10, king-less key, CaptSeeDiv. If the lock fails, the ep10 queue stands. Source: FORGE_IDEA_BOARD.md 03:55.
- 2026-10-24 03:55 Vienna Gate 13b QUEUED on PC (chain_gates22.ps1, PID 10884, BelowNormal): h256_e12 (forge_h256_e12.exe sha256 456743D9C065D2DEC2D9A52EF23992F36908EFC1243B6916EDAB9A8AB3C7FDFA, the Gate 13 H1 exe; built -DFORGE_NNUE_HIDDEN=256 + full znver5 set) vs 5101c252 (forge_5101c252.exe 770447EED3862E02275280DAC7C4D648CCD383B99D17B6A2BB229127D0947EC0). End of queue: waits for chain_gates21 (Gate 25, PID 13356) to exit, then for no fastchess, then 20 s settle and a fastchess re-check. Runs an exact pre-bench d11/13/20/22 308972/745494/11901452/31111774 first and aborts on mismatch. 1000-game cap, frozen gate1b settings, start=20001, srand 20261111, concurrency 5. Folder D:\grok-pc-data\forge_push\gate13b_h256e12_vs_5101c252. The driver json entry is a DRIVER_HOLD (BLOCKED) so the driver cannot misrun it vs ep10. See LOCK_CHECK_h256_e12.md.
- 2026-10-24 03:57 Vienna BUILT (NOT gated, no .ok) h256_e16h ep16: C:\Users\Administrator\grok-pc\forge_push\bin\forge_h256_e16h.exe sha256 D615ECE4422F32AA69668F895DB2755CBA0534B200C28DA740B7A5C9FC065296. Flags: g++ 15.2.0 (MSYS2 Rev14) -std=c++20 -O3 -DNDEBUG -DFORGE_NNUE_HIDDEN=256 -ffp-contract=off -fno-fast-math -march=znver5 -static -pthread (direct g++, all flags explicit, no int16, no tunables, BelowNormal). Source: /workspace/forge-coder/fc_nnue_h256_e16h_ep16_ep10base, 20-file zip sha256-checked; only src\nnue_weights.inc differs from the PC ep10 tree; net sha256 A75E9185…08E6, md5 57A30ECE2E6F07437BE54B84CEEBB42E. PC bench Threads=1 Hash=16 d11/13/16/20/22 396902/943495/3098231/13483475/30910402 = CR exactly. uciok. FMA: nnue::evaluate 0, whole exe 0, vmulps control 8. Log D:\grok-pc-data\forge_push\nnue_cand\build_h256_e16h.log. Gate opponent (h256_e12 if it locks, otherwise ep10) to be decided by Couns after Gate 13b. CR open item: trainer provenance.
- 2026-10-24 04:14 Vienna REORDER: Gate 13b moved to run right after Gate 14 (if h256_e12 locks, the later ep10 gates need reruns anyway). Stopped two WAITING runners (verified by command line, no fastchess/child): chain_gates22.ps1 PID 10884 (old end-of-queue 13b) and chain_gates11.ps1 PID 13960 (Gate 15, waiting on chain_gates10). Started chain_gates23.ps1 PID 6480 (Gate 13b, same settings as chain_gates22: h256_e12 456743D9… vs 5101c252 770447EE…, start=20001, srand 20261111, folder gate13b_h256e12_vs_5101c252, exact PreBench; waits on chain_gates10 then no fastchess, 20 s, re-check). Started new chain_gates11.ps1 PID 7196 (Gate 15, unchanged settings/srand 20261030; now waits on chain_gates23 then no fastchess, 20 s, re-check; old file chain_gates11.ps1.bak_20261024_reorder13b). The new one was started before the old one was stopped, so chain_gates12 (Gate 16) never saw a gap; it now waits on 7196. Gates 16-25 unchanged. Chain: G14 → 13b → G15 → … → G25. forge_gates.json: 13b moved after 14, runner chain_gates23, still DRIVER_HOLD/BLOCKED (backup forge_gates.json.bak_20261024_0412). Driver dry run: takeover order G14 → G13b(BLOCKED) → G15 … G25, would launch nothing now. Log D:\grok-pc-data\forge_push\reorder13b.log.
- 2026-10-24 ~04:20 Vienna SIMD checker v1 (CR-passed) on PC g++ 15.2 znver5: nnue_ep10.o, nnue_h256.o, forge_h256_e12.exe, forge_h256_e16h.exe all PASS (vcmpps+masked-zeroing). v2 (not CR'd) also PASS. Clamp = vcmpgtps (imm 0x0e) zero,x → k1 (x>0) + vmovaps {k1}{z}. See LOCK_CHECK_h256_e12.md.
- 2026-10-24 04:24 Vienna BUILT (NOT gated, no .ok) packc-h256: C:\Users\Administrator\grok-pc\forge_push\bin\forge_packc_h256.exe sha256 045A67D49C4219524D37D04AFC4C78F175BBB784AD81D047EAE31B55A7B3EF3D. Flags: g++ 15.2.0 (MSYS2 Rev14) -std=c++20 -O3 -DNDEBUG -DFORGE_EXPOSE_TUNABLES=1 -DFORGE_NNUE_HIDDEN=256 -ffp-contract=off -fno-fast-math -march=znver5 -static -pthread (direct g++, no int16, BelowNormal). Source /workspace/forge-strength/packc-h256 (IDEA_SOURCE.md present, no tools/__pycache__); 20-file zip sha256-checked; vs the PC h256_e12 tree only src\search.cpp differs (F0213CBE…, = packc-epa search.cpp); net md5 6D22F612. PC bench Threads=1 Hash=16: options OFF d11/13/16/20/22 308972/745494/2460422/11901452/31111774 (= h256_e12 exactly); gate options (AspFailHighReduce=1 AspFailHighMaxReduce=3 EvalSwingMult=24 EvalSwingMax=200) 226871/573439/1803650/10368990/21374182 exactly. Options advertised. FMA: evaluate 0, whole exe 0, vmulps control 8. Log D:\grok-pc-data\forge_push\nnue_cand\build_packc_h256.log. Gates only after h256_e12 locks (vs the h256_e12 lock); README says it still awaits a CR same-diff check.
- 2026-10-24 05:29 Vienna BUILT timepack-h256e12 — post-lock, gate after h_ep16 vs h256_e12 (NOT gated, no .ok, no runner). C:\Users\Administrator\grok-pc\forge_push\bin\forge_timepack_h256e12.exe sha256 5D5F095904D74F32A303E9BD21E37617A5DA7B805B369C9671D52E147103F747. Flags: g++ 15.2.0 (MSYS2 Rev14) -std=c++20 -O3 -DNDEBUG -ffp-contract=off -fno-fast-math -march=znver5 -static -pthread -DFORGE_NNUE_HIDDEN=256 -DFORGE_EXPOSE_TUNABLES=1 (direct g++, BelowNormal, no int16). Source /workspace/forge-coder/fc_timepack_h256e12 (CR_PASS_timepack_h256e12.txt); 20 compile files sha256-checked (= Coder handoff manifest); vs the PC h256_e12 tree only src\search.cpp 5a4e015d + include\forge\search.hpp 838be7f8 differ; net md5 6d22f612. FMA: evaluate 0, whole exe 0 (vmulps control 8).
  bench (Threads=1 Hash=16 OwnBook=false) options OFF d11/13/16/20/22: 308972/745494/2460422/11901452/31111774 = CR MATCH
  bench options ON d11/13/16/20/22: 308972/745494/2460422/11901452/31111774 = CR MATCH
  option line (candidate only): option.TmPlyBonus=6 option.TmPlyEnd=100 option.SingleMoveStop=1 option.SingleMoveDepth=6 ; opponent h256_e12 lock exe with identical flags, no options; 1000g SPRT [0,10], 10+0.1, TL must be 0.
  uci advertises TmPlyBonus/TmPlyEnd/SingleMoveStop/SingleMoveDepth. Forced-FEN sanity (2br1rkR/3q1pp1/1b6/pP2p3/Ppp1P1B1/3P4/1QK3n1/1R4N1 b - - 3 40, go wtime/btime 60000): options on stop at depth 6 (~46 ms incl. startup), options off reach depth 22. Log D:\grok-pc-data\forge_push\nnue_cand\build_timepack_h256e12.log.

## 2026-10-24 09:44 Vienna, Strategist: post-lock order
h_ep16, then run j net (after CR), then timepack_h256e12, then packc_h256, then PawnHist=1 alone on h256 (Strength, needs CR_PASS). Parked on h256 (node screens failed): NonPawnCorr, FiftyDamp, ReSearchAdjust, P11.

## 2026-10-24 09:51 Vienna — Couns: REWORK LIST (do not discard)
Couns: builds that came out plus or barely minus are NOT dropped. Redo them better on the h256_e12 lock and re-gate later, because +3 Elo matters once easy locks run out.
- Plus, capped at 1000g with no decision (vs ep10): packc_epa +5.9 (packc_h256 already built), packa_epa +5.2, timepack +4..+5.5 (Gate 17; timepack_h256e12 already built), packb_epa +3.8.
- Barely minus: p7_epa -0.7, contcorr_epa -1.4, rfpavg_epa -3.1.
- Never gated (ep10 Gates 18-25 dropped by the lock, kept for a rebase): packa_gateb, packc_p10, packd_p11, packf2_p16a, sol_teacher, packe ContHist4 and EvalOnlyStore (Coder is retuning those), int16 (needs a new H256 design).
- Failed the h256 node rule (Pack A, Pack B, P11, NonPawnCorr, FiftyDamp, ReSearchAdjust): retune them so they pass, rather than parking them for good.

## 2026-10-24 09:52 Vienna — rework list additions and the stack plan (QA)
- Added speed builds: fc_speedstack (box: 13/14 pairs, -5.9% time on ep10) and fc_ptype (10/14 pairs, -1.2%). Coder rebuilds them on h256, then CR, then Profiler box timing, then QA PC timing.
- sol_teacher can be gated but cannot lock without Couns's OK (Stockfish 19 d3 labels).
- DR stack plan adopted: once each plus item (packc, packa, timepack, packb) has an h256 rebuild, passes the node rule and has its own CR pass, build ONE stack, give it a CR same-diff and a fresh bench, and gate it once vs h256_e12. H1 locks it; anything else splits it. Barely-minus and never-gated items gate solo first.
- Gate 26 h_ep16 stays first. Gates 27 (timepack solo) and 28 (packc solo) stay as fallback fillers, so the PC is never idle if the stack isn't CR-passed by the time Gate 26 ends. Once the stack is ready, it replaces them.
- 09:56 Vienna: CR asks for a combined bench of the stack as well as each part's (node rule checked on the whole build). pawnhist-h256 is P3 from Pack A, so it becomes filler only if Pack A goes into the stack.

## 2026-10-24 09:57 Vienna — Couns order: 6-day unattended queue (QA)
- Order: the biggest plus reruns first (stack, packc, packa, timepack, packb), then the other plus items, then barely-minus (p7, contcorr, rfpavg), then never-gated items.
- Before weekly usage runs low, QA installs a self-running grok-pc queue sized for about 150 h. Unattended gates cap at 1500 games (in-session gates stay at 1000).
- Capacity: about 97 min per 1000 games at 5 slots (Gate 14 measurement), so a capped 1500-game gate takes about 2.4 h. 150 h is about 62 capped gates; early SPRT stops mean more. Target is at least 70 gate entries.
- Have about 25 now: the rework list (15 incl. speedstack and ptype), pawnhist, h_ep16, the run j net, the stack, P11 retune, NonPawnCorr, FiftyDamp, ReSearchAdjust and sol_teacher (gate only).
- To fill the rest, without new builds where possible:
  1. Option variants: an exe with EXPOSE_TUNABLES can gate several option sets (e.g. timepack TmPlyBonus 4/6/8, packc EvalSwingMult 16/24/32). Each set needs one CR bench line.
  2. Every new NNUE net from runs k and l and later (Engine NNUE packs, CR passes).
  3. New ideas from Strategist and DR.
- Driver fallback: if the queue runs dry, rerun the top capped-plus entries on fresh openings and seeds against the current base. The PC never sits idle. Lock rule unchanged: a lock still needs H1, and a fallback rerun only confirms.
- 09:58 Vienna CR rule (adopted): fresh-seed reruns are never pooled with earlier gates. A build that reaches H1 only on a rerun needs one clean confirm gate (new openings and seed) before any lock. Option variants each need their own CR bench line and node-rule check.
- 09:58 Vienna DR rules (adopted): (a) the 1500 cap for the unattended queue is Couns's own order (t354u, 09:57). (b) At most ONE fresh-seed rerun per build. (c) No auto-lock: every unattended gate stays vs h256_e12, and an H1 is recorded as LOCK CANDIDATE only. The driver never swaps the base by itself. Locks happen in a session (8-0 rule plus confirm gate).

## 2026-10-24 09:46–10:00 Vienna — LOCK h256_e12 + queue swap (QA)
- LOCK: h256_e12 (net 6d22f612, .inc 74c4009d, exe 456743D9…FDFA, float only) by crew vote 8-0 at 09:46 (Couns delegated). New baseline for every gate below.
- Gate 17 (timepack vs ep10, fastchess 9904, runner chain_gates13 PID 12588) left alone to run to cap/SPRT end (860 g, LLR 0.13 at 09:59).
- DROPPED_post_lock_h256 (never started; waiting runners stopped after command-line + no-child + no-fastchess checks): Gates 18–25 = chain_gates14..21. PIDs 13356, 6200, 12680, 7056, 3056, 3092, 9512 at 09:51:21–25; 9796 at 09:51:56 (first skipped because stale PID-reuse "child" 7924 = NNUE supervisor, not a child; 7924 untouched). Items kept on Couns's rework list for an h256 rebase.
- forge_gates.json: backups forge_gates.json.bak_20261024_lock_h256 (old 9CD83193…) and .bak_20261024_gate29 (810A3FA4…); now sha CCC3D4C1F51FA25BB76D1A06D8ED83CA1806B0B172F5398188E8326717FF4424, 19 gates. Top-level "lock" object; Gates 18–25 status DROPPED_post_lock_h256; Gates 26–29 added with base_override h256_e12, openings_start, ok_driver2 (real flag), ok = nonexistent DRIVER_HOLD flag so the running old driver 8356 BLOCKS them.
- forge_queue.ps1 v2 (file only; 8356 still runs v1 code until restart/reboot): base_override, openings_start, ok_driver2, DROPPED status. Backup forge_queue.ps1.bak_20261024_v1 (= .bak_20261024_lock_h256). v2 dry run: 18–25 dropped; takeover G17 → G26 → G27 → G28 → G29.
- Runner chain_gates24.ps1 PID 11000 (started 09:55): waits for chain_gates13 + no fastchess → PC nps (h256_e12 vs 6.4.24 and vs ep10) → Gate 26 → 27 → 28, each with sha/ok/exact pre-gate bench, ABORTED.txt on mismatch.
  - Gate 26 gate26_h256e16h_vs_h256e12: forge_h256_e16h.exe D615ECE4…, no options, srand 20261112, start 24001.
  - Gate 27 gate27_timepack_h256e12_vs_h256e12: forge_timepack_h256e12.exe 5D5F0959…, TmPlyBonus=6 TmPlyEnd=100 SingleMoveStop=1 SingleMoveDepth=6, srand 20261113, start 27001.
  - Gate 28 gate28_packc_h256_vs_h256e12: forge_packc_h256.exe 045A67D4…, AspFailHighReduce=1 AspFailHighMaxReduce=3 EvalSwingMult=24 EvalSwingMax=200, srand 20261114, start 30001.
- 09:58 BUILT pawnhist-h256 (CR_PASS_pawnhist_h256.txt): C:\Users\Administrator\grok-pc\forge_push\bin\forge_pawnhist_h256.exe sha256 2A16F4737A3855F323E42933E5FF6DC88C1D932AEC9CC99EE56E222F5C1410AE. g++ 15.2.0 (MSYS2 Rev14) -std=c++20 -O3 -DNDEBUG -DFORGE_EXPOSE_TUNABLES=1 -DFORGE_NNUE_HIDDEN=256 -ffp-contract=off -fno-fast-math -march=znver5 -static -pthread (float, no int16). 20 compile files sha-checked; vs PC h256_e12 tree only search.cpp 973BAE14 + search.hpp EDF6932B differ; net md5 6d22f612. PC bench OFF 308972/745494/2460422/11901452/31111774 = base; PawnHist=1 340429/793516/2283073/10048866/21779620 = CR exactly. FMA evaluate 0, whole exe 0 (vmulps control 8). Options advertised PawnHist, PawnHistDivisor. (Strength binary 8cc03a71 is an x86-64-v3 build, not byte-comparable.) Log D:\grok-pc-data\forge_push\nnue_cand\build_pawnhist_h256.log.
- Runner chain_gates25.ps1 PID 12252 (started 10:00): waits for chain_gates24 + no fastchess → Gate 29 gate29_pawnhist_h256_vs_h256e12, PawnHist=1 on the candidate only, srand 20261115, start 33001, same frozen settings and pre-gate checks.
- Note: the h256 candidates with options are EXPOSE_TUNABLES builds; the lock exe has no EXPOSE (as with packc_epa vs ep10); OFF bench is node-identical.
- 10:01 Vienna OPEN: queue driver PID 8356 runs OLD code (single base); the new forge_queue.ps1 loads only after restart/reboot. Verify old 8356 cannot relaunch DROPPED Gates 18-25 or double-run 26-29; consider restarting it (my own process) once chain_gates24/25 own 26-29. After a reboot the new driver does not re-run the pre-gate bench. IDEA_SOURCE provenance wording clash (MIT note vs 'no licence found'): reconcile.

## 2026-10-24 10:04 Vienna — Couns timeline (t355u)
- Phase 1 (now to about 17:00): build VERY HIGH QUALITY candidates for the 6-day queue (CR-passed, bench-exact, node rule, idea-source notes).
- Phase 2: INSTALL the 6-day unattended queue on grok-pc by 18:04 Vienna at the latest, unless Couns says otherwise earlier. Couns may call it earlier.
- Phase 3 (after the install is verified): the whole crew spends the remaining usage on making next week more effective and efficient (tooling, skills, automation, faster CR and gating, better data and training pipelines). Use relevant plugins and create or improve skills automatically, with no duplicates.

## 2026-10-24 10:06 Vienna — 6-DAY MATH (Couns t356u: "enough builds for 6 days, instruction to everyone")
- Need 144 h. A capped 1500-game gate takes about 2.4 h (97 min per 1000 games at 5 slots). Past gates sometimes stop early (13 at 478 games, 13b at 194), so the average is about 2.0 h.
- 144 / 2.0 = 72 gate entries. TARGET 72, with fallback reruns (max one per build) as a buffer on top.
- Have: 4 queued (G26 to G29), 4 under CR (e16j, ContHist4Pct 85/70/45), 18 on the rework list (packa, packb, p7, contcorr, rfpavg, packa_gateb, packc_p10, packd_p11, packf2_p16a, EvalOnlyStoreMinDepth, speedstack, ptype, the stack, P11 retune, NonPawnCorr, FiftyDamp, ReSearchAdjust, sol_teacher), and NNUE runs k and l (2). Total 28. Gap: 44.
- QUOTAS by 16:30 CR-passed (extra gate entries beyond the 28):
  - Engine Strength +18: 2 option variants each on packa, packb, P11, packd_p11 and packf2_p16a (10), plus 8 new builds from the Strategist/DR idea lists.
  - Engine Coder +18: 2 variants each on timepack, packc, EvalOnlyStoreMinDepth and pawnhist (8), plus 7 new builds from the idea lists, plus 3 Profiler speed builds.
  - Engine NNUE +4: nets m, n, o and p (or variants of k and l: different epochs or lambda), packed as they finish. Ones that finish after the install get appended while usage remains.
  - Engine Strategist: 16 ranked new ideas with idea-source notes and starting values, split 8 for Strength and 7 for Coder plus 1 spare, by 11:30.
  - Deep Research: 8 more ideas (per-subject best-engine map) to Strategist by 11:00, plus checks on idea sources.
  - Agent Profiler: 3 speed-idea specs to Coder by 11:30, plus box timing for every speed build.
  - Code Review: about 44 reviews. Batch the option variants per exe (one review, several bench lines) and post the verdicts in batches.
- Total 28 + 18 + 18 + 4 = 68, plus about 4 extra from NNUE variants or spares, gives 72. Fallback reruns are the buffer.
- If a quota slips at 16:30, QA fills the gap with fallback reruns of the top plus items and more option variants of passed exes, and reports the hours covered to Couns.
- 10:07 Vienna NNUE +4 plan: run i ep20 (4c5a96fe, b0.6 0.014445, best) and auto000 ep16 (ab049d95, 0.014506) in parity, then to Coder before 16:00; then k (~10:55), l (~13:25) and m (~15:55). n through q get appended after the install. DR: P20-P26 with Strategist, P27 before 11:00.
- 10:12 Vienna Couns (t359u): the 6-day install MUST auto-start NNUE GPU training, self-play data generation AND the gate queue together at logon, with the watchdog restarting each on crash or close. Verify each of the three restarts before reporting done.
- 10:13 Vienna: Strategist FORGE_6DAY_QUEUE.md is ready (90 entries; split S1/3/6/10-13/15 Strength, S2/4/5/7/8/9/14 Coder, S16 spare). Adopted: 3-4 omnibus EXPOSE builds with options off equal to the lock bench, one CR each plus a bench line per option set. Abort any option line whose bench equals option-off ('option ignored'). Possible corr-history add-and-clamp pinning bug (S1 tests the fix), with CR and Strength to confirm.
- 10:14 Vienna, option-check rules adopted:
  - Every option name must appear in the exe's uci list.
  - Search and eval lines: abort if the option-on bench equals the option-off bench.
  - TM lines (tag tm): exempt from the bench rule. They need a time proof on 3 FENs with go wtime 60000 btime 60000 winc 600 binc 600, on vs off, differing on at least 1.
  - Speed builds (tag speed): the bench MUST equal the h256_e12 bench. The proof is Profiler box timing plus a QA PC nps check, which must be faster before the gate.

## 2026-10-24 10:20 Vienna — QA tick
- Gate 17 timepack vs ep10 VERDICT: cap with no decision at 1000 g, -0.00±10.38 Elo, 50.00%, LLR -0.41, 0 TL/crash, CLEAN (ended 10:13). On rework list (rebase on h256 = Gate 27).
- PC nps (d20, 4 ABBA rounds, CPU 2, under NNUE+selfplay load): h256_e12 median 1.980M vs 6.4.24 (1ab50b2d) 2.302M = -14.0%; vs ep10 2.340M = -15.2%. NPS.md in nps_h256e12_lock. Recorded for the lock rule.
- Gate 26 h256e16h vs h256e12 STARTED 10:19:27 (fastchess 10548, runner chain_gates24 PID 11000), pre-gate bench d11-d22 MATCH, srand 20261112 start 24001.
- FIX: old v1 queue driver PID 8356 stopped 10:18 (QA's own process, command line checked); watchdog task relaunched forge_queue.ps1 v2 as PID 7500. v2 dry run: Gates 18-25 'dropped', 26-29 pending, launches nothing while chain runners alive -> no double-run.
- Install TODO (Phase 2): v2 argv still uses -rounds 500 (1000 cap); unattended queue needs 1500. Driver/watchdog log 'Vienna' label is +9 h off (PC clock already Vienna) — cosmetic, fix in install. Post-reboot pre-gate bench in v2 still to verify.

## 10:19 Vienna rule updates (room)
- S7 eval cache = tag speed (bench = lock; proof = Profiler box timing + QA PC nps faster).
- Profiler speed builds fc_pinlegal_h256, fc_pext_h256 (FORGE_PEXT default OFF), fc_nnuemem_h256 3a/3b = tag speed. Spec: /workspace/chess-tools/research/prof_forge_h256lock_20261024/SPEED_SPECS_h256.md
- TM time proof: 1 of the 3 FENs must be clearly won (~+5 or more, no mate) so P25 TmDecisive can act; pass = on vs off differ on >=1 FEN.
- S1 CorrGravity: CR checked search.cpp update_correction (~647-656, 1218-1222): no pinning bug (step <=0.5cp, self-correcting). Gate notes call it a tuning experiment, not a fix.
- Strength omnibus exe goes to CR as soon as it builds (options off), not at 15:45.
- 10:2x: Speed lines are NOT gated solo. Each passes CR + its own equality test (CR reqs: 3b bit-exact accumulator/output ~100k pos incl refresh; pext review+test on the FORGE_PEXT=ON build; pinlegal equality incl pin-ray, double check, castling + perft6 tricky FENs), then one combined speed build (pinlegal+pext ON+nnuemem 3a/3b+speedstack/ptype if ready), bench = lock, own CR, gated once. grok-pc is Zen 5 (znver5) so PEXT is OK.

## Sol work (Couns t360u, reviewed 01:31 PT Oct 24) — next-week list, not in 6-day queue yet
- Sol trained net (768->128x2, research commit 2b3038f5, SF19 d3 labels + 40% WDL, audit MSE -8.54% mostly from the game-result part, SF-only val loss worse per epoch): BLOCKED until the rook-underpromotion tests (8/k1P5/2K5/8/8/8/8/8 w c7c8r + mirror) pass without weakening them. Then a 6.4.24/ep10 run is RESEARCH ONLY (cannot support a lock or base swap). Lock rule applies only after a 1500g [0,10] gate vs h256_e12 (plus the confirm-gate rule for a rerun H1). Do NOT encode ep10 as opponent in the 6-day install for this line.
- buckets8 (8 output heads, all duplicates of the shipped head, parity 10000/10000, bench = shipped, clang build on 6.4.24): no SPRT while the heads are duplicates. First run Sol's speed helper on the PC in a free slot. Worth gating only after NNUE trains distinct heads, ports to h256, rebuilds with our g++ flags, passes CR.
- PC zip C:\Users\Administrator\Downloads\forge-6.4.24-buckets8-EXPERIMENTAL-NPS-UNRESOLVED-windows-zen5.zip == GitHub zip (sha 5fc34fcb...5933). Copy at /workspace/forge-sol-buckets8/from_pc/. Review at /workspace/forge-sol-buckets8/QA_REVIEW.md.
- 01:32 PT: Coder fc_packe2r_h256e12 (EvalOnlyStoreMinDepth V1=2, V2=4, expose 1f1b8e69) sent to CR; on PASS it replaces the held EvalOnlyStore line (2 gates, vs h256_e12). Box clock is now America/Los_Angeles (9h behind Vienna); routine cron stays CRON_TZ=Europe/Vienna.
- 01:34 PT: Couns OK (t364u): Sol's 5.99M independent-teacher dataset handed to Engine NNUE for upcoming h256 runs. Every net trained on it must run the rook-underpromotion test; the audit set stays unseen.
- 01:34 PT: fc_pinlegal_h256 (box sha 2ea076c8, bench = lock, equality 0 mismatch over 1.92M pos, perft6 ok) in CR. For the combined speed build, not a solo gate.
- 01:35 PT: Strength packd-h256 (exe 6cf4dda1; P12 Margin 240/300, 170 optional likely CR HOLD as SF-like constants) + packf2-h256 (exe 8cd37821; CaptSeeDiv 80/120, 40 optional under check) in CR. Each line gates on its own.
- 01:37 PT: Couns (t365u): h256 buckets8 experiment = 1 of the ~70 gates. NNUE trains a real 8-head H256 net (init from h256_e12), Coder ports Sol's buckets8 onto h256_e12 (step 1: duplicate heads, bench = lock; step 2: trained net). Only step 2 is gated, vs h256_e12, tagged experiment; appended after the install if late.
- 01:37 PT: DR fixed P12 (board line 142): Pack D line 170 dropped; Strength exposes HindsightDeepRed (2..5, def 4) / HindsightShallowRed (1..3, def 1); Margin 240/300 lines need a new CR pass with those options. No line may use 3/2/170.
- 01:37 PT: Coder buckets8 step 1 in /workspace/forge-coder/fc_buckets8_h256e12; CR handoff ETA ~13:30 Vienna; Coder sends the 8-head .inc layout to NNUE.
- 01:39 PT: Wording fixed per DR (Sol net line). Strength dropped F2 CaptSeeDiv=40 too; packd-h256 v2 is a same-diff for CR. NNUE buckets8 net ETA 14:30-15:30 Vienna, so it misses the 16:30 cut: append it after the install.
- 01:39 PT (DR): the stack (packc+packa+timepack+packb etc.) queues BEHIND its parts' own h256 gates (27/28/34/35...) and runs only if none of them leans negative. Unattended driver needs a conditional entry: skip the stack gate if any part's Elo < 0 at its end; QA implements this in the install.

## Engine QA executor: Gates 30-44 queued on grok-pc (2026-10-24 10:36-10:50 Vienna)

All 1000-game SPRT [0,10] vs the h256_e12 LOCK (forge_h256_e12.exe 456743D9...7FDFA), 10+0.1 tm1000, T1 H16 OwnBook=false, 8moves_v3 random, conc 5, options on candidate only, fresh srand/start each, never pooled.

**Run order (driver dry run, 10:49 Vienna): 26 (running) -> 30 -> 27 -> 28 -> 29 -> 31 -> 32 -> 33 -> 34 -> 35 -> 36 -> 37 -> 38 -> 39 -> 40 -> 41 -> 42 -> 43 -> 44.** Every gate appears once in forge_gates.json (34 entries, no duplicates); `-DryRun` and `-DryRun -AssumeIdle` both show that order with nothing BLOCKED.

How it's wired:
- New runner `forge_push\chain_gates26.ps1` (PID 12912, started 10:43 Vienna; sha 75A201AA) runs 30, 27, 28, 29, 31..44. It skips any gate that already has a RESULT.md, so nothing runs twice.
- `STOP_chain_gates24` / `STOP_chain_gates25` written 10:43 Vienna. These are graceful stops checked before each of their gates. Gate 26 (fastchess 10548 under chain_gates24 PID 11000) is untouched: chain_gates24 exits after 26 without starting 27/28, chain_gates25 (PID 12252) exits without starting 29, then chain_gates26 takes over after a 20 s settle. No process was killed.
- forge_gates.json backed up to `forge_gates.json.bak_20261024_e16j` (= original CCC3D4C1, 16831 B).
  - Gate 30 is inserted after 26; 27-29 runner is now chain_gates26; 31-44 appended (ok=DRIVER_HOLD_v1, ok_driver2=CR flag, base_override h256_e12, openings_start, prebench).
  - chain_gates26 reads each candidate sha from the manifest at gate time and re-runs the exact lock/OFF/ON pre-bench before every gate (any mismatch writes ABORTED.txt).
- Driver forge_queue.ps1 v2 PID 7500 is untouched. Cosmetic bug: its log shows "19:4x Vienna" because it adds +9 h to a PC clock that already shows Vienna time.
- Book 8moves_v3 has 34700 openings. Starts above that wrap: fastchess rotates by (start-1) mod size after the srand shuffle, so it doesn't crash; distinct srand + start per gate.

| Gate | Candidate (PC exe sha256) | Options | srand / start | PC bench d11/13/16/20/22 vs CR |
|---|---|---|---|---|
| 30 | forge_h256_e16j.exe 48FB604A...F6D7 (net md5 cee0ec8d; CR box c66484f1 is Linux) | none | 20261116 / 36001 | 314254/747895/2797992/13254857/22370641 MATCH |
| 31 | forge_packe2_h256.exe 3CBBEC34...FC02 (CR box expose 0d5e02ec) | ContHist4Pct=85 | 20261117 / 39001 | MATCH (OFF = lock MATCH) |
| 32 | same | ContHist4Pct=70 | 20261118 / 42001 | MATCH |
| 33 | same | ContHist4Pct=45 | 20261119 / 45001 | MATCH |
| 34 | forge_packa_h256.exe C98EE238...7611 (CR box 40f165c4) | NonPawnCorr=1 PawnHist=1 NonPawnCorrWeight=60 | 20261120 / 48001 | MATCH (OFF MATCH) |
| 35 | forge_packb_h256.exe B7BD2AD8...C8C0 (CR box 4fdbb1d2) | ReSearchAdjust=1 FiftyDamp=1 FiftyDampenStart=20 | 20261121 / 51001 | MATCH (OFF MATCH) |
| 36 | forge_p11r_h256.exe 9E66E3AF...2DEC (CR box 74e5740d NOT used) | FailHighBlend=1 FailHighBlendSoft=3 | 20261122 / 54001 | MATCH, exact CR_PASS_p11r line (OFF MATCH) |
| 37 | forge_pawnhist_h256.exe 2A16F473...10AE (CR box 8cc03a71) | PawnHist=1 PawnHistDivisor=4 | 20261123 / 57001 | MATCH |
| 38 | packa C98EE238 | ...Weight=55 | 20261124 / 60001 | MATCH |
| 39 | packa C98EE238 | ...Weight=65 | 20261125 / 63001 | MATCH |
| 40 | packb B7BD2AD8 | ...Start=10 | 20261126 / 66001 | MATCH |
| 41 | packb B7BD2AD8 | ...Start=40 | 20261127 / 69001 | MATCH |
| 42 | p11r 9E66E3AF | FailHighBlend=1 FailHighBlendSoft=16 | 20261128 / 72001 | MATCH |
| 43 | packa C98EE238 | ...Weight=50 | 20261129 / 75001 | MATCH |
| 44 | pawnhist 2A16F473 | PawnHist=1 PawnHistDivisor=1 | 20261130 / 78001 | MATCH |

How the PC builds were made:
- Compiler: g++ 15.2.0 MSYS2 Rev14, `-std=c++20 -O3 -DNDEBUG -DFORGE_NNUE_HIDDEN=256 -ffp-contract=off -fno-fast-math -march=znver5 -static -pthread`, plus `-DFORGE_EXPOSE_TUNABLES=1` for every build except e16j.
- Every build passed: a 20-file source manifest check, a net md5 check, and a diff against the PC h256_e12 tree that showed only the expected files. Every option is in the exe's uci list. FMA is 0 (vmulps control 8). Logs are in `D:\grok-pc-data\forge_push\nnue_cand\build_*.log`.
- P11r: current p11r_h256.patch (c90c9ad8) applied with `patch -p2` to a fresh h256_e12 tree. It applied cleanly and gave search.cpp 4a0a8704 / search.hpp 145872d3, the same as CR's review and the Strength tree. Soft 3 bench matched exactly, so it is NOT blocked.
- CR's Linux box binaries can never match the Windows PC exes byte for byte. Equivalence was checked by source tree and exact bench instead.
- New ok flags: CR_PASS_nnue_h256_e16j.ok, CR_PASS_packe2_h256.ok, CR_PASS_packa_h256.ok, CR_PASS_packb_h256.ok, CR_PASS_p11r_h256.ok. CR_PASS_pawnhist_h256.ok already existed.

Extra measurements the runner records:
- **Pack A (34/38/39/43) and Gate 44:** before the gate starts, chain_gates26 takes a paired PC nps measurement (lock vs candidate-ON, bench d20 x3, CPU 6, only while no fastchess runs). It goes in NPS.txt and RESULT.md.
- **Every gate:** RESULT.md also records average search depth per engine (from the PGN) and time losses. Gate 44's RESULT.md therefore holds the nps, average depth and TL that CR asked for.
- The Idle-priority build benches already measured about 1.8-2.1 M nps for every line under gate and NNUE load. These are rough numbers only.

**Rules:**
- **Any H1 in Gates 31-33 or 34-44 needs a CONFIRM gate on new openings + a new seed before lock.** No lock on a single gate.
- **e16j net lock (Gate 30) still needs Couns to clear the trainer origin**, even if Gate 30 is H1 and confirmed.
- 01:50 PT: DR opening rule adopted: runner logs each gate's opening indices; confirm gates must have 0 overlap with their original; default confirm-gate book = a second book (UHO if present on PC, verify at install), never pooled. 1500g unattended gates use 750 openings each, so 8moves_v3 wraps sooner. Coder timepack TM lines V1 (TmPlyBonus=8 TmPlyEnd=100 SingleMoveStop=1 SingleMoveDepth=6) and V2 (TmIncrementPercent=90) in CR; time proof OK (V2 effect is small).
- 01:50 PT: Strength p11r -p1 patch sha 9831207b ok (same as QA's -p2 build). packd-h256 v2 in CR: lines Margin240 DeepRed3 ShallowRed1 (primary), 300 3/1, 240 5/2, 240 5/1. packf2: CaptSeeDiv 80/120 only.
- 01:51 PT: GrokChess->Forge gaps handed to the crew (Couns OK t367u): Coder TM divisor 18; Strength qsearch queen-only promos + LMP guards (quiet checks, K+P), plus optional LMR/NMP/check-ext/SE-floor values; next week: Texel HCE retune + net retrain. See GROKCHESS_TO_FORGE.md.

## Gates 45–48 (queued 2026-10-24 ~11:00 Vienna, Engine QA executor), all vs the h256_e12 LOCK
Each gate is its own fresh 1000-game SPRT [0,10] (a=b=0.05, normalized), 10+0.1, T1 H16, 8moves_v3 random, conc 5, built with EXPOSE, options set on the candidate only. Gates are never pooled. Any H1 needs a confirm gate (new openings + new seed) before lock. H1 means no measurable regression; it is not an Elo claim.
Runner: forge_push\chain_gates27.ps1 (sha EDEEE7EF, PID 2484, started 10:58:51 Vienna). It waits for chain_gates24/25/26 to exit and for no fastchess to be running, then runs 45, 46, 47, 48 (stop file STOP_chain_gates27). The manifest entries are in autorestart\forge_gates.json under runner chain_gates27. Manifest backup taken before the edit: forge_gates.json.bak_20261024_g45 (7D720050). The manifest now has 38 entries, with unique tags and srands.
Driver dry run order: 26(running) → 30 → 27 → 28 → 29 → 31…44 → 45 → 46 → 47 → 48. Nothing is BLOCKED.

| Gate | Tag | Exe (PC sha256) | Candidate options | srand / start | ON bench (d11/13/16/20/22) |
|---|---|---|---|---|---|
| 45 | gate45_timepack_v1_vs_h256e12 | forge_timepack_h256e12.exe 5D5F0959…F747 | TmPlyBonus=8 TmPlyEnd=100 SingleMoveStop=1 SingleMoveDepth=6 | 20261131 / 81001 | = lock 308972/745494/2460422/11901452/31111774 MATCH |
| 46 | gate46_timepack_inc90_vs_h256e12 | same exe | TmIncrementPercent=90 | 20261132 / 84001 | = lock MATCH |
| 47 | gate47_packf2_c80_vs_h256e12 | forge_packf2_h256.exe 5DBC8AE7…3426 | CaptSeeDiv=80 | 20261133 / 87001 | 308021/710812/2292593/11539412/22894603 MATCH |
| 48 | gate48_packf2_c120_vs_h256e12 | same exe | CaptSeeDiv=120 | 20261134 / 90001 | 308994/766981/2562732/8690048/28907978 MATCH |
Base for every gate: forge_h256_e12.exe 456743D9. OFF bench is the lock on both exes, and the pre-gate bench re-runs before each gate.

**45/46 timepack TM lines** (CR PASS; box release d106c5e4 / expose 36d727c6; Coder fc_timepack_h256e12/VARIANTS_h256.md). No rebuild was needed: the PC EXPOSE exe 5D5F0959, built 05:28 with our flags (FMA 0, vmulps 8), comes from a tree byte-identical to fc_timepack_h256e12 (all 20 files). Bench re-verified at 10:54 Vienna: OFF, V1 and V2 all equal the lock, and all 5 TM options are present in the uci list. The TM exemption applies, so ON must equal the lock. Ok flag: CR_PASS_timepack_h256e12_tm.ok.
- Gate 45 note: this line bundles PlyBonus and SingleMoveStop, so the result cannot be split between them.
- Gate 46 note: low gate power is expected.
- PC time proof (10:55 Vienna, CPU 2 BelowNormal, go wtime 60000 btime 60000 winc 600 binc 600, 2 reps; ms / depth):
  - V1 differs on 3 of 3 FENs, PASS:
    - opening_ply6: OFF 2491/2503 d23/23 vs V1 2184/2409 d22/22
    - won_Q_vs_R_ply58: OFF 2420/2353 vs V1 2321/2274, d34 for both
    - forced_one_move_ply79: OFF 1594/1812 d22/23 vs V1 1/1 d6/6
    - Bestmoves are the same for all three.
  - V2 differs on 2 of 3 FENs, PASS by the rule. However, the PC differences are noise-level and in the opposite direction to the box's +90 ms soft limit:
    - opening: OFF 2491/2503 vs V2 2486/2406
    - forced: depth OFF 22/23 vs V2 22/22
    - The time effect of V2 is not visible on the PC under gate and NNUE load. This is consistent with the low-power note.

**47/48 packf2-h256** (CR_PASS_packf2_h256.txt; box sha 8cd37821; patch fd329792 changes search.cpp only, to 542A8343; NoisyLmrDiv is left UNSET; CaptSeeDiv=40 was withdrawn). There was no PC exe, so I built a new one at 10:56 Vienna from /workspace/forge-strength/packf2-h256 using our EXPOSE flags (g++ 15.2.0 Rev14):
  - zip 1440EA40
  - 20/20 source shas OK
  - the only difference from the PC h256_e12 tree is src\search.cpp
  - net md5 6D22F612
  - exe 5DBC8AE7 with FMA 0 and vmulps 8
  - CaptSeeDiv and NoisyLmrDiv are in the uci list
  - bench: OFF equals the lock; C80 and C120 match CR exactly
  - Ok flag: CR_PASS_packf2_h256.ok.
- Notes on 47/48:
  - These are 2 gates of ONE idea (the screen was non-monotonic). Do not pool them. Any H1 needs a confirm gate.
  - Watch time-to-depth and movetime by ply, because the deep-node swings are large (C80 d22 −26%, C120 d20 −27%).
  - The patch is not rebased on Packs A–E.
- Pinlegal (2ea076c8) is NOT gated; it is for the speed stack only.

### Gate 45 condition (added 2026-10-24 ~11:05 Vienna)
Rule: Gate 45 runs only if Gate 27's final Elo is >= -5 (taken from the `- Elo:` line in gate27_timepack_h256e12_vs_h256e12\RESULT.md). If it is lower, SKIPPED_REDUNDANT is written to gate45's RESULT.md and the queue continues with 46. If Gate 27 has no RESULT.md or no Elo line when 45 is due, 45 runs.
- chain_gates27 (PID 2484) only ever waited: it had no fastchess child (its only child was conhost) and launched nothing. It was stopped gracefully with STOP_chain_gates27 and logged "exiting, nothing started" at 11:02:51 Vienna. The STOP file stays in place.
- It is replaced by chain_gates28.ps1 (sha 6A50D1CF…E7FB7FE9B1, PID 11876, started 11:03:18 Vienna). This is chain_gates27 plus the check: it waits for chain_gates24/25/26/27 to exit and for no fastchess, then runs 45 (conditional), 46, 47, 48. Stop file: STOP_chain_gates28.
- forge_gates.json was backed up to .bak_20261024_g45cond (A297814D). Gate 45 now has run_if {gate_tag: gate27_timepack_h256e12_vs_h256e12, min_elo: -5, else: SKIPPED_REDUNDANT, if_no_result: run}, and gates 45–48 now have runner chain_gates28.
- forge_queue.ps1 was backed up to .bak_20261024_v2 (3E3A891B) and patched to v3 (4CE42492). The patch adds run_if handling: status skip_redundant, and in live mode it writes a SKIPPED_REDUNDANT RESULT.md and continues. The patched file parses cleanly, and the parse/threshold logic was tested on sample Elo values -7.20, -5.00, -4.99 and 3.1, giving SKIP, RUN, RUN, RUN.
  CAVEAT: the live driver PID 7500 started at 10:18 and still runs the v2 code in memory, so it was NOT restarted. It does honour a SKIPPED_REDUNDANT RESULT.md once chain_gates28 writes one. It would ignore run_if only if it took over Gate 45 itself, which happens only if chain_gates28 died. A driver restart, or the next reboot, loads v3.
- Dry run at 11:03 Vienna gave the order 26(running) → 30 → 27 → 28 → 29 → 31…44 → 45 → 46 → 47 → 48, with nothing BLOCKED.

### omni-s-h256 PC build: NOT built (waiting on Strength's new handoff), 2026-10-24 11:04 Vienna
- The tree /workspace/forge-strength/omni-s-h256 changed at 11:03:09 Vienna, before any PC build started. src/search.cpp is now 1e1532b2 (S11 clamp + S15 !in_check/!promotion guard), no longer CR's 5870750a, which is kept as omni-s-h256.search.cpp.v1. search.hpp is still bc876470, net md5 6d22f612. Strength's box v2 build at build-omni-s-h256-v2/forge is 77ccfafb.
- IDEA_SOURCE.md is still missing. The fixed tree has not had a CR pass. Not queued; no gate.

## fc_pext_h256 PC speed check (2026-10-24 ~11:11–11:20 Vienna, Engine QA executor). Not a gate; nothing queued.
- Handoff: zip handoff/fc_pext_h256_src.zip 5f609488…793d; the include/ and src/ trees inside it are identical to the tree. Patch artifacts/fc_pext_h256.patch 88e4ea82…5cc0. Compared with the h256_e12 lock, only include/forge/bitboard.hpp (571e47f0) and src/bitboard.cpp (d7829a85) differ. Net md5 6d22f612.
- Macro: the code tests `#if defined(FORGE_USE_PEXT)` (bitboard.hpp:7/161/170/200, bitboard.cpp:20/114/185) and fails with `#error` if __BMI2__ is missing. CMake `-DFORGE_PEXT=ON` only adds `FORGE_USE_PEXT=1` (CMakeLists.txt:21-22). Coder's Windows line `-DFORGE_USE_PEXT=1` is therefore correct; a bare `-DFORGE_PEXT` would have no effect.
- PC builds, from the same 20-file tree (staged zip 29C85FFF, 20/20 source shas OK), g++ 15.2.0 MSYS2 Rev14, `-std=c++20 -O3 -DNDEBUG -DFORGE_NNUE_HIDDEN=256 -ffp-contract=off -fno-fast-math -march=znver5 -static -pthread`, no EXPOSE, Idle priority:
  - ON (adds `-DFORGE_USE_PEXT=1`): bin\forge_pext_h256_on.exe sha256 75E12360AA7B3F95CC995CA0EA23E154C6BD8FE7E9B26C3DBA24FD1589210B78
  - OFF: bin\forge_pext_h256_off.exe sha256 DF6F4FF9050E96621074C55D2AC2C7CDB6569D3123DAC2D02F51B665A5D25252
- objdump instruction counts: pext ON 105 / OFF 0 (box ON shows 104; the compiler differs). FMA (vf[n]madd/msub) is 0 in both.
- Bench d11/13/16/20/22: ON and OFF both 308972/745494/2460422/11901452/31111774, equal to the lock (MATCH).
- perft startpos d6 (`go perft 6`): ON 119060324, OFF 119060324 (both correct).
- nps ABBA: NOT RUN, because no core is free.
  - The Gate 26 fastchess (PID 10548) and its 10 engine processes are unpinned (affinity 0xFFFF), so they can run on any of the 16 cores.
  - Self-play forge.exe x2 is pinned to CPUs 12-15.
  - Per-core load at 11:12 Vienna was 34–75% on every core.
  - No core is unused by fastchess or self-play, so per the rule I did not take one. No NNUE trainer process was visible on the PC (no python trainer, no nvidia-smi).
  - The ABBA can run when Gate 26 finishes and before the next gate starts. Note that chain runners start the next gate within about 20 s, so that gap is short. Otherwise it needs a scheduled window with the chain held, which is your decision.

### QA tick 2026-10-24 11:18 Vienna
- Gate 26 h256e16h vs h256e12 at 580/1000 games: Elo +0.6 ±13.4, LLR -0.18, running (fastchess 10548 under chain_gates24 PID 11000). Runners alive: 11000, 12252 (25), 12912 (26), 11876 (28); driver 7500 (v2 in memory).
- Correction to the 11:12 pext note: NNUE GPU training IS running (nnue_supervisor PID 3880 -> train_resid_b8.py PID 8284/9980, gpu_guard 10836). Self-play running (forge_selfplay, 2x forge.exe). Free RAM 13.1 GB. No change to report.

### QA 2026-10-24 11:30 Vienna — NNUE never-idle (Couns's order)
- Root cause of the 11:10–11:15 gap: Engine NNUE's PAUSE_supervisor (b8 swap) had no expiry. Supervisor is now v2.1-qa: PAUSE expires after 20 min, no permanent HALT (fallback with backoff), fallback recipe lr 7e-4/b0.8 family, C: block 10 GB, heartbeat; `--script` kept. New task Forge-NNUE-IdleWatchdog runs every 5 min and restarts only the supervisor after >10 min idle. b8 run (8284/9980) uninterrupted. Details: NNUE_NEVER_IDLE.md.

### ARCHIVE INTAKE 2026-10-24 11:35 Vienna (ChatGPT-Pro archive, Couns pt368u) — pointer only, queue unchanged
- Details: /workspace/forge-hashes/ARCHIVE_INTAKE.md. Index: /workspace/forge-archive-intake/INDEX.md.
- Two bench-neutral correctness patches vs lock h256_e12 are ready for CR, then QA. They are not gate items:
  - (A) root claimable-draw: searches claimable roots and floors the score at 0. Owner Strength.
  - (B) SMP stale helper node counters. Owner Coder.
- Patches are in /workspace/forge-archive-intake/repro/.
- Already covered by 6.4.24: TT concurrency, qsearch TT rule-50 and qsearch stalemate.

- 11:43 Vienna: CR PASS buckets8 step 1 (fc_buckets8_h256e12, 267b4695). Plumbing only, not gated. QA still has to do the PC build: vfmadd 0, bench = lock, PC nps in the install speed window. Step 2 additionally needs a trainer-vs-engine export parity check (int16/4096 rounding), the head-index log and the bias control. Fix A owner is Strength (draft due ~14:30), fix B owner is Coder (~14:30).

### QA tick 2026-10-24 11:44 Vienna
- Gate 26 h256e16h vs h256e12 at 840/1000: Elo -2.1 +/-11.3, LLR -0.65, running (fastchess 10548). Runners alive 11000/12252/12912/11876, driver 7500 (v2). NNUE b8 run 8284/9980 under supervisor 12716, gpu guards up, self-play up. Free RAM 10.5 GB. No change to report.

## Gates 49–56 (queued 2026-10-24 ~11:48 Vienna, Engine QA executor), all vs the h256_e12 LOCK
Each gate is its own fresh 1000-game SPRT [0,10] (a=b=0.05, normalized), 10+0.1, T1 H16, 8moves_v3 random, conc 5, options on the candidate only (base forge_h256_e12.exe 456743D9…FDFA, no options). Never pooled. Any H1 needs a confirm gate (new openings + new seed) before lock; H1 = no measurable regression, not an Elo claim. All UNPROVEN.
Runner: forge_push\chain_gates29.ps1 (sha B9D6DB6CE2D1C65BEE28D3ED64EBF2C3C22E4320482E332A19C363B879DAE58E, PID 9084, started 11:48:22 Vienna). It is chain_gates28's per-gate logic unchanged (manifest sha check, ok flag, exact pre-gate bench lock/OFF/ON, avg depth, TL); it waits for chain_gates24/25/26/27/28 to exit and no fastchess (20 s settle), then runs 49→56. Stop file STOP_chain_gates29. Log D:\grok-pc-data\forge_push\chain_gates29.log. No running runner was stopped or edited.
Manifest: autorestart\forge_gates.json backup .bak_20261024_g49 (F9B731BC…FAE5, 38 entries); new sha 54F5023F…F9A1, 46 entries (old 38 verified identical, unique tags/srands; ok = DRIVER_HOLD_v1 / ok_driver2 = real flag, same pattern as 45–48). Driver dry run 11:48: launches nothing now; takeover order …G48 → G49 → … → G56, nothing BLOCKED.
packd order per Strength: L1, L3, L4, L2. Gate 54 (L2) has run_if {gate_tag gate51_packd_l1_vs_h256e12, min_elo -5, else SKIPPED_REDUNDANT, if_no_result run}.

| Gate | Tag | Exe (PC sha256) | Candidate options | srand / start | ON bench d11/13/16/20/22 (PC = CR) |
|---|---|---|---|---|---|
| 49 | gate49_packe2r_v1_vs_h256e12 | forge_packe2r_h256e12.exe 8C23A300…66C4 | EvalOnlyStore=1 EvalOnlyStoreMinDepth=2 | 20261135 / 93001 | 308972/744172/2459120/12091213/28730023 MATCH |
| 50 | gate50_packe2r_v2_vs_h256e12 | same | EvalOnlyStore=1 EvalOnlyStoreMinDepth=4 | 20261136 / 96001 | 308972/744172/2459100/10963164/25861818 MATCH |
| 51 | gate51_packd_l1_vs_h256e12 | forge_packd_h256_v2.exe 567FA450…75B1 | Hindsight=1 HindsightMargin=240 HindsightDeepRed=3 HindsightShallowRed=1 | 20261137 / 99001 | 306588/722263/2372328/12446061/23494250 MATCH |
| 52 | gate52_packd_l3_vs_h256e12 | same | Hindsight=1 HindsightMargin=240 HindsightDeepRed=5 HindsightShallowRed=2 | 20261138 / 102001 | 304278/732406/2580667/13028919/33316684 MATCH |
| 53 | gate53_packd_l4_vs_h256e12 | same | Hindsight=1 HindsightMargin=240 HindsightDeepRed=5 HindsightShallowRed=1 | 20261139 / 105001 | 305675/769707/2617904/12645769/32723744 MATCH |
| 54 | gate54_packd_l2_vs_h256e12 (if G51 Elo >= -5) | same | Hindsight=1 HindsightMargin=300 HindsightDeepRed=3 HindsightShallowRed=1 | 20261140 / 108001 | 306861/722565/2372671/11747753/22751739 MATCH |
| 55 | gate55_h256e20i_vs_h256e12 | forge_h256_e20i.exe F982EB7B…0F91 | none (net-only, md5 4c5a96fe) | 20261141 / 111001 | 339071/1146672/3210718/9724519/16668673 MATCH |
| 56 | gate56_h256auto000_vs_h256e12 | forge_h256_auto000.exe 135E4463…12F5 | none (net-only, md5 ab049d95) | 20261142 / 114001 | 382474/1129317/2950787/12705524/19487516 MATCH |

Builds (11:40–11:46 Vienna, build_spec.ps1, Idle priority, g++ 15.2.0 MSYS2 Rev14, `-std=c++20 -O3 -DNDEBUG -DFORGE_NNUE_HIDDEN=256 -ffp-contract=off -fno-fast-math -march=znver5 -static -pthread`; packe2r/packd add `-DFORGE_EXPOSE_TUNABLES=1`; nets: no EXPOSE, float, no INT16/INT32). Staging: /workspace/forge-hashes/pc_stage_g49_54 (zips of include/+src/, 20/20 source shas OK on PC, net md5 checked).
- packe2r: tree fc_packe2r_h256e12 (search.cpp 123DA679, search.hpp 995FE584), only those 2 files differ from PC h256_e12 tree. Full sha 8C23A3001F690A3D987657BC1F25A01946D68E66B0FB5A5020B7C612BE5C66C4. FMA 0, vmulps 10. uci lists EvalOnlyStore, EvalOnlyStoreMinDepth. OFF = lock. CR box expose 1f1b8e69 (Linux; PC sha differs as expected).
- packd v2: tree forge-strength/packd-h256 (search.cpp DCD44A2C, search.hpp 145872D3 = CR's patch e51a0fe0 result), only those 2 differ. Full sha 567FA4509B70B549FFDE96048D333765DD6F74A76C29BFE390FBD9C9A13F75B1. FMA 0, vmulps 10. uci lists Hindsight, HindsightMargin, HindsightDeepRed, HindsightShallowRed. OFF = lock. L1–L4 PC benches = CR box numbers exactly; none reads 297126/861939 (defaults). CR box expose 61f4b037.
- e20i: only src\nnue_weights.inc differs from the lock tree. Full sha F982EB7B04768D2AA7CE28E289761C9288C2C5751984AA6E0DE351ACCF8F0F91, FMA 0. CR box release f5d62378.
- auto000: only src\nnue_weights.inc differs. Full sha 135E4463DA8B9DFF5C0A7CC8BAA90761D2F2947C676E5C6F9BFE21B7F6D912F5, FMA 0. CR box release 019dc399.
- Ok flags written: CR_PASS_packe2r_h256e12.ok, CR_PASS_packd_h256_v2.ok, CR_PASS_nnue_h256_e20i.ok, CR_PASS_nnue_h256_auto000.ok.
- Notes: 49/50 low gate power (CR MEDIUM). 51–54 one idea, non-monotonic in DeepRed: no pattern across lines. 55/56 net-only, never pooled with each other or e16j; any net lock needs Couns to clear the trainer origin.
- nnuemem 3b symbol check: NOT DONE, no CR pass for nnuemem 3a/3b yet (only cr_scratch_nnuemem in progress).

### ARCHIVE BIG ZIPS 2026-10-24 ~11:50 Vienna (Couns approved 11:37) — pointer only, queue unchanged
- Unpacked on the PC under D:\forge_archive_unpack\. 3160 new files were pulled to /workspace/forge-archive-intake/from_pc_big/, all sha-verified. Details: ARCHIVE_INTAKE.md "Big zips".
- New witnesses back fixes A and B: lock 41/50 vs fixA 50/50 on 8 new threefold mate-in-1 cases. B also shows as cumulative info nodes dropping at T4 (lock 5/90, fixB 0/90). No new patch.
- New ideas, untested and not gated: int16/int32 first-layer NNUE, likely bit-exact (Coder); PGO solo PC nps (Coder/QA); underpromotion/mate screen for new nets (NNUE).

- 11:5x Vienna: CR PASS fix A rootclaim-h256 (patch 90a2fb8a, exe d47ca11b) and fix B smp_reset_published_nodes (raw; Coder fc_smpnodes_h256e12 still needs a same-diff check; IDEA_SOURCE must say "ported from archive patch 03"). Combined A+B exe 21063a73, bench = lock. QA decision: no solo gate; both ride the next lock, and on that lock QA reruns bench/perft/ctest/20 claim FENs/50 archive cases/T4 nodes stress.
- 11:54 PT CR PASS fc_pext_h256 (CR_PASS_pext_h256.txt). PC exe accept only if: bench == lock, objdump pext>0 (QA saw 105), built with -DFORGE_USE_PEXT=1 (NOT -DFORGE_PEXT), no vfmadd inside forge:: functions (glibc log_fma ok). Goes into the install-window speed-parts PC nps ABBA.
- 11:59 Vienna G58-60 gcx queued in order QsQ/CheckExtCap8/LmpOffKP (matches Strength). DR rule: if G59 CheckExtDepthCap=8 or G60 LmpOffKP reaches H1, its confirm gate runs at LONGER TC (e.g. 60+0.6), not STC on new openings; G58 normal confirm.
- 12:00 Vienna fc_speedcombo_h256 (Coder, box exe 67ce677e; pinlegal+3a/3b+pext) awaiting CR. Plan: parts' PC nps ABBA, then combo PC nps, then one own 1000g SPRT [0,10] vs h256_e12 with 0 TL/crash before lock (DR reminder). PC exe: -DFORGE_USE_PEXT=1, pext>0, FMA 0 per function.
- 12:01 Vienna CR PASS nnuemem 3a (0530751a) + 3b (49c00075), speed stack only. PC checks in speed-parts window: bench==lock, 3b symbol call count >0, simd checker on update_and_evaluate via /workspace/forge-hashes/cr_scratch_nnuemem/simd_uae.py (plus evaluate), FMA 0 per function. Combo staging waits for CR_PASS_speedcombo.
- 12:04 Vienna CR PASS fc_ptype_h256e12 (board.hpp only, box a86ea931), speed-only, no solo gate. Added to install-window PC nps ABBA list with pext/pinlegal/3a/3b/buckets8s1; joins a combo only via new CR pass.

## Gates 57–60 (queued 2026-10-24 ~12:07 Vienna, Engine QA executor), all vs the h256_e12 LOCK
Each gate is a fresh 1000-game SPRT [0,10] (a=b=0.05, normalized), 10+0.1, T1 H16, 8moves_v3 random, conc 5. The option goes on the candidate only. The base is forge_h256_e12.exe 456743D9…FDFA with NO options (base_override options empty, no shared `-each option.*`). Never pooled; any H1 needs a confirm gate. All UNPROVEN.
Runner: forge_push\chain_gates30.ps1 (sha 2841770AC9A669908846BEB7E0CF67050B2DCF3EAEDE6ECA52129ECDD87D8810, PID 12660, started 12:06:52 Vienna). It uses chain_gates29's per-gate logic plus the VOID checks. It waits for chain_gates24..29 to exit and for no fastchess (20 s settle), then runs 57→60. Stop file STOP_chain_gates30. Log D:\grok-pc-data\forge_push\chain_gates30.log. No running runner was stopped or edited.
VOID checks (CR rule) are built into the runner:
- (a) Static arg check: base gets only Threads/Hash/OwnBook; the candidate gets those plus exactly its gate option; no option.* under -each. A failure means ABORTED.
- (b) Pre-launch: the candidate `uci` must advertise the option name, exact spelling. A failure means ABORTED.
- (c) fastchess `-log engine=true` writes `<gate>\engine_io.log`. The runner parses every `<--- setoption` line after finished game 1, after game 10, and on the whole log at the end. A violation writes VOID.txt, the runner stops only ITS OWN fastchess child, and RESULT.md is marked VOID. ENGINE_OPTIONS_CHECK.txt records each check.
- The parser was tested on a 2-game PC smoke log (PASS) and on a negative case (VOID). The log format is `[Engine] [ts] <  n>  cand_tmdiv18 <--- setoption name TmSoftDivisor value 18`.
Manifest: autorestart\forge_gates.json, backup .bak_20261024_g57 (54F5023F…F9A1, 46 entries). New sha 916474F6B4C0D64045B519F0F42F5D6FFBE56F90C199FB1D64779A9A687D0397, 50 entries. The old 46 are identical, and tags/srands are unique. Each new entry uses ok = DRIVER_HOLD_v1 and ok_driver2 = the real flag, runner chain_gates30. Ok flags written: CR_PASS_tmdiv18_h256e12.ok, CR_PASS_gcx_h256.ok.

| Gate | Tag | Exe (PC sha256) | Candidate option | srand / start | ON bench d11/13/16/20/22 (PC) |
|---|---|---|---|---|---|
| 57 | gate57_tmdiv18_vs_h256e12 | forge_tmdiv18_expose_h256e12.exe 3D432D6B…2DFD | TmSoftDivisor=18 | 20261143 / 117001 | 308972/745494/2460422/11901452/31111774 = lock (TM-only, expected) |
| 58 | gate58_gcx_qsqpromo_vs_h256e12 | forge_gcx_h256.exe D61A8ADC…41B7 | QsQueenPromoOnly=1 | 20261144 / 120001 | 308546/744432/2651938/12022957/29503114 MATCH CR |
| 59 | gate59_gcx_chkcap8_vs_h256e12 | same | CheckExtDepthCap=8 | 20261145 / 123001 | 316092/710285/2128743/10709671/17757113 MATCH CR |
| 60 | gate60_gcx_lmpoffkp_vs_h256e12 | same | LmpOffKP=1 | 20261146 / 126001 | 363528/771438/2549234/15146082/41352219 MATCH CR |

Builds: 11:57–12:01 Vienna, Idle priority, one g++ each, g++ 15.2.0 MSYS2 Rev14 `-std=c++20 -O3 -DNDEBUG -DFORGE_NNUE_HIDDEN=256 -ffp-contract=off -fno-fast-math -march=znver5 -static -pthread -DFORGE_EXPOSE_TUNABLES=1`. Log: D:\grok-pc-data\forge_push\nnue_cand\verify_g57_60.log.
- tmdiv18: tree = copy of PC src_h256_e12; all 20 compile files match the lock manifest. Full sha 3D432D6B1D350545427BF22C38C5B6DC200DD54689FCE58AC8AB705EDBE82DFD. Results:
  - OFF and TmSoftDivisor=18 both read d11-d22 = lock.
  - uci lists `TmSoftDivisor type spin default 22 min 5 max 80`.
  - perft5 4865609. FMA: 0 inside forge:: functions, 0 in the whole exe.
  - TM probe on 10 positions at 20000+200: Div18/default total think time = 1.088. That is directionally consistent with the option applying but noisy (expected ~1.19). The engine_io.log check is the authority.
- gcx: lock tree with only src\search.cpp replaced by Strength's 8E84B1EB (= patch 84d6bc90 result; patch staged too, sha checked). Full sha D61A8ADC05E6E17DA189334F92C787C6F4262F8505C36F233E20B7B4AB2241B7. Results:
  - OFF = lock, and L1/L2/L3 = CR exactly; none reads the lock numbers.
  - uci lists QsQueenPromoOnly, CheckExtDepthCap and LmpOffKP.
  - perft5 4865609. FMA 0.
- Queue position at 12:07 Vienna: Gate 30 is running (chain_gates26, fastchess 2120, started 11:59:56). Ahead of 57: chain_gates26 (30, 27, 28, 29, 31–44), chain_gates28 (45–48) and chain_gates29 (49–56), so about 30 gates.
- Gate 26 finished 11:57: cap with no decision, 1000 g, Elo -4.17 ±10.28, LLR -1.14, clean.
- 03:08 PT Gate 26 h256e16h vs h256_e12 VERDICT cap with no decision 1000g, -4.17+-10.28, LLR -1.14, CLEAN -> REWORK list (barely minus). Install todo: chain_gates30 gates bypass driver PID 7500 (old in-memory, no VOID checks); restart driver onto v3 at install; engine_io.log ~1-2GB/gate (D: 110GB free) - cap logging for unattended queue.

## Gate 61 — net-only k_ep16 vs h256_e12 lock (queued 2026-10-24 12:15 Vienna, Engine QA executor)
- Source: CR_PASS_nnue_h256_k_ep16.txt. Net resid_h256_e16_k_ep16.inc md5 a0542f7e13da80851cfa2b58cf989ffb (PC copy verified, sha256 59FD3599…250F3).
- Exe: bin\forge_h256_k_ep16.exe sha256 DA4A52548ED27406E42E52B12067B03A77CB491455B681DDB22C049ACCB806D6. Built from the lock tree src_h256_e12 with only src\nnue_weights.inc swapped (tree src_h256_k_ep16). Lock flags: float, no EXPOSE, no INT16/INT32, g++ 15.2.0 Rev14. CR's line also had -mtune=znver5, which -march=znver5 already implies.
- Checks: bench d11/13/16/20/22 287715/661305/2481343/11411374/28204132 = CR MATCH; perft5 4865609; FMA 0 (whole exe); uci advertises 0 tunables.
- Gate: gate61_h256kep16_vs_h256e12 vs lock 456743D9…FDFA. No setoption on either side. 10+0.1, T1 H16, 8moves_v3, SPRT [0,10], conc 5, cap 1000, srand 20261147, start 129001, never pooled. Paired PC nps runs first.
- Runner: chain_gates31.ps1 (sha 71545B73…F0F6BB), PID 4276, started 12:15:22 Vienna. Waits on chain_gates24..30, stop file STOP_chain_gates31, log D:\grok-pc-data\forge_push\chain_gates31.log. Same VOID checks as chain_gates30 (static args, engine_io.log at games 1/10/end).
- ok flag: forge_push\CR_PASS_nnue_h256_k_ep16.ok. Manifest: backup forge_gates.json.bak_20261024_g61 (916474F6…, 50 entries). New file A01CC6C4D3874D605912AFCCA211AE8460DC2710F2703417A7E1FF8D07FE0C76, 51 entries, UTF-8 BOM.
- 03:15 PT fix B fc_smpnodes_h256e12 same-diff CR PASS (release 68037472). Rides next lock with fix A, no gate. Next-lock rerun: bench, perft, ctest, claim FENs, 50 archive cases, T4 nodes stress (N>=1500 must be 0 bad). Residual: T4 N<1500 ~1/20 unsearched move (helper depth-1, archive 05/06) -> later fix candidate, rework list.
- 03:17 PT omni-s-h256 v2 (Strength exe 77ccfafb, 13 lines) awaiting CR. DR rule: S6a, S10b, S11a, S12c, S15b (depth-growing node change) confirm at LONGER TC if H1; other lines normal confirm.
- 03:21 PT CR PASS fc_speedcombo_h256 (box 67ce677e). Install-window PC nps ABBA order: pext, pinlegal, nnuemem 3a, 3b, ptype, buckets8s1 -> combo nps -> combo own 1000g gate vs h256_e12 (0 TL/crash). PC exe: -DFORGE_USE_PEXT=1, pext>0, FMA 0 per function, simd_uae.py on update_and_evaluate.
- 03:22 PT (12:22 Vienna) QA tick: Gate 30 h256e16j vs h256e12 at 200g, -29.6±24.8, LLR -1.05 (fastchess 2120). Runners 26/28/29/30/31 + driver 7500 + NNUE supervisor 12716 alive; training python up; 13.4 GB RAM free. No change to report.

## Gates 62-74: omni-s-h256 v2 lines vs the h256_e12 lock (queued 2026-10-24 12:34 Vienna, Engine QA executor)
- Source: CR_PASS_omni_s_h256_v2.txt. Patch omni_s_h256.patch 576b1282 was applied on the box to the PC lock search.cpp/search.hpp, giving search.cpp 1E1532B2 and search.hpp BC876470 (both match CR).
- PC tree src_omni_s_h256v2 is the lock with only those 2 files changed.
- Exe: bin\forge_omni_s_h256v2.exe, sha256 8001127C8552F65DDF6B047D1A00709906A181A153310B5D29AF061BB223FFCB. Built with the lock flags + -DFORGE_EXPOSE_TUNABLES=1 (g++ 15.2.0 Rev14, Idle).
- Checks:
  - all-off bench = lock 308972/745494/2460422/11901452/31111774
  - perft5 4865609
  - FMA 0
  - uci lists all 12 options
- Per-line bench, all five depths, equals ALL_SCREENS for all 13 lines (none equals the lock). S10a d16 = 2518405.
- Settings: candidate-only options, base = stock lock with no options, 10+0.1, T1 H16, 8moves_v3, SPRT [0,10], conc 5, cap 1000, never pooled. VOID: the candidate log must show every setoption at its exact value.
- Order (Strength's revised order):

  | Gate | Line | Options | srand / start |
  |---|---|---|---|
  | G62 | S11b | RfpOppWorse=40 | 20261148 / 132001 |
  | G63 | S1a | CorrUpdateMode=1 | 20261149 / 135001 |
  | G64 | S3b | ThreatHist=1 + ThreatHistDiv=2 | 20261150 / 138001 |
  | G65 | S13c | CheckOrderSee=1 + CheckOrderBonus=16000 | 20261151 / 141001 |
  | G66 | S15a | PawnEgPrune=1 | 20261152 / 144001 |
  | G67 | S12b | HistMalusPct=125 | 20261153 / 147001 |
  | G68 | S1c | CorrUpdateMode=1 + CorrDiffClampCp=12 | 20261154 / 150001 |
  | G69 | S10a | QuietBadThreshold=-12000 | 20261155 / 153001 |
  | G70 | S6a | AspFailHighAlpha=1 [LONGER-TC CONFIRM IF H1] | 20261156 / 156001 |
  | G71 | S11a | RfpOppWorse=20 [LONGER-TC CONFIRM IF H1] | 20261157 / 159001 |
  | G72 | S12c | HistMalusPct=90 [LONGER-TC CONFIRM IF H1] | 20261158 / 162001 |
  | G73 | S15b | PawnEgPrune=2 [LONGER-TC CONFIRM IF H1] | 20261159 / 165001 |
  | G74 | S10b | QuietBadThreshold=-6000 [LONGER-TC CONFIRM IF H1] | 20261160 / 168001 |

- Runner: chain_gates32.ps1, sha A70BD93C…2D6581, PID 8104, started 12:34:13 Vienna.
  - Waits on chain_gates24..31. Stop file STOP_chain_gates32. Log D:\grok-pc-data\forge_push\chain_gates32.log.
  - Same VOID checks as chain_gates30/31.
- ok flag: CR_PASS_omni_s_h256_v2.ok.
- Manifest:
  - backup forge_gates.json.bak_20261024_g62 (A01CC6C4…0C76, 51 entries)
  - new file B7913BD981CFC2875FB89E52619431B3D7BBE509758EC4EAE252C88B4BEB08EF, 64 entries
  - each entry has longer_tc_confirm_if_h1 (true for S6a/S10b/S11a/S12c/S15b, with the reason)
- 03:45 PT (12:45 Vienna) QA tick: Gate 30 h256e16j vs h256e12 at 440g, -15.8±16.6, LLR -1.30 (fastchess 2120). Runners 26/28-32 + driver 7500 + NNUE supervisor 12716 alive; train_resid_v2 (PID 4052, since 12:07) and selfplay up; 7.7 GB RAM free. No change to report.

## 2026-10-24 12:55 Vienna QA decision: speed window order changed
- Box: speedcombo_h256 67ce677e +7.6% median, 14/14 ABBA (Profiler). pext alone neutral (+1.45%, in noise).
- PC order now: (1) speedcombo PC nps ABBA FIRST; if clearly faster, queue its own 1000g gate (0 TL/crash) right away. (2) Per-part PC nps (pext, pinlegal, 3a, 3b, ptype, buckets8 s1) after it, for attribution only; they don't block the combo. 3b still needs simd_uae.py.
- Bug-B regression check for the next lock's A+B: /workspace/forge-coder/cand_tools/smp_mated_fen_check.py (sha bf6911c0…b43f1); run with --cpus on >=2 free cores, or --reps 20+ on 1 core.
- NNUE FYI: b8 ep8 net md5 09227945… (holdout 0.003925, new best) -> Coder pack fc_buckets8_h256e12 -> CR by 16:30 -> QA gate vs h256_e12.

## 2026-10-24 13:12 Vienna crew vote: fc_buckets8_b8ep8 d8 null-cutoff ctest failure
- YES 5/7 (QA, DR, Strength, Profiler, CR first read); NNUE and Strategist not voted. Majority, so it PASSES under Couns's 12:32 majority rule.
- Recorded as a known net-driven effect; test NOT edited. Condition: d8 null tries/cutoffs on a second neutral FEN must show cutoffs (Coder). CR confirms same-diff + d9+ pruning. Lock rules unchanged.
- 04:18 PT (13:18 Vienna) QA tick: Gate 30 h256e16j vs h256e12 at 780g, -10.7±12.0, LLR -1.72 (fastchess 2120). Runners 26/28-32 + driver 7500 + NNUE supervisor 12716 alive; train_resid_v2 (PID 8436) and selfplay up; 11.4 GB RAM free. No change to report.

## 2026-10-24 13:22 Vienna — GPU90 crew vote: PASSED 6/7 YES (NNUE, QA, Strength, Coder, CR, DR; Profiler not yet)
Test line resid_h256_e16_bs16k_lr14e4_b07_s8 (bs16384, lr 1.4e-3, warmup 300, same epochs), queued after current run, flags only.
Conditions: cosine length in positions seen; 1% val-loss check at equal positions seen; CR sees queue-entry diff first; QA benchmark must show loader doesn't cap 16384 below 1.8x pos/s (else loader fix/v3 first); new nets get own net-only gate, never pooled with k-run.

## Gates 75-77: omni-g-h256 (G') lines vs the h256_e12 lock (queued 2026-10-24 13:22 Vienna, Engine QA executor)
- Source: CR_PASS_omni_g_h256.txt. P27A (QsEvasionSee=1) is on HOLD (CR FIX: WAC300 regression) and is NOT queued.
- Patch: omni_g_h256.patch e701f8e1…15c4. Its src/include hunks were applied on the box to the PC lock search.cpp/search.hpp, giving search.cpp 76CD1600 and search.hpp 0E24E020 (both match CR and Strength's tree).
  - The CMakeLists and tests hunks only add a test target, so the direct g++ build does not use them.
  - PC tree src_omni_g_h256 is the lock with only those 2 files changed.
- Exe: bin\forge_omni_g_h256.exe, sha256 9E18ABEC3A85F5CCDFE0158480712359BD6F9FFF6DA50D35A840E2B14C65B7A4. Lock flags + -DFORGE_EXPOSE_TUNABLES=1 (g++ 15.2.0 Rev14, Idle).
- Checks:
  - all-off bench = lock 308972/745494/2460422/11901452/31111774
  - perft5 4865609
  - FMA 0
  - uci lists all 7 options
- Line benches match CR at all 5 depths:

  | Gate | Line | Options | Bench | srand / start |
  |---|---|---|---|---|
  | G75 | P20A | SmallPcMargin=350 + SmallPcDepthGap=3 | 308936/781627/2291405/9304245/22960594 | 20261161 / 171001 |
  | G76 | P21B | QsFutSee=1 | 323517/755660/2478898/11903973/21782699 | 20261162 / 174001 |
  | G77 | P24C | FutHistDiv=256 + FutHistMode=1 | 308949/745397/2510826/11240384/24231089 | 20261163 / 177001 |

  P24C is live: d16 = 2510826.
- Settings: candidate-only options, base = stock lock with no options, 10+0.1, T1 H16, 8moves_v3, SPRT [0,10], conc 5, cap 1000, never pooled. No longer-TC confirm flag on these lines. Any H1 still needs a confirm gate.
- Runner: chain_gates33.ps1, sha 2945FE78…E5D7, PID 14300, started 13:22:26 Vienna.
  - Waits on chain_gates24..32. Stop file STOP_chain_gates33. Log D:\grok-pc-data\forge_push\chain_gates33.log.
  - Same VOID checks as chain_gates32.
- ok flag: CR_PASS_omni_g_h256.ok.
- Manifest:
  - backup forge_gates.json.bak_20261024_g75 (B7913BD9…08EF, 64 entries)
  - new file ABCB2C447FD320856769AA02C579D87DA5051BB3B121A1FE01C8409E5375E76A, 67 entries

## 2026-10-24 13:40 Vienna — Standing null-test class rule PASSED 6/7 YES (DR, CR, QA, Strength, Coder, Profiler)
Net-only build failing d8 startpos null-cutoff ctest = known net-eval effect, test unedited, IF CR confirms diff vs lock touches only src/nnue_weights.inc AND both neutral FENs (Italian, QGD) show d8 null cutoffs. Build still gets its own fresh gate. Applies to e16l (pending CR diff check).

## Speed window: PC nps (grok-pc) and Gate 84 speedcombo (renumbered from G78) (2026-10-24 13:29-13:40 Vienna, Engine QA executor)

**Builds.** `forge_push\build_verify_speed.ps1` ran at Idle with one g++ (13:29-13:31). Each exe = lock tree src_h256_e12 + Coder's sha-verified changed files, built with the exact lock flags and no EXPOSE (speedcombo and pext add `-DFORGE_USE_PEXT=1`). Every exe has:
- bench = lock at d11/13/16/20/22 (308972/745494/2460422/11901452/31111774)
- perft5 4865609
- uci option list = lock
- FMA 0

| Candidate | Exe sha256 | pext instr. | Extra checks |
|---|---|---|---|
| speedcombo (pinlegal + nnuemem 3a/3b + pext) | 55D25DD5FCE85AF62A9C735B08ADAD755DEA4D60A974C1C1FE51CDB44FF10F77 | 107 | simd_uae PASS for evaluate and update_and_evaluate (PC exe, box objdump 2.44) |
| nnuemem3b | 90152ED56EC14282F85DBBD05473E5C12927F43237E5A920D6EA9A35F9FA1BDB | 0 | simd_uae PASS for evaluate and update_and_evaluate |
| pext | AC2364F6B27430A1917B40D19E109909C4C5B051DFBA33F673601FF4F4B49C17 | 105 | |
| ptype | E1E7541DE862F1E8FC837322FB78DCD2F1165F3218B0D2939E58EAE724333EC3 | 0 | |

Lock = forge_h256_e12.exe 456743D9…FDFA.

**PC nps.** `forge_push\nps_abba_speed.ps1` ran 13:32-13:38 with:
- 14 ABBA pairs per candidate, each run `bench 16` at T1 H16
- every run pinned to logical CPU 6 at Normal priority, the same CPU for A and B
- delta per pair = mean(B)/mean(A) − 1
- nodes identical to the lock in every run

Affinity check before the run:
- NNUE trainer: 0xF (CPUs 0-3)
- selfplay workers and their forge.exe: 0xF000 (CPUs 12-15)
- gpu guard: 0xF000
- gate fastchess and engines: not pinned (0xFFFF)

No CPU is reserved for the gate slots, so CPU 6 (outside the trainer and selfplay masks) was used. The A/A control measures the noise.

| Run | Median | Mean | Min / max | Pairs faster |
|---|---|---|---|---|
| speedcombo | **+3.39%** | +2.92% | −0.24 / +6.25 | **12/14** |
| A/A control (lock vs lock) | +0.07% | −0.06% | −2.28 / +0.85 | 8/14 |
| nnuemem3b | +2.04% | +2.05% | −1.70 / +4.50 | 13/14 |
| pext | +3.50% | +3.95% | +2.62 / +6.23 | 14/14 |
| ptype | +4.49% | +4.31% | +1.53 / +6.16 | 14/14 |

Raw data: `D:\grok-pc-data\forge_push\speed_window\nps_abba.csv` and `nps_abba.log`.

- pext is NOT slower on the PC.
- speedcombo meets the bar (≥ +3% and ≥ 12/14), but only just. Its four weakest pairs (1, 2, 7, 9) are single-run dips. It came out below pext alone, and below the sum of its parts.
- pinlegal was not measured on its own.
- ptype is not in speedcombo.

**Gate 84 prepared** (speedcombo vs the h256_e12 lock, same net, no options on either side):

> **Numbering fix (13:46):** this gate was first queued as G78 on chain_gates34 at 13:40, but G78 and chain_gates34 belong to the other executor (e16l G78, option lines G79-G82). What I changed:
> - Stopped my own waiting runner PID 13852. It had only conhost as a child and had started nothing.
> - Renamed my files so the names are free (nothing deleted): chain_gates34.ps1 → chain_gates34_SUPERSEDED_speedcombo_g78.ps1, and chain_gates34.log → chain_gates34_SUPERSEDED_speedcombo_g78.log.
> - Changed the manifest entry to gate 84 (tag gate84_speedcombo_vs_h256e12, srand 20261170, start 198001, runner chain_gates35).

- exe forge_speedcombo_h256.exe 55D25DD5…0F77
- srand 20261170, start 198001
- cand_off = lock bench, no cand_on, nps=1 (paired d20 nps before games)
- ok flag CR_PASS_speedcombo_h256.ok
- manifest:
  - backup forge_gates.json.bak_20261024_g78 (ABCB2C44…E76A, 67 entries, before my add)
  - backup forge_gates.json.bak_20261024_g84fix (40CEFA23…8AAD, 68 entries, with the wrong G78 number)
  - current file 855A66C5225CECFE6F3BC58DB80AE719DDC35FC5C30476C3030D62F3FB27D0A8, 68 entries. No G78 entry from me; G84 = speedcombo.
- runner chain_gates35.ps1 (BEE83732…9969), PID 6656, started 13:46:07
  - waits on `chain_gates(2[456789]|3[01234])\.ps1`
  - also waits for the line "chain_gates34 finished" in `D:\grok-pc-data\forge_push\chain_gates34.log`, so G84 can't run before the other executor's G78-G82
  - then no fastchess, then 20 s
  - stop file STOP_chain_gates35, log `D:\grok-pc-data\forge_push\chain_gates35.log`
  - same VOID checks as chain_gates31 (both sides only Threads/Hash/OwnBook)
  - note (13:55): the other executor's chain_gates34.ps1 does not exist on the PC yet. G84 waits until it has run and logged "chain_gates34 finished" (200 h abort). If that runner is renamed or never logs that line, G84 never starts.

**speedstack (fc_speedstack_h256e12, CR box d92283a9): speed only, no gate. Result: drop it, keep ptype alone.**

- exe forge_speedstack_h256e12.exe 822AE8B1DCAA99AF31E99563049473514AC225077A99B97A55515392DB14DFE9, built with lock flags at Idle. Bench = lock at all 5 depths, perft5 4865609, FMA 0, uci = lock.
- Method: 14 rounds of L P S S P L on CPU 6, bench 16 T1 H16, plus 14 A/A pairs. Nodes OK in every run. Finished 13:49.

| comparison | median | mean | min / max | faster |
|---|---|---|---|---|
| ptype vs lock | +4.73% | | | 14/14 |
| speedstack vs lock | +4.46% | | | 14/14 |
| speedstack vs ptype | −0.14% | −0.39% | −3.80 / +1.13 | 4/14 |
| A/A | +0.11% | +0.95% | −2.40 / +6.55 | 7/14 |

- speedstack does not beat ptype; its median is slightly negative, inside the A/A noise.

**EvalCacheKB on the omni_eval expose exe (box 46e0e2c0, patch b71c4d77): speed only, no gate. Result: no measurable gain.**

- No PC omni_eval exe from the other executor existed, so I built forge_omni_eval_h256e12.exe 77D1003715354F1B3591C9C7DCA2AE33B4AA09C613A6C10BFA19C03BD2FF494B (lock flags + -DFORGE_EXPOSE_TUNABLES=1, Idle).
- Checks: uci advertises EvalCacheKB/MinorCorrWeight/UpcomingRep/UpcomingRepMinPly/NetScalePct; perft5 4865609; FMA 0. Bench = lock at all 5 depths with the option OFF, EvalCacheKB=64 and EvalCacheKB=128.
- Method: same exe, A = OFF, B = setoption EvalCacheKB N. 14 ABBA pairs each on CPU 6, bench 16 T1 H16, and nodes OK 42/42. Ran 13:51-13:54.

| B side | median | mean | min / max | faster |
|---|---|---|---|---|
| EvalCacheKB=64 | +1.01% | +0.89% | −4.58 / +7.17 | 9/14 |
| EvalCacheKB=128 | +0.21% | +0.31% | −7.22 / +4.74 | 8/14 |
| A/A | −0.02% | +0.06% | −2.79 / +3.49 | 7/14 |

- Both are within noise. Neither reaches the +3% / 12-of-14 bar.
- Logs: `D:\grok-pc-data\forge_push\speed_window\` build_omnieval.log, nps_speedstack.csv/.log, nps_evalcache.csv/.log.

## 13:41 Vienna — CR PASS fc_stack_h256e12 (release 7df006c8, expose 38d00325)
Queue only after all four part gates finish (packc, packa, packb, timepack on h256). Lines G-S1 ALL, G-S2 (fs40), G-S3 (no packb) per CR_PASS_stack_h256e12.txt; ALL and fs40 longer-TC confirm if H1. Other subsets need a full 5-depth bench first. Drop a part only on H0 or clearly negative at the cap.
fc_speedstack (d92283a9): PC nps only (lock, ptype, speedstack), added to the nps list.

## 13:43 Vienna — 6-day install TODO (DR gap): fc_stack auto-queue
Chain G-S1/S2/S3 after the four h256 part gates in the unattended runner. Runner reads each part verdict; part OFF only on H0 or clearly negative at cap. If all parts stay in -> run S1, S2, S3 as CR listed. If a part is off -> run the precomputed subset line for that case (precompute 5-depth benches NOW for no-packc, no-packa, no-packb=S3, timepack-off=echo check) and skip+log if no precomputed bench matches. Pre-gate bench check is scripted before each stack gate.

## 13:48 Vienna — P27A (QsEvasionSee=1) reserved as G83
Queue only after CR lifts HOLD and Strength adds WAC 001 mate-depth (P27A vs OFF) to P27A_RERUN.txt (DR). PC exe forge_omni_g_h256.exe (9E18ABEC…), pre-gate d11 must be 294807. Flag longer_tc_confirm_if_h1 (finds 196/205/232 later). srand 20261169, start 192001.

## 13:50 Vienna Oct 24 — QA notes
- GPU90 line (CR PASS, NNUE inserting as next queue line): warmup 150 steps (~2.46M pos) instead of the voted 300, per QA's suggestion. Fallback bs8192 / lr 9.9e-4 needs its own CR look before it is queued.
- P27A QsEvasionSee=1 (67f629d6): CR HOLD lifted, PASS. WAC 001 mate d10 vs lock d13. G83, own fresh 1000g SPRT [0,10] vs h256_e12, option on candidate only, PC d11 must be 294807; H1 needs a longer-TC confirm.
- fc_buckets8_b8ep8_h256e12: CR PASS (Release 2519734b, UNPROVEN). Reserved G85 (srand 20261171, start 204001). PC bench must equal 271885/644468/1897857/11812003/18700642 with vfmadd 0 before queueing; record nps vs lock (box 0.963). Trainer licence origin blocks the lock, not the gate.
- 13:51: G85 buckets8 also needs a paired WAC300 at 1000 ms on a quiet core (OFF, buckets8, OFF) added to CR_PASS_buckets8_b8ep8_h256e12.txt before it starts (DR, node-reducing screen).
- 13:52: WAC300 condition met (CR_PASS_buckets8 line 55: 285 vs 284 @1000ms, 263 vs 256 @100ms). G85 hold lifted; queue once PC bench matches.

## 13:51 Vienna Oct 24 — QA tick
- Gate 30 h256_e16j (run j net) vs h256_e12: cap with no decision, 1000g, -11.1 ±10.6, LLR -2.28, CLEAN. Not locked; rework list (minus net).
- Gate 27 timepack_h256e12 vs h256_e12 started 13:42 (benches MATCH, srand 20261113), 95/1000 at 13:51. Note: Explorer/dir length shows 0 B for the open log; read it with a shared FileStream.
- NNUE trainer alive (thermal hs 53 / mj 74), free RAM 7.7 GB.
- 13:57 G84 switched speedcombo to ptype (+4.49% 14/14, confirm +4.73%) by crew majority; speedcombo to rework list; next speed build idea ptype+pext+nnuemem3b without pinlegal/3a (Profiler) needs CR then PC nps vs ptype. Runner chain_gates35 restarted as PID 4504; forge_gates.json sha 2EA95831...28F7, 68 entries.

## 14:03 Vienna Oct 24 — Engine QA executor: G78–G82 + G85 queued (grok-pc)
All vs the h256_e12 lock exe forge_h256_e12.exe 456743D9…FDFA (base gets only Threads/Hash/OwnBook, VOID-checked by static fastchess-arg check + engine_io.log after game 1, 10 and final). 10+0.1 tm1000, T1 H16, 8moves_v3 random, SPRT [0,10] a=b=0.05, conc 5, 1000 cap, never pooled, any H1 needs a confirm gate.
- **G78** e16l net-only (fc_nnue_h256_e16l_ep16_ep10base), exe bin\forge_h256_e16l.exe **B565980C…3667** (lock tree + only nnue_weights.inc md5 c6a5b6d1…, lock flags, no expose). Bench 424944/993118/3150849 = CR, d20/22 recorded 13505834/26501692; perft5 4865609; FMA 0; uci = lock. srand 20261164, start 180001. **Priority insert**: chain_gates_g78ins.ps1 (PID 7392) did pre-gate checks (all MATCH 14:00) and polls gate27 fastchess 13592 every 1 s; launches within ~1 s of its exit only if no other fastchess is running, so it runs ahead of chain_gates26's next gate and G31+. Fallback (if it can't launch safely): chain_gates34 runs G78 first after G77.
- **G79** MinorCorrWeight=100, exe forge_omni_eval_mcw_h256e12.exe **166C8C93…7DF0** (own tree *_mcw_*, expose). OFF = lock, ON 265022/765880/2618097/16419587/37386307 = CR; perft5, FMA 0; uci `MinorCorrWeight spin 0 0..300`. srand 20261165, start 183001. longer_tc_confirm_if_h1 = true.
- **G80** TmNewIterPct=75 / **G81** TmPrevMoveFall=1 / **G82** TmPrevMoveFall=1 + TmPrevMoveFallScale=50, exe forge_omni_tm_h256e12.exe **BBAD74F6…32E2** (search.cpp 7f44965c, search.hpp 5a277970). srand 20261166/67/68, start 186001/189001/192001. Bench = lock with each option on (TM-only, onEqualsLockOk).
  - Isolation (PC exe uci): TmPlyBonus default 0, TmPlyEnd 100, SingleMoveStop 0, SingleMoveDepth 6, TmBmcDecay 0, TmBmcScale 50, TmNewIterPct 0, TmPrevMoveFall 0, TmPrevMoveFallScale 100 → all switches OFF; dependent params are only read when their switch is on (source). Lock-common Tm* defaults equal the lock's. Candidate lines carry only the gate option(s); no timepack option set.
  - Time proof (PC CPU 9, Normal, 13:54–13:57): FALL FEN (tm_fall, 2 reps): lock OFF 1978/1956 ms, 7583730 nodes; omni_tm OFF 1963/2088 ms, 7583730 nodes (= lock); FALL 5329/5363 ms, 20992978 nodes; FALL50 3626/3660 ms, 14200520 nodes. tm_proof middlegame search2: lock 3970, OFF 4026/3962, NIP75 3446/3344 ms; tactical search2 lock 5027, OFF 4886/4895, NIP75 1662/1634 ms; FALL leaves these unchanged (3936/4740). Short 150+10 ms: NO_TIME_LOSS for all. Files nnue_cand\tmproof_g80_82.txt, tmproof2_g80_82.txt.
- **G85** buckets8 (fc_buckets8_b8ep8_h256e12), exe forge_buckets8_b8ep8_h256e12.exe **71580B31…A977**. PC bench 271885/644468/1897857/11812003/18700642 = CR, perft5 4865609, vfmadd 0, uci = lock. WAC300 hold cancelled (CR line 55: 285 vs 284 @1000 ms). srand 20261171, start 204001. PC nps (info only) 8 ABBA pairs bench 16 CPU 9: median cand/lock 0.977 (0/8 faster; box 0.963).
- Runner **chain_gates34.ps1 (PID 11132)**: G78 (fallback, skipped if RESULT.md exists), G79, G80, G81, G82, G85. It waits for chain_gates24..33 + chain_gates_g78ins. It always writes "chain_gates34 finished" (also after STOP/abort/error), and chain_gates35 (G84) waits for that line.
- Order: gate27 (running) → **G78 insert** → chain_gates26 rest … chain_gates33 (G75–G77) → G79, G80, G81, G82, G85 → chain_gates35 G84.
- forge_gates.json backup autorestart\forge_gates.json.bak_20261024_g78_85 (2EA95831…28F7, 68 entries) → new **121D4233F2C3299C14C8C3703CD8CB4F2E1C84ADC14FDBF0CB79D09CCC2A0BDF, 74 entries**, UTF-8 BOM, old entries byte-identical as objects.
- ok flags written: CR_PASS_e16l_h256.ok, CR_PASS_omni_eval_h256e12.ok, CR_PASS_omni_tm_h256e12.ok, CR_PASS_buckets8_b8ep8_h256e12.ok.
- Note: G82 and G83 P27A both use openings start 192001 (srand differ 20261168 vs 20261169); accepted.

### Rework list
- NIP60 (TmNewIterPct=60): dropped, not queued — tuning step if NIP75 is H1.
- 14:06: G84 ptype holds cleared (CR 13:58 solo-gate + 14:05 IDEA_SOURCE addenda in CR_PASS_ptype_h256e12.txt; zip 0d15082f). Runs on chain_gates35 PID 4504 after chain_gates34.
- 2026-10-25 02:05 CET (Engine QA executor), per Couns "never discard plus or barely-minus builds":
  - G89 e16s_sol (fc_nnue_h256_e16s_sol_ep16_ep10base): cap 1500, no decision, -6.49 ±9.12, LLR -2.17, CLEAN -> rework list, barely minus (keep; no pooling).
  - G90 e16m (fc_nnue_h256_e16m_ep16_ep10base): H0 at 1360g, -10.48 ±9.06, LLR -2.96, CLEAN -> rework list, minus (keep, not dropped).
  - G95 e12f (pack e12f c1d8c41a): cap 1500, no decision, +0.23 ±8.53, LLR -0.56, CLEAN -> rework list, flat (eligible for one fresh-seed rerun under the driver fallback, never pooled).

## 14:07 Vienna Oct 24 — Engine QA executor: G83 P27A queued
- **G83** P27A QsEvasionSee=1, exe bin\forge_omni_g_h256.exe 9E18ABEC…B7A4. PC uci `option name QsEvasionSee type spin default 0 min 0 max 1`. PC bench (CPU 9) OFF 308972/745494/2460422/11901452/31111774 = lock. ON 294807/637545/2061683/11447052/18014861: d11 294807 as required, all 5 depths = CR.
- 1000g SPRT [0,10] vs the plain lock exe, option on the candidate only, longer_tc_confirm_if_h1 = true. srand 20261169. Openings start **207001**, moved off 192001 so it no longer shares openings with G82; no other gate starts in 207001–208000.
- New ok flag CR_PASS_omni_g_h256_p27a.ok, pointing to /workspace/forge-hashes/CR_PASS_omni_g_h256.txt. That box file (13:17) still reads HELD at line 51. The lift is recorded here (13:50) and in Strength P27A_RERUN.txt: 287/287 vs OFF 283/283.
- chain_gates34: stopped my own PID 11132 while it was only waiting, added G83 after G82, restarted as **PID 9396** (script sha 57A35F17…). Order: 78, 79, 80, 81, 82, 83, 85. It still writes "chain_gates34 finished", so chain_gates35 G84 runs after it.
- forge_gates.json backup .bak_20261024_g83 (121D4233…) → **8EB36E231A33E12516B5E383EFDB44B5570006878C8019EE3654380A628C5449, 75 entries**, UTF-8 BOM.
- 14:35 6-day install TODO (GPU): guard logs every throttle event (83 C memory-junction guard); >3 per hour means the next NNUE line auto-falls back to bs8192/lr 9.9e-4 (needs CR on that line). g90 isn't a clean batch test (extra shards, per CR). NNUE to record the equal-positions loss comparison in GPU90_PLAN.md (DR).

## 14:42 Speed builds B/C (CR PASS, UNPROVEN, speed route)
- B fc_pext_ptype_h256e12, exe 9f08c126 (CR_PASS_pext_ptype_h256e12.txt)
- C fc_ptype_pext_nnuemem3b_h256e12, exe d7949164 (CR_PASS_ptype_pext_nnuemem3b_h256e12.txt)
- Next step: 14 ABBA nps pairs on the PC (CPU 6) vs ptype alone (E1E7541D). A build gets a gate only if it is faster than ptype beyond noise (A/A control was +0.07%, 8/14).
- PC acceptance for each exe: bench equal to the lock at d11-d22, objdump pext count >0, 0 FMA in Forge functions; for C also simdcheck on update_and_evaluate as well as evaluate.
- Use stripped patches (relative a/ b/ paths) only, never -p0 against the lock tree.
- **14:43–14:49 Vienna, PC result (Engine QA executor).** No gate queued; QA decides.
  - Build: `forge_push\build_verify_bc.ps1` (a copy of build_verify_speed.ps1, Idle, one g++). Each tree = lock src_h256_e12 + the CR-verified changed files from Coder's trees (sha = CR manifest, 10/10 OK on PC). No patch applied, so there was no -p0 risk. Tree diff vs lock = exactly the expected files. Lock flags + `-DFORGE_USE_PEXT=1`, no expose.
  - PC exe shas differ from CR's box shas (Windows static g++ vs box Linux cmake; same as ptype box a86ea931 → PC E1E7541D). Source identity is proven by the file shas.
    - B `bin\forge_pext_ptype_h256e12.exe` **FF5965DD728C130CB6F3CBF507E22108276C4F38D33AB4B17764285300A2C54A** (box ref 9f08c126)
    - C `bin\forge_ptype_pext_nnuemem3b_h256e12.exe` **7346222C000B3F4AA6C79C2BE7FD006ABA9907F9DB5CB3487E7B84ED835ED999** (box ref d7949164)
  - Acceptance (both PASS): bench d11/13/16/20/22 = 308972/745494/2460422/11901452/31111774 = lock; perft5 4865609; uci list = lock; pext 105 (all in forge::); FMA 0 in forge:: and 0 in the whole exe. C only: 2 calls to update_and_evaluate; box objdump 2.44 on the PC exe: simd_uae.py (update_and_evaluate) PASS and simd_eval.py (evaluate) PASS.
  - nps: `forge_push\nps_abba_bc.ps1` (a copy of nps_abba_speedstack.ps1), 14:46–14:49. 14 rounds of the palindrome P B C C B P (P = ptype E1E7541D) + 14 A/A pairs P P P P. bench 16, T1 H16 OwnBook false, every run on CPU 6 at Normal priority. Nodes 2460422 in all runs. Affinity was the same as the earlier window (trainer 0xF, selfplay 0xF000, gate 27 fastchess 13592 and its engines unpinned 0xFFFF). Free RAM 10.5 GB.

| vs ptype | median | mean | min / max | pairs faster | verdict |
|---|---|---|---|---|---|
| B pext+ptype | +1.60% | **+1.58%** | −1.64 / +4.45 | **13/14** | FASTER beyond noise |
| C ptype+pext+3b | +2.60% | **+2.56%** | −0.12 / +4.69 | **13/14** | FASTER beyond noise |
| C vs B | +0.94% | +0.98% | −0.09 / +2.44 | 13/14 | (info) |
| A/A ptype vs ptype | +0.18% | +0.10% | −1.97 / +1.19 | 7/14 | noise band ±1.05% |

  - Bar: at least 12/14 pairs faster and mean over +1%. Both pass. B is marginal: +1.58% is only about 0.5% above the A/A band, and round 6 was 0.00%. C is clearer, and in 13/14 rounds C beat B as well. Neither reaches the 14/14 and +4% of the earlier real gains (ptype vs lock).
  - Logs: `D:\grok-pc-data\forge_push\speed_window\` build_bc.log, nps_bc.csv, nps_bc.log, *.dis.txt.

## 14:44 rfpavg / contcorr (CR PASS, UNPROVEN) -> 6-day queue, each its own 1000g (1500 unattended) SPRT [0,10] vs h256_e12, option on candidate only, no pooling, confirm if H1
- rfpavg exe 5252c263 (CR_PASS_rfpavg_h256e12.txt); contcorr exe 143b5765 (CR_PASS_contcorr_h256e12.txt)
- Primaries: G-rfpA RfpReturnBlend=25 (bench 328818/798654/2270651, longer-TC confirm if H1); G-rfpB RfpReturnBlend=35 (291464/813197/2539014); G-ccA ContCorrectionWeight=60 (306229/703990/2479806); G-ccB ContCorrectionWeight=45 (312218/716516/2561106, longer-TC confirm if H1, WATCH for TL/stalls).
- Spares if room: RfpReturnBlend=30 (336648/721576/2222087); ContCorrectionWeight=80 (332005/726418/2695739, longer-TC confirm if H1).
- Before each start on PC: OFF bench == lock at 5 depths, option listed in uci, exe sha matches.
- 14:45 G-ccB HOLD until CR replays the stalled WAC position 20x with ContCorrectionWeight=45 on a quiet core and it never repeats (Strength's ask). If it repeats: hang, G-ccB is not queued and goes back to Coder.
- 14:46 B/C rel patches (Coder): B _rel.patch sha256 264ecb3c0250cb0d..., C _rel.patch sha256 1899de8631fee75d...; exes unchanged 9f08c126 / d7949164.
- 14:46 DR proposal (QA votes YES): one primary per option, rfpA (RfpReturnBlend=25) and ccA (ContCorrectionWeight=60); rfpB/ccB only as a tuning step if the primary reaches H1. Pending majority.
- 14:46 Install TODO: verify fastchess timeout handling under 10+0.1 (a stalled engine must lose on time, get logged as TL, and the match must continue); add a slot watchdog that flags any game log with no progress for >5 min.
- 14:47 one-primary vote tally: YES DR, Strength, QA (3/7, majority needs 4). CR running WAC300 x3 cc45 stall repro, result ~15:30.
- 14:48 DECIDED 4/7 (DR, Strength, QA, Profiler): queue only rfpA and ccA as primaries; rfpB/ccB only as tuning steps after a primary H1. ccA also HOLD until CR's WAC300 watchdog run (incl. a weight-60 pass, DR's ask) is stall-free.
- 14:51 QA decision: C (PC exe 7346222C...D999) goes into the 6-day queue as its own speed gate vs h256_e12 after G84. Openings get a fresh srand and start offset that no other gate uses. B is not gated, since C contains B and beat B 13/14; B stays on the rework list as a fallback in case C fails.
- 14:52 DR proposal: give G84's slot (srand 20261170, start 198001) to C instead of ptype; ptype becomes fallback like B. Votes YES: DR, QA (2/7).
- 14:53 DECIDED 6/7 (DR, QA, Strength, Coder, Profiler, CR): G84 slot goes to C (PC exe 7346222C...D999), keeping srand 20261170 / start 198001. ptype is the first fallback, then B. If G84 has already started, it finishes and C runs right after it. The separate C-after-G84 entry from 14:51 is replaced by this.
- **14:52–14:56 Vienna, G84 -> build C applied on the PC (Engine QA executor).** G84 had NOT started: no G84 output folder, the only fastchess was gate 27 (PID 13592, srand 20261113), chain_gates35 was still waiting on chain_gates26..34, and chain_gates34.log has no 'chain_gates34 finished' yet.
  - The G84 config was baked into the running PID 4504 (the $GATES array in chain_gates35.ps1 is parsed at launch; only the sha256 is read from forge_gates.json, by tag, at gate start). So: edited the script, then stopped 4504 the clean way, via its own stop file `forge_push\STOP_chain_gates35` (approved by Couns; log 14:54:37 "STOP file present while waiting; exiting, nothing started"). Stop file then renamed to `STOP_chain_gates35.used_20261024_g84c`. Relaunched the same command line (powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File ...\chain_gates35.ps1) via Win32_Process Create: **new runner PID 5212** (started 14:54:52). It still waits for chain_gates24..34 to exit AND 'chain_gates34 finished' in D:\grok-pc-data\forge_push\chain_gates34.log, then no fastchess. No other process touched (13592, chain runners 26/28-34/g78ins, forge_queue 7500, trainer, selfplay, guards all alive after).
  - `C:\Users\Administrator\grok-pc\forge_push\chain_gates35.ps1`: backup `chain_gates35.ps1.bak_20261024_g84c` (sha256 D8B2C56F...33BA). New sha256 0C1DA2D6CE1942E3BDAD0DC0A98D1866CF1EF447C25973431B42050F60B0436D; parses with 0 errors. G84 line now: tag/out folder `g84_c_ptype_pext_nnuemem3b` (D:\grok-pc-data\forge_push\g84_c_ptype_pext_nnuemem3b), cand `cand_c_ptype_pext_nnuemem3b`, exe `bin\forge_ptype_pext_nnuemem3b_h256e12.exe`, ok `CR_PASS_ptype_pext_nnuemem3b_h256e12.ok`, opts none, srand 20261170, start 198001, nps 1, off = lock bench. Unchanged: base forge_h256_e12.exe 456743D9...FDFA, 10+0.1 tm1000, T1 H16 OwnBook=false, 8moves_v3 random, 1000 cap, conc 5, SPRT [0,10] a=b=0.05, VOID checks, header comment updated.
  - New `forge_push\CR_PASS_ptype_pext_nnuemem3b_h256e12.ok` (sha256 0C57C7F0...4545), points to box CR_PASS_ptype_pext_nnuemem3b_h256e12.txt (45bfa353...315c). Without it the runner would ABORT the gate.
  - `forge_push\autorestart\forge_gates.json`: backup `forge_gates.json.bak_20261024_g84c` (= old sha 8EB36E23...C5449). G84 entry: tag g84_c_ptype_pext_nnuemem3b, cand, exe, sha256 7346222C000B3F4AA6C79C2BE7FD006ABA9907F9DB5CB3487E7B84ED835ED999, ok + ok_driver2, driver_note; srand/start/base_override/prebench unchanged. Text edit only (same BOM/CRLF), JSON parses. **New forge_gates.json sha256 FBB13743A3C4A8C9B2DC85E1C855B18706BB2002BE08BBE73A2FFE000DBC1563.**
  - Check: bin\forge_ptype_pext_nnuemem3b_h256e12.exe sha256 on PC = 7346222C...D999 = manifest entry. ptype (E1E7541D) is the first fallback, then B (FF5965DD); neither is queued.
- 14:58 Install TODO: leftover STOP_chain_gates24/25/27 (10:44/11:01) in forge_push; their runners are not alive. Before the install, confirm those gates are retired, then rename the files to .used_. STOP_chain_gates35 was already renamed .used_20261024_g84c; runner 5212 is alive.
- 15:03 Net packs from Coder (await CR): g90 fc_nnue_h256_e16g90_ep16_ep10base (exe 7cd802ac..2215, net ceb7dd61) PRIORITY; s_sol fc_nnue_h256_e16s_sol_ep16_ep10base (exe 61cfd344..246e, net 247fd729), provenance MEDIUM (4.4% Sol SF-d3 labels): gate allowed but NO LOCK without Couns. On CR PASS: each its own 1500g SPRT [0,10] vs h256_e12 in the 6-day queue (g90 first), unique srand/start, PC bench + sha + simdcheck before start, confirm on H1.
- 15:11 s_sol provenance: Coder relays Couns (15:10) that Sol data is allowed and the lock hold is lifted. QA will verify this in Coder's chat before any s_sol lock; gating is unaffected either way.
- 15:13 Trainer origin vote (train_resid_b8 / v2, own code): YES QA, CR, Coder (3/7). CR spot-check clean (Sol copy is C++ only, no shared lines). NNUE said both b8 and v2 are its own; Coder asked NNUE to confirm v2 for g90/s_sol.
- 15:14 DECIDED 6/7 (QA, CR, Coder, Strength, Profiler, DR): b8 trainer origin cleared for net locks. QA check of v2: forge_resid/train_resid_v2.py md5 7640ffe6, 432 lines, grep finds 0 copyright/licence/spdx/stockfish/bullet/nnue-pytorch/github hits. v2 is covered as well, per DR's condition.
- 15:15 CORRECTION (NNUE): v2 is derived in structure from the Couns-supplied train_nnue.py (5a161c70; author/licence unknown, not in dwqww). Chain: train_nnue.py -> train_resid.py (fe1d1281) -> v2 -> b8. Training-side only, not shipped. Re-vote posted; QA and NNUE YES with an IDEA_SOURCE lineage note. Next week: optional clean-room trainer from NNUE, checked by export parity.
- 15:16 RE-VOTE on corrected lineage: YES 7/7 (QA, NNUE, Profiler, Strength, DR, CR with caveat, Coder). v2/b8 nets lockable; lineage note in IDEA_SOURCE.md; clean-room trainer from NNUE next week (off the running GPU queue, done only on export parity; no trainer published until then).

## 15:17 trainer provenance closed
Couns (via NNUE, t228u 15:17): train_nnue.py 5a161c70 was AI-written (Fable 5.1) for Forge at his request; not third-party. v2/b8 nets fully usable. Recorded in IDEA_SOURCE.md (backup .bak_20261024_1517).

## 15:19 contcorr un-hold
CR stall check done (CR_cc45_stall_check.txt): G-ccA (ContCorrectionWeight=60) CLEAR, G-ccB (=45) CLEAR with a watch on it. Both go in the 6-day queue at 1500g. Watch rule: check TLs daily; if either gate gets a time loss or a bestmove later than movetime+1s, pause that gate through its own STOP/PAUSE file and send the FEN to CR.

## 15:20 correction
Per the 14:47 4/7 vote (one primary per option): only G-ccA (=60) is queued. G-ccB (=45) stays a conditional tuning step and runs only if ccA reaches H1. Supersedes the 15:19 note.

## 15:20 Vienna QA tick
- Gate 27 timepack_h256e12 vs h256_e12 VERDICT cap with no decision at 1000g (ended 15:17:17): -5.91±9.05, nElo -14.06±21.53, LLR -1.58, 97/114/789, ptnml [2,89,335,72,2], CLEAN (0 TL/crash/warn). Not locked -> REWORK list (barely minus).
- chain_gates26 saw a STOP file, did not start Gate 28, finished. All chain runners 24-35/g78ins and forge_queue (7500) exited via STOP files at 15:09 (6-day install in progress; INSTALL_6D_20261024.txt, gates json 77393455..., queue ps1 71D1A4E8...). No fastchess running at 15:20; slots idle until the installed driver starts.
- GPU 15:20:42: util 84%, hot spot 58 C, mem junction 76 C; trainer resid_h256_e24_n alive; supervisor 12716, gpu_guard 4904 alive; 17.2 GB RAM free.

## 15:46 Vienna QA tick (no post; install still in progress)
- Installed driver now r4 (forge_queue.ps1 v3-6day r4, PID 6092, started 15:46:02 by the watchdog) and it adopted its own fastchess PID 380. Gate 78 h256_e16l vs h256_e12 (attempt 2, fresh srand 1838728869, start 180001, cap 1500) running since 15:30:19: prebench all MATCH, static arg check and engine option check PASS. At 158 games: -35.3±32.3, LLR -0.82, 23/39/96. PGN growing (859 KB).
- NNUE: train_resid_v2 (PIDs 11292/3232, since 15:19:42), supervisor 12716, gpu_guard 4904, selfplay guard alive. ADLX CSV fresh (15:46:06): util 61-71%, hot spot 59 C, mem junction 80 C. All 8 Forge scheduled tasks Ready. RAM 12.7 GB free. Only leftover STOP-type file: stop_ep10_runners.ps1 (a script, not a STOP flag).
- Install TODO still open: forge_watchdog.log Vienna label is ~9 h off ("00:46 Vienna" at 15:46 PC). GPU util below the ~90% target in these samples.

## INSTALL 6-day (2026-10-24, Engine QA executor; times are PC clock = Vienna)
- Driver: autorestart\forge_queue.ps1 r4 sha 19FA0C5F6DEA536115D4B78594A3B86B1F8874BEB49B53C8B7224A74E79CF387 (r1 71D1A4E8, r2 80CC4A7B, r3 C3ADC4FE; CR copy + diffs in forge-hashes/install_6d/). Driver PID 6092 (started 15:46 by task Forge-AutoRestart-Watchdog), it adopted G78 fastchess PID 380.
  - r2 bug: PowerShell names are case-insensitive, so the Preflight local $d shadowed the global $D and G78 attempt 1 (15:22-15:30) wrote to relative paths. That attempt is archived as partial_attempt1_badpaths_20261024_1535 and not counted; it was fixed in r3.
  - r4 implements CR findings H1 (per-gate STOP_<tag>), M1 (per-side overrun; tl<=0.1005) and M2 (a clean H1 auto-queues exactly ONE confirm gate with a fresh srand/openings at 1500 g, never pooled, no auto-lock; a confirm that hits H1 queues nothing; longer_tc_confirm_if_h1 gates confirm at 60+0.6, which takes about 16 h for 1500 g; NOT CLEAN H1 writes an alert only), plus L1-L4.
  - Until a STOP_<tag> is used, end a gate only with ABORTED.txt in its folder, never with a PAUSE file. Rename used STOP files to .used_<stamp>.
- Queue (forge_gates.json B96E5278..): G78 (running), then G88 g90 and G89 s_sol (both new, see below), then the rework list including G86 rfpA (RfpReturnBlend=25, LTC confirm) and G87 ccA (ContCorrectionWeight=60, time watch). The dry run reports 60 runnable gates = about 165 h at the 1500 cap.
  - G27 timepack_h256e12 is on the rework list as barely minus.
  - ccB (ContCorrectionWeight=45) is CONDITIONAL: queue it only if G87 ccA reaches H1. No ccB line was ever added.
  - G83 P27A precondition PASS: on exe 9E18ABEC, d11 ON = 294807 and d11 OFF = 308972 (= lock).
- G88 gate88_e16g90_vs_h256e12 (srand 1602516321, start 216001) and G89 gate89_e16s_sol_vs_h256e12 (srand 1921068996, start 219001): both CR PASS and net-only.
  - The PC builds have different shas from the box (6534EABA / 1E19D19B vs 7cd802ac / 61cfd344) because the PC uses znver5, static and g++ 15.2.
  - PC bench d11-22 equals CR exactly (356701/... and 360488/...). perft5 OK, FMA 0, simdcheck v2 PASS. v1 FAILs, which is the known znver5 vcmp+mask lowering.
  - The s_sol PC underpromotion probe scored core 16/16, so the flag ROOK_UNDERPROMO_PASS_gate89 is written.
- Note: 8moves_v3.pgn has 34,700 games, but openings starts run past it (180001..219001). fastchess still runs (G78 at 180001 plays), presumably wrapping the start. Opening uniqueness between gates therefore comes from the per-gate srand shuffle, not from the start offset. Worth a CR look.
- NNUE: F:\forge_nnue_train\queue.txt md5 ED8D5D688E901C1C61D2E7CCA9337E9E, 161 lines. n/o/p/q are at L22-25 and unchanged; f001-f136 are at L26-161.
  - At 15:36:51 another agent added --val-positions 1000000 to 139 lines and left no backup. It was not me.
  - Throttle fallback watcher v2 (6CB511BE.., task Forge-NNUE-ThrottleFallback) rewrites only not-started lines with bs>8192 to _fb8k after more than 3 thermal events in 60 min.
  - Supervisor auto-fallback is unchanged. The named fb8k line was not added (rule: no fill-line or supervisor edits).
- Boot: the new task Forge-Boot-Kick (AtStartup, S4U) starts the driver, idle watchdog and throttle watcher when no interactive session appears within 4 min. Its 15:44 test saw explorer and did nothing.
- forge_watchdog.ps1 label fixed (93B87992..). The 15:46 line "00:46 Vienna" was the old 9 h-off label.

## 16:05 Vienna opening wrap closed
CR checked fastchess 1.8.2 opening_book: order=random shuffles the whole 34.7k book by -srand, rotates it by (start-1)%size and takes 750. The start wrap is harmless; only the srand separates gates (about 2% overlap by chance). Rule: never reuse an srand, including on retries (r4 already follows this).

## 16:19 Vienna e16m queued as G90 (Engine QA executor)
- G90 gate90_e16m_vs_h256e12 (fc_nnue_h256_e16m_ep16_ep10base, CR PASS 16:15, net-only, net md5 ed2c7099, zip de1dcfa5). Inserted directly after G89 s_sol; it mirrors G89 (base_override h256_e12, options [], 1500 cap, SPRT [0,10], no pooling, longer_tc_confirm_if_h1 false, r4 auto-confirm on H1).
- srand 1166240132 (new: not in the manifest, RUN_INFO files, the queue log or any PC text file) and start 222001.
- PC build: build_verify_e16m.ps1 (same recipe as g90/s_sol: lock tree plus the net only, g++ 15.2, znver5, static). exe forge_h256_e16m.exe sha A6307193C9D9B51ED5E8AA2885D29672A47F19641380EA24064EBFBEE0930BB5. The box build was 05352f2c.
- PC checks: bench d11-22 337126/824328/3443707/17045834/44264240 = CR (d11 337126 is the r4 prebench precondition). perft5 4865609, FMA 0, uci list = lock, simdcheck v2 PASS (v1 FAIL is the known znver5 false fail). Log: D:\grok-pc-data\forge_push\nnue_cand\build_e16m.log.
- forge_gates.json B96E5278.. -> CE835BBE.. (backup forge_gates.json.bak_e16m_20261024_161906). ok flag CR_PASS_nnue_e16m.ok created. Driver SelfTest ALL PASS. The DryRun order is G88 (running since 16:14) -> G89 -> G90 -> G28 ..., with 59 runnable gates (about 162 h).
- G78 e16l finished as H0 accepted (Elo -44.5 +/- 18.1).

## 16:19 Vienna QA tick
- Gate 78 h256_e16l vs h256_e12 VERDICT H0 accepted at 432g (ended 16:13:39): -44.5±18.1, nElo -81.6±32.8, LLR -2.96, 44/99/289, ptnml [10,67,108,30,1], CLEAN (0 TL/crash/warn), option check PASS final. Clearly minus -> dropped (not rework).
- Driver r4 (PID 6092) auto-started Gate 88 e16g90 vs h256_e12 at 16:14:49 (fastchess 9372, srand 1602516321, cap 1500): prebench base+cand d11-22 all MATCH, static arg + engine option checks PASS. 40g: 5/3/32, LLR 0.11. This is the first real finish->next-gate handover by the installed driver: verified. Still unverified: pre-gate bench after a reboot.
- NNUE: train_resid_v2 run o (resid_h256_e16_o_bs16k..., since 15:58:47), supervisor 12716, gpu_guard 4904, throttle watcher 13580, selfplay guards alive. ADLX 16:19:25: util 75%, hot spot 60 C, mem junction 81 C. All 8 Forge tasks Ready. RAM 13.7 GB free.

- 2026-10-24 16:43 Vienna HELD B4/B11/B12 (Strategist Q3 timepack variants, FORGE_6DAY_QUEUE.md): held because they use the dropped P13 TmPlyBonus/TmPlyEnd; replaced by timepack2-h256 (TmDecisivePct primary, TmForcedDepth filler) pending CR.
  - B4 = Gate 45 gate45_timepack_v1_vs_h256e12 (TmPlyBonus=8 TmPlyEnd=100 SingleMoveStop=1 SingleMoveDepth=6): never started (no out folder, no fastchess). Was already SKIPPED_REDUNDANT via run_if (G27 -5.91 < -5); now status "HELD_dropped_P13_TmPlyBonus_B4_replaced_by_timepack2_h256_pending_CR" (r4 HELD* mechanism). Entry kept, on rework list.
  - B11 (TmPlyBonus=4) and B12 (TmPlyEnd=60): never added to the manifest; nothing to change. Do not add them.
  - Manifest backup autorestart\forge_gates.json.bak_holdB4B11B12_20261024_1643 (CE835BBE…3409, 80 entries) → new 059E8CA6180EF47FF7163C4D953517D359A7E2A1EB2D5E344BA7F0955A7D31A6, 80 entries; only gate45 changed (one inserted status line, BOM kept). Note: real path is C:\Users\Administrator\grok-pc\forge_push\autorestart (not D:).
  - Dry run 16:43: G88 running (e16g90), next G89; order unchanged except G45 now (held) instead of skip. Runnable 59 x 2.75 h = 162.25 h, held 1. SelfTest ALL PASS. No STOP/PAUSE files created; no process touched.

## 16:51 Vienna QA tick (no post; nothing changed)
- Gate 88 e16g90 vs h256_e12 (fastchess 9372, driver r4 PID 6092) at 360g: +1.0±15.7, LLR -0.08, ptnml [1,30,117,31,1]. PGN really 1.995 MB / 374 results (Explorer shows 0 B only because the open handle hides the size). Watchdog 16:42 all alive.
- NNUE trainer (train_resid_v2) + supervisor 12716, gpu_guard 4904, selfplay guards alive. ADLX 16:51:17: util 82%, hot spot 59 C, mem junction 78 C. All 8 Forge tasks Ready. RAM 16.3 GB free.

## 17:03 Vienna timepack2-h256 queued as G91 DEC70 + G92 FD6 (Engine QA executor)
- CR PASS 16:52 (CR_PASS_timepack2_h256.txt f5f7e952): UNPROVEN, OFF-default, TM-only. Zip bf9fcb8e..6c862, patch 25bfe3ef (-p1 vs h256_e12), net 6d22f612 = lock. Box check: lock + patch == zip src/include (search.cpp 7fb7c090, search.hpp ddfc4642).
- PC build: build_verify_timepack2.ps1 (same recipe as e16m/omni_g: PC lock tree src_h256_e12 + only search.cpp/search.hpp; g++ 15.2.0, znver5, static, H256, + -DFORGE_EXPOSE_TUNABLES=1 per CR). Tree 20 files, only those 2 differ. exe bin\forge_timepack2_h256e12.exe sha256 6505F859D7BCAF6FF75B83621E8ABBDD0211FF035372831454BDDDEF08DA73DF (box CR expose a5d58d02; differs as expected).
- PC precondition, all PASS: bench d11-22 308972/745494/2460422/11901452/31111774 = lock bare, with TmDecisivePct=70 and with TmForcedDepth=6. uci "TmForcedDepth type spin default 0 min 0 max 12", "TmDecisivePct type spin default 0 min 0 max 100". perft5 4865609, FMA 0, simdcheck v2 PASS (v1 known znver5 false FAIL). Log D:\grok-pc-data\forge_push\timepack2\build_timepack2.log.
- Option echo (core 3): forced FEN wtime 10000: FD6 d6 in 1 ms vs OFF d18 342-357 ms (3/3). Won FEN wtime 10000: DEC70 504-516 ms d22 vs OFF 515-528 ms d22, so CR's 240-250 ms identifier does NOT reproduce on the faster PC. Probe (probe_dec70.txt): the option does apply (2 s: d17 vs d18; losing side 10 s: d20 vs d21), but at 10+0.1 the 0.45 TmMinFactorPercent floor and iteration granularity often absorb it. Expect DEC70 to be near-flat.
- Manifest 059E8CA6.. -> 9B45C78C1B807E71FD8220025BBEF3BB1543CE810C2FE8FAD63397C3183C3DFB (backup forge_gates.json.bak_timepack2_20261024_170224, 80 -> 82 entries, BOM kept). ok flag CR_PASS_timepack2_h256.ok created. Install script autorestart\install_timepack2.ps1.
  - G91 gate91_tp2_dec70_vs_h256e12: option.TmDecisivePct=70 only, directly after G90. srand 1754428259, start 225001.
  - G92 gate92_tp2_fd6_vs_h256e12: option.TmForcedDepth=6 only, very end of the manifest. srand 899825575, start 228001.
  - Both mirror G90: base_override h256_e12 (options []), 10+0.1, T1 H16 OwnBook off, 8moves_v3, SPRT [0,10], cap 1500, no pooling, longer_tc_confirm_if_h1 false, r4 auto-confirm on H1. prebench cand_off = cand_on = lock (r4 runs base/OFF/ON at all 5 depths + uci advert check; TM-only so ON==lock is allowed).
  - srands: no hit anywhere (manifest, RUN_INFO, logs, all txt/json/log/ps1/md under both forge_push folders). Starts: no hit outside engine_io*.log. Every 6-digit number shows up there as a timestamp or node-count substring, so that check can't be strict.
- CR low F2 (record): DEC uses |score|. If DEC70 comes back flat or H0, the next rework is a WINNING-ONLY variant (score >= +450) before trying 60. FD6 stays OFF unless H1.
- SelfTest ALL PASS. DryRun: G88 running (fastchess 9372, 489 games at 17:02) -> G89 -> G90 -> G91 DEC70 -> G28 ... G85 -> G84 -> G92 FD6 (last). Runnable 61 x 2.75 h = 167.75 h, held 1 (G45/B4). This is over the 144 h of 6 days, so FD6 likely runs after day 6, and any later r4 auto-confirm is appended after it.
- Not touched: G88, NNUE trainer/supervisor/guards, any other process. No STOP/PAUSE files. RAM 14.5 GB free. B4/G45 stays HELD.
- 2026-10-24 17:05 Vienna: G91 DEC70 (gate91_tp2_dec70_vs_h256e12) moved behind the ranked gates per CR (now directly before G92, last), because on the PC it saves only ~2% time; Strength reworks it so DEC acts after the 0.45 floor, winning-only (>=+450), and it requeues only after the PC time check shows the won position spending >=25% less time, with a fresh srand and a CR same-diff check. forge_gates.json 9B45C78C -> 5BEB6F78 (backup forge_gates.json.bak_g91move_20261024_170533).

## 17:14 Vienna QA tick (no post; nothing changed)
- Gate 88 e16g90 vs h256_e12 (fastchess 9372, driver r4 PID 6092) at ~609g: -0.0+-12.5, LLR -0.25, ptnml [2,53,190,53,2]. No STOP/PAUSE files.
- NNUE train_resid_v2 (5040/13476, since 16:51) + supervisor 12716, gpu_guard 4904, throttle watcher 13580, selfplay guards alive. ADLX 17:14:10: util 74%, hot spot 60 C, mem junction 81 C. All 8 Forge tasks Ready. RAM 13.9 GB free.

## 17:52 Vienna QA tick: 6-DAY INSTALL DONE + VERIFIED (Phase 2 closed before 18:04) -> Phase 3 starts
- Install verified: driver r4 (19FA0C5F, PID 6092) reads forge_gates.json (5BEB6F78.., 82 entries, ~165 h runnable at the 1500 cap); real finish->next-gate handover G78->G88 at 16:14:49 with prebench all MATCH + option checks PASS; watchdog relaunch proven (10:18 v1->v2, 15:46 r4); 8 Forge tasks Ready (Logon, Watchdog, Boot-Kick, NNUE-IdleWatchdog, ThrottleFallback, GPU-PowerCap, HWiNFO-Autostart, HWiNFO-Watchdog); watchdog log every 15 min all alive (queue, gpu_guard, nnue_supervisor, selfplay, hwinfo, sensors fresh).
- Post-reboot prebench: verified by code path in r4 (st.current with dead fastchess -> Finish-Gate -> partial -> rerun with fresh srand via Run-Gate, which always runs prebench and aborts on mismatch). Not a live reboot (would cost a running gate); Boot-Kick only tested in the interactive-session case.
- Gate 88 e16g90 vs h256_e12 at 1000g: -1.74+-10.17, LLR -0.72, ptnml [7,89,310,90,4]; running on to the 1500 cap. engine_io.log stopped growing at 17:14 (425 MB; logging cap), gate log live.
- NNUE: trainer now train_resid_v3a.py (guard-tag train_resid_v2.py, PIDs 6972/7036, since 17:39), supervisor 12716, gpu_guard 4904, throttle watcher 13580, selfplay guards + forge_selfplay alive. ADLX 17:52:24: util 63%, hot spot 59 C, mem junction 82 C. RAM 13.9 GB free.
- Open (not blockers): GPU util still under the ~90% target; FD6/G92 likely past day 6.

## 2026-10-24 18:00 Vienna (UTC+2) — Engine QA executor: G93 e24n + G94 e16o queued (net-only, CR PASS 17:52, UNPROVEN)
- Packs (box sha verified, then re-verified on the PC): e24n fc_nnue_h256_e24n_ep24_ep10base zip 24f89518..ae18, patch vs h256e12 4b5fbc73..3337 (only src/nnue_weights.inc), net md5 5a1cab10; e16o fc_nnue_h256_e16o_ep16_ep10base zip 251ba787..dd1e, patch f1f252eb..349a (only src/nnue_weights.inc), net md5 368c9f10.
- PC build (autorestart\build_verify_netpack.ps1 -K e24n|e16o, copy of build_verify_e16m.ps1; lock tree + only nnue_weights.inc, g++ 15.2.0 MSYS2, -O3 -march=znver5 -static -DFORGE_NNUE_HIDDEN=256 -ffp-contract=off -fno-fast-math, no tunables):
  - e24n exe forge_h256_e24n.exe sha256 FF5CDE4372135D8D3EE5D98C10C4F5FBCC34D11FEBF85D65EC77D5499262C137; bench T1 H16 OwnBook false d11/13/16/20/22 398567/1112953/3091840/13454558/33935333 = box/CR; perft5 4865609; FMA 0 in whole exe; simdcheck v2 PASS (v1 known znver5 false FAIL); uci list = lock. STATUS PASS.
  - e16o exe forge_h256_e16o.exe sha256 EAF05F47B0D21DCED1103768A87876D9B3B5F65475A10265748569350811F67D; bench 273777/943889/4231283/20110777/47318371 = box/CR; perft5 4865609; FMA 0; simdcheck v2 PASS; uci list = lock. STATUS PASS.
- Blend-end (crew P29 placement rule: > 0.6 goes behind the ranked gates): e24n = 0.75 (run n resid_h256_e24_n_bs16k_lr14e4_b075_s11; NETS.md l.1507/1533, p29/queue_13c921bd_current.txt l.22, Coder draft + IDEA_SOURCE.md); e16o = 0.8 (run o resid_h256_e16_o_bs16k_lr12e4_b08_s12; NETS.md l.1508, queue l.23, Coder draft + IDEA_SOURCE.md). CR confirmed both. -> both placed after G84, before G91/G92 (NOT after G90).
- Manifest forge_gates.json 5BEB6F78..6FF -> BA2848FE910D73A8EF73BCDAB9CE2B935A4AD6DD173B3B1A5CFC22A8692FCBD1 (82 -> 84 entries), backup forge_gates.json.bak_e24n_e16o_20261024_175940 (= 5BEB6F78). Installer autorestart\install_e24n_e16o.ps1.
  - G93 gate93_e24n_vs_h256e12: srand 1057512028, openings_start 231001, prebench cand_off = e24n bench (d11 398567), watch_time=true (r4 stop-on-TL), ok CR_PASS_nnue_e24n.ok.
  - G94 gate94_e16o_vs_h256e12: srand 1081675020, openings_start 234001, prebench cand_off = e16o bench (d11 273777), ok CR_PASS_nnue_e16o.ok.
  - Both copied from G90: 10+0.1, T1 H16 OwnBook off, base h256_e12 (456743D9) and candidate get only Hash/Threads/OwnBook (options []), 8moves_v3, SPRT [0,10] a=b=0.05, cap 1500, conc 5, never pooled, longer_tc_confirm_if_h1=false -> one r4 auto-confirm on H1, no auto-lock.
  - srands/starts: checked unused in manifest and in 916 RUN_INFO/log/result/json/ps1/txt/md files under forge_push (C: and D:): 0 hits. G93/G94 numbers unused.
- CR F1 (e24n): one WAC chunk once hit the harness 30 s bestmove wait (not reproduced). r4 supports stop-on-TL, so G93 has watch_time=true: any loss on time, move ending < 0.10 s on the clock, or move > 5 s stops G93's own fastchess and writes a driver PAUSE_gate93_e24n_vs_h256e12.txt (48 h expiry) + CR_TIMEWATCH_<stamp>.txt. QA then pings CR. To keep a gate stopped beyond that, use STOP_<tag> or the gate's ABORTED.txt — never leave a hand-made PAUSE file in place. Same rule (manual) for G94.
- Checks: SelfTest ALL PASS; dry-run order G88 (running, fastchess 9372, untouched) -> G89 -> G90 -> G28 ... G85 -> G84 -> G93 e24n -> G94 e16o -> G91 -> G92 last. Runnable 63 x 2.75 h = 173.25 h at the cap (+1 held G45, +G88 running); ~59 gates ahead of G93 => G93 starts at most ~162 h after G88 ends (~Oct 31 at the cap; SPRT early stops shorten it). G93/G94 are past day 6 if most gates run to the cap.
- Not touched: G88, NNUE training, any foreign process. No STOP/PAUSE files made. PC RAM ~13.8 GB free.
- Crew rules:
  - (a) DR conditional: if G88, G89 and G90 all end H0 before e24n starts, move e24n/e16o behind the ranked gates (held, not dropped). NOTE: by the P29 placement they already sit behind the ranked gates (after G84), so this is satisfied; if it fires, keep them there (no drop).
  - (b) Strategist P29: when the f ep12 b0.5 pack is CR-passed, it gets its own gate AHEAD of e16o (b0.8), i.e. insert it before G94 (blend-end 0.5 <= 0.6, so per the P29 placement rule it goes right after G90 — which is also ahead of e16o).

## 2026-10-24 18:07 Vienna (UTC+2) — Engine QA executor: G91b timepack3 TmDecisiveWin=60 replaces G91 DEC70 (CR PASS d8c8f4b6, 17:58; UNPROVEN)
- Done after the e24n/e16o edit was verified (sequential, one writer). Pack zip f8635523 (= CR), patch 59e1800f (= CR); PC tree = lock + only src/search.cpp ae7721ca + include/forge/search.hpp fc10d316, net md5 6d22f612 = lock. Script autorestart\build_verify_timepack3.ps1, log D:\grok-pc-data\forge_push\timepack3\build_timepack3.log.
- PC exes (g++ 15.2, znver5, static, H256, -ffp-contract=off -fno-fast-math): release forge_timepack3_h256e12_release.exe 52D8D2D618206CFBB936CD3F0F7482CEAE0D41CB3827E849A450E33549C73F78 (box d24e8fdc); expose forge_timepack3_h256e12.exe AB5111CCCC382B597B20F840750DC3EE73C3D8756C6F7DF5ECC13DFA6629131F (box f1ffded2). Differ from box as expected (box x86-64-v3/dynamic).
- Preconditions: bench expose OFF and TmDecisiveWin=60 = lock at all 5 depths (d11 308972 / d13 745494 + 3 deeper, per build_timepack3.log); W40, release OFF, release W60 = lock at d11/d13. uci expose: "option name TmDecisiveWin type spin default 0 min 0 max 100". FMA 0 (both exes), simdcheck v2 PASS, perft5 4865609.
- Time check 10+0.1, OFF/ON interleaved, fresh process, median of 3, Idle on core 3 (gate fastchess affinity 0xFFF0), RAM 15.7 GB free:
  | FEN | OFF ms (median) | ON=60 ms (median) | delta | depth OFF->ON | verdict |
  | knight_up W (+709) | 586/580/245 (580) | 142/152/147 (147) | -74.7% | 18->15 | PASS (<= -25%) |
  | mg_knight_up W (+520) | 337/336/350 (337) | 148/149/159 (149) | -55.8% | 18->16 | PASS |
  | knight_up B losing (-673) | 998 | 1005 | +0.7% | d20, nodes 2959197 identical all runs | PASS |
  | mg_knight_up B losing (-474) | 543 | 545 | +0.4% | d21, nodes 1002607 identical all runs | PASS |
  | QvR W (+495, info) | 511 | 196 | -61.6% | 22->19 | info only |
  - Note: knight_up OFF run 3 was 245 ms / d17 (wall noise); the median still clears the bar by a wide margin. 40 not needed.
- Manifest BA2848FE.. -> 63C20BE995D48EE57C3992675ADC2B95696533CC23F736888BB88DF93C2C6DBF (84 -> 85 entries), backup forge_gates.json.bak_timepack3_20261024_180638 (= BA2848FE). JSON validated (re-parse + order checks).
  - New G91b gate91b_tp3_dwin60_vs_h256e12 in G91's slot: expose exe AB5111CC, candidate-only option.TmDecisiveWin=60, base h256_e12 only Hash/Threads/OwnBook, SPRT [0,10], cap 1500, 10+0.1, never pooled, TL=0 via watch_time=true, prebench cand_off = cand_on = lock, srand 1882198661, start 237001 (both unused in the manifest and 961 RUN_INFO/log/result files), ok CR_PASS_timepack3_h256.ok.
  - G91 DEC70: status HELD_replaced_by_gate91b_tp3_dwin60_CR_PASS_timepack3_h256, moved to the very end (held tail), not deleted.
- Dry-run order (SelfTest ALL PASS): G88 running -> G89 -> G90 -> G28 ... G85 -> G84 -> G93 e24n -> G94 e16o -> G91b tp3 dwin60 -> G92 FD6 (last runnable) -> [G91 DEC70 held]. Runnable 63 x 2.75 h = 173.25 h (+ held 2).

## 2026-10-24 18:08 Vienna (UTC+2) — Crew vote 4/7 (QA, Profiler, Coder, CR): G91b moved up to right after G90
- G91b gate91b_tp3_dwin60_vs_h256e12 moved from after G94 to right after G90 and before G28. Only the position changed. Every entry was checked byte-identical as compressed JSON, and the top-level fields are unchanged. G88 was not touched (still running, fastchess 9372).
- forge_gates.json 63C20BE995D48EE57C3992675ADC2B95696533CC23F736888BB88DF93C2C6DBF -> 7640BAFD39B3B1311D8DEC256631D031E8D529F2443B0DA5B5FC89A339CEB4CC (85 entries). Backup forge_gates.json.bak_g91bmove_20261024_180824. SelfTest ALL PASS.
- Dry-run order: G88 (running) -> G89 -> G90 -> G91b -> G28 -> G34 -> G35 -> G86 -> ... -> G85 -> G84 -> G93 -> G94 -> G92 -> [G91 DEC70 held]. Runnable 63 x 2.75 h = 173.25 h.
- Follow-up rules:
  (a) When Strategist P29 f ep12 b0.5 passes CR, queue it right after G90, AHEAD of G91b. It is the P29 direction test.
  (b) If G91b ends H0, do NOT drop it. Retry at TmDecisiveWin=40, then 20, then a variant with CR's F3 extension (skip the scale on an unstable or falling eval). That variant goes on the rework list.

## 2026-10-24 18:48 Vienna (UTC+2) — QA tick: G88 verdict, G89 started
- G88 gate88_e16g90_vs_h256e12: cap with no decision at 1500g (ended 18:41): +2.78 ±8.52 Elo, LLR 0.09, W/L/D 201/189/1110, ptnml [11,129,455,147,8], 0 TL, 0 crash, option check PASS, CLEAN. Not locked; small plus -> rework list (eligible for one fresh-seed rerun under the driver fallback, never pooled).
- G89 gate89_e16s_sol_vs_h256e12 started automatically 18:41:50 (fastchess 10252). PREBENCH base and cand all 5 depths MATCH; option check PASS. At 40g: -34.9 ±67.9, LLR -0.19.
- PC: GPU 78% util, hot spot 60 C, mem junction 80 C (adlx_sensors.csv fresh 18:47); trainer train_resid_v3a (guard-tag train_resid_v2) alive; HWiNFO/ADLX/Forge tasks Ready; RAM 10.2 GB free.

## 2026-10-24 19:17 Vienna (UTC+2) — Engine QA executor: G95 e12f + G96 e16p + G97 e16q queued (net-only, CR PASS 18:37/18:53/19:08, UNPROVEN)
- Packs (box zip sha = CR, re-verified on PC; net md5 + patch sha + patch scope only src/nnue_weights.inc): e12f c1d8c41a (net 27641a08), e16p 5df47d48 (net 6ad348ac), e16q 58faa4fe (net e3317599). PC build autorestart\build_verify_netpack2.ps1 -K (copy of build_verify_netpack.ps1 + RAM guard; lock tree + only nnue_weights.inc; g++ 15.2.0 MSYS2 -O3 -march=znver5 -static -DFORGE_NNUE_HIDDEN=256 -ffp-contract=off -fno-fast-math). Min free RAM during builds 14.7 GB.
  - e12f forge_h256_e12f.exe 37AC63D2B80CE2C3938F6551FA266957704FA8FA6E06DA87CC861F39515FD95B; bench T1 H16 OwnBook false d11-22 308504/796021/2706765/10248772/16629648 = CR; perft5 4865609; FMA 0 whole exe; simdcheck v2 PASS; uci = lock. PASS.
  - e16p forge_h256_e16p.exe F3F19DCACF69E2D89F665F540EE0F8BCA83A17B7F27252A0BD4B648E38AB38FF; bench 360158/900776/2970791/9726892/28360353 = CR; perft5 OK; FMA 0; v2 PASS; uci = lock. PASS.
  - e16q forge_h256_e16q.exe FD2EB5E0697F1AA505086E80807F46BC4D2ED0D4FDD49E8E6496E2B3C1221786; bench 324823/941378/3015674/16300606/24550219 = CR; perft5 OK; FMA 0; v2 PASS; uci = lock. PASS.
- Box oracle precondition (qa_oracle_e12f_e16p_e16q/run.log): cr_oracle_stream.py 45b0ffe9 + pinned oracle cpp ea459353, fresh scratch libforge_core per pack: 1000000 records, bad_records=0, exit 0 for all three; oracle bins 5d73099b / f370f939 / e10a0c4c and stream shas 8f93d0d2.. / 392b9f51.. / f5f66f7d.. (e12f/e16p equal CR's). Scratch removed.
- Manifest forge_gates.json 7640BAFD..CB4CC -> E7462E43F07DF33092E63A08855F7B971E0DDDBEE3A3198A8EDA34E9FAE1B31A (85 -> 88 entries; every old entry byte-identical), backup forge_gates.json.bak_e12f_e16p_e16q_20261024_191750. Installer autorestart\install_e12f_e16p_e16q.ps1. Entries cloned from G93 (SPRT [0,10], 10+0.1, T1 H16 OwnBook off, 8moves_v3, cap 1500, never pooled, options [] (candidate-only Hash/Threads/OwnBook), one r4 auto-confirm on H1, watch_time=true).
  - G95 gate95_e12f_vs_h256e12: srand 973474437, start 240001, right after G90, ahead of G91b (P29 direction test b0.5, rule (a)). CR fast-TC tactics FLAG noted in driver_note.
  - G96 gate96_e16p_vs_h256e12: srand 1867938095, start 243001, after G84, before G93 (b0.7; tail ordered by ascending blend-end 0.7/0.75/0.8/0.85).
  - G97 gate97_e16q_vs_h256e12: srand 1262762038, start 246001, after G94, before G92 (b0.85).
  - srands/starts unused: manifest + 1238 json/ps1/txt/md/log/csv/RUN_INFO/RESULT files under forge_push (C: + D:) + 25 pgn: 0 real hits (one '243001' substring is a microsecond timestamp in gate89 engine_io.log). Gate folders 95-97 did not exist.
- Checks: SelfTest ALL PASS; DryRun order G89 (running, fastchess 10252, untouched) -> G90 -> G95 -> G91b -> G28 ... G85 -> G84 -> G96 -> G93 -> G94 -> G97 -> G92 -> [G91 held] (G45 held in place). Runnable 65 x 2.75 h = 178.75 h at the cap.
- Day 6 (144 h from the ~15:30 install = ~Oct 30 15:30): at the cap, gates from G76 on start after day 6 (14 gates: G76 G77 G79-G83 G85 G84 G96 G93 G94 G97 G92); before this edit it was from G77 (11). G95 starts ~Oct 25 00:12 at the cap. SPRT early stops shorten all of this.
- Not touched: G89, NNUE training, any foreign process. No STOP/PAUSE files made. Nothing deleted.

## 2026-10-24 19:37 Vienna — G98 e12rec + G99 f001 queued (Engine QA executor, net-only H256 vs h256_e12 lock)
- G98 gate98_e12rec_vs_h256e12: pack fc_nnue_h256_e12rec_b04_ep12_ep10base (box 75c964c5, net md5 8c4304ca, blend-end 0.4, run resid_h256_e12rec_b04_s200_fb8k per CR override; HANDOFF run_name wrong). PC exe forge_h256_e12rec.exe 86308F9F…31CB; bench 317753/765471/2132628/10281627/26115090 = CR; FMA 0; perft5 4865609; simdcheck v2 PASS; oracle d3a0ea30 bad_records=0 (stream b40e7eef = CR). srand 309521385, start 249001. Placed after G95, before G91b. driver_note: "P29 b0.4 probe; demote behind ranked gates if G95 e12f ends H0 or clearly minus, before it starts".
- G99 gate99_f001_vs_h256e12: pack fc_nnue_h256_e16f001_b07_ep16_ep10base (box 02d1aa55, net md5 b55ac19b, blend-end 0.7). PC exe forge_h256_f001.exe B9C6B1D1…62E0; bench 344662/856404/3237912/16276677/35296253 = CR; FMA 0; perft5 4865609; simdcheck v2 PASS; oracle b72ff00d bad_records=0 (stream 5c7f3b66 = CR). srand 903841213, start 252001. Placed after G96, before G93.
- forge_gates.json E7462E43… -> B3736882D50FA090CBAC7A79E85FF0F6DBF139F3938CA3ECB2191A9F202EBEB4 (90 entries); backup forge_gates.json.bak_e12rec_f001_20261024_193727. SelfTest ALL PASS; dry-run runnable 67 x 2.75 h = 184.25 h.
- TODO (QA): when G95 finishes, if H0 or clearly minus, move G98 behind the ranked gates before it starts.

## 2026-10-24 19:52-20:12 Vienna — PC builds + paired nps: fc_speedmp_h256e12, fc_speedtt_h256e12 (Engine QA executor; NOT queued, no manifest change)
- Builds (`forge_push\build_verify_sp2.ps1`, lock tree + CR-sha-verified changed files, lock flags, g++ Idle pinned 0xF): speedmp B986CAA090EE6AB7D83810F985B5C6B7136EA7839108317D34466C46B899E947; speedtt AFBF50A1D743B7321971B67206CF97453609D5502A3497788DDD35046F301B22. Both: bench = lock 308972/745494/2460422/11901452/31111774, FMA 0 (whole exe), perft5 4865609, uci = lock (10).
- nps (`forge_push\nps_abba_sp2.ps1` / `nps_abba_sp2b.ps1`, port of forge_abba_time.py 7e044426): CPU 2 (outside gate mask 0xFFF0; trainer 0xF Idle shares CPUs 0-3), Normal, palindrome rounds + interleaved A/A.
  - bench 16 x16 rounds: mp +3.82% CI [3.08, 4.56] 16/16; tt +3.37% CI [2.92, 3.83] 16/16; A/A -0.14% CI [-0.57, 0.29].
  - bench 20 x12 rounds: mp +3.85% CI [3.31, 4.40] 12/12; tt +0.80% CI [-0.26, 1.85] 9/12; tt vs mp -2.94%; A/A +0.55% CI [-0.14, 1.24].
  - speedmp clears +3% at both depths. speedtt clears only at d16; NOT at d20 -> not robust.
- Logs: D:\grok-pc-data\forge_push\speed_window\ build_sp2.log, nps_sp2.csv/.log, nps_sp2_d20.csv/.log.

## 2026-10-24 20:24 Vienna — G100 e32f003 queued (Engine QA executor, net-only H256 vs h256_e12 lock)
- G100 gate100_e32f003_vs_h256e12: pack fc_nnue_h256_e32f003_b06_ep32_ep10base (zip 9504a867, patch 8e7dc242, box forge 56c3eee9, net md5 80a35e2f, blend-end 0.6; CR c9e2c485). PC exe forge_h256_e32f003.exe DD4189ED977D10A33C7ECFD5E9B19C084FCE121FF88532CBEDD7BF77E9BBB81D; bench 323789/1088205/3091218/12682638/27879525 = CR; FMA 0; perft5 4865609; simdcheck v2 PASS; uci = lock; box oracle bin 5f8474d9, stream f97c3647 (= CR), bad_records=0.
- srand 1050264640, start 255001, watch_time. Order: G89 (running) -> G90 -> G95 -> G100 -> G98 -> G91b. driver_note starts "f003 ep32 b0.6, NNUE best holdout, CR PASS c9e2c485; queued 2026-10-24 20:24 Vienna".
- forge_gates.json B3736882… -> 8CE2C38097C96FAF2930B2075CF5E783304F22CE0B521080913E49BFB74D3030 (91 entries); backup forge_gates.json.bak_e32f003_20261024_202416. SelfTest ALL PASS; dry-run runnable 68 x 2.75 h = 187 h. build_verify_netpack2.ps1 v3 (adds e32f003; v2 backup .bak_v2_e12rec_f001).

## 2026-10-24 20:48 Vienna — G101 speedmp2 QUEUED (Engine QA)
- fc_speedmp2_h256e12 (CR PASS cfa86385; zip f0c43710, patch 36eaa221; changed files board.hpp 702d19a4 (= v1), search.cpp ae80b62d, both sha-verified against CR).
- PC exe bin\forge_speedmp2_h256e12.exe AEDC06D0AF8C3960615531C6337838BAC93648291A65FE705FB3338D3BC4E92D (build_verify_sp3.ps1, lock flags). bench d11..d22 308972/745494/2460422/11901452/31111774 = lock; perft5 4865609; FMA 0 (forge:: and whole exe); uci = lock.
- PC nps vs lock 456743D9 (CPU 2, Normal, ABBA palindrome with v1 B986CAA0, interleaved A/A): d16x16 +4.30% [3.87,4.72] 16/16; d20x12 +4.55% [3.98,5.13] 12/12. v1 vs lock +4.50%/+4.22%; v1 vs v2 +0.19% [-0.38,0.76] / -0.31% [-0.97,0.35] (no difference). A/A -0.02% / +0.03%. Clears the STRICT bar at both depths.
- G101 gate101_speedmp2_vs_h256e12, srand 480620746, start 258001, after G91b, before G28, prebench = lock, watch_time true, auto-confirm on H1 (r4). Manifest 8CE2C380 -> A8A3D61B (backup forge_gates.json.bak_speedmp2_20261024_204810). SelfTest ALL PASS; dry-run order OK.
- Stacking: still conflicts with fc_ptype/G84 on piece_type() in board.hpp (CR); a rebase needs a new CR.

## 2026-10-24 21:25 Vienna — G102 e24f005 queued (Engine QA executor, net-only H256 vs h256_e12 lock)
- G102 gate102_e24f005_vs_h256e12: pack fc_nnue_h256_e24f005_b06_ep24_ep10base (zip 2fd24c49, patch 2aed11d9, box forge e9fb06ba, net md5 0ae059d1, blend-end 0.6; CR eef26351, 21:17). PC exe bin\forge_h256_e24f005.exe 46F7E14BBC8F6558452F36F74AA84C97677FF471B7C7248EAC820C04FCC7B30E; bench 399462/1023141/3844623/13962453/22941217 = CR; FMA 0 (whole exe); perft5 4865609; simdcheck v2 PASS (v1 known znver5 false FAIL); uci = lock (10); tree = lock + src\nnue_weights.inc only. Box oracle (qa_oracle_e24f005/run.sh) bin 15f91f85, stream 189c3ce4 (= CR), 1000000 records, bad_records=0.
- srand 1180590640 (random), start 261001 (no start within 3000; next auto-confirm start = max+3000 = 264001), watch_time, cap 1500, auto-confirm on H1 (r4), no auto-lock, candidate options none. Order: G90 (running, fastchess 3456) -> G95 -> G100 -> G102 -> G98 -> G91b -> G101 -> G28 ...
- forge_gates.json A8A3D61B… -> B1C49259CDD58437AD442B240E444BEBC74281C6E45CFB38687B572891D34EE0 (93 entries, old entries unchanged); backup forge_gates.json.bak_e24f005_20261024_212537. SelfTest ALL PASS; dry-run runnable 69 x 2.75 h = 189.75 h, order OK.
- build_verify_netpack2.ps1 v4 (adds e24f005; RAM guard lowered for the trainer: start >= 1.2 GB free, own g++ stopped < 0.8 GB, also on the simd obj build; g++/uci/bench pinned 0x3 Idle; v3 backup .bak_v3_e32f003 on box and PC). Build min free RAM 1.2 GB. install_e24f005.ps1 (c8831110) on box install_6d and PC autorestart, in sync. Driver PID 6092, trainer 2336/4960 untouched.

## 2026-10-24 22:01 Vienna — G103 e16f004 queued (Engine QA executor, net-only H256 vs h256_e12 lock)
- G103 gate103_e16f004_vs_h256e12: pack fc_nnue_h256_e16f004_b06_sol_ep16_ep10base (CR-built zip 4ffe6736, patch 81bcde4c, box forge a93d2db3, net md5 4c8ba6dd, blend-end 0.6, own self-play + Sol data; CR cb9fef0c, 21:34). Box parity PASS_TOL 9999/10000 under packer a07f1972 accepted (CR ruling: one float32 trunc() flip at FEN #3371, max|d| 1 cp).
- PC exe bin\forge_h256_f004.exe 69CBD5A64D417BF218EB48048CDA94FD2511EEB3A5D26AA84476EBFDA63C1ED8 (build_verify_netpack2.ps1 v5 -K f004; lock tree + only src/nnue_weights.inc). bench d11-22 339347/814074/2377747/14825809/28582780 = CR; perft5 4865609; FMA 0 whole exe; simdcheck v2 PASS (v1 known znver5 false FAIL); uci list = lock. Box oracle (qa_oracle_e16f004): oracle bin 4941b01a (= CR), stream e309da99…2064 (= CR), 1000000 records, bad_records=0.
- srand 1535500495 (random, unused PC/box), start 264001 (unused; driver confirm starts are max+3000 at confirm time, so no clash). watch_time, cap 1500, SPRT [0,10], auto-confirm on H1 (r4), no auto-lock, candidate options none, .ok CR_PASS_nnue_e16f004.ok.
- forge_gates.json B1C49259… -> 47F38276EA6C18176F0635D0201F0DDA5F66DF02422A660E83558E1273CD2840 (94 entries, old entries unchanged); backup forge_gates.json.bak_f004_20261024_220116. SelfTest ALL PASS; dry-run order G90(running) -> G95 -> G100 -> G102 -> G103 -> G98 -> G91b -> G101 -> G28 ...
- build_verify_netpack2.ps1 v5: adds f004; RAM rule back to hard floor (start >= 5 GB free, abort/stop own g++ if < 4 GB; RAM checked before uci/simd/bench). v4 backup .bak_v4_e24f005 (PC autorestart + box install_6d).
- Day-6: runnable 70 x 2.75 h = 192.5 h; G103 starts ~08:09 Oct 25 if all before it run to cap; 20 gates now start after day 6 (G71 onward; was 19, G72 onward).

## 2026-10-25 00:18 Vienna — G104 e48f006 + G105 e16f007 queued (Engine QA executor, net-only H256 vs h256_e12 lock)
- G104 gate104_e48f006_vs_h256e12: pack fc_nnue_h256_e48f006_b06_ep48_ep10base (CR-built zip fabdb64b, Coder's packer wrote none; patch 6a1dde47; box CR forge 668b8483; net md5 0fae54a4c0c437432ddb5da85512b5f4, blend-end 0.6, own self-play, v3a, seed 25; CR_PASS_nnue_e48f006.txt md5 6d329124 / sha256 572d16c6, 00:13, FLAG LOW WAC300 1000 ms 279 vs 283/284; HANDOFF.json says HOLD, CR note overrides: WAC timeouts = box CPU starvation, INFO).
  - PC exe bin\forge_h256_f006.exe EEC06D8A127EA50F7535D975F7650F6B3AB3D5BE5EFC63F2133E44F2F4D582D4 (build_verify_netpack2.ps1 v6 -K f006; lock tree + only src/nnue_weights.inc; g++ 15.2 znver5 static). bench d11-22 328459/945640/3024381/9162399/20421972 = CR; perft5 4865609; kiwipete perft5 193690690 (separate Idle 0x3 run); FMA 0 whole exe; simdcheck v2 PASS (v1 known znver5 false FAIL); uci list = lock (10). Box oracle (qa_oracle_e48f006): bin b7f5e60a (= CR), stream b3bb8587…bd33 (= CR), 1000000 records, bad_records=0.
  - srand 1585072642 (random; unused in PC manifest/backups/gate folders and box), start 267001. Placed right after G103, before G98.
- G105 gate105_e16f007_vs_h256e12: pack fc_nnue_h256_e16f007_b06_ep16_ep10base (Coder zip ac6871fc; patch 37793769; box CR forge f1c4918a; net md5 eaf55cb926df074db6888a7e08300f00, blend-end 0.6, own self-play, v3a, seed 26; CR_PASS_nnue_e16f007.txt md5 b74b2e6b / sha256 e1449e5a, 00:13, FLAG LOW WAC300 100 ms 251 vs 255/255; checker HOLD on WAC.122 = box stall, INFO).
  - PC exe bin\forge_h256_f007.exe 8F0F454451361350B877B8025742D7E5D7FA7D211F302687626F072380455F87 (v6 -K f007). bench d11-22 328260/911654/2615094/14358515/36553106 = CR; perft5 4865609; kiwipete perft5 193690690; FMA 0; simdcheck v2 PASS; uci = lock (10). Box oracle (qa_oracle_e16f007): bin f1ab109f (= CR), stream 3f382e27…f8e1 (= CR), 1000000 records, bad_records=0.
  - srand 468953754 (random, unused), start 270001. Placed after G101 speedmp2, before G28 (QA order 00:14).
  - CONDITIONAL: if both G100 e32f003 and G102 e24f005 end H0, QA moves G105 f007 to the rework tail before it starts.
- Both: vs h256_e12 (456743D9…FDFA), 10+0.1, T1, H16, 8moves_v3, SPRT [0,10], cap 1500, one auto-confirm on H1 (r4), no auto-lock, watch_time, candidate options none; entries cloned from G103; .ok CR_PASS_nnue_e48f006.ok / CR_PASS_nnue_e16f007.ok.
- forge_gates.json 47F38276… -> 01D81B07170E4FE665FF2091C8966E12F19DDF5C05B7034E0D359B6FFA6E8420 (96 entries, old entries unchanged); backup forge_gates.json.bak_f006f007_20261025_001817. install_f006_f007.ps1 8d1e1ca1. SelfTest ALL PASS; dry-run order G95 (running, fastchess 7376 untouched) -> G100 -> G102 -> G103 -> G104 -> G98 -> G91b -> G101 -> G105 -> G28 ...; runnable 71 x 2.75 h = 195.25 h.
- build_verify_netpack2.ps1 v6 (e64ebe89): adds f006/f007, logic unchanged; v5 backup .bak_v5_f004 (PC autorestart + box install_6d). Kiwipete perft is not in the script; run separately for both.
- Day-6 (Oct 30 15:30): at the cap from G95's end (~02:05 Oct 25), G103 starts ~07:35, G104 ~10:20, G105 ~21:20 Oct 25. 22 gates now start after day 6 (G69 onward; was 20, G71 onward). SPRT early stops shorten this.
- Not touched: G95/fastchess, NNUE training, foreign processes. No STOP/PAUSE files. Nothing deleted (stage_f006/f007 zips+dirs, src_h256_f006/f007 trees, box qa_oracle scratch kept).

## 2026-10-25 01:23 Vienna — G106 e20f008 + G107 e16f009 queued (Engine QA executor, net-only H256 vs h256_e12 lock)
- G106 gate106_e20f008_vs_h256e12: pack fc_nnue_h256_e20f008_b06_sol_ep20_ep10base (Coder zip 6e49da51…e8aa; patch 711896f5…be92; box CR forge a9aad390…10b9; net md5 1a2ea39884024703f4009129dfc15c97, blend-end 0.6, v3b, seed 27, own self-play + Sol data as DATA only; CR_PASS_nnue_e20f008.txt md5 57b3285b / sha256 9fbce3ec, 01:10, no flag; WAC.152 hang ruled INFO = box starvation).
  - PC exe bin\forge_h256_f008.exe F4689133F110206BECB69C4A4640E7CBCEEFDC83830E9F7C39A144B5A4654B97 (build_verify_netpack2.ps1 v7 -K f008; lock tree + only src/nnue_weights.inc; g++ 15.2 znver5 static). bench d11-22 326333/791863/3667157/13607535/28393769 = CR; perft5 4865609; kiwipete perft5 193690690 (separate Idle 0x3 run); FMA 0 whole exe; simdcheck v2 PASS (v1 known znver5 false FAIL); uci list = lock (10). Box oracle (qa_oracle_e20f008): bin b949af91 (= CR), stream df13ea30…f88d7b (= CR), 1000000 records, bad_records=0.
  - srand 252550784 (random; unused in PC manifest/backups and box), start 273001. Placed after G105 f007, before G28.
- G107 gate107_e16f009_vs_h256e12: pack fc_nnue_h256_e16f009_b06_ep16_ep10base (Coder zip 252480a8…8c92; patch 8f3a3ad0…294b; box CR forge ef3e95bf…ae25; net md5 eee839babc2c958482207b0d56403245, blend-end 0.6, v3b, seed 28, own self-play only; CR_PASS_nnue_e16f009.txt md5 2dac413a / sha256 81af8e22, no flag; packer parity PASS_TOL truncation flip INFO).
  - PC exe bin\forge_h256_f009.exe 04F8ED0371C6750D45AE12C1239D8030B623574860ED3B033FA20386C3EFD825 (v7 -K f009). bench d11-22 360565/908789/3023903/11129702/24020452 = CR; perft5 4865609; kiwipete perft5 193690690; FMA 0; simdcheck v2 PASS; uci = lock (10). Box oracle (qa_oracle_e16f009): bin c09a2b0b (= CR), stream 1bfb48fb…530967 (= CR), 1000000 records, bad_records=0.
  - srand 1058230796 (random, unused), start 276001. Placed after G106, before G28.
  - CONDITIONAL (CR placement, like f007): if both G100 e32f003 and G102 e24f005 end H0, QA moves G107 f009 to the rework tail before it starts.
- Both: vs h256_e12 (456743D9…FDFA), 10+0.1, T1, H16, 8moves_v3, SPRT [0,10], cap 1500, one auto-confirm on H1 (r4), no auto-lock, watch_time, candidate options none; entries cloned from G105; .ok CR_PASS_nnue_e20f008.ok / CR_PASS_nnue_e16f009.ok.
- forge_gates.json 01D81B07… -> 59FD7052326FB71AE136DC8CFA5406386F1085E2EFBC7AC19D196E5EE6ECA6CD (98 entries, old entries unchanged); backup forge_gates.json.bak_f008f009_20261025_012342. install_f008_f009.ps1 615E4BA6. SelfTest ALL PASS; dry-run order G95 (running, fastchess 7376 untouched) -> G100 -> G102 -> G103 -> G104 -> G98 -> G91b -> G101 -> G105 -> G106 -> G107 -> G28 ...; runnable 73 x 2.75 h = 200.75 h.
- build_verify_netpack2.ps1 v7 (B70F943D): adds f008/f009, logic unchanged; v6 backup .bak_v6_f006f007 (PC autorestart). PC free RAM ~16.9 GB at build (>= 5 GB start rule).
- Day-6: at the cap, G106 starts ~00:05 Oct 26, G107 ~02:50 Oct 26. SPRT early stops shorten this.
- Not touched: G95/fastchess 7376, NNUE training/selfplay, foreign processes. No STOP/PAUSE files. Nothing deleted (stage_f008/f009 zips+dirs, src_h256_f008/f009 trees, box qa_oracle scratch kept).

## 2026-10-25 02:10 Vienna — G108 e20f011 + G109 e16f010 queued (Engine QA executor, net-only H256 vs h256_e12 lock)
- G108 gate108_e20f011_vs_h256e12: pack fc_nnue_h256_e20f011_b06_ep20_ep10base (Coder zip 68b075ad…2fe9; patch bc53e8b4…6560; box CR forge 5a5afd50…5f10; net md5 2623b4346ee2b8fd962c20291467c7b4, blend-end 0.6, v3b, seed 30, own self-play only, no Sol; CR_PASS_nnue_e20f011.txt md5 26be7158 / sha256 a96c1389, 01:45, no flag; lock-side WAC.174 hang ruled INFO = box stall).
  - PC exe bin\forge_h256_f011.exe 52F052C2B844F138B27112D4D7FAC396CEACE1F257500D80EF35A5BF0DC1231E (build_verify_netpack2.ps1 v8 -K f011; lock tree + only src/nnue_weights.inc; g++ 15.2 znver5 static). bench d11-22 291812/783089/2280331/10822565/22433074 = CR; perft5 4865609; kiwipete perft5 193690690 (separate Idle run); FMA 0 whole exe; simdcheck v2 PASS (v1 known znver5 false FAIL); uci list = lock (10). Box oracle (qa_oracle_e20f011): bin d4effa70 (= CR), stream 164cf75c…54fb (= CR), 1000000 records, bad_records=0.
  - srand 1843331874 (random; unused in PC manifest/backups/gate folders/logs (2331 files) and box), start 279001. Placed after G107 f009, before G28. e20 net: unconditional.
- G109 gate109_e16f010_vs_h256e12: pack fc_nnue_h256_e16f010_b06_ep16_ep10base (Coder zip eafed592…f246; patch 674a2b66…79d1; box CR forge 4196008b…e106; net md5 d8e332e9f717442f88288c2d0dc3755b, blend-end 0.6, v3b, seed 29, own self-play only, no Sol; CR_PASS_nnue_e16f010.txt md5 a7a28ebb / sha256 ade4f48f, 01:59, no flag).
  - PC exe bin\forge_h256_f010.exe C1CA13BE6F684716578C0535F1EE37D2C6FE26D6DFDF8CB422F4914D63EE7C8E (v8 -K f010). bench d11-22 324346/920965/2770596/14190276/22718858 = CR; perft5 4865609; kiwipete perft5 193690690; FMA 0; simdcheck v2 PASS; uci = lock (10). Box oracle (qa_oracle_e16f010): bin 15bdba9e (= CR), stream 057e5915…f910 (= CR), 1000000 records, bad_records=0.
  - srand 578451693 (random, unused), start 282001. Placed after G108, before G28.
  - CONDITIONAL (CR placement, like f007/f009): if both G100 e32f003 and G102 e24f005 end H0, QA moves G109 f010 to the rework tail before it starts.
- Both: vs h256_e12 (456743D9…FDFA), 10+0.1, T1, H16, 8moves_v3, SPRT [0,10], cap 1500, one auto-confirm on H1 (r4), no auto-lock, watch_time, candidate options none; entries cloned from G106; .ok CR_PASS_nnue_e20f011.ok / CR_PASS_nnue_e16f010.ok.
- forge_gates.json 59FD7052… -> 09DC6645174BCAB7E75FED3C083A5B16B134742890CEB51701BC8CD6F456E16F (100 entries, old entries unchanged); backup forge_gates.json.bak_f011f010_20261025_020641. install_f011_f010.ps1 98DDE7F5 (box install_6d + PC autorestart). SelfTest ALL PASS; dry-run order G100 (running, fastchess 4484 untouched, game 226/1500) -> G102 -> G103 -> G104 -> G98 -> G91b -> G101 -> G105 -> G106 -> G107 -> G108 -> G109 -> G28 ...; runnable 74 x 2.75 h = 203.5 h (+ held G45, G91).
- build_verify_netpack2.ps1 v8 (0354D8BD): adds f011/f010, logic unchanged; v7 backup .bak_v7_f008f009 (PC autorestart, B70F943D); box install_6d synced to v8 (box v6 copy kept as .bak_v6_f006f007). PC free RAM 23.3 GB at f011 build, 16.6 GB at f010 (>= 5 GB rule; min during builds 16.2 GB). Builds/verify on CPUs 0-3, Idle.
- Day-6 (Oct 30 15:30), at the cap from G100's end (~04:30 Oct 25): G108 starts ~05:15 Oct 26, G109 ~08:00 Oct 26. 26 gates now start after day 6 (G65 onward; was 25 on the same basis). SPRT early stops shorten this.
- Not touched: G100/fastchess 4484, the driver, NNUE training/selfplay, foreign processes. No STOP/PAUSE files. Nothing deleted (stage_f011/f010 zips+dirs, src_h256_f011/f010 trees, box qa_oracle scratch kept).

## 2026-10-25 02:05 Vienna (CET, UTC+1) — Engine QA executor: G89/G90/G95 verdicts; G110 e20f013 + G111 e16f012 queued (net-only H256 vs h256_e12 lock)
- Clock note: Vienna left DST at 03:00 CEST -> 02:00 CET today. The PC (Windows zone Pacific, wall clock set to Vienna time) does NOT shift until Pacific DST ends Nov 1, so PC-clock stamps ("Vienna(PC clock)", RESULT/CSV times after 03:00) now read 1 h ahead of real Vienna time. Install below ran 02:02 CET real = 03:02 PC clock.
- Verdicts (verified vs PC FORGE_RESULTS.csv and each gate's RESULT.md; all 0 TL, 0 crash, CLEAN):
  - G89 gate89_e16s_sol_vs_h256e12: cap with no decision at 1500g, -6.49 ±9.12, nElo -12.51 ±17.58, LLR -2.17, W/L/D 193/221/1086, ptnml [16,153,439,127,15] (srand 1921068996, start 219001; recorded 21:07:36 CEST). Not locked -> rework list (barely minus).
  - G90 gate90_e16m_vs_h256e12: H0 accepted at 1360g, -10.48 ±9.06, nElo -21.38 ±18.47, LLR -2.96, 159/200/1001, ptnml [11,146,402,115,6] (srand 1166240132, start 222001; ended 23:20:11 CEST). -> rework list (minus), not dropped.
  - G95 gate95_e12f_vs_h256e12: cap with no decision at 1500g, +0.23 ±8.53, nElo +0.48 ±17.58, LLR -0.56, 192/191/1117, ptnml [13,128,463,137,9] (srand 973474437, start 240001; ended 01:44:44 CEST). -> rework list (flat). TODO from 19:37 closed: G95 was neither H0 nor clearly minus, so G98 e12rec stays where it is (after G104, before G91b).
- Name correction: f013 is an **e20** net, blend-end 0.6 (NETS.md L1678/1679; renamed e24 -> e20 by the CR-passed step-cap queue 380f478b). The stale name "resid_h256_e24_f013_bs16k_lr10e4_b06_s32_fb8k" is in the NNUE-owned p29 queue files (handoff stage_*/07_nnue/p29/queue_blenddown_phase1_fb8k_variant.txt L42 and the sibling p29 queue files), not in this file. Those files were NOT edited (NNUE training-owned). Correct name is e20_f013; G110 driver_note records the pre-cap e24 name.
- G110 gate110_e20f013_vs_h256e12: pack fc_nnue_h256_e20f013_b06_ep20_ep10base (zip c3c8efbb, box CR exe 0cc3de77, net md5 6d0ede668acdf804f8e99c0b4e16f2c0, blend-end 0.6; CR_PASS_nnue_e20f013.txt md5 ff53ad7e / sha256 60426d4a).
  - PC exe bin\forge_h256_f013.exe 6A3A4167C8BA7AF3378DDA02747C997DFCF941965358F1B549092043BE21DEC0 (build_verify_netpack2.ps1 v9 -K f013; lock tree + only src/nnue_weights.inc; g++ 15.2 znver5 static). bench d11-22 352000/1341169/3421108/14475287/33766359 = CR; perft5 4865609; kiwipete perft5 193690690 (separate Idle run); FMA 0 whole exe; simdcheck v2 PASS; uci list = lock (10). Box oracle (qa_oracle_e20f013): bin 9624b803 (= CR), stream d1de3138…2a7c9 (= CR), 1000000 records, bad_records=0.
  - srand 374715874 (random; unused across the PC (2941 files under forge_push C:+D:) and the box), start 285001. After G109, before G28. e20 net: unconditional.
- G111 gate111_e16f012_vs_h256e12: pack fc_nnue_h256_e16f012_b06_sol_ep16_ep10base (zip 6f31bef6, box CR exe d3bf65e0, net md5 1f0bca9a5e8d0418c8c8cdb394f26bbd, blend-end 0.6; CR_PASS_nnue_e16f012.txt md5 6b7d1a9c / sha256 e227e976).
  - PC exe bin\forge_h256_f012.exe E2343C1C0D3A84C4DDEC8D12337E74B19ECBB69C6791CA19DC6506EC9C1292A7 (v9 -K f012). bench d11-22 336068/951984/3415049/15487744/27061243 = CR; perft5 4865609; kiwipete perft5 193690690; FMA 0; simdcheck v2 PASS; uci = lock (10). Box oracle (qa_oracle_e16f012): bin 3ae301bb (= CR), stream 5e21cf88…9ed4 (= CR), 1000000 records, bad_records=0.
  - srand 1827529024 (random, unused), start 288001. After G110, before G28.
  - CONDITIONAL (same as G109): if both G100 e32f003 and G102 e24f005 end H0, QA moves G111 f012 to the rework tail before it starts.
- Both: vs h256_e12 (456743D9…FDFA), 10+0.1, T1, H16, 8moves_v3, SPRT [0,10], cap 1500, one auto-confirm on H1 (r4), no auto-lock, watch_time, candidate options none; entries cloned from G108; .ok CR_PASS_nnue_e20f013.ok / CR_PASS_nnue_e16f012.ok. driver_notes say subject to the 10:00 two-per-epoch 0.6 cap (no prune now).
- forge_gates.json 09DC6645… -> 55D8D6EA7A5F1A3CEC2B166F1703620E9CF4C3A8EF10D455DC45A517014EB796 (102 entries, old entries unchanged, JSON valid, no duplicate srand, no start within 3000 of 285001/288001); backup forge_gates.json.bak_f013f012_20261025_030206 (PC-clock stamp). install_f013_f012.ps1 85A1FC3D (box install_6d + PC autorestart). SelfTest ALL PASS; dry-run order G100 (running, fastchess 4484 untouched, game 797/1500, +10.25 ±11.78, LLR 1.05) -> G102 -> G103 -> G104 -> G98 -> G91b -> G101 -> G105 -> G106 -> G107 -> G108 -> G109 -> G110 -> G111 -> G28 ...; runnable 76 x 2.75 h = 209 h (+ held G45, G91). Dry-run log D:\grok-pc-data\forge_push\nnue_cand\dryrun_f013f012.txt.
- build_verify_netpack2.ps1 v9 (72C948CA): adds f013/f012, logic unchanged; v8 backup .bak_v8_f011f010 (0354D8BD, PC autorestart + box install_6d). PC free RAM 16.4 GB at f013 build, 16.55 GB at f012 (min 16.07 GB; >= 5 GB rule). Builds/verify on CPUs 0-3, Idle, strictly one pack at a time.
- Day-6 (Oct 30 15:30 CET = 14:30 UTC), at the cap from G100's end (~03:30 CET Oct 25 = 04:30 CEST basis used at 02:10): G110 starts ~09:45 CET Oct 26, G111 ~12:30 CET Oct 26. On the same basis as the 02:10 entry, 28 gates now start after day 6 (G63 onward; was 26). DST-correct, G63 starts right on the boundary (~15:30 CET Oct 30), so 27 strictly after (G64 onward). SPRT early stops shorten this.
- Not touched: G100/fastchess 4484, the driver, NNUE training/supervisor/GPU guard/selfplay/Firefox, NNUE p29 queue files, foreign processes. No STOP/PAUSE files. Nothing deleted (stage_f013/f012 zips+dirs, src_h256_f013/f012 trees, box qa_oracle scratch kept).

### 2026-10-25 02:24 CET Vienna (PC clock 03:23) — Engine QA executor: f014 installed as G112 (unconditional)
- Pack fc_nnue_h256_e20f014_b06_ep20_ep10base, e20 b0.6, own data only (no Sol), CR PASS CR_PASS_nnue_e20f014.txt 59027849. Coder zip 7330431c (= CR), net md5 4eb578933a18996b446d4272dfc8aecb, patch 44c079e2 (scope src/nnue_weights.inc only).
- PC build build_verify_netpack2.ps1 v10 (v9 + f014 CFG, logic unchanged; PC v9 backed up as .bak_v9_f013f012): tree = lock + only src\nnue_weights.inc (20 files); PC exe forge_h256_f014.exe C28E36D522AF061CDAD68AF816388102C5A36D0F47A9112DEBDEA4611B6D905B (box CR 39d07473, differs as expected znver5/static); bench d11-22 343116/888837/2975236/10896916/19431167 = CR MATCH; perft5 4865609; kiwipete perft5 193690690; FMA 0; simdcheck v2 PASS (v1 known false FAIL); uci list = lock (10). RAM free >= 16.2 GB throughout. STATUS PASS.
- Box oracle qa_oracle_e20f014: bin 4090ace9 (= CR), stream bc698c85c2e6db73 (= CR), 1000000 records, bad_records=0, exit 0.
- srand 1460372917 (0 hits box /workspace+/home/box, PC C:\...\forge_push and D:\grok-pc-data\forge_push), openings_start 291001 (>= 3000 from all; prev max 288001).
- forge_gates.json 55D8D6EA… -> B4ECEB62FD4194FE34E4A0E17FBD7F154E4D9C2F79E15CA2AA26490FAEF6A318 (103 entries, old entries unchanged, JSON valid, no dup srand); backup forge_gates.json.bak_f014_20261025_032341 (PC-clock stamp). install_f014.ps1 A1240A00 (box install_6d + PC autorestart), entry cloned from G110, placed G110 -> G111 -> G112 -> G28. driver_note: "Subject to the 10:00 two-per-epoch 0.6 cap; e20 group f008/f011/f013/f014, QA picks f008 (Sol) + lowest full-holdout b0.6 loss non-Sol". SelfTest ALL PASS; dry run: G100 running (fastchess 4484 untouched), next G102; runnable 77 x 2.75 h = 211.75 h (+ held 2). Log D:\grok-pc-data\forge_push\nnue_cand\dryrun_f014.txt.
- Full-holdout b0.6 (NETS.md): f011 0.014375, f013 0.014373, f014 0.014345 -> lowest non-Sol e20 = f014.
