# NNUE status (2026-10-24 ~17:45 Europe/Vienna, CEST)
- Engine net format: HCE + residual net, 768 inputs ("forge768-relative-pieces-rank-flip", no king buckets), hidden 256 (build flag -DFORGE_NNUE_HIDDEN=256), float inference. Net is embedded as src/nnue_weights.inc. Lock net md5 6d22f612c855e17c62d396d32da99ea4 (run e, ep12, blend-end 0.6).
- Trainer: train_resid_v3a.py (in 07_nnue/). First v3a line f001 from 17:16 Vienna: 73 s/epoch at 1.60-1.70M pos/s unthrottled (~10% faster than v2), ~1.55M pos/s overall once the GPU memory junction reaches 83-84 C and gpu_guard duty-cycles. The trainer is no longer the limit; memory-junction heat at batch 16384 is. A watcher rewrites not-started queue lines to batch 8k (_fb8k) after >3 memory-junction >=83 C events in 60 min. Hard limit 90 C.
- Blend-down evidence (P29, game results vs the lock h256_e12, all H256, lr 7e-4):
  - e12 blend-end 0.6 = the lock
  - h  blend-end 0.7, Gate 26: -4.2 Elo
  - j  blend-end 0.8, Gate 30: -11.1 Elo
  - l  blend-end 0.9, Gate 78: H0, -44.5 +/-18.1 (best teacher holdout loss ever)
  => lower teacher loss is a NEGATIVE signal here; choose nets by games. Next: run f ep12 (blend 0.5, resid_h256_e12_f_b05_ep12.inc on the box) gets its own gate; later a new blend 0.4 run.
- Queued/pending net gates: G88 e16g90 (running), G89 s_sol, G90 e16m, then e24n and e16o (pending CR; held to the back if G88-G90 all end H0).
- int16: the existing int16 path (fc_int16_ep10, CR_PASS_int16_ep10.txt, source in 06_sol_next/fc_int16_ep10_src.tar.gz) is H128-only and aborts on H256 (output bound > 2^31). H256 int16 needs a new design.

## Update 2026-10-24 17:52 Europe/Vienna
Trainer now train_resid_v3a.py (since 17:39), supervisor, gpu_guard, throttle watcher and self-play guards alive. GPU util 63% (target ~90%), hot spot 59 C, memory junction 82 C.

## Update 2026-10-24 22:00 Europe/Vienna
- Lock unchanged (h256_e12). G89 e16s_sol capped at 1500 g with no decision (-6.5 +/-9.1, LLR -2.17) -> rework list. G90 e16m running (at 378 g: -10.1 +/-17.9, LLR -0.77).
- Queued net-only gates since 20:05: G100 e32f003 (f003 ep32 b0.6, net md5 80a35e2f) and G102 e24f005 (net md5 0ae059d1). CR passed e16f004 at 21:34 (not yet queued).
- PC RAM problem: trainer train_resid_v3a.py grows to ~23 GB (host-RAM leak with DirectML), free RAM fell below 1 GB. Fix: train_resid_v3b.py (07_nnue/, CHANGES_v3b.md, v3a_to_v3b.diff) passed CR at 21:56 with conditions (leak fix only provable on the PC); the queue moves f007+ to v3b with epochs capped at 20.

## Update 2026-10-25 00:05 Europe/Vienna
- Lock unchanged (h256_e12). G90 e16m ended H0 at 1360 g (-10.48 +/-9.06, LLR -2.96, clean) -> rework list. G95 e12f (run f ep12, blend-end 0.5) started 23:20; at ~317 g it was +9.8 +/-16.4, LLR 0.47 (far from a decision).
- G103 e16f004 (net md5 4c8ba6dd, own self-play + Sol data) queued 22:01. Queue order: G95 (running) -> G100 -> G102 -> G103 -> G98 -> G91b -> G101 -> G28 ... (94 manifest entries, ~192 h runnable).
- Trainer v3b (RAM-leak fix, epoch cap 20) runs from f008 on; PC free RAM back to ~18 GB. f006 hit OOM at ep48 but its net 0fae54a4 was saved; f006 and f007 are packed (08_pending_nets/ CR drafts, UNPROVEN, f006 pack on HOLD for a WAC300 harness error, not a net finding). f008-f010 done (teacher holdout ~0.00457), f011 ep20 running. GPU ~81%, hot spot ~58 C, memory junction ~78 C.

## Update 2026-10-25 02:10 CEST (01:10 CET; clocks went back at 03:00 CEST today)
- Nets f006-f011 all CR PASS and queued as G104-G109. f012 (e16, own + Sol data, md5 1f0bca9a) and f013 (e20, own only, md5 6d0ede66) CR PASS 02:24 and 02:49 CEST, i.e. 01:24 and 01:49 CET (not yet queued; subject to the 2-per-epoch prune cap). See 04_cr/.
- Trainer v3b running on the PC; GPU ~84%, hot spot ~59 C, memory junction ~78 C, free RAM ~16.5 GB at 01:50.

## Update 2026-10-25 04:10 CET (Europe/Vienna; grok-pc's clock still reads CEST, 1 h ahead)
- Lock unchanged (h256_e12).
- G100 e32f003 (net md5 80a35e2f, 32 epochs, blend-end 0.6) ended 03:11 CET: capped at 1500 games with no decision, +8.34 +/-8.45 Elo, LOS 97.35%, LLR 1.54, pentanomial [4,132,450,152,12], 0 time losses, 0 crashes, CLEAN. Nothing claimed; it goes on the rework list. It is the closest net-only gate to H1 so far, which hints that longer training at blend-end 0.6 may help (UNPROVEN).
- G102 e24f005 (net md5 0ae059d1, 24 epochs, own data) started 03:12 CET; at 560 games it was -6.83 +/-14.94, LLR -0.84.
- Queued after it: G103 e16f004, G98, G91b, G101 (speedmp2), G104-G112 (nets f006-f014; f014 = e20 own data, net md5 4eb57893, lowest e20 full-holdout b0.6 loss 0.014345, queued as G112 at 02:24 CET). Manifest forge_gates.json sha256 B4ECEB62..., 103 entries, about 77 runnable (~212 h).
- Strategist's guardrail (03:30 CET, idea board): about a dozen seed-equivalent nets are being gated, so a lucky false H1 is likely (~45% that at least one passes by chance); the first net that reaches H1 gets one fresh confirm run before the lock is cut.
- Watchdog 03:57 CET: queue, gpu_guard, NNUE supervisor, self-play and HWiNFO all alive, sensors fresh.
