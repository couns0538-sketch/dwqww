# nps_abba_bc.ps1 - PC nps, ptype (base) vs B pext+ptype vs C ptype+pext+nnuemem3b. Engine QA executor 2026-10-24 ~14:50 Vienna. Copy of nps_abba_speedstack.ps1.
# 14 rounds of the palindrome  P B C C B P  (bench 16, T1 H16 OwnBook=false), every run pinned to the same logical CPU at Normal priority,
# then 14 A/A pairs (P P P P) in the same session for the noise band. Nodes must equal the lock bench 16 (2460422) in every run. Never kills anything.
param([int]$Cpu=6,[int]$Rounds=14,[int]$Depth=16)
$ErrorActionPreference='Stop'
$fp='C:\Users\Administrator\grok-pc\forge_push'; $out='D:\grok-pc-data\forge_push\speed_window'
$csv="$out\nps_bc.csv"; $log="$out\nps_bc.log"; $stat="$out\nps_bc.STATUS"
function L($m){ Add-Content -LiteralPath $log -Value "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') | $m" }
'RUNNING' | Set-Content $stat
$lock="$fp\bin\forge_ptype_h256e12.exe"; $pt="$fp\bin\forge_pext_ptype_h256e12.exe"; $ss="$fp\bin\forge_ptype_pext_nnuemem3b_h256e12.exe"
$mask=[IntPtr]([int64]1 -shl $Cpu)
function Run1($exe){
  $psi=New-Object System.Diagnostics.ProcessStartInfo; $psi.FileName=$exe; $psi.RedirectStandardInput=$true; $psi.RedirectStandardOutput=$true; $psi.UseShellExecute=$false; $psi.CreateNoWindow=$true
  $p=[System.Diagnostics.Process]::Start($psi); $p.ProcessorAffinity=$mask; try{ $p.PriorityClass='Normal' }catch{}
  foreach($l in @('uci','setoption name Threads value 1','setoption name Hash value 16','setoption name OwnBook value false','isready',"bench $Depth",'quit')){ $p.StandardInput.WriteLine($l) }
  $t=$p.StandardOutput.ReadToEnd(); $p.WaitForExit()
  $m=[regex]::Match($t,'bench depth (\d+) nodes (\d+) time (\d+) nps (\d+)'); if(-not $m.Success){ throw "no bench line from $exe" }
  return @([int64]$m.Groups[2].Value,[double]$m.Groups[4].Value) }
function Med($a){ $s=@($a|Sort-Object); if($s.Count%2){$s[[int][math]::Floor($s.Count/2)]}else{($s[$s.Count/2-1]+$s[$s.Count/2])/2} }
L "start: CPU $Cpu, Normal, bench $Depth, $Rounds rounds P B C C B P + $Rounds A/A pairs. ptype $((Get-FileHash $lock).Hash) B $((Get-FileHash $pt).Hash) C $((Get-FileHash $ss).Hash)"
'kind,round,P1,B1,C1,C2,B2,P2,nodes_ok,B_vs_P,C_vs_P,C_vs_B' | Set-Content $csv
$ref=$null; $dPL=@(); $dSL=@(); $dSP=@(); $dAA=@()
for($i=1;$i -le $Rounds;$i++){
  $r=@(); foreach($e in @($lock,$pt,$ss,$ss,$pt,$lock)){ $r+=,(Run1 $e) }
  if(-not $ref){ $ref=$r[0][0]; if($ref -ne 2460422){ L "STOP: ptype bench 16 nodes $ref != 2460422"; "BADNODES" | Set-Content $stat; exit 3 } }; $nok=-not @($r | ? { $_[0] -ne $ref }).Count
  $l=($r[0][1]+$r[5][1])/2; $p=($r[1][1]+$r[4][1])/2; $s=($r[2][1]+$r[3][1])/2
  $a=$p/$l*100-100; $b=$s/$l*100-100; $c=$s/$p*100-100; $dPL+=$a; $dSL+=$b; $dSP+=$c
  "PBC,$i,$($r[0][1]),$($r[1][1]),$($r[2][1]),$($r[3][1]),$($r[4][1]),$($r[5][1]),$nok,$([math]::Round($a,3)),$([math]::Round($b,3)),$([math]::Round($c,3))" | Add-Content $csv
  L "round $i B/P $([math]::Round($a,2))% C/P $([math]::Round($b,2))% C/B $([math]::Round($c,2))% nodes_ok $nok"
}
for($i=1;$i -le $Rounds;$i++){
  $r=@(); foreach($e in @($lock,$lock,$lock,$lock)){ $r+=,(Run1 $e) }; $nok=-not @($r | ? { $_[0] -ne $ref }).Count
  $d=(($r[1][1]+$r[2][1])/2)/(($r[0][1]+$r[3][1])/2)*100-100; $dAA+=$d
  "AA,$i,$($r[0][1]),$($r[1][1]),$($r[2][1]),,,$($r[3][1]),$nok,,,$([math]::Round($d,3))" | Add-Content $csv
  L "A/A pair $i $([math]::Round($d,2))% nodes_ok $nok"
}
foreach($x in @(@('B pext_ptype vs ptype',$dPL),@('C ptype_pext_3b vs ptype',$dSL),@('C vs B',$dSP),@('A/A ptype vs ptype',$dAA))){
  $v=$x[1]; L ("SUMMARY {0}: median {1:N2}% mean {2:N2}% min {3:N2}% max {4:N2}% faster {5}/{6}" -f $x[0],(Med $v),($v|Measure-Object -Average).Average,($v|Measure-Object -Minimum).Minimum,($v|Measure-Object -Maximum).Maximum,@($v|?{$_ -gt 0}).Count,$v.Count) }
$s=@($dAA|Sort-Object); $band=[math]::Max([math]::Abs($s[1]),[math]::Abs($s[$s.Count-2]))
foreach($x in @(@('B',$dPL),@('C',$dSL))){ $v=$x[1]; $mn=($v|Measure-Object -Average).Average; $f=@($v|?{$_ -gt 0}).Count
  L ("VERDICT {0} vs ptype: mean {1:N2}% faster {2}/{3} (A/A band {4:N2}%) -> {5}" -f $x[0],$mn,$f,$v.Count,$band,$(if($f -ge 12 -and $mn -gt 1){'FASTER beyond noise'}else{'NOISE/SLOWER'})) }
'DONE' | Set-Content $stat; L 'done'
