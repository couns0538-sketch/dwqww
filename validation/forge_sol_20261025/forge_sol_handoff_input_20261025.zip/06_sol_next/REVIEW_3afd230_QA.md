# Engine QA box review of Sol checkpoint 3afd230 (2026-10-24, ~07:40 PDT / 16:40 Vienna)
Read-only box review. No PC use, no matches. Box = Intel Xeon (AVX-512F/BW/VL), g++-14.2, shared cores.

## Tree
3afd230 -> e69a7c2 (report) -> 97469f3 -> a5670fa -> 706da44 (guard) -> 7629878 -> 7716853 (align64) -> b8ebc4c -> bf237d2 (generic no-copy) -> a57a847 -> 7e4c22a (AVX-512) -> f4911f2 (lock net 6d22f612) -> 1ab50b2.
Engine source changed vs 1ab50b2: only src/nnue.cpp (+127/-?) and src/search.cpp (+2); src/nnue_weights.inc = lock net. Everything else is tools/docs/validation.
All three switches are COMPILE-TIME macros, not UCI options: FORGE_AVX512, FORGE_NNUE_ALIGN64 (only effective with AVX512), FORGE_COMPLETE_ITERATION_ONLY.

## Reproduced on the box (Sol's flags: -std=c++20 -O3 -DNDEBUG -DFORGE_NNUE_HIDDEN=256 -ffp-contract=off -fno-fast-math -march=znver5 -static -pthread -Iinclude)
- sha256 reproduce Sol's exactly: OFF d90f5060...c47f, AVX512+ALIGN64 d7c9b37e...e0bd, guard ON 208e82c5...d9de.
- Bench T1 H16 OwnBook=false, all three builds: 308972 / 745494 / 2460422 / 11901452 / 31111774 = lock at all 5 depths.
- perft5 startpos 4865609 (OFF); kiwipete perft5 193690690 (AVX512 build).
- Box nps, SAME core, alternating (4 runs per core, bench 16): AVX512+align vs OFF = +8.9% (core 4) and +8.0% (core 6). Core 4 vs core 6 differ 2x (shared host), which explains Sol's 0.77..2.30 spread: his ratios were not same-core paired. UNPROVEN, box only; PC decides.

## Findings (severity-ranked)
1. MEDIUM (process) - Sol's speed screen was effectively unpaired noise; treat 0.956/0.915/1.249 as no data. Stage 2 (0.915) stays "possible regression" until the PC protocol says otherwise (CR rule).
2. MEDIUM (portability) - AVX-512 is compile-time only (#error if !__AVX512F__); no runtime dispatch. Safe in the sense that a non-AVX512 compile fails loudly, but an AVX512 exe will SIGILL on a non-AVX512 CPU. Fine for grok-pc (Zen5), must be a separate exe name.
3. LOW-MEDIUM (latent memory safety) - search.cpp:361 `bad_captures_[bad_count_++] = move;` writes into std::array<Move,64> (search.cpp:453) with no bound check, while the capture list it drains holds up to 256 (moves_ at 450, MoveList::Capacity 256 board.hpp:51). Overflow needs >64 SEE-losing captures/promotions in one main-search node. Overflow lands inside the MovePicker object (bad_count_ is the next member), so ASan will NOT see it; use -D_GLIBCXX_ASSERTIONS. My crafted FENs with ~68-70 approximately-losing captures did not trip the assertion at depth 2 (engine SEE counted fewer as losing), so it is UNCONFIRMED but real as an unchecked write. captures_tried (1035/1187) is correctly bounded. Fix is one line and bench-neutral (bound check, or size 256).
   Candidate FENs (pseudo-legal, white to move): 
   1Q1bq3/pr1Q1p1R/KQ1n1Q1b/1p1Q1n1Q/BQ1p1Q1r/1p1QpN2/1k1pR2p/5NB1 w - - 0 1
   1krQ2b1/8/Q2pQnR1/p1Q3b1/Q1n2QrQ/p1QQpKp1/q1ppR2p/1NB1BN2 w - - 0 1
4. LOW (search guard) - FORGE_COMPLETE_ITERATION_ONLY only removes the "adopt the partial-iteration root move" block (search.cpp 1404-1414). Root PV is set only when score > alpha (1171-1177) and pv_length is reset per root call (889), and aborts return before the update (1166), so legacy adoption is the normal, usually Elo-positive policy, not a bug. The only real defect is cosmetic: emit(depth, result.score, ...) prints the unfinished depth with the previous iteration's score. Bench cannot change (fixed depth, no abort). Recommendation: do NOT default ON; if anything fix the info line (print result.depth, or mark the score as a bound) as a tiny OFF-default cosmetic change. Gating it ON would need its own SPRT and could lose Elo.
5. LOW (numerics) - AVX-512 evaluate keeps 16 lane sums mod 16 and ordered tail sum, matches the scalar contract; generic update keeps per-lane op order; columns[4] in the generic path assumes dirty.count <= 4 (true for chess moves; add a static_assert/assert).
6. INFO (ctest) - Sol's "four known failures" are four FAIL lines inside ONE failing test (forge_tests), i.e. 13/14 like ours: WAC 001 (two lines: g3g6 vs f6h5, score 661) + the underpromotion line twice. CR_PASS_int16_ep10 lists the same 4 lines; CR's e16m note mentioned only the 2 underpromotion lines. CR should confirm whether the h256_e12 lock prints 2 or 4 lines.
7. INFO (provenance) - IDEA_SOURCE.md updated; diff is intrinsics + own structure, no third-party code found in nnue.cpp/search.cpp changes.

## int16 on FORGE_IDEA_BOARD
Item 3 of the original list ("int16 SIMD net inference, est +4..+6, ranked"), then DROPPED at 03:55 Vienna (Gate 21: H256 nets abort with INT16) and the 10:05 batch-4 rule says "no int16/int32 inference with H256". The crew's 6/7 vote for (d) overrides that only as an OFF-default research build; gating/locking with int16 ON needs a separate vote. Abort cause (CR_PASS_int16_ep10 Low-1): int32 output bound for e12 = 2,510,422,016 > 2^31-1 (scale 8192).
Top unbuilt+unclaimed search item for the fallback: P22 SingTtPv (first unbuilt in batch 4 / Pack G; zero hits in forge-hashes, forge-coder, forge-strength); backup P23 RefutLmr. (P20 SmallPc, P21 QsPrune, P24 FutHist, P27 QsEvasion are already built/queued.)
