# FORGE_IDEA_BOARD excerpt for Sol (2026-10-24). Rules + fallback search items P22 (first) and P23 (backup). Both checked unbuilt/unclaimed in forge-hashes on 2026-10-24 07:40 PDT.

# Forge idea board (Strategist + Deep Research). Ideas only, never copied code.
Skill: forge-idea-pipeline. State at 22:50 Vienna Oct 23: ep10 locked; Gate 10 running, 11 contcorr-epa and 12 packb-epa queued; CR_PASS H256 ep12 net (gain route) and nonpawnkey plumbing; Pack A (P1+P3+P7) being built by Strength.

## Lessons
- (10:35 Vienna Oct 24) Gate 17 timepack (TmPlyBonus + SingleMoveStop) vs ep10 capped at 1000 g: -0.0 +/- 10.4, LLR -0.41, 0 TL, clean. Time-management tweaks on Forge are below the +10 detection limit; the lock already uses its clock well. Keep TM entries (Gate 27 timepack rebase, P25 TmDecisive) as low-cost fillers, never ahead of search or net items, and never expect a solo H1 from them.
- (10:35 Vienna Oct 24) h256_e12 costs -14% PC nps vs 6.4.24 (d20 ABBA, under NNUE + selfplay load) yet gated +38 vs ep10, so the wider net pays for itself. The speed lines (pinlegal, pext, nnuemem 3a/3b, combined once) now win back real Elo: about +8..+12 if they recover half the loss. Rank the combined speed build right after the net items.
- (10:35 Vienna Oct 24) Strength h256 retune screens: P11 FailHighBlendSoft passes only at isolated K=3 (d20 +19.7% flag) and K=16, non-monotonic, so treat it as noise and rank it last of the rework list. CR found no pinning bug in correction-history add-and-clamp, so S1 CorrGravity is a tuning experiment, not a fix.
- (03:15 Vienna Oct 24) Gate 12 packb-epa (P2 ReSearchAdjust + P4 FiftyDamp) capped at 1000 g with no decision: +3.8 +/- 10.7 Elo, LLR +0.22, clean. Matches the +10 detection limit: a ~+4 pack cannot resolve in one capped gate and games may not be pooled. Not a fail. After the push, options that capped leaning positive (Pack B, any later ones) should be stacked with other neutral-or-better options into ONE fresh combined gate rather than retried alone. P12 Hindsight parked by Strength (not failed); keep it out of any stack with P11.
- (23:10 Vienna) P7 correction-magnitude LMR: whole-ply r-=1 cannot be calibrated (T=40 triggers 50% at d20, +69% nodes); parked unless rewritten as a fractional/depth-scaled term. Gate order after 12: 13 H256 net, 14 Pack A (P1+P3).
- (22:10 Vienna) P6 step 0 on the real PC data (95.4M pos, 5.0M sampled): WLD contradictions are only 0.62% of all positions (target was 3-8%), so the --wld_down switch is dropped. Piece counts are near flat (each 4-piece bin 10.7-18.5%) but endgame-heavy (2-10 pieces 30%, 31-32 only 8%), so --pc_alpha 0.35 stays a low-priority A/B after run e, not before.
- ep10 locked 21:55 (7/7). Gates now run in order 10 (rfpavg-epa), 11 (contcorr-epa), 12 (packb-epa), all vs plain net-a ep10 (da65098c), never forge-strength/base-ep10 (runb net).
- Hosted 1000-game gates only detect about +10 Elo or more: bundle small tweaks.
- Net work has been the largest lever (ep10 vs runc +26.6 @772 g). Fine-tune chains on small data stalled in GrokChess.
- A build is only tested against the base it was built on; rebase after a lock.


### P22 SingTtPv: wider singular margin on former-PV non-PV nodes, plus a double-extension margin knob
- Idea and source: idea only. A node that was on the PV before (tt_pv) but is searched with a null window now has a better-tested TT move. Making it prove singularity by a wider margin there gives fewer, better extensions. Separately, the double-extension threshold is a hard-coded 24 cp; expose it.
- Why it fits Forge: singular (1089-1108) uses `tt_score - SingularMargin*depth` for every node type. grep: tt_pv is used only in LMR/stores (793, 919, 1137-1139), never in the singular block. E28 showed a SMALLER margin (more extensions) loses. This goes the other way, and only for one node class.
- Implementation (search.cpp ~1091 and ~1102): `const int margin = tune::SingularMargin + ((ss->tt_pv && !pv_node) ? tune::SingularTtPvExtra : 0); singular_beta = tt_score - margin * depth;` and replace the literal 24 with `tune::DoubleExtMargin`. New tunables: SingularTtPvExtra 0 (off), range 0..4 (cp per depth); DoubleExtMargin 24 (default = today), range 8..64.
- Variants: A `SingularTtPvExtra=1`; B `SingularTtPvExtra=2`; C `SingularTtPvExtra=1 DoubleExtMargin=36`.
- Owner: Strength.
- Expected Elo: +0..+3.
- Risk: fewer extensions can miss a deep forced line (screen WAC300). Node rule: nodes go DOWN (fewer singular and double extensions), low risk. The d20/d22 screen matters because extensions compound deep.
- Test route: CR same-diff (bench-identical at defaults, because DoubleExtMargin=24 matches the literal), fresh bench per variant, 1000-game [0,10] gate vs h256_e12.

### P23 RefutLmr: less LMR for killer and counter-move quiets
- Idea and source: idea only (a classic LMR term; GrokChess-TS has it, Forge never did). Killers and the counter-move refuted a sibling or the previous move, so they deserve one ply less reduction than history-ordered quiets.
- Why it fits Forge: the LMR block (1137-1146) has tt_pv, improving, cut_node, tt_capture, check, in-check, cutoff_count and history terms, but grep finds no killer/counter term. Killers are stable inside the move loop (they are updated only on the cutoff, after which the loop breaks), so comparing `move == ss->killers[0/1]` is exact. The counter needs one const accessor on MovePicker (counter_ at 338/448).
- Implementation (search.cpp LMR block, quiet moves only): `if (tune::RefutLmr > 0 && quiet && (move == ss->killers[0] || move == ss->killers[1] || (tune::RefutLmr >= 2 && move == picker.counter_move()))) r -= tune::RefutLmrPlies;` plus `Move counter_move() const { return counter_; }` in MovePicker. New tunables: RefutLmr 0 (off) / 1 (killers) / 2 (killers + counter); RefutLmrPlies 1, range 1..2.
- Variants: A `RefutLmr=1`; B `RefutLmr=2`; C `RefutLmr=2` plus the term applied only when `!cut_node` (needs a third mode value, RefutLmr=3).
- Owner: Strength.
- Expected Elo: +1..+3.
- Risk: low on tactics. Node rule: nodes go UP (at most 3 moves per node reduced one ply less). I expect d13/d16 at +2..+6%, a MEDIUM node risk, so screen d20/d22 too (the P14 lesson). Variant C is the node-safe fallback.
- Test route: CR same-diff, fresh bench per variant, 1000-game [0,10] gate vs h256_e12.

