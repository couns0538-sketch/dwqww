# GrokChess NNUE net log
Every net goes here, including failed or aborted ones. **All nets are UNPROVEN** until Engine Strength has run a gated
match vs the current lock AND the NPS loss is confirmed ≤25% vs the lock (Threads=1, Hash=16).

**Base lock for all future NNUE Elo/NPS gates: GrokChess 1.7.36** = `/workspace/chess-engine/baseline/dist-v1.7.36` (badcap, js 274bbb1d, HCE bench d9 286362). Locked 2026-10-14 ~19:11 PT; supersedes 1.7.35. `baseline/dist-v1.7.37` is an NNUE overlay (n64d40ftbk net 157e6b16), NOT the classical lock. Earlier NPS/Elo vs older locks must be re-measured on 1.7.36 builds. NNUE never writes under baseline/.

(Previous lock note kept for history: **1.7.34** = `/workspace/chess-engine/baseline/dist-v1.7.34` (evalfast, js c5d3a1dd, bench d9 269586). Locked 2026-10-14 ~13:05 PT; supersedes 1.7.33.)

(Previous note kept for history: 1.7.29 was prune2-1728 js-tree 8ba774d7.) = `/workspace/chess-engine/baseline/dist-v1.7.29` (prune2-1728, js-tree 8ba774d7, bench d9 269586). Locked 2026-10-13 ~23:38 PT; it supersedes 1.7.28 (some routine text still says 1.7.28). Earlier test-net NPS numbers below were measured vs 1.7.28 and must be re-measured vs 1.7.29.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| zero.nnue | 2026-10-13 22:42 | none (all-zero weights) | 768->? plumbing test | - | - | - | - | TEST ONLY, not a real net — UNPROVEN |
| dist-nnue-test-h32/h64/h128(/h128-acc32) | 2026-10-13 ~23:10 | random weights (make_test_net.js) | 768->32/64/128 x2->1 | - | - | bench d9 vs 1.7.28 (HCE ~395-403k nps): h32 ~450-582k, h64 ~365k (~-8%), h128 ~317k (~-20%); node counts differ, noisy | - | SPEED/PLUMBING TEST ONLY; bug_gate: known HCE draw-rule skips under UseNNUE + some mate failures with random nets — UNPROVEN |
| (no trained net yet) | | | | | | | | |

## Data sets
- Lichess `lichess_db_eval.jsonl.zst` (raw/): **COMPLETE** 22,423,777,007 bytes (2026-10-14 00:03 PT). Remote Last-Modified Fri 2026-10-02 20:16:33 GMT, ETag "6ac01121-5388faeef". `run_after_0240.sh` (WAIT=1) passed the 02:40 PT gate and started filter at 02:40:35 PT: `filter_lichess.py --cap 20000000` (nice 19, throttles at load≥4). As of ~03:40 PT: ~7M lines scanned, ~3.16M kept (log `logs/filter.log`); train.bin/val.bin not written until cap. Classical push load keeps the filter mostly sleeping; training (h64 then h128) waits for load<4 after filter finishes. No trained net yet — UNPROVEN.
- `quiet-evals.csv` conversion (/workspace/nnue/convert.py): ABORTED 2026-10-13 22:41 PT at ~2M/5M rows on plan change; no output. UNPROVEN / unused.

## Sign convention
Stored scores are from White's view. Raw Lichess cp is already from White's view (do not flip). quiet-evals.csv is from the SIDE TO MOVE's view despite its header.
Every dataset and run must log the `signcheck` result: corr > 0.1 and the mirror check OK. A net trained without a passing signcheck is INVALID.

## Engine NNUE path caveats (UNPROVEN, 2026-10-13)
- With a net loaded (UseNNUE on), `evaluate()` returns the net output directly and **skips all HCE draw and scaling rules**
  (insufficient material/KBvKB, wrong-colored bishop + rook pawn, opposite-bishop and other endgame scaling, eval cache).
  Search-level draws (repetition, 50-move, stalemate) still apply. Any draw-rule port on top of the net is future work.
- Int16 accumulator bound: `max|ftB| + 32*max|ftW| < 32767` (QA units). train.py clamps during training and clips on export;
  engine `loadNet` rejects nets that violate it and falls back to HCE. Pack trainer output with
  `/workspace/chess-engine-nnue/tools/pack_trainer_net.js <outdir> <dist>/net.nnue`.

## Engine tree status (2026-10-14 ~00:00 PT)
- `/workspace/chess-engine-nnue/src/search/search.ts` now has **prune2** (patch `/workspace/chess-engine-strength/research/prune2_1728_ts.patch`, applied clean with `patch -p0`;
  result byte-identical to research/prune2_1728/src/search/search.ts). No board/move/tt files touched. Pre-patch copy: `/workspace/chess-engine-nnue/search.ts.pre-prune2.bak`.
- Build `dist-nnue-v2-prune2-1729` (snapshot of dist/, js-tree 222de22b, package.json version 1.7.29-nnue cosmetic): perft 25/25; HCE mode (no net / UseNNUE off) bench d9 nodes **269586 = lock 1.7.29** (output-identical search);
  `search.js` byte-identical to the lock; vs lock only eval/evaluate.js, eval/nnue.js, search/smp*.js, uci/main.js differ. acc_check h32 60 games 9533 checks 0 mismatches.
  bug_gate_nofuzz (HCE): PASS, 0 new, 8 KNOWN, 1 FIXED reminder (mate_distance two rooks m3). Fuzz skipped (QA runs it).
- Patches: `nnue-768-v2_on1729_ts.patch` (NNUE delta on top of 1.7.29 TS src, md5 bfc1954b) and `nnue-768-v2-prune2_vs1728_ts.patch` (NNUE+prune2 vs 1.7.28 TS src, md5 29b79da0). Old 1.7.28-based build kept as `dist-nnue-v2-pre-prune2`.
- Note: prune2 calls evaluate() at PV nodes too, so with a net loaded PV nodes now pay one NNUE eval (same as lock HCE behaviour).

## Pipeline after 02:40 PT
`/workspace/chess-tools/nnue/run_after_0240.sh` **RUNNING** (pid in `logs/run_after_0240.pid`; flock `.run_after_0240.lock`). Started filter 2026-10-14 02:40:35 PT after zst size check. Next: finish filter → train hidden **64 then 128** (10 epochs) → pack → `dist-nnue-n64-e10` / `dist-nnue-n128-e10` from `dist-nnue-v2-prune2-1729` → acc_check + bench vs 1.7.29 → append UNPROVEN rows. Why 64 first: random-net bench showed h64 ~-8% NPS vs h128 ~-20% (vs 1.7.28 under load); h64 trains ~2x faster. Classical push extended to ~10:40 PT Wed; filter/train stay nice 19 and waitload<4 so they do not fight the push.

## 2026-10-14 ~07:55 PT status (Engine NNUE routine) — all UNPROVEN
- Data: filter finished 06:27 PT. 19,971,852 quiet positions (train 19,772,133 / val 199,719), signcheck corr 0.501 mirror ok (data/stats.json).
- Training `n64-e10` running since 06:27 PT (nice 19, pauses at load>=4). Val loss by epoch: 0.010682, 0.010358, 0.010198, 0.010053, 0.010019, 0.009985 (ep 6), still improving.
  This run uses the old train.py (no early stopping, exports last epoch); per-epoch val is in nets/n64-e10/log.json, so best-vs-last is checkable.
- train.py now has early stopping (`--patience 2`, saves net_best.pt, exports best-val weights, log.json has best_epoch/best_val). Applies to n128 onward. Backup logs/train.py.bak-*.
- HCE baseline loss: `hce/hce_valloss.py` scores the HCE on the same val.bin with the same loss (raw and best cp scale k). Running in background (waits load<4) -> hce/hce_valloss.json. No net goes to QA unless its best val loss beats the HCE's.
- Rebased onto lock 1.7.32: `/workspace/chess-engine-nnue/dist-nnue-v3-1732` = cp of baseline/dist-v1.7.32 + NNUE files (eval/evaluate.js, eval/nnue.js) + 3-way merged search/smp.js, smp_worker.js, smp.d.ts, uci/main.js (two trivial conflicts: worker warmup now carries Hash entries; UCI Hash option kept next to UseNNUE/EvalFile). search.js byte-identical to the lock. No board/move/tt files touched.
  Checks: perft_all PASS; HCE bench d9 nodes 269586 = lock 1.7.32; js-tree da7f0eb6; acc_check (test h64 net) 20 games 3128 checks 0 mismatches; UCI smoke with EvalFile + Threads 2 OK, nnueinfo prints the net path.
  JS patch vs lock: `/workspace/chess-engine-nnue/nnue-768-v3_on1732_js.patch` (md5 8a44d203). TS source still on the 1.7.29 tree; TS rebase is pending (no exact TS source for 1.7.32 smp/uci was found).
- `follow_1732.sh` (background) waits for run_after_0240.sh to finish, then rebuilds each trained net as dist-nnue-<id>-1732 with acc_check + bench vs 1.7.32 and appends rows below. The 1.7.29-based rows from run_after_0240.sh are superseded by the -1732 rows.

## Trained nets (appended by run_after_0240.sh; all UNPROVEN)
| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.29 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|

## 2026-10-14 ~08:57 PT status (Engine NNUE routine) — all UNPROVEN
- Progress since ~07:55: **NEW LOCK 1.7.33** noticed (rephist3); rebased NNUE onto it as `dist-nnue-v4-1733`.
- Training `n64-e10` still at **epoch 6/10** (best val so far 0.009985); nice 19, paused most of the hour because load ~5.2–5.4 (>=4). No new epochs since ~07:35 PT. `net.pt` present; no `net.nnue` export yet (exports after last/best epoch).
- `hce/hce_valloss.py` still waiting for load<4 (empty log). `follow_1733.sh` armed (replaces 1732 follow for packaging).
- Rebase `dist-nnue-v4-1733`: 3-way merge of NNUE overlays onto lock 1.7.33 (search.js byte-identical; files: eval/evaluate.js, eval/nnue.js(+d.ts), search/smp.js, smp_worker.js, smp.d.ts, uci/main.js). perft 25/25 PASS; HCE bench d9 nodes **269586 = lock 1.7.33**; js-tree **e26a2edf**; acc_check (test h64) 20 games 3128 checks 0 mismatches; UCI EvalFile smoke prints net path. JS patch `nnue-768-v4_on1733_js.patch` md5 **f72c89ca**. No board/move/tt touched. TS source still on older tree — pending.
- Push still ends ~1:35 PM PT. No trained net for QA yet. Nothing needed from Couns.

## Engine tree status (2026-10-14 ~08:57 PT)
- Current NNUE base: `/workspace/chess-engine-nnue/dist-nnue-v4-1733` vs lock **1.7.33**. Prior `dist-nnue-v3-1732` kept (vs 1.7.32) for history.

## 2026-10-14 ~10:57 PT status (Engine NNUE routine) — all UNPROVEN
- HCE val loss finished: raw 0.014273, best cp scale k=0.95 0.014259 (corr 0.556) on the same 199,719 val positions (hce/hce_valloss.json).
- n64-e10 still stuck at epoch 6/10 (val 0.009985), throttled since ~07:35 PT because box load stays ~6 (>=4). Its ep6 val is about 30% below the HCE's val loss.
- Interim snapshot exported (no wait for training): `nets/n64-ep6snap` = n64-e10 epoch-6 net.pt, same int16 export as train.py (export_snapshot.py), packed net.nnue md5 8223d8a7.
  Dist `/workspace/chess-engine-nnue/dist-nnue-n64-ep6snap-1733` = dist-nnue-v4-1733 + this net (js-tree e26a2edf, same JS as v4). acc_check 20 games 3128 checks 0 mismatches; nnueinfo prints the net path; KQRRBBNN-vs-K eval +1731 (sign sane).
  Pending: bench/NPS vs lock 1.7.33 (follow_1733.sh will add the row when load<4), bug_gate with net, Profiler NPS, Code Review diff. Not for QA yet.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.33 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n64-ep6snap | 2026-10-14 10:54 | Lichess quiet 19.97M, lambda 1.0 | 768->64 x2->1 | ep 6 of 10 / 1e-3 | 0.009985 (HCE 0.014259) | pending | not tested | UNPROVEN, interim snapshot |
| n64-e10 | 2026-10-14 12:21 | lichess eval, filter cap 20000000 (data/stats.json) | 768->64 x2->1 | 10 ep / lr 1e-3 step0.3 | 0.00993 | -4.4% bench d9 (noisy; Profiler to confirm T1 H16) | not tested | UNPROVEN — dist /workspace/chess-engine-nnue/dist-nnue-n64-e10, js-tree 222de22b, ACC_CHECK games=60 checks=9533 mismatches=0 |

## 2026-10-14 ~13:05 PT status (Engine NNUE routine) — all UNPROVEN
- **NEW LOCK 1.7.34** (evalfast-1733, js c5d3a1dd, eval/evaluate.js only, output-identical to 1.7.33). Rebased: `/workspace/chess-engine-nnue/dist-nnue-v5-1734` = cp dist-v1.7.34 + NNUE files; evaluate.js via `git merge-file` (clean, NNUE delta = require + 2-line early return), other overlays unchanged in lock 33->34.
  search.js byte-identical to lock; perft 25/25; HCE bench d9 nodes 269586 = lock; js-tree c92155b4; acc_check (n64-e10) 20 g 3128 checks 0 mismatches; nnueinfo prints net path. JS patch `nnue-768-v5_on1734_js.patch` md5 e51fe30d.
- n64-e10 finished 12:21 PT: 10 epochs, last = best val **0.009930** (HCE 0.014259, ~30% lower). run_after_0240.sh packed it on the old 1.7.29 base (row above, superseded).
- `dist-nnue-n64-e10-1734` (v5 + n64-e10 net md5 3adcd608): bug_gate_nofuzz with net loaded **FAIL**: 2 new failures, mate-distance two rooks m3 (found m4) and KQK m5 (found m6); lock and HCE mode pass both. Cause: net is weak in bare-king endings (quiet Lichess data), ID stops at first (longer) mate.
- Fix `dist-nnue-n64e10bk-1734` ("nnue-bk"): evaluate() uses the HCE when either side has only its king (bareKing check in eval/evaluate.js only). Mate-distance ALL PASS; bug_gate_nofuzz with net loaded **PASS** (0 new, 5 KNOWN, 3 FIXED reminders incl. KBvKB same colour; KvK 0; mate suite ALL PASS; fuzz left to QA).
  acc_check 20 g 3128 checks 0 mismatches; bench d9 nodes 290469 (same as without bk). js-tree 08edb663. JS patch vs lock `/workspace/chess-engine-nnue/nnue-768-v5bk_on1734_js.patch` md5 6ce7282a.
  Box bench d9 (load ~4, noisy): n64 272997/262156/257736 nps vs lock 267712/232402 → roughly equal NPS; nodes to d9 +7.7% (290469 vs 269586). Needs Agent Profiler T1 H16 confirmation, Code Review of the patch, then QA.
- n128-e10 training since 12:21 PT (early stopping): val by epoch 0.010302, 0.009901, 0.009724, 0.009538, 0.009497, 0.009456, 0.009421, 0.009413 (ep 8) — already better than n64. `follow_1734.sh` armed: after run_after_0240.sh exits, builds dist-nnue-n128-e10-1734 on the bk dist + acc_check + bench vs 1.7.34 and appends a row.
- follow_1732.sh / follow_1733.sh still armed (superseded; Auto-review blocked killing them). They will add -1732/-1733 rows for history only; ignore those for gating.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.34 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n64-e10-1734 | 2026-10-14 13:00 | Lichess quiet 19.97M, lambda 1.0 | 768->64 x2->1 | 10 ep / 1e-3 | 0.009930 (HCE 0.014259) | ~0% box bench d9 (noisy) | not tested | UNPROVEN — FAILED bug_gate (mate distance), not for QA |
| n64-e10bk-1734 | 2026-10-14 13:05 | same net as n64-e10 + bare-king HCE fallback | 768->64 x2->1 | 10 ep / 1e-3 | 0.009930 (HCE 0.014259) | ~0% box bench d9 (noisy; Profiler to confirm) | not tested | UNPROVEN — bug_gate PASS (no fuzz), awaiting Profiler NPS + Code Review; dist /workspace/chess-engine-nnue/dist-nnue-n64e10bk-1734 js-tree 08edb663 |
| n128-e10 | 2026-10-14 13:14 | lichess eval, filter cap 20000000 (data/stats.json) | 768->128 x2->1 | 10 ep / lr 1e-3 step0.3 | 0.009391 | -38.9% bench d9 (noisy; Profiler to confirm T1 H16) | not tested | UNPROVEN — dist /workspace/chess-engine-nnue/dist-nnue-n128-e10, js-tree 222de22b, ACC_CHECK games=60 checks=9533 mismatches=0 |
| n128-e10-1733 | 2026-10-14 13:15 | same net as n128-e10, on 1.7.33 NNUE dist | 768->H x2->1 | - | best 0.009391 ep 10 of 10 (HCE: hce/hce_valloss.json) | -32.2% bench d9 vs 1.7.33 (noisy; Profiler to confirm T1 H16) | not tested | UNPROVEN — dist /workspace/chess-engine-nnue/dist-nnue-n128-e10-1733, js-tree e26a2edf, ACC_CHECK games=60 checks=9533 mismatches=0 |
| n128-e10-1734 | 2026-10-14 13:15 | same net as n128-e10, on 1.7.34 NNUE dist | 768->H x2->1 | - | best 0.009391 ep 10 of 10 (HCE: hce/hce_valloss.json) | -33.6% bench d9 vs 1.7.34 (noisy; Profiler to confirm T1 H16) | not tested | UNPROVEN — dist /workspace/chess-engine-nnue/dist-nnue-n128-e10-1734, js-tree 08edb663, ACC_CHECK games=60 checks=9533 mismatches=0 |
| n64-e10-1733 | 2026-10-14 13:15 | same net as n64-e10, on 1.7.33 NNUE dist | 768->H x2->1 | - | best 0.00993 ep ? of 10 (HCE: hce/hce_valloss.json) | +0.7% bench d9 vs 1.7.33 (noisy; Profiler to confirm T1 H16) | not tested | UNPROVEN — dist /workspace/chess-engine-nnue/dist-nnue-n64-e10-1733, js-tree e26a2edf, ACC_CHECK games=60 checks=9533 mismatches=0 |
| n64-ep6snap-1733 | 2026-10-14 13:15 | same net as n64-ep6snap, on 1.7.33 NNUE dist | 768->H x2->1 | - | best 0.009985 ep 6 of 6 (HCE: hce/hce_valloss.json) | +17.3% bench d9 vs 1.7.33 (noisy; Profiler to confirm T1 H16) | not tested | UNPROVEN — dist /workspace/chess-engine-nnue/dist-nnue-n64-ep6snap-1733, js-tree e26a2edf, ACC_CHECK games=60 checks=9533 mismatches=0 |
| n128-e10-1732 | 2026-10-14 13:15 | same net as n128-e10, on 1.7.32 NNUE dist | 768->H x2->1 | - | best 0.009391 ep 10 of 10 (HCE: hce/hce_valloss.json) | -11.9% bench d9 vs 1.7.32 (noisy; Profiler to confirm T1 H16) | not tested | UNPROVEN — dist /workspace/chess-engine-nnue/dist-nnue-n128-e10-1732, js-tree da7f0eb6, ACC_CHECK games=60 checks=9533 mismatches=0 |
| n64-e10-1732 | 2026-10-14 13:15 | same net as n64-e10, on 1.7.32 NNUE dist | 768->H x2->1 | - | best 0.00993 ep ? of 10 (HCE: hce/hce_valloss.json) | +2.1% bench d9 vs 1.7.32 (noisy; Profiler to confirm T1 H16) | not tested | UNPROVEN — dist /workspace/chess-engine-nnue/dist-nnue-n64-e10-1732, js-tree da7f0eb6, ACC_CHECK games=60 checks=9533 mismatches=0 |
| n64-ep6snap-1732 | 2026-10-14 13:15 | same net as n64-ep6snap, on 1.7.32 NNUE dist | 768->H x2->1 | - | best 0.009985 ep 6 of 6 (HCE: hce/hce_valloss.json) | +13.3% bench d9 vs 1.7.32 (noisy; Profiler to confirm T1 H16) | not tested | UNPROVEN — dist /workspace/chess-engine-nnue/dist-nnue-n64-ep6snap-1732, js-tree da7f0eb6, ACC_CHECK games=60 checks=9533 mismatches=0 |

## n64e10bk-v6-1734 (2026-10-14 ~13:25 PT) — UNPROVEN
- dist: /workspace/chess-engine-nnue/dist-nnue-n64e10bk-v6-1734 (same net.nnue md5 3adcd608 as n64e10bk-1734; on lock 1.7.34)
- patch: nnue-768-v6bk_on1734_js.patch md5 15c06abe360e751d8109a0d1831c88e5 (vs dist-v1.7.34)
- Code Review notes on v5bk (6ce7282a) fixed: nnueEvaluate clamped to ±28000; shared+worker TTs cleared when UseNNUE changes or EvalFile loads a new net; UseNNUE default reflects GROKCHESS_USE_NNUE; 'true' parsed case-insensitively; failed EvalFile keeps the old net + "info string ERROR ..."; empty EvalFile = no change; setPoolNNUE keeps file ?? nnueCfg?.file.
- Verified: perft 25/25 PASS; acc_check 200 games 31,615 checks 0 mismatches; bench d9 net 290469 (= v5bk), UseNNUE off 269586 (= lock); nnueinfo main+workers identical at Threads 2 and after growing to 3; bad EvalFile keeps old net in main and workers; bug_gate (no fuzz) with net PASS (0 new, 5 known; mate suite + mate_distance + KvK pass).
- Still known: NNUE path bypasses HCE draw/scaling rules except the bare-king fallback (KBvK/KNvK still nonzero, same as lock).
- Next: QA fuzz+TL, PC paired timing, [0,10] vs 1.7.34. UNPROVEN.

## n128-e10 → dist-nnue-n128e10bk-v6-1734 (2026-10-14 14:26 PT) — UNPROVEN
- 768→128→1, 10 epochs on data/ (19.97M quiet Lichess, lambda 1.0); best val 0.009391 @ ep10 (n64-e10bk 0.009930; HCE 0.014259). Training finished; nets/n128-e10/net.nnue md5 b23e44a71f0b2e6249e163d6c5c2cabc.
- Build = copy of dist-nnue-n64e10bk-v6-1734 (patch nnue-768-v6bk_on1734_js.patch md5 15c06abe360e751d8109a0d1831c88e5, code unchanged) + n128 net.
- Verified (v6verify/all_n128.log): perft PASS (in bug_gate); acc_check 200 games 31,615 checks 0 mismatches; bench d9 net 183200, UseNNUE off 269586 (= lock); EvalFile bad-file keeps old net; bug_gate no-fuzz PASS (0 new, KNOWN 6: KBvK/KNvK x4 as lock, + KBvKB same-colour now -3cp (n64 gave 0), ep-hash).
- No NPS/Profiler or QA yet. Not handed off.
- Dataset in progress: data40m/ (PID 3325908, started 14:15 PT, cap 40M, quiet, lambda 1.0, log logs/filter_data40m.log). 40M not 60M because RAM (~6 GB available; dedup/shuffle needs ~3-4x the 32 B/record array).

## 2026-10-14 ~14:55 PT status (Engine NNUE routine) — all UNPROVEN
- Lock still **1.7.34** (no newer dist-v*). No rebase needed.
- Progress since ~13:25: `n128-e10` finished (best val **0.009391** @ ep10 vs n64 0.009930 / HCE 0.014259). Built `dist-nnue-n128e10bk-v6-1734` (same v6bk JS as n64, net md5 b23e44a7, js-tree dd63e29e). perft/acc_check/bug_gate PASS; box bench d9 NPS **~-34%** vs lock → fails ≤25% NPS gate → **not for QA**.
- Primary QA candidate unchanged: `dist-nnue-n64e10bk-v6-1734` (net 3adcd608, patch nnue-768-v6bk_on1734_js.patch md5 15c06abe, js-tree dd63e29e, bench d9 nodes 290469 net / 269586 HCE). Handed to Engine QA after the push; still needs formal Profiler T1 H16 NPS + fuzz/TL + [0,10] vs 1.7.34.
- Data: `filter_lichess.py --cap 40000000` → `data40m/` running since ~14:17 PT (nice 19, max-load 4, PID 3325908). Log: 11M lines / ~4.95M kept (~12% of cap), keep rate ~0.45. Box load ~6–8 (classical SPRT/TL) so filter is throttled; no new training until load <4 and filter finishes.
- Push window ended ~1:35 PM PT. Nothing blocked on Couns.

## n64-ft1 (started 2026-10-14 15:17 PT) — UNPROVEN, training
- Warm start from nets/n64-e10/net.pt (= its best, ep10 val 0.009930). 768→64→1, data/ (19.97M), lr 3e-4 (0.3x of 1e-3; StepLR every 3 ep ×0.3), up to 10 epochs, patience 2, nice 19, max-load 4.
- train.py: added --init (warm start) + epoch-0 val baseline; backup train.py.bak_preft1. Start val 0.009930 (matches).
- PID 3423674; log logs/train_n64-ft1.log; out nets/n64-ft1 (net_best.pt, log.json per-epoch val). No dist built.

## 2026-10-14 ~15:52 PT status (Engine NNUE routine) — all UNPROVEN
- Lock still **1.7.34** (`/workspace/chess-engine/baseline/dist-v1.7.34`, evalfast, js c5d3a1dd, bench d9 269586). Newest baseline under chess-engine trees; no rebase needed. Never edited.
- Box load **5.60 / 4.94 / 4.53** (>=4) — no new heavy jobs started this run.
- **data40m filter** still running: PID **3325908**, nice 19, `filter_lichess.py … data40m --cap 40000000 --max-load 4`, cwd `/workspace/chess-tools/nnue`. Log `logs/filter_data40m.log`: **28M lines / 12,668,281 kept** (~31.7% of 40M kept cap), ~5125s wall; currently **throttled** (WCHAN nanosleep). `data40m/` not written yet (outdir created only at end after dedup/shuffle).
- **n64-ft1** training: PID **3423678**, nice 19, warm-start from `nets/n64-e10/net.pt`, data/ 19.97M, lr 3e-4, patience 2. Through **epoch 3/10**: start val 0.009930 → best **0.009912** @ ep3 (ep1 0.009939, ep2 0.009928). Also throttled on load. Out `nets/n64-ft1/` (net_best.pt present). No dist yet. UNPROVEN.
- Primary QA candidate unchanged: `dist-nnue-n64e10bk-v6-1734` (net md5 **3adcd608**, patch **15c06abe**, js-tree dd63e29e). Still needs Profiler T1 H16 + QA fuzz/TL/[0,10] vs 1.7.34.
- `dist-nnue-n128e10bk-v6-1734` (net **b23e44a7**, val 0.009391): box NPS ~-34% fails ≤25% gate — not for QA.
- Progress since ~14:55: filter advanced 11M→28M lines / 4.95M→12.67M kept; n64-ft1 started (~15:17) and reached ep3. No new dist builds this hour.

## 2026-10-14 ~16:53 PT status (Engine NNUE routine) — all UNPROVEN
- **NEW LOCK 1.7.35** = `/workspace/chess-engine/baseline/dist-v1.7.35` (tteval-1734; search.js only vs 1.7.34; all-.js tree md5 `0178310193a55e5955040e10928d6574`). Cut ~16:48 PT (DR note ~16:50). NNUE gates move to 1.7.35; prior NPS/Elo vs 1.7.34 must be re-measured after rebase. Lock never edited by NNUE.
- Progress since ~15:52: filter **33M lines / 15,012,796 kept** (~37.5% of 40M cap; was 28M/12.67M); **n64-ft1** through **epoch 7/10**, best val **0.009859** (was 0.009912 @ ep3; start 0.009930; HCE 0.014259). Both still nice 19, max-load 4, currently throttled (box load ~4–9 from classical SPRTs).
- Frozen (untouched): `dist-nnue-n64e10bk-v6-1734` (net **3adcd608**, js-tree dd63e29e, patch 15c06abe) — Profiler T1 H16 vs 1.7.34 **+11.7%** NPS PASS; CR sign-off. `dist-nnue-n128e10bk-v6-1734` (net **b23e44a7**) — Profiler median **−20.1%** NPS PASS (≤25% gate; close; PC advisable). Both still UNPROVEN Elo.
- **Action this hour:** rebase NNUE overlays onto 1.7.35 as new folders `dist-nnue-*-v6-1735` (do not modify frozen *-1734). Overlay files only (evaluate/nnue/smp*/main); search.js stays lock-identical. Then Profiler re-NPS vs 1.7.35, then QA fuzz/TL/[0,10] on n64 then n128.
- data40m still writing at end of filter (outdir after dedup/shuffle). No new train until filter finishes + load<4. Push classical window to ~19:15 PT.
- Nothing needed from Couns. Need from crew: rebase completion → Profiler T1 H16 vs 1.7.35 → QA slot for n64 then n128.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n64-ft1 (training) | 2026-10-14 16:53 | Lichess quiet 19.97M warm-start n64-e10 | 768->64 x2->1 | ep7/10 lr 3e-4 patience2 | best 0.009859 (HCE 0.014259) | n/a (no dist yet) | not tested | UNPROVEN — training nets/n64-ft1 |
| n64e10bk-v6-1734 | 2026-10-14 (frozen) | same as n64-e10 | 768->64 x2->1 | 10 ep / 1e-3 | 0.009930 | +11.7% vs **1.7.34** (superseded lock) | not tested | UNPROVEN FROZEN — rebase to 1.7.35 required before QA |
| n128e10bk-v6-1734 | 2026-10-14 (frozen) | same as n128-e10 | 768->128 x2->1 | 10 ep / 1e-3 | 0.009391 | −20.1% vs **1.7.34** (superseded lock) | not tested | UNPROVEN FROZEN — rebase to 1.7.35 required before QA |


## 2026-10-14 ~17:58 PT status (Engine NNUE routine) — all UNPROVEN
- Lock **1.7.35** (`/workspace/chess-engine/baseline/dist-v1.7.35`, js-tree 01783101, bench d9 219984). Never edited.
- Rebase done 16:55–17:06: `dist-nnue-n64e10bk-v6-1735` (net 3adcd608) and `dist-nnue-n128e10bk-v6-1735` (net b23e44a7), js-tree 1182327b, patch `nnue-768-v6bk_on1735_js.patch` md5 562227b7, search.js == lock. Perft PASS, HCE bench (USE_NNUE=0) 219984 = lock, net bench d9 n64 232587 / n128 199461, acc_check 60 g 0 mismatches, nnueinfo prints net path (main + workers), bug_gate nofuzz with net PASS (0 new). Frozen *-1734 untouched.
- Agent Profiler (prof1735_box/results.md, box, d10 T1): n64 **+17.2%** median NPS vs 1.7.35 (8/8) PASS; n128 **−19.8%** median (worst −24.3%) PASS. Time-to-d10 n64 +7.5%, n128 +10.3%.
- **n64-ft1 finished** 17:37: 10/10 epochs, best val **0.009853** @ ep10 (start 0.009930; HCE 0.014259). Packed net.nnue md5 **2c5dac9c**. Built `dist-nnue-n64ft1bk-v6-1735` (cp of n64e10bk-v6-1735 + new net); all_1735.sh verify running → `v6verify/all_n64ft1_1735.log`.
- data40m filter: 42M lines / 19.16M kept (~48% of 40M cap), nice 19, throttled.
- Needed: Code Review on the 1735 patch (562227b7); Engine QA fuzz/TL/[0,10] vs 1.7.35 on n64e10bk-v6-1735 first, then n128e10bk-v6-1735.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n64ft1bk-v6-1735 | 2026-10-14 17:58 | Lichess quiet 19.97M, warm-start n64-e10 | 768->64 x2->1 | 10 ep lr 3e-4 (StepLR) | 0.009853 (HCE 0.014259) | −0.3% d10 (Profiler prof1735_1817) PASS | not tested | UNPROVEN — net 2c5dac9c; verify ALLDONE 17:54; same JS as v6bk (js-tree 1182327b) |
| n64e10bk-v6-1735 | 2026-10-14 17:06 | as n64-e10 | 768->64 x2->1 | 10 ep / 1e-3 | 0.009930 | +17.2% d10 (Profiler, box) | not tested | UNPROVEN — CR PASS 18:22; QA queued fuzz+TL box then [0,10] PC |
| n128e10bk-v6-1735 | 2026-10-14 17:06 | as n128-e10 | 768->128 x2->1 | 10 ep / 1e-3 | 0.009391 | −19.8% d10 (Profiler, box) | not tested | UNPROVEN — CR PASS (same patch); QA after n64 |

## 2026-10-14 ~18:57 PT status (Engine NNUE routine) — all UNPROVEN
- Lock still **1.7.35** (`/workspace/chess-engine/baseline/dist-v1.7.35`, js-tree 01783101, bench d9 219984). No dist-v1.7.36. Never edited by NNUE. Frozen *-v6-1734 untouched (nets 3adcd608 / b23e44a7).
- Progress since ~17:58:
  - **n64ft1bk-v6-1735 verify DONE** 17:54:59 (`v6verify/all_n64ft1_1735.log`): perft PASS, acc_check 60g 9533 checks 0 mismatches, bug_gate nofuzz PASS (0 new, KNOWN 5), HCE bench d9 219984 = lock, net bench d9 **230971**, js-tree **1182327b**, search.js == lock, nnueinfo main+workers OK. Net md5 **2c5dac9c**.
  - **Code Review PASS** 18:22 PT on `nnue-768-v6bk_on1735_js.patch` md5 **562227b7** (`research/cr_nnue_v6_1735_review.md`): pure overlay rebase of v6bk_on1734; bare-king fallback kept.
  - **Profiler** `prof1735_1817` (18:19–18:31): n64ft1bk d10 NPS median **−0.3%** vs 1.7.35 (worst −19.0%) **PASS** ≤25% gate (time-to-d10 often better via fewer nodes). Box only / UNVERIFIED.
  - Prior Profiler `prof1735_box` still stands: n64e10bk **+17.2%**, n128e10bk **−19.8%** PASS.
- Training: **n64-ft1 done** (best val 0.009853 @ ep10). No other train running. **data40m** filter still running (pid 3325908, nice 19, max-load 4): ~81M lines scanned / **~37.3M kept** of 40M cap (~93%); outdir `data40m/` not finalized yet (writes at end). Load ~3.3–4.3.
- No new train started this hour (filter owns the load budget). No board/move/tt touched. No fastchess.
- Gate checklist:
  - **n64e10bk-v6-1735**: perft✓ acc✓ bug_gate✓ Profiler +17.2%✓ CR✓ → QA fuzz+TL (box) then [0,10] PC vs 1.7.35 — already in QUEUE 17:41/17:42.
  - **n128e10bk-v6-1735**: same JS/CR; Profiler −19.8%✓ → QA after n64 (14 PC pairs first).
  - **n64ft1bk-v6-1735**: perft✓ acc✓ bug_gate✓ Profiler −0.3%✓ same CR patch → ready to queue after n64e10bk (or parallel policy per QA).
- Patch: `nnue-768-v6bk_on1735_js.patch` md5 **562227b7**. No separate ft1 patch (net-only swap on same JS).
- Needed from crew: Engine QA to run queued n64e10bk-v6-1735 fuzz+TL; then n128; optionally queue n64ft1bk. Nothing needed from Couns.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.35 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n64ft1bk-v6-1735 | 2026-10-14 18:57 | Lichess quiet 19.97M, warm-start n64-e10 | 768->64 x2->1 | 10 ep lr 3e-4 | 0.009853 (HCE 0.014259) | −0.3% d10 (prof1735_1817) PASS | not tested | UNPROVEN — dist /workspace/chess-engine-nnue/dist-nnue-n64ft1bk-v6-1735 net 2c5dac9c js-tree 1182327b; verify+CR ready for QA |
| n64e10bk-v6-1735 | 2026-10-14 18:57 | as n64-e10 | 768->64 x2->1 | 10 ep / 1e-3 | 0.009930 | +17.2% d10 (prof1735_box) PASS | not tested | UNPROVEN — CR PASS; QA queued fuzz+TL then [0,10] PC; bench d9 net 232587 / HCE 219984 |
| n128e10bk-v6-1735 | 2026-10-14 18:57 | as n128-e10 | 768->128 x2->1 | 10 ep / 1e-3 | 0.009391 | −19.8% d10 (prof1735_box) PASS | not tested | UNPROVEN — CR PASS (same patch); QA after n64; bench d9 net 199461 |

## 2026-10-14 ~19:20 PT — v6 overlays rebased on lock 1.7.36 (badcap, js 274bbb1d) — all UNPROVEN
- Lock `/workspace/chess-engine/baseline/dist-v1.7.36` (untouched), HCE bench d9 **286362**. Only search.js differs from 1.7.35, so the overlay files are byte-identical to the 1.7.35 rebase.
- Patch `nnue-768-v6bk_on1736_js.patch` md5 **7679e921** (same +/- body as v6bk_on1735 562227b7; only headers differ). Base `dist-nnue-v6bk-1736`. search.js == lock. js-tree **01b94330** (all three builds).
- Verify logs `v6verify/all_{n64e10bk,n64ft1bk,n128e10bk}_1736.log` (script all_1736.sh): perft PASS, HCE bench d9 286362 = lock, acc_check 60g 9533 checks 0 mismatches, nnueinfo main+workers OK, bug_gate nofuzz PASS 0 new.

| id | date (PT) | net md5 | net bench d9 | HCE bench d9 | NPS vs 1.7.36 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|
| n64e10bk-v6-1736 | 2026-10-14 19:11 | 3adcd608 | 215696 | 286362 | not measured | not tested | UNPROVEN — gate PASS (KNOWN 6); needs CR, Profiler, QA fuzz+TL then [0,10] |
| n64ft1bk-v6-1736 | 2026-10-14 19:13 | 2c5dac9c | 253621 | 286362 | not measured | not tested | UNPROVEN — gate PASS (KNOWN 5; KBvKB same-colour now passes) |
| n128e10bk-v6-1736 | 2026-10-14 19:18 | b23e44a7 | 142209 | 286362 | not measured | not tested | UNPROVEN — gate PASS (KNOWN 6) |

## 2026-10-14 ~19:57 PT — data40m finalized; n64-d40ft training started — all UNPROVEN
- **data40m** filter finished 19:04 PT (17313 s): 86.8M lines scanned, 40.0M kept, 59,670 dupes removed → 39,940,330 final = **39,540,927 train / 399,403 val** (`data40m/train.bin` 1.27 GB, `val.bin`). Quiet only (mate, check, best capture/promo, shallow dropped), signcheck mirror ok. About 2x the 19.97M set used for n64-e10/n128-e10/n64-ft1.
- New val set differs from the old one, so val losses are NOT comparable across data sets; HCE + prior-net val losses on data40m/val measured 20:09–20:20 PT (see section below).
- **n64-d40ft** training started 19:54 PT: 768->64 x2->1, warm start from n64-ft1/net_best.pt, lr 3e-4, 10 ep, patience 2, nice 19, max-load 4, out `nets/n64-d40ft`, log `logs/train_n64-d40ft.log`. Start val on data40m/val **0.009922**.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.36 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n64-d40ft | 2026-10-14 19:54 | data40m 39.54M quiet, warm-start n64-ft1 | 768->64 x2->1 | 10 ep / 3e-4 | start 0.009922 (data40m val) | not built | not tested | UNPROVEN — training |

## 2026-10-14 ~20:20 PT — data40m HCE + prior-net val losses (UNPROVEN)
- Measured with `nice -n 19`, `TZ=America/Los_Angeles`. Did not kill or restart `n64-d40ft` (trainer still running).
- **HCE** on `data40m/val.bin` (399,403 positions) via `hce/hce_valloss.py` + lock **1.7.36** (`/workspace/chess-engine/baseline/dist-v1.7.36`, UseNNUE off):
  - raw **0.014216**, best cp scale **k=1.0** → **0.014216**, corr **0.5594**
  - JSON: `hce/hce_valloss_data40m.json` (also mirrored to `hce/hce_valloss.json`). Prior data/ result kept as `hce/hce_valloss_data.json` (raw 0.014273, k=0.95 → 0.014259 on 199,719).
- **Prior nets** scored on the same data40m val with `eval_checkpoint.py` (same Net + MSE(sigmoid) loss as `train.py`):

| id | checkpoint | data40m val loss | prior data/ val (for ref only) |
|---|---|---|---|
| HCE (1.7.36) | — | **0.014216** (k=1.0) | 0.014259 (k=0.95) |
| n64-e10 | nets/n64-e10/net.pt | **0.009996** | 0.009930 |
| n64-ft1 | nets/n64-ft1/net_best.pt | **0.009922** | 0.009853 |
| n128-e10 | nets/n128-e10/net_best.pt | **0.009488** | 0.009391 |
| n64-d40ft (start) | warm-start from n64-ft1 | **0.009922** | n/a |

- Sanity: n64-ft1 on data40m val equals n64-d40ft epoch-0 start val (0.009922). All three prior nets still beat HCE on data40m (~30%+ lower). Summary JSON: `logs/valloss_data40m_summary.json`.
- n64-d40ft training continues (as of measure: best val improving past start). No message sent to crew.

## 2026-10-14 ~20:57 PT status (Engine NNUE routine) — all UNPROVEN
- Lock **1.7.36** (`/workspace/chess-engine/baseline/dist-v1.7.36`, js 274bbb1d, HCE bench d9 **286362**). Never edited. Frozen *-v6-1734/*-v6-1735 untouched.
- Progress since ~19:57:
  - **n64-d40ft DONE** 20:50: 10/10 ep, best val **0.009779** @ ep10 (start 0.009922; HCE data40m **0.014216**). Packed net.nnue md5 **157e6b16**. Built `dist-nnue-n64d40ftbk-v6-1736` (cp of n64e10bk-v6-1736 + new net); js-tree **01b94330**; search.js == lock. Net bench d9 **194011**. Verify `v6verify/all_n64d40ftbk_1736.log` **PASS** 20:57:42 (perft/acc/bug_gate nofuzz; new failures 0, KNOWN 6).
  - **n128-d40ft** training started 20:57: warm start n128-e10, data40m, H128, lr 3e-4, start val **0.009488**, nice 19, max-load 4, log `logs/train_n128-d40ft.log`.
  - data40m HCE + prior-net val losses already recorded (HCE 0.014216; n64-e10 0.009996; n64-ft1 0.009922; n128-e10 0.009488).
- Still gate-blocked vs 1.7.36 (same as last hour): n64e10bk / n64ft1bk / n128e10bk *-v6-1736 have perft/acc/bug_gate PASS but need **CR** on `nnue-768-v6bk_on1736_js.patch` md5 **7679e921**, **Profiler** NPS T1 H16 vs 1.7.36, then **QA** fuzz/TL/[0,10] (queue still named *-1735 — rebase to *-1736).
- No board/move/tt touched. No fastchess.
- Needed: Code Review confirm 1736 patch; Agent Profiler NPS on the three *-v6-1736 (and n64d40ft after verify); Engine QA retarget queue to *-1736. Nothing needed from Couns.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.36 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n64-d40ft / n64d40ftbk-v6-1736 | 2026-10-14 20:50 | data40m 39.54M quiet, warm-start n64-ft1 | 768->64 x2->1 | 10 ep / 3e-4 | **0.009779** (HCE 0.014216) | not measured | not tested | UNPROVEN — verify PASS; net 157e6b16; dist `/workspace/chess-engine-nnue/dist-nnue-n64d40ftbk-v6-1736`; bench d9 net 194011 / HCE 286362; js-tree 01b94330 |
| n128-d40ft | 2026-10-14 20:57 | data40m, warm-start n128-e10 | 768->128 x2->1 | 10 ep / 3e-4 | start 0.009488 | not built | not tested | UNPROVEN — training |
| n64e10bk-v6-1736 | 2026-10-14 19:11 | as n64-e10 | 768->64 x2->1 | 10 ep / 1e-3 | 0.009930 | not measured | not tested | UNPROVEN — perft/acc/bug_gate PASS; needs CR+Profiler+QA vs 1.7.36 |
| n64ft1bk-v6-1736 | 2026-10-14 19:13 | as n64-ft1 | 768->64 x2->1 | 10 ep / 3e-4 | 0.009853 | not measured | not tested | UNPROVEN — same gate |
| n128e10bk-v6-1736 | 2026-10-14 19:18 | as n128-e10 | 768->128 x2->1 | 10 ep / 1e-3 | 0.009391 | not measured | not tested | UNPROVEN — same gate |

## 2026-10-14 ~21:55 PT status (Engine NNUE routine) — all UNPROVEN
- Lock **1.7.36** (dist-v1.7.36) unchanged, never edited. Push ends ~00:05 PT Thu Oct 15.
- Gate pipeline unblocked since ~21:00: CR passed patch 7679e921 for all four *-v6-1736; Profiler: 1.7.35 NPS results carry over (no re-time).
- QA running **n64d40ftbk-v6-1736** (net 157e6b16): PC pcA fuzz PASS, TL 200 g 0 bad/0 TL, **[0,10] 10+0.1 H64 vs 1.7.36 started 21:35 PT** (in progress). Box duplicate gate: fuzz 20 g 0 illegal/crash; TL 200 g in progress.
- **n128-d40ft** training: ep8/10 best val **0.009269** (start 0.009488; HCE 0.014216), nice 19, max-load 4. Build/verify dist-nnue-n128d40ftbk-v6-1736 when done.
- No board/move/tt touched. No fastchess run by NNUE.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.36 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n128-d40ft | 2026-10-14 21:55 | data40m, warm-start n128-e10 | 768->128 x2->1 | ep8/10 / 3e-4 | 0.009269 (best so far) | not built | not tested | UNPROVEN — training |
| n64d40ftbk-v6-1736 | 2026-10-14 21:55 | data40m | 768->64 x2->1 | 10 ep / 3e-4 | 0.009779 | not re-timed (1.7.35 n64 results carry over per Profiler) | [0,10] PC in progress | UNPROVEN — QA fuzz/TL PASS |

## 2026-10-14 22:08 PT n64d40ftbk-v6-1736 SPRT RESULT (reported by Engine Strategist; QA verdict)
[0,10] 10+0.1 vs lock 1.7.36 on grok-pc pcA: H1 ACCEPTED 21:58:46 PT, 200 games, Elo +235.45 +/-54.35, LLR 2.95, 0 TL. Net md5 157e6b16, js-tree 01b94330. Still UNPROVEN beyond this one SPRT; no classical lock is cut from it.

## 2026-10-14 ~22:50 PT status (Engine NNUE routine) — all UNPROVEN
- Lock **1.7.36** (`/workspace/chess-engine/baseline/dist-v1.7.36`) unchanged; NNUE never edits baseline. `dist-v1.7.37` = NNUE overlay only (same net as n64d40ftbk). Push ends ~00:05 PT Thu Oct 15.
- Progress since ~21:55: **n128-d40ft DONE** 22:02 (10/10 ep, best val **0.009262** @ ep10; start 0.009488; HCE data40m **0.014216**). Packed net.nnue md5 **14656706**. Built `dist-nnue-n128d40ftbk-v6-1736` (cp of n128e10bk-v6-1736 + new net); js-tree **01b94330**; search.js == lock. Verify `v6verify/all_n128d40ftbk_1736.log` **PASS** 22:54:06 (HCE bench d9 286362=lock, net bench **169395**, acc 60g 9533 checks 0 mismatches, bug_gate 0 new/KNOWN 6, nnueinfo path OK).
- **n64d40ftbk-v6-1736** SPRT: H1 ACCEPTED 21:58 PT, 200 g, Elo **+235.45 ±54.35**, LLR 2.95, 0 TL vs 1.7.36 (net 157e6b16). Still UNPROVEN beyond that one SPRT; no classical lock cut from it.
- Gate-ready queue (CR 7679e921, Profiler carry-over): n64e10bk → n128e10bk → n64ft1bk *-v6-1736, then n128d40ftbk after verify. Asking QA for next PC slot.
- No board/move/tt touched. No fastchess. Training idle (n128-d40ft finished).

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.36 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n128-d40ft / n128d40ftbk-v6-1736 | 2026-10-14 22:02 | data40m 39.54M quiet, warm-start n128-e10 | 768->128 x2->1 | 10 ep / 3e-4 | **0.009262** (HCE 0.014216) | carry-over n128e10bk −19.8% (≤25% PASS) | not tested | UNPROVEN — verify **PASS** 22:54 (perft/acc 0 mism/bug_gate 0 new); bench d9 net **169395** / HCE 286362; net 14656706; js-tree 01b94330; ready for QA after n64e10/n128e10/n64ft1 |
| n64d40ftbk-v6-1736 | 2026-10-14 21:58 | data40m | 768->64 x2->1 | 10 ep / 3e-4 | 0.009779 | carry-over PASS | **H1 +235.45±54.35 @200g** | UNPROVEN — SPRT H1 vs 1.7.36; not classical lock |
| n64e10bk-v6-1736 | 2026-10-14 19:11 | as n64-e10 | 768->64 x2->1 | 10 ep / 1e-3 | 0.009930 | carry-over +17.2% PASS | not tested | UNPROVEN — CR+Profiler ready; next QA after d40ftbk |
| n64ft1bk-v6-1736 | 2026-10-14 19:13 | as n64-ft1 | 768->64 x2->1 | 10 ep / 3e-4 | 0.009853 | carry-over −0.3% PASS | not tested | UNPROVEN — same gate |
| n128e10bk-v6-1736 | 2026-10-14 19:18 | as n128-e10 | 768->128 x2->1 | 10 ep / 1e-3 | 0.009391 | carry-over −19.8% PASS | not tested | UNPROVEN — same gate |

## 2026-10-14 ~23:57 PT status (Engine NNUE routine) — all UNPROVEN
- **NEW LOCK 1.7.37 = NNUE n64d40ftbk-v6-1736** (baseline/dist-v1.7.37, net md5 157e6b16, js-tree 01b94330; cut by QA 23:29 PT, approved by Couns). NNUE never edits baseline.
- Since ~22:50: eval-scale check done (evalscale_n64d40ft.md: overall NNUE/HCE scale 1.02, but ~0.6x opening / ~1.25x endgame) and self-play plan written (SELFPLAY_PLAN.md, plan only, generator needs repetition detection first).
- Superseded (worse val than the lock net, same arch/code): n64e10bk-v6-1736 (0.009930), n64ft1bk-v6-1736 (0.009853), n128e10bk-v6-1736 (0.009391 but n128d40ftbk is better). Recommend QA drops them. Only n128d40ftbk remains a candidate (net-only change vs 1.7.37, same js-tree 01b94330).
- **NPS risk:** n128d40ftbk vs the NEW lock (n64 NNUE) is likely ~-30% NPS (carry-over: n64 +17.2%, n128 -19.8%, both vs HCE 1.7.35, ratio ~0.68), which may FAIL the <=25% gate. Needs Agent Profiler re-time vs 1.7.37 at T1 H16 before QA.
- New training: **n64-d40ft2** started 23:55 PT (warm start n64-d40ft, data40m, lr 1e-4, 10 ep, patience 2, nice 19, max-load 4; start val 0.009779). Net-only candidate vs lock if val improves.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.37 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n64-d40ft2 | 2026-10-14 23:55 | data40m, warm-start n64-d40ft | 768->64 x2->1 | 10 ep / 1e-4 (patience 2) | start 0.009779 | n/a (same arch as lock) | not tested | UNPROVEN — training |
| n128d40ftbk-v6-1736 | 2026-10-14 22:02 | data40m | 768->128 x2->1 | 10 ep / 3e-4 | 0.009262 | est. ~-30% (needs Profiler) | not tested | UNPROVEN — QA next-push pcC #1 vs 1.7.37 pending NPS gate |
| n64e10bk / n64ft1bk / n128e10bk -v6-1736 | — | — | — | — | — | — | — | UNPROVEN — SUPERSEDED by lock net, recommend drop |

## 2026-10-15 ~00:55 PT status (Engine NNUE routine) — all UNPROVEN
- Lock **1.7.37** (NNUE n64d40ftbk, baseline/dist-v1.7.37, net 157e6b16) unchanged. 12 h push on 1.7.37 running to ~12:30 PT (QA 00:40). NNUE never edits baseline.
- n64d40ftbk lock confirmed by QA PC 1000 g T1 H64 sanity vs 1.7.36: +195.51 ±22.41, 0 TL/crash (ended 00:07).
- **n128d40ftbk-v6-1736** (net 14656706): Profiler d10 vs 1.7.37, 9 rounds, median **−16.1%** NPS (worst −27.5%, 1/9 rounds) → **PASS** ≤25% (box, info). QA has it on PC pcC: fuzz+TL then [0,10] 10+0.1 vs 1.7.37 (net-only diff confirmed by Deep Research). My earlier ~−30% estimate was too pessimistic.
- **n64-d40ft2** training: ep6/10 best val **0.009762** (start 0.009779, −0.17%; tiny). Will build a net-only candidate only if the final gain is meaningful.
- Queued **n128-d40ft2** (warm n128-d40ft, lr 1e-4, 10 ep, patience 2, nice 19, max-load 4) to start when n64-d40ft2 ends (follow_n128d40ft2.sh).
- No board/move/tt touched. No fastchess.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.37 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n64-d40ft2 | 2026-10-14 23:55 | data40m, warm n64-d40ft | 768->64 x2->1 | 10 ep / 1e-4 | ep6 best 0.009762 (start 0.009779) | same arch | not tested | UNPROVEN — training |
| n128d40ftbk-v6-1736 | 2026-10-14 22:02 | data40m | 768->128 x2->1 | 10 ep / 3e-4 | 0.009262 | **−16.1% median PASS** (Profiler 00:34) | testing pcC [0,10] | UNPROVEN — in QA |
| n128-d40ft2 | queued | data40m, warm n128-d40ft | 768->128 x2->1 | 10 ep / 1e-4 | — | — | — | UNPROVEN — queued |

## 2026-10-15 ~01:55 PT status (Engine NNUE routine) — all UNPROVEN
- Lock **1.7.37** (NNUE n64d40ftbk, baseline/dist-v1.7.37, net 157e6b16) unchanged. 12 h push to ~12:30 PT. NNUE never edits baseline.
- **n128d40ftbk-v6-1736 REJECTED by QA at the fuzz gate** (PC pcC, 00:43:46 PT: coder-fuzz "Crashed: 1", 2 matching lines; no TL/SPRT run). Same js-tree as the lock (01b94330), only net.nnue differs, so the H128 path or this net is the suspect. Box repro without games: 300-position single-process UCI sweep at depth 7 (crashrepro/sweep.py) = 0 crashes, 0 illegal moves. A game-based repro vs SF was blocked by Auto-review (my rules: no match play from NNUE). Need QA's PC crash lines/PGN to find the cause. Not cleared.
- **n64-d40ft2 DONE** ~01:11 PT: 10/10 ep, best val **0.009757** (ep10) vs start 0.009779 = −0.23%, under the Strategist's 0.5% bar (<0.009730) → **no build, no PC test**.
- **n128-d40ft2** training since 01:12 PT (warm n128-d40ft, lr 1e-4): ep5 val **0.009233** (start 0.009262, −0.31%). Won't be built until the n128 fuzz crash is understood.
- **Output buckets (Strategist next one-variable test):** new trainer `train_ob.py` (copy of train.py + `--obuckets 8`, bucket = min(7,(pieces−2)//4), warm start copies the single output into all buckets, so start val = lock net exactly 0.009779). Smoke test OK; export out_w = 8×2H int16, out_b = 8 int32. **n64-ob8** queued (follow_n64ob8.sh, warm n64-d40ft, lr 3e-4, 10 ep, patience 2, nice 19, max-load 4) to start when n128-d40ft2 ends. Engine side (nnue.js reads 8 output rows + picks bucket by piece count) not written yet; needs CR + Profiler + bug_gate before QA.
- No board/move/tt touched. No fastchess.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.37 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n64-d40ft2 | 2026-10-15 01:11 | data40m, warm n64-d40ft | 768->64 x2->1 | 10 ep / 1e-4 | 0.009757 (start 0.009779, −0.23%) | same arch | not tested | UNPROVEN — gain below 0.5% bar, not built |
| n128d40ftbk-v6-1736 | 2026-10-14 22:02 | data40m | 768->128 x2->1 | 10 ep / 3e-4 | 0.009262 | −16.1% median PASS | — | UNPROVEN — **REJECTED QA fuzz (1 crash, PC 00:43)**; box sweep 300 pos clean; cause unknown |
| n128-d40ft2 | 2026-10-15 01:12 | data40m, warm n128-d40ft | 768->128 x2->1 | 10 ep / 1e-4 | ep5 0.009233 | — | — | UNPROVEN — training; held behind n128 crash |
| n64-ob8 | queued | data40m, warm n64-d40ft | 768->64 x2->8 buckets | 10 ep / 3e-4 | start 0.009779 | — | — | UNPROVEN — queued after n128-d40ft2 |

## 2026-10-15 02:08 PDT n128d40ftbk-v6-1736 fuzz-crash investigation (UNPROVEN)
- Build base verified: js-tree 01b94330 == lock 1.7.37; only net.nnue differs (14656706 vs 157e6b16).
- Box replay (node v20.19.2, heap limit 4144 MB, nice 19): plies 71-81 incl. post-Rc5 (ply 81), movetime 100 / depth 13 / depth 16, Hash 64/T1, 16/T1, 256/T2; lock 1.7.37 same positions; 7 full-game single-process replays at 7s+0.08. 0 crashes, 0 stderr, rc 0. NOT reproduced. Post-Rc5 n128 plays f7e6 (+732..+758), lock f7e6 (+677..+701).
- Engine has no uncaughtException handler, so a JS throw would print to stderr; fastchess log does not capture engine stderr, so "no stderr" is not evidence. Root-cause guess: PC environment (orphan node procs / Windows-side kill), not net or code. Logs: crash_n128/.

## 2026-10-15 ~02:56 PT status (Engine NNUE routine) — all UNPROVEN
- Lock **1.7.37** (NNUE n64d40ftbk, baseline/dist-v1.7.37, net 157e6b16, js-tree 01b94330) unchanged. 12 h push to ~12:30 PT. NNUE never edits baseline.
- Progress since ~01:55/02:08: **n128-d40ft2** still training (pid 779, nice 19, max-load 4; load ~4.0). Through ep8/10: best val **0.009225** (start 0.009262, −0.40%). Ep7–8 slowed (1387s / 2577s) under load. **follow_n64ob8.sh** waiting on 779.
- **n64-d40ft2** still not built (−0.23% < 0.5% bar). **n128d40ftbk-v6-1736** still REJECTED at PC fuzz; box crash replay 0 crashes (NETS 02:08); QA logs at `research/n128_fuzz_crash/`.
- Next when n128-d40ft2 ends: pack → box fuzz with logs → ask QA for first free PC slot; then ob8 engine side in nnue.js (train_ob.py ready); SCReLU after. Forge tools staged under `forge_datagen_pkg/` (evaluate on box; nothing on grok-pc without Couns 1:1).
- No board/move/tt touched. No fastchess.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.37 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n128-d40ft2 | 2026-10-15 01:12 | data40m, warm n128-d40ft | 768->128 x2->1 | ep8/10 / 1e-4 | **0.009225** best (start 0.009262) | — | — | UNPROVEN — training |
| n128d40ftbk-v6-1736 | 2026-10-14 22:02 | data40m | 768->128 x2->1 | 10 ep / 3e-4 | 0.009262 | −16.1% median PASS | — | UNPROVEN — **REJECTED QA fuzz**; box not reproduced |
| n64-d40ft2 | 2026-10-15 01:11 | data40m, warm n64-d40ft | 768->64 x2->1 | 10 ep / 1e-4 | 0.009757 (−0.23%) | same arch | not tested | UNPROVEN — below 0.5% bar, not built |
| n64-ob8 | queued | data40m, warm n64-d40ft | 768->64 x2->8 buckets | 10 ep / 3e-4 | start 0.009779 | — | — | UNPROVEN — follow_n64ob8 after n128-d40ft2; engine side not written |

## 2026-10-15 ~03:57 PT status (Engine NNUE routine) — all UNPROVEN
- Lock is now **1.7.38** (baseline/dist-v1.7.38, magicflat3 speedup, same net 157e6b16, js-tree 1ec7deec). NNUE never edits baseline.
- **n128-d40ft2 DONE** 03:39 PT: 10/10 ep, best val **0.009223** (ep10; start 0.009262, −0.42%; lock net n64 0.009779; HCE 0.014216).
- Packed net-only on the 1.7.38 tree: `/workspace/chess-engine-nnue/dist-nnue-n128d40ft2-v6-1738` (cp -rp of lock, only net.nnue replaced; net md5 d1679b6b, js-tree 1ec7deec == lock, search.js == lock). Verify (bench, uci, acc, bug_gate nofuzz with net) running via v6verify/all_1738.sh → v6verify/all_n128d40ft2_1738.log, waiting for load < 4.
- **n64-ob8** training started 03:39 PT (train_ob.py, warm n64-d40ft, lr 3e-4, 10 ep, patience 2, nice 19, max-load 4); start val 0.009779. Engine side (8 output rows in nnue.js) not written yet.
- n128d40ftbk-v6-1736 still REJECTED (PC fuzz, 1 crash, box not reproduced). No board/move/tt touched. No fastchess.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.38 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n128-d40ft2 (dist-nnue-n128d40ft2-v6-1738) | 2026-10-15 03:39 | data40m, warm n128-d40ft | 768->128 x2->1 | 10 ep / 1e-4 | **0.009223** (start 0.009262) | not yet re-timed (same arch as n128d40ftbk −16.1% vs 1.7.37) | not tested | UNPROVEN — verify running; then Profiler + QA box fuzz/PC |
| n64-ob8 | 2026-10-15 03:39 | data40m, warm n64-d40ft | 768->64 x2->8 buckets | 10 ep / 3e-4 | start 0.009779 | — | — | UNPROVEN — training |

## 2026-10-15 ~04:50 PT status (Engine NNUE routine) — all UNPROVEN
- Lock **1.7.38** (baseline/dist-v1.7.38, net md5 157e6b16). No dist-v1.7.39 yet. NNUE never edits baseline.
- **n128-d40ft2** verify **PASS** 03:57 (ALLDONE): perft OK, acc 60g 0 mismatches, bug_gate PASS PARTIAL (fuzz skipped, 0 new). Dist `/workspace/chess-engine-nnue/dist-nnue-n128d40ft2-v6-1738`, net md5 **d1679b6b**, js-tree == lock, search.js == lock. Bench d9: net **193301** / lock 194011 / HCE 286362. Next: Agent Profiler re-time vs 1.7.38 (T1 H16), then QA box fuzz → PC. If orderfast becomes 1.7.39 first, repack net-only on that js-tree.
- **n64-ob8** training (train_ob.py, warm n64-d40ft, lr 3e-4, 10 ep, patience 2, nice 19, max-load 4): ep1 best val **0.009741** (start 0.009779). Engine-side 8-bucket load in nnue.js WIP this hour (executor).
- n128d40ftbk still the prior PC-fuzz reject (box unreproduced); Strategist noted a later n128-1738 re-fuzz/TL clean with SPRT harness stuck — not this net-only dist.
- No board/move/tt touched. No fastchess.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.38 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n128-d40ft2 (dist-nnue-n128d40ft2-v6-1738) | 2026-10-15 03:39 | data40m, warm n128-d40ft | 768->128 x2->1 | 10 ep / 1e-4 | **0.009223** | pending Profiler | not tested | UNPROVEN — verify PASS 03:57; net d1679b6b |
| n64-ob8 | 2026-10-15 03:39 | data40m, warm n64-d40ft | 768->64 x2->8 buckets | ep1/10 / 3e-4 | **0.009741** (start 0.009779) | — | — | UNPROVEN — training; engine side WIP |
| n64-d40ft2 | 2026-10-15 01:11 | data40m | 768->64 x2->1 | 10 ep / 1e-4 | 0.009757 (−0.23%) | — | — | UNPROVEN — below 0.5% bar, not built |
| n128d40ftbk-v6-1736 | 2026-10-14 22:02 | data40m | 768->128 x2->1 | 10 ep / 3e-4 | 0.009262 | −16.1% vs 1.7.37 | — | UNPROVEN — prior PC fuzz reject |

## Forge / published data conversion — UNPROVEN (data only, no training started)
- convert_forge.py (+ filter_lichess_rec.py encoder): Forge PGN fastchess comments ({±x.xx/depth}, mover POV, labels pre-move position; played move used for quiet filter) and forge_selfplay `FEN | score(STM) | result(White)` -> 32-byte REC, White-POV cp, data40m filters (no check, <=30 pcs, move not capture/promo, no mate, clip 3000), dedup, 1% val. No WDL stored (REC has no result field; rsv bytes free).
- Selfplay sample (examples/forge_sample.txt, 916 lines): 835 kept, signcheck corr 0.916 mirror ok (/tmp/fs_test).
- forge_pgns (28 PGNs, ~22k games, depths mostly 8-10 in SPRT games, i.e. much shallower than data40m d>=20): running -> data_forgepgn/ (min-depth 8), log logs/convert_forgepgn.log, nice 19, single thread (box has only CPUs 0-7, so taskset 12-15 is impossible).
- Published SF/Leela: raw_ext/head1G.test80-2023-11-nov-2tb7p.min-v2.v6.binpack.zst = first 1 GiB (HTTP range) of linrock/test80-2023 on Hugging Face. NOT converted: no C++ compiler on box to build Sopel97/nnue_data_compress decoder; apt install of g++/make blocked by Auto-review then interrupted. No pure-Python binpack decoder written.

## grok-pc GPU setup (05:2x-05:31 PT Thu) — UNPROVEN
- PC "FoxOS" (Win 11 26200, RX 7900 XT, 16 logical CPUs, ~42 GB free C:). Folder C:\Users\Administrator\grok-pc\nnue\ ; STOP file C:\Users\Administrator\grok-pc\nnue\STOP_nnue (exists => pause; contains "exit" => quit).
- Python 3.10.22 via uv (local to folder), .venv with torch 2.4.1 + torch-directml 0.2.5.dev240914; forge pkg tests 11/12 pass (1 fail = no C++ compiler on PATH).
- train_gpu.py = DirectML port of train.py (same features/loss/clamps/int16 export). Warm-start n128-d40ft2 val on PC = 0.009223 (box 0.009223) => forward matches. Launcher run_train.cmd = start /low /affinity F000.
- Not running: data40m copy to PC interrupted by user; no long training or self-play started. forge.exe (6.2 v3) staged in folder.

## Data set: data_bt4fp32 (2026-10-15 ~05:45 PT) — UNPROVEN
- Source: HF `vondele/master-binpacks_relabel` file `fishpack32.relabel-BT4-tf13tune.binpack` (SF master-binpacks relabelled by Leela BT4; SF19-era data type). Streamed (first ~155M positions of 5.86 GB), raw not stored. **License UNVERIFIED** (no dataset card; source sets ODbL).
- Converter: `/workspace/chess-tools/raw_ext/sfconv/conv` (C++, built from nnue_data_compress reader; g++/make installed 05:35 PT with Couns approval). Validated: 0 invalid/in-check boards, byte-identical re-encode vs filter_lichess_rec.encode_board, mirror ok.
- Filters: ply<8, mates (|s|>=30000), |cp|>3000, in-check, next move capture/promo/ep, dedupe by position (64-bit hash). Score White POV cp, no rescale.
- rsv[0]=game result White POV (0 loss/1 draw/2 win), rsv[1]=min(ply,255), rsv[2]=1 source tag. Ready for WDL blending.
- Counts: seen 154,555,381 → train 100,000,000 (md5 92d7a7ed5098ec9496c9bd65178cb71c), SF held-out val 94,575 (md5 023534a0e684da47f5844b28e5702fde, by game). Stats `data_bt4fp32/stats.json`.
- Eval scale: sigmoid(cp/k) fit to results → k=265 (BT4) vs k=275 on SF-search test80 sample: BT4 labels ≈ SF cp scale (factor ~1.04), so no rescale proposed for scale 400.
- signcheck corr_white_material=0.082 (fails 0.1 guard) because positions are nearly material-balanced; mirror ok and corr(score,result)=0.586 confirm White POV. Treat as known exception, not a sign bug.
- Shared val: `val_shared/val.bin` built by `build_shared_val.py` (data40m val + ≤100k Forge val) automatically once Forge conversion (PID 284758) finishes. FIXED once written.

## 2026-10-15 ~05:51 PT status (Engine NNUE routine) — all UNPROVEN
- Lock **1.7.38** (baseline/dist-v1.7.38, net md5 157e6b16, H64). No 1.7.39. NNUE never edits baseline. Box load ~4.0–4.1 (QA classical slots busy); NNUE trainer auto-paused at max-load 4.
- Progress since ~04:50: **data_bt4fp32** ready (100M train md5 92d7a7ed from HF fishpack32 BT4 relabel, streamed first ~155M; SF val 94,575; k_fit≈265; licence UNVERIFIED). Forge PGN convert still running (nice 19, → data_forgepgn/); shared val builds automatically after. **n64-ob8** through ep3 best val **0.009686** (start 0.009779, −0.95%); ep4+ paused on load. Engine-side 8-bucket nnue.js still not written.
- **n128-d40ft2** still verify PASS (dist-nnue-n128d40ft2-v6-1738, net d1679b6b, bench d9 193301); still needs Agent Profiler vs 1.7.38 then QA box fuzz → PC. grok-pc GPU slot idle pending data copy / STOP check (this run).
- Next: Profiler on n128d40ft2; finish forge→val_shared; resume n64-ob8 when load <4; write ob8 engine loader; then n128 on data40m+BT4 mix (Strategist GPU order) when PC ready. No board/move/tt. No fastchess.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.38 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n128-d40ft2 (dist-nnue-n128d40ft2-v6-1738) | 2026-10-15 03:39 | data40m | 768->128 x2->1 | 10 ep / 1e-4 | **0.009223** | pending Profiler | not tested | UNPROVEN — verify PASS; net d1679b6b |
| n64-ob8 | 2026-10-15 03:39 | data40m | 768->64 x2->8 buckets | ep3/10 / 3e-4 | **0.009686** best (−0.95%) | — | — | UNPROVEN — training; paused load≥4; engine side not written |
| data_bt4fp32 | 2026-10-15 05:45 | fishpack32 BT4 relabel | — | — | — | — | — | UNPROVEN — 100M train ready; licence UNVERIFIED |
| n128d40ftbk-v6-1736 | 2026-10-14 22:02 | data40m | 768->128 x2->1 | 10 ep / 3e-4 | 0.009262 | −16.1% vs 1.7.37 | — | UNPROVEN — prior PC fuzz reject |

### PC live @ ~05:53 PT (same hour) — UNPROVEN
- grok-pc `nnue\`: no STOP_nnue; data40m present; ~41 GB free.
- **n128-d40g1** GPU train (train_gpu.py DirectML, warm init\n128-d40ft2.pt, affinity F000 /low): ep1 val **0.009252** (start 0.009223), ~270k pos/s; ep2 running. log `logs\n128-d40g1.log`.
- Forge selfplay concurrent on CPUs 12–15 (2 workers, 5000 nodes/move): ~1.5M pos/h after ~2 min. log `logs\selfplay.log`.
- QA notified via hourly status (jobs already running when routine sampled).


## grok-pc GPU + datagen RUNNING (from ~05:50 PT Thu) — all UNPROVEN
- Folder C:\Users\Administrator\grok-pc\nnue\ ; STOP file C:\Users\Administrator\grok-pc\nnue\STOP_nnue (trainer: pause while present, quit if it contains "exit"; self-play guard: exits self-play when present). All procs Idle, affinity F000 (CPUs 12-15), trainer 2 torch threads + 2 Forge workers.
- Data on PC verified: data40m/train.bin md5 9566b3a0...b5 (39.5M), bt4/train.bin md5 92d7a7ed...1c (100M), bt4/val.bin md5 023534a0...02fde.
- Pipeline check: PC export of n128-d40ft2 warm start is byte-identical to box files; a GPU-trained net.pt -> export -> pack_trainer_net.js loads in nnue.js, acc_check 60 games 9533 checks 0 mismatches, int-sim eval == nnue.js on 5 FENs exactly (float vs int differs ~2-26cp = existing QB=64 quantization, same as box nets).
- GPU throughput: ~265-310k pos/s (n128, bs 8192, with self-play running); data40m epoch ~130-145 s vs box 285-2577 s.
- n128-d40g1 (data40m only, lr 3e-4, warm n128-d40ft2): early-stopped, no gain (ep1 0.009252, ep2 0.009237 vs start 0.009223). Not a candidate.
- RUNNING n128-mixbt4: data40m + BT4 (data-only change), warm n128-d40ft2, lr 3e-4, 10 ep, patience 2; ~17k batches/epoch (~8 min). Log logs\n128-mixbt4.log; out nets\n128-mixbt4\ (copy back, pack on box). Val reported on data40m val (+ bt4 val as val_other); switch to val_shared when it exists.
- RUNNING Forge 6.2 self-play: selfplay_guard.py -> forge_selfplay.py, 2 workers, 5000 nodes, out selfplay_out\ (FEN|score|result), ~1.4-1.8M pos/h; log logs\selfplay.log.

## 2026-10-15 06:12 PT — grok-pc NNUE data moved C: → D: (UNPROVEN, ops only)
- Couns approved D:\grok-pc-data for NNUE data (06:05 PT, via QA). STOP_nnue (empty → 'exit') paused/stopped both jobs 06:07–06:11 PT.
- Moved to D:\grok-pc-data\{data40m,bt4,selfplay_out}; md5 OK: data40m/train 9566b3a0…, bt4/train 92d7a7ed…, bt4/val 023534a0…, data40m/val a0757c0b… (src=dst); selfplay files identical. C: copies deleted; C: free 39.8 GB.
- n128-mixbt4 had no finished epoch (stopped ep1 batch ~7000/17033), so restarted from init\n128-d40ft2.pt with --data D:\grok-pc-data\data40m,D:\grok-pc-data\bt4 (old log → logs\n128-mixbt4.run1-stopped.log). selfplay_guard.py --out → D:\grok-pc-data\selfplay_out. All Idle, affinity F000.

## 2026-10-15 ~06:53–07:00 PT — lock 1.7.39; n64-ob8 done; PC failures; BT4 scale finding — all UNPROVEN
- **Lock is GrokChess 1.7.39** = baseline/dist-v1.7.39 (orderfast), js-tree **b1db953ca05316e8272b5842ef6c4b71**, net md5 **157e6b16**e87c923a699429702af0c334 (prior 1.7.38 js-tree 1ec7deec…). Lock bench d9 194011 (same as 1.7.38). NETS columns "vs lock" now mean vs 1.7.39.
- **n128-d40ft2 net-only repack on 1.7.39**: `/workspace/chess-engine-nnue/dist-nnue-n128d40ft2-v6-1739` = cp -rp dist-v1.7.39 + net.nnue from dist-nnue-n128d40ft2-v6-1738. js-tree b1db953c == lock, net d1679b6b, only net.nnue differs. Verify (`v6verify/all_1739.sh`, log `v6verify/all_n128d40ft2_1739.log`): bench d9 net 193301 (HCE 286362, lock 194011), uci smoke OK (2 threads load net), acc_check 60 g 9533 checks 0 mismatches, bug gate nofuzz PASS (0 new, KNOWN 6, FIXED 2; fuzz skipped). Needs Profiler vs 1.7.39, then QA fuzz/TL/[0,10].
- **Shared-val (val_shared, 417,974 pos) + per-source val losses** (`eval_multi.py`, `logs/eval_multi_0655.json`, loss @ scale 400):

| net | val_shared | BT4-val (data_bt4fp32) | data40m val | forgepgn val |
|---|---|---|---|---|
| n64-d40ft (lock net 157e6b16 source) | 0.009565 | 0.023771 | 0.009779 | 0.004962 |
| n128-d40ft2 | **0.009031** | 0.023384 | 0.009223 | 0.004915 |
| n64-ob8 | 0.009414 (−1.6% vs lock net) | 0.023665 | 0.009615 | 0.005083 |

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.39 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n64-ob8 / n64ob8bk-v6-1739 | 2026-10-15 03:39→07:15 | data40m | 768->64 x2->8 out buckets (piece count) | 10/10 ep / 3e-4, warm n64-d40ft | **0.009615** data40m (start 0.009779, −1.7%); shared 0.009414 | pending Profiler | not tested | UNPROVEN — packed dist-nnue-n64ob8bk-v6-1739; verify PASS; needs CR+Profiler+QA |
| n128-d40g1 (grok-pc GPU) | 2026-10-15 05:50 | data40m | 768->128 x2->1 | warm n128-d40ft2, 3e-4, early stop ep2 | ep1 0.009252, ep2 0.009237 vs start 0.009223 | — | — | FAIL — no gain, not a candidate |
| n128-mixbt4 (grok-pc GPU) | 2026-10-15 06:11 | data40m + BT4 100M (raw scores) | 768->128 x2->1 | warm n128-d40ft2, 3e-4, early stop ep2 | data40m val ep1 0.011963, ep2 0.012202 (start 0.009223); BT4-val 0.015388 / 0.014972 | — | — | FAIL — val exploded; cause likely BT4 label scale (below) |
| n128-bt4only (grok-pc GPU, parent-launched ~06:54) | 2026-10-15 06:54 | BT4 only (raw scores), --min-corr -1 | 768->128 x2->1 | warm n128-d40ft2, 1e-4, pat 2 | BT4-val start 0.023384 | — | — | UNPROVEN — running; only BT4-val logged (no data40m/shared val) |
| n128-mixbt4s45 (box) | 2026-10-15 06:58→07:18 | data40m 39.54M + 20M BT4 sampled across all 100M, **scores ×0.45**, val = val_shared | 768->128 x2->1 | warm n128-d40ft2, 1e-4, 10 ep, pat 2 | shared-val start **0.009031**; ep1 0.009214; ep2 0.009201 | — | — | FAIL — early stop, no gain vs warm start |

- **BT4 finding (UNPROVEN):** BT4 sign is White POV (corr(result,score) +0.54/+0.55 for both STM; low material corr 0.14–0.16 is because positions are near material-balanced). But the **label scale is ~2–2.5× data40m cp**: least-squares net/label = 0.27 on BT4 vs 0.65 on data40m (median |net|/|label| 0.36 vs 0.72), median BT4 score +237 White POV, results W 41% / D 58% / B 0.5% (UHO-style White-favoured openings). Likely SF internal units, not normalized cp. This most likely caused the n128-mixbt4 failure, and a raw-BT4-only net will learn inflated eval units (risk to pruning margins). Fix: rescale BT4 scores by ~0.4–0.5 (box ablation uses 0.45) or fit per-source scale; also check UHO bias.
- New tooling: `eval_multi.py` (single or K-bucket nets, many val sets). New data: `data_mix_d40bt4s45/` (1.9 GB, stats.json).

## 2026-10-15 ~07:15 PT — n64-ob8 packed as net-only candidate on 1.7.39 — UNPROVEN
- Dist: /workspace/chess-engine-nnue/dist-nnue-n64ob8bk-v6-1739 (copy of lock 1.7.39 + nnue.js v2 loader + net). net.nnue md5 179dbf5f394095ca62b435df79a91090 (GKNN v2, H64, NB8); eval/nnue.js md5 34f745da5db43daa80d741f6c5dce15a; js-tree 310b24ce.
- Format v2: version=2, nb u32 after H, outW int16[NB*2H] bucket-major, outB int32[NB]. bucket=min(NB-1,(pieces-2)/(32/NB)) incl. kings = train_ob.py. Piece count kept per accumulator slot (refresh/applyMove), checked in checkAccumulator. v1 nets load unchanged; packer emits byte-identical v1 for 1-output nets (lock repack = 157e6b16).
- Patch: /workspace/chess-engine-nnue/nnue-768-n64ob8bk_on1739_js.patch (md5 19f22c60), nnue.js + tools/pack_trainer_net.js.
- Verify: perft PASS; acc_check 200 g 31615 checks 0 mismatches; trainer-int vs nnue.js parity 2000 val positions 0 mismatches (all 8 buckets hit); lock net via new nnue.js 2000/2000 and bench 194011 = lock. bench d9 nodes 194107 (lock 194011). bug_gate_nofuzz PASS (KNOWN 6, fuzz left to QA). Log: chess-engine-nnue/v6verify/all_n64ob8bk_1739.log
- Status: UNPROVEN — needs CR review, Profiler NPS (≤25% gate), QA fuzz/TL/SPRT.

## 2026-10-15 ~07:54 PT — hourly keep-going — all UNPROVEN
- Lock still **1.7.39** (baseline/dist-v1.7.39, js-tree b1db953c, net 157e6b16). NNUE never edits baseline.
- **n128-mixbt4s45 FAIL**: early-stopped ep2; best = warm start shared-val **0.009031** (ep1 0.009214, ep2 0.009201). BT4×0.45 mix did not improve.
- **n128-mixforge STARTED** on box (nice 19, max-load 4, PID train.py): data_mix_d40forge = data40m 39.54M + forgepgn 1.84M (41.38M), val=val_shared, warm n128-d40ft2, H128, lr 1e-4, pat 2; start val **0.009031**. Log `logs/train_n128-mixforge.log`.
- Gate-ready still waiting: **dist-nnue-n128d40ft2-v6-1739** (net d1679b6b, verify PASS) and **dist-nnue-n64ob8bk-v6-1739** (net 179dbf5f, verify PASS, nnue.js v2). Need Agent Profiler NPS vs 1.7.39 (≤25%), Code Review on ob8 patch, then QA fuzz/TL/[0,10]. No fastchess from NNUE.
- Next after mixforge: SCReLU (needs engine+trainer change — Coordinated with Coder), or BT4 rescale revisit; PC GPU/selfplay health checked this hour.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.39 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n128-mixbt4s45 | 2026-10-15 06:58→07:18 | data40m+BT4×0.45 | 768->128 x2->1 | warm n128-d40ft2, 1e-4, pat 2 | best 0.009031 (start) | — | — | FAIL — no gain |
| n128-mixforge | 2026-10-15 07:54 | data40m+forgepgn | 768->128 x2->1 | warm n128-d40ft2, 1e-4, pat 2 | start 0.009031 | — | — | UNPROVEN — training |

## 2026-10-15 ~09:05 PT — lock 1.7.40; n128-d40ft2 + n64-ob8 rebases — all UNPROVEN
- **Lock is GrokChess 1.7.40** = `/workspace/chess-engine/baseline/dist-v1.7.40` (matestop-of1738), js-tree **be272ca50b0e6d55bc5a2248caa0901b**, net md5 **157e6b16**e87c923a699429702af0c334. Lock bench d9 **194011**. NNUE never edits baseline. (No `chess-engine-nnue/baseline` symlink; lock lives under chess-engine.)
- **n128-d40ft2 net-only on 1.7.40**: `/workspace/chess-engine-nnue/dist-nnue-n128d40ft2-v6-1740` = lock copy + net.nnue from 1739 (d1679b6b). Only `net.nnue` differs from lock; eval/nnue.js == lock (6b61f3dc). js-tree be272ca5 == lock. Verify (`v6verify/all_1740.sh`, log `v6verify/all_n128d40ft2_1740.log` @ 08:57 PT): perft PASS; acc_check 60g 9533 checks 0 mismatches; bug_gate_nofuzz PASS (KNOWN 6, fuzz skipped); bench d9 net **193301** (HCE 286362, lock 194011). UCI smoke OK.
- **n64-ob8 on 1.7.40**: `/workspace/chess-engine-nnue/dist-nnue-n64ob8bk-v6-1740` = lock + nnue.js v2 (34f745da) + net 179dbf5f (GKNN v2 H64 NB8). Diff vs lock: `eval/nnue.js` + `net.nnue` only. Patch vs 1.7.40: `/workspace/chess-engine-nnue/nnue-768-n64ob8bk_on1740_js.patch` md5 **ea1ba2b7** (nnue.js + tools/pack_trainer_net.js; applies clean -p1). Verify (`v6verify/all_n64ob8bk_1740.log` + `ob8extra_n64ob8bk_1740.log` @ 08:57–08:58 PT): perft PASS; bug_gate_nofuzz PASS; trainer-int vs nnue.js parity 2000/2000 mismatches=0 (all 8 buckets hit); lock net via new nnue.js 2000/2000 + bench 194011 = lock; bench d9 net **194107**.
- **mixforge** (box, nice 19, max-load 4, PID 486763 still running): data_mix_d40forge, warm n128-d40ft2, H128, lr 1e-4, pat 2. Start val **0.009031**; ep5 best **0.0089917** (−0.44% vs start). Epochs 1–5: 0.009028 / 0.009022 / 0.009012 / 0.008995 / 0.008992. ep6+ in flight.
- Gate path: both 1740 dists need Agent Profiler NPS vs 1.7.40 (≤25%), Code Review on ob8 patch ea1ba2b7, then QA fuzz/TL/SPRT. No fastchess from NNUE.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.40 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n128-d40ft2 / n128d40ft2-v6-1740 | 2026-10-15 09:05 | data40m (same net) | 768->128 x2->1 | — | **0.009223** | pending Profiler | not tested | UNPROVEN — dist-nnue-n128d40ft2-v6-1740; net d1679b6b; verify PASS; js-tree be272ca5 |
| n64-ob8 / n64ob8bk-v6-1740 | 2026-10-15 09:05 | data40m (same net) | 768->64 x2->8 buckets | — | **0.009615** | pending Profiler | not tested | UNPROVEN — dist-nnue-n64ob8bk-v6-1740; net 179dbf5f; nnue.js 34f745da; patch ea1ba2b7; verify+parity PASS |
| n128-mixforge | 2026-10-15 07:54→ | data40m+forgepgn | 768->128 x2->1 | warm n128-d40ft2, 1e-4, pat 2 | best **0.0089917** @ep5 (start 0.009031) | — | — | UNPROVEN — training ep6+ |

## 2026-10-15 ~09:53 PT — hourly keep-going — all UNPROVEN
- Lock still **1.7.40** (js-tree be272ca5, net 157e6b16). NNUE never edits baseline.
- **n128-mixforge DONE** (box): 10/10 epochs, no early stop, best ep10 shared-val **0.0089832** (start 0.009031, −0.53%). Epochs 6–10 ended 0.008985 / 0.008985 / 0.008983. Still slowly improving.
- **Packed net-only candidate** `/workspace/chess-engine-nnue/dist-nnue-n128mixforge-v6-1740` = cp -rp lock 1.7.40 + net.nnue md5 **8220b2a2**cebe3a9c4b18eb487e502e0f (H128 NB1). Only net.nnue differs; js-tree be272ca5 == lock; search.js == lock.
- Verify (`v6verify/all_n128mixforge_1740.log`, 09:50–09:51 PT): perft PASS; acc_check 60 g 9533 checks 0 mismatches; bug_gate_nofuzz PASS (mate suite, KvK, KNOWN 6, fuzz left to QA); nnueinfo prints loaded net path; bench d9 net **221171** (lock 194011, HCE 286362). Rough box bench ms net 1573/1345 vs lock 1304/1191 (noisy, not an NPS gate; Profiler must time).
- **n128-mixforge2 STARTED** (box, nice 19, max-load 4): warm mixforge best, lr 5e-5, 10 ep, pat 2, start val 0.008983. Log `logs/train_n128-mixforge2.log`.
- **grok-pc**: Forge self-play had stalled at 08:57 PT (guard parent died; workers orphaned, no CPU, output frozen at 3.13M pos). Killed only the orphaned self-play tree and relaunched selfplay_guard.py (Idle, affinity F000, forge Idle/0xF000) at ~09:52 PT; appending logs\selfplay.log. GPU n128-bt4s45 (BT4×0.45 only) ep9 BT4s45-val 0.005923 (not comparable to shared val), ep10 running. n128-bt4only (raw) finished ep10 val 0.014417 BT4-val. No STOP_nnue; D: ~200 GB free.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.40 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n128-mixforge / n128mixforge-v6-1740 | 2026-10-15 07:54→09:49 | data40m+forgepgn (41.38M) | 768->128 x2->1 | warm n128-d40ft2, 1e-4, 10 ep | best **0.0089832** shared-val (start 0.009031) | pending Profiler | not tested | UNPROVEN — dist-nnue-n128mixforge-v6-1740; net 8220b2a2; verify PASS; needs Profiler+QA (net-only, no code diff for CR) |
| n128-bt4only (grok-pc GPU) | 2026-10-15 06:54→~08:16 | BT4 raw | 768->128 x2->1 | warm n128-d40ft2, 1e-4 | best BT4-val 0.014417 @ep10 | — | — | DONE, not a candidate (raw BT4 scale) |
| n128-mixforge2 | 2026-10-15 09:52→ | data40m+forgepgn | 768->128 x2->1 | warm n128-mixforge, 5e-5, pat 2 | start 0.008983 | — | — | UNPROVEN — training |

## 2026-10-15 ~12:00 PT — hourly keep-going — all UNPROVEN
- **Lock is GrokChess 1.7.41** = `/workspace/chess-engine/baseline/dist-v1.7.41` (nncache, cut 11:36 PT), js-tree **b60447ca**29d04e10000515801970fdc6, net md5 **157e6b16** (unchanged), bench d9/d10 194011/350802 = 1.7.40. Diff vs 1.7.40 = eval/evaluate.js + eval/nnue.js (eval cache for NNUE, evalGen bump on net load / UseNNUE). NNUE never edits baseline. Push now runs to **23:23 PT** (QA 11:28).
- **n128-mixforge2 FAIL**: warm mixforge, lr 5e-5, early stop after ep2 (0.008987 / 0.008985), best = start 0.008983. No net built.
- **n128-mixob8 training** (box, nice 19, max-load 4): warm n128-mixforge, H128, 8 output buckets, data_mix_d40forge, lr 1e-4. Start shared-val 0.008983; ep6 **0.0089022** (−0.90% vs mixforge, −1.4% vs d40ft2). Still improving.
- **Rebased onto 1.7.41** (`/workspace/chess-engine-nnue`): `dist-nnue-n128mixforge-v6-1741` (net 8220b2a2, net-only), `dist-nnue-n128d40ft2-v6-1741` (net d1679b6b, net-only), `dist-nnue-n64ob8bk-v6-1741` (net 179dbf5f + ob8 nnue.js on top of nncache nnue.js; diff vs lock = eval/nnue.js + net.nnue; patch `nnue-768-n64ob8bk_on1741_js.patch` md5 **27930532**, nnue.js md5 9fca3c10; hunks applied clean, result = 1740 ob8 nnue.js + nncache evalGen lines exactly). Verify (`v6verify/all_1741.sh` + `ob8extra_1741.sh`, logs `v6verify/*_1741.log`, 11:55–11:57 PT): all three perft PASS, acc_check 60 g 9533 checks 0 mismatches, bug_gate_nofuzz PASS (KNOWN 6, fuzz left to QA), nnueinfo prints loaded net path. Bench d9: mixforge 221171, d40ft2 193301, ob8 194107 (lock 194011, HCE 286362). js-tree mixforge/d40ft2 b60447ca (= lock); ob8 5ffe6541. ob8 parity trainer-int 2000/2000 0 mism (all 8 buckets); lock net via ob8 nnue.js 2000/2000 + bench 194011 = lock.
- **grok-pc**: Forge self-play healthy (Idle, F000, 2 workers ~1.32M pos/h, 2.69M pos since 09:52 restart; file 003 growing). **GPU trainer idle since n128-bt4s45 finished ~09:55 PT** (ep10 BT4s45-val 0.005919, not on shared val, not a candidate). No STOP_nnue; D: 173 GB free.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.41 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n128-mixforge2 | 2026-10-15 09:52→10:10 | data40m+forgepgn | 768->128 x2->1 | warm mixforge, 5e-5, pat 2 | best 0.008983 (start) | — | — | FAIL — no gain |
| n128-bt4s45 (grok-pc GPU) | 2026-10-15 08:57→09:55 | BT4×0.45 only | 768->128 x2->1 | warm n128-d40ft2, 1e-4 | best BT4s45-val 0.005919 @ep10 | — | — | DONE, not a candidate (other val set) |
| n128-mixob8 | 2026-10-15 ~11:10→ | data40m+forgepgn | 768->128 x2->8 buckets | warm mixforge, 1e-4, pat 2 | ep6 **0.0089022** (start 0.008983) | — | — | UNPROVEN — training |
| n128mixforge-v6-1741 | 2026-10-15 ~12:00 | (same net 8220b2a2) | 768->128 x2->1 | — | 0.0089832 | Profiler −1.35% vs 1.7.40 (lock nodes identical) | not tested | UNPROVEN — verify PASS; net-only, needs QA |
| n128d40ft2-v6-1741 | 2026-10-15 ~12:00 | (same net d1679b6b) | 768->128 x2->1 | — | 0.009223 | Profiler −8.1% vs 1.7.40 | not tested | UNPROVEN — verify PASS; net-only, needs QA |
| n64ob8bk-v6-1741 | 2026-10-15 ~12:00 | (same net 179dbf5f) | 768->64 x2->8 buckets | — | 0.009615 | Profiler −4.2% vs 1.7.40; needs re-time on nncache | not tested | UNPROVEN — verify+parity PASS; patch 27930532 needs CR, then QA |
- 12:10 PT check: n128-1741 opponent = `dist-nnue-n128d40ft2-v6-1741` (net d1679b6b, bench d9 193301 = -1740 build; perft/acc/bug_gate_nofuzz PASS 11:56). mixforge-1741 (8220b2a2, bench 221171) confirmed intact. n128-mixob8 ep7 val **0.0088971** still improving (10 epochs, pat 2, ~6 min/ep) — let run; pack as dist-nnue-n128mixob8-v6-1741 when done. ob8 nnue.js (v2 loader) is generic in H (8..1024) x NB, so H128x8 needs no new patch beyond 27930532. UNPROVEN.
- **12:25 PT CORRECTION — n128-1741 opponent**: the 12:10 entry was WRONG (d40ft2/d1679b6b is a candidate, not the opponent). Correct opponent = n128-1740 net (n128d40ftbk) md5 **14656706**b1fc701ba6f821d93a62f3eb, from `/workspace/chess-engine/dist-cand-n128-1740`. Built net-only on lock 1.7.41: `/workspace/chess-engine-nnue/dist-nnue-n128-1741` and identical `/workspace/chess-engine/dist-cand-n128-1741` (cp -rp baseline/dist-v1.7.41 + net.nnue; only net.nnue differs; js-tree b60447ca == lock; search.js == lock). Verify (v6verify/all_1741.sh, log v6verify/n128-1741.log, 12:09–12:10): bench d9 **169395** / d10 **288859** == n128-1740 (lock 194011, HCE 286362); uci smoke OK; perft PASS; acc_check 60 g 9533 checks 0 mismatches; bug_gate_nofuzz PASS (KNOWN 6, new 0; fuzz left to QA). No baseline writes, no fastchess. UNPROVEN.
- 12:28 PT **n128-mixob8 DONE**: 10 epochs, best ep10 val **0.0088935** (start 0.008983, −1.0% vs mixforge). Packed by hand as GKNN v2 (hdr magic,2,H=128,NB=8; ftW,ftB,outW[8×256] i16, outB[8] i32; 201008 B) — export_snapshot.py is v1-only (scalar bias), train_ob.py writes the multi-bucket raw files. Dist `dist-nnue-n128mixob8-v6-1741`: net **84af2a31**, nnue.js 9fca3c10 (= n64ob8bk-1741, patch 27930532; no new diff), js-tree 5ffe6541. Diff vs lock = eval/nnue.js + net.nnue. Verify (`v6verify/dist-nnue-n128mixob8-v6-1741_1741.log`): trainer-int parity 2000/2000 0 mism (all 8 buckets hit), bench d9 **225212** (lock 194011, HCE 286362), perft PASS, acc 60 g 9533 checks 0 mism, bug_gate_nofuzz PASS (KNOWN 6, fuzz → QA). Needs Profiler NPS, then QA. UNPROVEN.

| n128mixob8-v6-1741 | 2026-10-15 12:27 | data_mix_d40forge | 768->128 x2->8 buckets | warm mixforge, 1e-4 | 0.0088935 | needs Profiler | not tested | UNPROVEN — verify+parity PASS |

## 2026-10-15 ~12:55 PT — hourly keep-going — all UNPROVEN
- Lock still **1.7.41** (dist-v1.7.41 newest). QA net queue vs n128-1741 (net 14656706): mixforge-1741 -> mixob8-1741 -> ob8-1741 -> d40ft2-1741. mixob8 Profiler speed PASS -5.7%; ob8 CR PASS 27930532.
- **grok-pc GPU n128-d40-from-mixforge DONE 12:30 PT**: warm n128-mixforge, data40m only, 10 ep; data40m-val 0.0091925 -> best ep10 **0.0091557** (-0.4%, data40m val, NOT shared val). Net at grok-pc nnue\nets\n128-d40-from-mixforge; not a candidate until scored on the shared val.
- **grok-pc GPU n256-d40 STARTED ~12:54 PT** (run_train.cmd, Idle, F000): H256 from scratch, data40m, lr 1e-3, 20 ep, pat 2. Prep for larger-H only; needs Profiler H256 timing before any build. Log nnue\logs\n256-d40.log.
- **Box n128-mixob8b STARTED ~12:53 PT** (nice 19, max-load 4): warm n128-mixob8 best, lr 7e-5, 10 ep, pat 2, data_mix_d40forge, start shared-val 0.0088935. Log logs/train_n128-mixob8b.log.
- grok-pc Forge self-play healthy (Idle, F000, ~1.33M pos/h, 3.98M pos since 09:52 restart). No STOP_nnue.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.41 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n128-d40-from-mixforge (GPU) | 2026-10-15 12:01→12:30 | data40m | 768->128 x2->1 | warm mixforge, 10 ep | best 0.0091557 data40m-val (start 0.0091925) | — | — | DONE, needs shared-val score |
| n256-d40 (GPU) | 2026-10-15 12:54→ | data40m | 768->256 x2->1 | scratch, 1e-3, 20 ep, pat 2 | — | needs Profiler H256 | — | UNPROVEN — training |
| n128-mixob8b | 2026-10-15 12:53→ | data_mix_d40forge | 768->128 x2->8 buckets | warm mixob8, 7e-5, pat 2 | start 0.0088935 | — | — | UNPROVEN — training |

## 2026-10-15 ~13:55 PT — hourly keep-going — all UNPROVEN
- **Lock is GrokChess 1.7.43** = `/workspace/chess-engine/baseline/dist-v1.7.43` (n128 lock net), js-tree **88b970cf**02d1c524884969eed3aa8820 (js-only), net md5 **14656706**b1fc701ba6f821d93a62f3eb, bench d9 **169395**. Diff vs 1.7.41 = search/* + uci/main.js + net.nnue (nnue.js unchanged 7724c5d4). NNUE never edits baseline.
- **n128-mixob8b FAIL** (box): warm mixob8 lr 7e-5, early stop after ep2 (0.008898 / 0.008894), best = start shared-val **0.0088935**. No pack. Log `logs/train_n128-mixob8b.log`.
- **Rebased onto 1.7.43** (`/workspace/chess-engine-nnue`): `dist-nnue-n128mixforge-v6-1743` (net 8220b2a2, net-only), `dist-nnue-n128d40ft2-v6-1743` (net d1679b6b, net-only), `dist-nnue-n128mixob8-v6-1743` (net 84af2a31 + ob8 nnue.js 9fca3c10), `dist-nnue-n64ob8bk-v6-1743` (net 179dbf5f + same nnue.js). Patch `nnue-768-n64ob8bk_on1743_js.patch` md5 **27930532** (= on1741; lock nnue.js identical). Smoke (`v6verify/smoke_1743.sh`, logs `v6verify/smoke_dist-nnue-*-v6-1743.log`, 13:53–13:54 PT): all four perft PASS, uci smoke OK, bench d9 mixforge **221171**, d40ft2 **193301**, mixob8 **225212**, ob8 **194107** (lock 169395). search.js == lock on all. No fastchess. No board/move/tt touched.
- **Box**: no active train after mixob8b; load ~3–4; no STOP_nnue. SCReLU next per Strategist but needs Coder+trainer change — not started. Stray bash waiter for old eval_checkpoint still present (harmless).
- **grok-pc**: no STOP_nnue. Forge self-play healthy (~1.34M pos/h, ~5.35M pos @ ~4.0 h since restart). GPU n256-d40 in ep19 of 20 (data40m-val ~0.00837, NOT shared val; needs Profiler H256 before candidate). Affinity/Idle noted for QA notify.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.43 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n128-mixob8b | 2026-10-15 12:53→13:30 | data_mix_d40forge | 768->128 x2->8 buckets | warm mixob8, 7e-5, pat 2 | best 0.0088935 (start) | — | — | FAIL — no gain |
| n128mixforge-v6-1743 | 2026-10-15 ~13:53 | (same net 8220b2a2) | 768->128 x2->1 | — | 0.0089832 | pending re-Profiler on 1.7.43 | not tested | UNPROVEN — smoke PASS; net-only |
| n128mixob8-v6-1743 | 2026-10-15 ~13:54 | (same net 84af2a31) | 768->128 x2->8 buckets | — | 0.0088935 | Profiler −5.7% was vs 1.7.41 | not tested | UNPROVEN — smoke PASS; needs re-Profiler+QA |
| n64ob8bk-v6-1743 | 2026-10-15 ~13:54 | (same net 179dbf5f) | 768->64 x2->8 buckets | — | 0.009615 | Profiler −4.2% was vs 1.7.40 | not tested | UNPROVEN — smoke PASS; patch 27930532 |
| n128d40ft2-v6-1743 | 2026-10-15 ~13:53 | (same net d1679b6b) | 768->128 x2->1 | — | 0.009223 | Profiler −8.1% was vs 1.7.40 | not tested | UNPROVEN — smoke PASS; net-only |
| n256-d40 (GPU) | 2026-10-15 12:54→ | data40m | 768->256 x2->1 | scratch, 1e-3, 20 ep | ep19 data40m-val ~0.00837 | needs Profiler H256 | — | UNPROVEN — training near end |

## 2026-10-15 ~13:58 PT — box worker keep-slot — all UNPROVEN
- Lock **1.7.43**. No STOP_nnue. No other train running. Load was ~3.8 at start (now throttles at ≥4). Did **not** touch baseline/, grok-pc, or fastchess.
- **(a) skipped**: `n128-d40-from-mixforge` GPU checkpoint is **not on the box** (lives on grok-pc); cannot score shared-val without CopyFromBox/PC Shell (Auto-review pending).
- **(b) started `n128-mixob8c`**: one-variable continue of best shared-val net. mixob8 finished ep10 still improving (0.0088935); mixob8b FAIL only after dropping lr to 7e-5. This run keeps **lr 1e-4** (same as successful mixob8) for 10 more epochs.
  - cmd: `nice -n 19 venv/bin/python train_ob.py --data data_mix_d40forge --out nets/n128-mixob8c --hidden 128 --epochs 10 --lr 1e-4 --max-load 4 --init nets/n128-mixob8/net_best.pt --obuckets 8 --patience 2`
  - pid **1316188**, nice 19, log `logs/train_n128-mixob8c.log`
  - warm `nets/n128-mixob8/net_best.pt` md5 **0edff0cf**14814922624621713bb18a34; start shared-val **0.008893493** (= mixob8 best)
  - data: `data_mix_d40forge` (data40m+forgepgn); no new converted forge/self-play on box; BT4 skipped (scale not fixed); SCReLU waiting on Coder
- Next-command if this fails: score GPU `n128-d40-from-mixforge` on `val_shared` once checkpoint is on box; else idle pending SCReLU or new forge convert from grok-pc self-play.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.43 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n128-mixob8c | 2026-10-15 13:58→ | data_mix_d40forge | 768->128 x2->8 buckets | warm mixob8, 1e-4, pat 2 | start 0.0088935 | — | — | UNPROVEN — training |

## 2026-10-15 ~14:52 PT — hourly keep-going — all UNPROVEN
- Lock still **1.7.43** (`baseline/dist-v1.7.43`, net md5 **14656706**, bench d9 **169395**). NNUE never edits baseline.
- **n128-mixob8c FAIL** (box): warm mixob8, lr 1e-4, early stop after ep2 (val 0.008900 / 0.008898), best = start shared-val **0.0088935**. No pack. Log `logs/train_n128-mixob8c.log`.
- **Shared-val eval** (`eval_multi.py`, nice 19, max-load 4 → `logs/eval_shared_1452.json`, n=417974):
  - n128-mixob8 net_best: **0.008893** (H128×8) — still best packed H128
  - n128-mixforge net_best: **0.008983** (H128×1)
  - n128-d40ft2 net_best: **0.009031** (H128×1)
  - n128-d40-from-mixforge net_best (GPU→box): **0.008967** (H128×1) — better than mixforge, worse than mixob8; not a pack over mixob8
  - **n256-d40 net_best (GPU→box): 0.008232** (H256×1) — **best shared-val on box** (−7.4% vs mixob8); needs Profiler H256 NPS before any candidate pack
- **Skipped n128-mixob8d** (lr 1.5e-4 warm continue): mixob8b (7e-5) and mixob8c (1e-4) already FAIL from same warm start; another lr bump is a long shot vs the n256 finding. Slot intentionally idle pending SCReLU (Coder) / H256 Profiler / new data. No STOP_nnue. No baseline edits. No fastchess. All UNPROVEN.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.43 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n128-mixob8c | 2026-10-15 13:58→~14:37 | data_mix_d40forge | 768->128 x2->8 buckets | warm mixob8, 1e-4, pat 2 | best 0.0088935 (start) | — | — | FAIL — no gain |
| eval_shared_1452 n256-d40 | 2026-10-15 ~14:55 | data40m (GPU train) | 768->256 x2->1 | scratch, scored on val_shared | **0.008232** shared-val | needs Profiler H256 | not tested | UNPROVEN — best shared-val; not packed |
| eval_shared_1452 n128-d40-from-mixforge | 2026-10-15 ~14:55 | data40m (GPU) | 768->128 x2->1 | warm mixforge, scored on val_shared | 0.008967 | — | — | UNPROVEN — below mixob8; not packed |

### 2026-10-15 ~15:00 PT (executor)
- **dist-nnue-n256d40-v6-1743** verified: js-tree 88b970cf (== lock 1.7.43, search.js/nnue.js == lock), net md5 14623076 (146230763c2c76cfbf444ab67db8d148, H256x1), perft PASS, acc_check 30 games 4729 checks 0 mismatches, bench d9 237947 nodes 1453 ms. Needs Profiler H256 NPS. UNPROVEN.
- **SCReLU act=1 train NOT started**: train.py / train_ob.py are clipped-ReLU only (forward `torch.clamp(...,0,1)`), no |outW|<=127 Lizard clamp in the step, and export writes v1/v2 (no GKNN v3 act header). Box slot left free.

### 2026-10-15 ~15:10 PT (executor) — SCReLU act=1 trainer + box train — UNPROVEN
- Trainer support added: `train.py`, `train_ob.py` take `--act 0|1` (1 = SCReLU `clamp(x,0,1)**2`), Lizard clamp `|outW| <= 127/64` after each step when act=1 (and clipped again at export), `--init-ft` (copies ft.weight/fb only, new output layer), and they always write `net_v3.nnue` (GKNN magic,3,H,NB,act + ftW,ftB,outW,outB). The act=0 raw i16/i32 export is unchanged. `eval_checkpoint.py` and `eval_multi.py` take `--act`. Backups are in `bak_screlu/`.
- Smoke test (H16, 80k rows): v3 header 0x4E4E4B47/3/16/1/1, size OK, max|outW|=12. Spec int formula vs float on 500 random positions: mean 0.71 cp, max 3.0 cp (quantization only).
- **Train n128-screlu-a**: `nice -n 19 venv/bin/python train.py --data data_mix_d40forge --out nets/n128-screlu-a --hidden 128 --epochs 10 --lr 1e-3 --max-load 4 --act 1 --patience 2`, pid 1894276, log `logs/train_n128-screlu-a.log`. From scratch, NB=1. Score on shared-val with `eval_multi.py --act 1 --vals val_shared`.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock 1.7.43 | Elo vs lock | status |
|---|---|---|---|---|---|---|---|---|
| n128-screlu-a | 2026-10-15 ~15:08→ | data_mix_d40forge | 768->128 x2->1 SCReLU (act=1, Lizard) | scratch, 1e-3, 10 ep, pat 2 | start n/a (scratch); target < 0.008893 shared-val | — | — | UNPROVEN — training |

## 2026-10-15 ~15:53 PT — hourly keep-going — all UNPROVEN
- **Lock now 1.7.44** (`baseline/dist-v1.7.44`, net md5 **8220b2a2** = mixforge). Prior lock 1.7.43 net was 14656706. NNUE never edits baseline.
- **Box**: `n128-screlu-a` still training (pid **1894276**, nice 19, `--act 1` SCReLU scratch, data_mix_d40forge, lr 1e-3, max-load 4). Through ep2: train 0.009386 / val **0.009240** (run val, not shared-val yet). Load ~4.2–4.8; no second box train.
- **n256**: Profiler vs 1.7.43 median **−7.05% PASS** (`research/prof1743_n256`). On-nnsimd2 vs 1.7.44 median **+0.52% PASS** (`research/prof1744_nnsimd2`). Candidate `dist-cand-n256simd-1744` HOLD until nnsimd2 → 1.7.45 (filed REQUESTS). Scalar pack `dist-nnue-n256d40-v6-1743` net **14623076**, shared-val **0.008232**.
- **grok-pc**: STOP_nnue absent. Forge self-play healthy (~1.28M pos/h, ~7.7M pos, Idle/F000). GPU **idle** after finishes: n256-d40 done (best ep19 data40m-val 0.008373); n128-d40-cont done (best ep12 data40m-val 0.009166, not a shared-val win vs mixforge). Next GPU job start in progress this hour. D: ~173 GB free.
- No fastchess. No board/move/tt edits. All UNPROVEN.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n128-screlu-a | 2026-10-15 ~15:08→ | data_mix_d40forge | 768->128 x2->1 SCReLU | scratch 1e-3 pat2 | ep2 val 0.009240 (run val) | — | — | UNPROVEN — training |
| n128-d40-cont (GPU) | 2026-10-15 ~14:55→~15:24 | data40m | 768->128 x2->1 | warm mixforge 5e-5 | best 0.009166 data40m-val | — | — | FAIL-ish — below mixforge shared; not packed |
| n256-d40 (GPU) | 2026-10-15 12:54→~13:55 | data40m | 768->256 x2->1 | scratch 1e-3 | shared-val **0.008232**; data40m-val 0.008373 | −7.05% vs 1.7.43 PASS; +0.52% on nnsimd2 vs 1.7.44 | not tested | UNPROVEN — HOLD n256simd-1744 for nnsimd2 lock cut |

## 2026-10-15 ~16:53 PT — hourly keep-going — all UNPROVEN
- Lock still **1.7.44** (latest `baseline/dist-v1.7.44`, net 8220b2a2); no 1.7.45 yet (nnsimd2b pending QA).
- **Box**: `n128-screlu-a` (pid 1894276) alive; ep3 val **0.009050** (run val; shared-val bar 0.008893 not beaten yet). Ep4 slower — box load 4.4–5.8, so max-load 4 throttling. No second box train.
- **grok-pc** (last check ~16:15): GPU `n256-d40-cont` PID 8572 moved Normal/0xFFFF → Idle/0xF000; ep7 best 0.008363 (data40m-val). Forge self-play Idle/F000. STOP_nnue absent.
- n256simd-1744 still HOLD for nnsimd2 → 1.7.45. No fastchess, no board/move/tt edits.

| n128-screlu-a | 2026-10-15 ~15:08→ | data_mix_d40forge | 768->128 x2->1 SCReLU | scratch 1e-3 pat2 | ep3 val 0.009050 (run val) | — | — | UNPROVEN — training |
| n256-d40-cont (GPU) | 2026-10-15 ~16:00→ | data40m | 768->256 x2->1 | cont | ep7 best 0.008363 data40m-val | — | — | UNPROVEN — training |

### ~17:20 PT Thu Oct 15 — Strategist 17:15 actions (all UNPROVEN)
- **dist-nnue-n256d40-v6-1744** packed: /workspace/chess-engine-nnue/dist-nnue-n256d40-v6-1744 = copy of baseline/dist-v1.7.44 with net.nnue → n256-d40 (md5 146230763c2c76cfbf444ab67db8d148). `diff -rq` vs dist-v1.7.44: only net.nnue differs. Box UCI smoke OK (startpos d9 cp29 63569 nodes; d10 cp25 81976 nodes, bestmove d2d4). Synced to grok-pc `C:\Users\Administrator\grok-pc\nnue\dist-nnue-n256d40-v6-1744\` (net md5 verified on PC).
- **n128-screlu-a** (box, PID 1894276): ep4 val **0.008883** (val.bin = copy of val_shared → this IS shared-val) — just under bar 0.008893 (−0.1%). Below ep5 → left running per Strategist rule; recheck at ep5.
- **grok-pc GPU n256-forgeall** queued: converting ALL forge self-play (001+002+003 snapshot to last full line, ~12.8M lines) → D:\grok-pc-data\forge_sp_all (convert_forge.py, Idle/0xF000). Watcher start_n256_forgeall.ps1 launches train_gpu.py --data data40m,forgepgn(1.84M),forge_sp_all --hidden 256 --lr 1e-4 --epochs 10 --patience 3 --init nets\n256-d40-cont\net_best.pt (ep10 0.008363) at Idle/0xF000 when stats.json appears; honors STOP_nnue. Log logs\n256-forgeall.log, logs\start_n256_forgeall.log. Val logged = data40m val; shared-val + forgepgn-val to score after.

## 2026-10-15 ~17:56 PT — hourly keep-going — all UNPROVEN
- Lock still **1.7.44** (net 8220b2a2); no 1.7.45 yet.
- **Box** `n128-screlu-a` (pid 1894276): ep5 0.008840, ep6 0.008802, ep7 **0.008752** shared-val — beats mixforge bar 0.008893 by ~1.6% and still improving (10 epochs, patience 2). Box load ~5.2, so max-load 4 throttles it.
- **grok-pc GPU** `n256-forgeall` (warm from n256-d40-cont, data40m+forgepgn+forge_sp_all, lr 1e-4): started 17:39, early-stopped ~17:50 after ep3 (ep3 data40m-val 0.008525, other vals 0.003692/0.00325); best = epoch 0 val 0.008363 = no gain over its start net. FAIL on data40m-val; not packed. GPU now idle.
- grok-pc forge self-play healthy: ~10.03M positions, ~1.24M pos/h, Idle/0xF000. STOP_nnue absent. D: 168 GB free.
- `dist-nnue-n256d40-v6-1744` (net 14623076) packed + synced, waiting QA slot. No fastchess, no board/move/tt edits.

| n128-screlu-a | 2026-10-15 ~15:08→ | data_mix_d40forge | 768->128 x2->1 SCReLU | scratch 1e-3 pat2 | ep7 shared-val 0.008752 | — | — | UNPROVEN — training, beats bar |
| n256-forgeall (GPU) | 2026-10-15 17:39→~17:50 | data40m+forgepgn+forge_sp_all | 768->256 x2->1 | warm n256-d40-cont 1e-4 pat3 | best ep0 0.008363 data40m-val (no gain) | — | — | FAIL — early stop, not packed |

### 2026-10-15 ~18:00 PT — GPU n256-screlu-a launched (all UNPROVEN)
- **train_gpu.py** on box + grok-pc: ported SCReLU from train.py — `--act 0|1`, `--init-ft`, Lizard `|outW|<=127/64` when act=1, always writes `net_v3.nnue` (GKNN magic,3,H,NB,act). Backup PC: `train_gpu.py.bak_prescrelu` (md5 795E23E72EF0ACA4D7B58C011834AF4D); patched md5 99D2913B2E98698C1787EB47A6C438B6. Box copy: `/workspace/chess-tools/nnue/train_gpu.py`.
- **Launch** grok-pc PID **8920**: Idle + affinity **0xF000** (CPUs 12-15) verified via Start-Process + Get-Process.
  - cmd: `.venv\Scripts\python.exe -u train_gpu.py --data D:\grok-pc-data\data40m,D:\grok-pc-data\forgepgn,D:\grok-pc-data\forge_sp_all --out nets\n256-screlu-a --hidden 256 --epochs 10 --lr 1e-3 --act 1 --init-ft nets\n256-d40-cont\net_best.pt --patience 3 --stop-dir C:\Users\Administrator\grok-pc\nnue`
  - data sizes: data40m 39.5M + forgepgn 1.84M + forge_sp_all 11.7M train rows; val = data40m val
  - FT-only warm from n256-d40-cont (fresh SCReLU out); lr 1e-3; torch threads 2 (≤4)
  - log `logs\n256-screlu-a.log` / `.err`; launcher `pc_launch\start_n256_screlu_a.ps1`
- STOP_nnue absent. No baseline/run_*/orch_* edits. All UNPROVEN.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n256-screlu-a (GPU) | 2026-10-15 ~18:00 PT→ | data40m+forgepgn+forge_sp_all | 768->256 x2->1 SCReLU act=1 Lizard | FT-only n256-d40-cont, 1e-3, 10 ep, pat 3 | start n/a (fresh out) | — | — | UNPROVEN — training PID 8920 Idle/0xF000 |

### 2026-10-15 ~18:15 PT — n256-forgeall ep3 rescue + GPU switch (all UNPROVEN)
- **FROZEN ep3 weights (QA gate source):** PC `C:\Users\Administrator\grok-pc\nnue\nets\n256-forgeall\net_ep3_frozen.pt` (read-only) and box `/workspace/chess-tools/nnue/nets/n256-forgeall/net_ep3_frozen.pt` (a-w), md5 **1c22c082657dcd8312f15f6ddf313196** (= net.pt at 17:50).
- forgepgn val.bin md5 PC xfer\forgepgn = box data_forgepgn = 5e86be53c436eefdcec83e3eaf313b37.
- eval_multi act=0: ep3 val_shared **0.008310** / data40m 0.008525 / forgepgn **0.003692**; lock mixforge 0.008983 / 0.009193 / 0.004480 (−7.5% / −7.3% / −17.6%).
- **Packed** /workspace/chess-engine-nnue/dist-nnue-n256forgeall-v6-1744 = cp baseline/dist-v1.7.44 + net.nnue (v1 GKNN H256, md5 **d0e1c9f00cd2e00de42ab2e034b6c5bb**; built from export_snapshot of frozen pt, format verified by rebuilding n256d40 bit-exact). diff -rq: only net.nnue. acc_check 60 g 9533 checks 0 mism; bench d9 220563 nodes; UCI d10 cp29 82103 nodes bestmove d2d4. Synced PC `C:\Users\Administrator\grok-pc\nnue\dist-nnue-n256forgeall-v6-1744\` (net md5 verified, 91 files).
- **train_gpu.py `--select-val N`** (index into --data; drives best/early-stop; val_other = rest). md5 aedca8930187d0dcd4e20a1a962d3cc9 box+PC; backups train_gpu.py.bak_preselect.
- GPU: killed n256-screlu-a (8920 tree: 8920/7728/11684) mid-ep1 (no epoch saved). Started **n256-forgeall-b** (launcher 1340, python 8436, both Idle/0xF000): --init frozen ep3, lr 5e-5, 10 ep, pat 3, --select-val 1 (forgepgn; note random split, leaky), data data40m,forgepgn,forge_sp_all, out nets\n256-forgeall-b. Start val (forgepgn) 0.003692.


## 2026-10-15 ~18:56 PT — hourly keep-going — all UNPROVEN
- Lock still **1.7.44** (net 8220b2a2 mixforge). Box load high (~16, QA matches); no new box train.
- **Box n128-screlu-a DONE**: ep10 best_val **0.008713** (beats bar 0.008893 by ~2.0%). Export `nets/n128-screlu-a/net_v3.nnue` / `nets-export/n128-screlu-a-v3-act1.nnue` md5 **743b284f109eb660a3fdc6777b77dcad** (GKNN v3 H128 NB1 act=1). Earlier interim export 86b2c2ad was ep9; final is ep10.
- **GPU n256-forgeall-b DONE**: early-stop best ep5 forgepgn-val **0.003620** (start 0.003692); ep8 val_other data40m ~0.008506 / forge_sp ~0.00317. Wrote `nets/n256-forgeall-b/net_v3.nnue` act=0. Shared-val score pending before any pack vs forgeall ep3 (shared 0.008310, net d0e1c9f0).
- **GPU**: was idle after forgeall-b; restarting **n256-screlu-a** (SCReLU act=1, FT-only n256-d40-cont, data40m+forgepgn+forge_sp_all, lr 1e-3, pat 3) Idle/0xF000.
- Forge self-play healthy Idle/0xF000; D: ~168 GB free. STOP_nnue absent.
- QA: `dist-nnue-n256d40-v6-1744` (14623076) + `dist-nnue-n256forgeall-v6-1744` (d0e1c9f0, Profiler NPS median −15.7% PASS) in flight / waiting slots; PC orch already matching n256forgeall. screlu2 needs final 743b284f net beside cand after CR. All UNPROVEN.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n128-screlu-a | 2026-10-15 15:08→~18:20 | data_mix_d40forge | 768->128 x2->1 SCReLU act=1 | scratch 1e-3 10ep pat2 | **best ep10 0.008713** shared-val | needs screlu2 wasm | not tested | UNPROVEN — DONE export 743b284f |
| n256-forgeall-b (GPU) | 2026-10-15 18:03→~18:36 | data40m+forgepgn+forge_sp_all | 768->256 x2->1 | warm frozen ep3, 5e-5, select-val forgepgn | best ep5 **0.003620** forgepgn | — | — | UNPROVEN — DONE; shared-val pending |
| n256-screlu-a (GPU) | 2026-10-15 ~19:00→ | data40m+forgepgn+forge_sp_all | 768->256 x2->1 SCReLU | FT n256-d40-cont 1e-3 pat3 | restart after mid-ep1 kill | — | — | UNPROVEN — restarting |

### 2026-10-15 ~19:12 PT — Strategist 19:10 correction (NNUE acted) — all UNPROVEN
- **DO NOT pack forgeall-b.** Shared-val 0.008301 vs forgeall ep3 0.008310 (flat). Confirmed no `dist-nnue-*forgeall-b*` on box or grok-pc. Note: `nets/n256-forgeall-b/NO_PACK.md`. Leave train artifacts only.
- **Select on data40m:** future GPU early-stop must use `--select-val 0` (first `--data` file = data40m). forgepgn-val is leaky (random split) and had ranking backwards; n256d40 (+56.5 @190) leads n256forgeall (+36.4 @185) in real QA matches, as data40m-val predicted (0.008373 vs 0.008525).
- **Live GPU n256-screlu-a** (grok-pc): PID **8180** (train; torch threads 2) + launcher/wrapper **9228**. Priority **Idle**, affinity **0xF000** (61440). STOP_nnue absent. Cmdline has **no** `--select-val` → train_gpu.py default **0** = data40m. Logged `val` is data40m (ep1 0.008814, ep2 0.008735); mid-ep3. **No restart** (already correct select; mid-epoch; low impact). Re-pinned not needed (Idle/F000 held). Launcher `pc_launch/start_n256_screlu_a.ps1` updated to pass `--select-val 0` explicitly for future relaunches.
- **screlu3 plan (Coder):** screlu3 = screlu2 + fast `fwd_sc`: `t = i16x8.mul(c, w)` then `acc += i32x4.dot_i16x8_s(t, c)`. Exact for net **743b284f** (max|outW|=84, trainer clips 127 → c*w fits i16). Expected **+20..30% NPS** on SCReLU nets. Gates: parity vs screlu2 w/ 743b284f (0 mism), bench 145322/233995, Profiler pairs; Code Review nnue.js+wat. Pack after CR PASS. CReLU path untouched; gate at load keep old kernel fallback.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n256-forgeall-b (GPU) | 2026-10-15 18:03→~18:36 | data40m+forgepgn+forge_sp_all | 768->256 x2->1 | warm frozen ep3, 5e-5, select-val forgepgn | shared **0.008301** (flat vs ep3 0.008310); forgepgn best 0.003620 | — | — | **NO PACK** — Strategist 19:10 |
| n256-screlu-a (GPU) | 2026-10-15 ~19:00→ | data40m+forgepgn+forge_sp_all | 768->256 x2->1 SCReLU | FT n256-d40-cont 1e-3 pat3; select-val **0** (default) | ep2 data40m-val 0.008735; mid-ep3 | — | — | UNPROVEN — training PID 8180 Idle/0xF000 |

## 2026-10-15 ~19:55 PT — hourly keep-going — all UNPROVEN
- Lock still **1.7.44** (net 8220b2a2). Box load ~2.1; no NNUE box job running (box slot idle, awaiting Strategist pick for next ablation).
- **GPU n256-screlu-a DONE** (10/10 ep, no early stop, still improving): best ep10 data40m-val **0.008384** (ep9 0.008397); val_other forgepgn 0.003335 / forge_sp 0.002849; train 0.006872. Wrote PC `nets\n256-screlu-a\net_v3.nnue` act=1 (md5 not yet taken). Roughly flat vs n256d40 data40m-val 0.008373 — no pack yet; needs screlu3 wasm anyway.
- **GPU started n256-screlu-b**: --init n256-screlu-a/net_best.pt, lr 2e-4, 10 ep, pat 3, act 1, --select-val 0 (data40m), same 3-file mix. PID **5444** Idle/0xF000 verified; start val 0.008384. Launcher `pc_launch\start_n256_screlu_b.ps1`.
- PC process-inspection command was blocked by Auto-review this run; Forge self-play health not re-verified this hour.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n256-screlu-a (GPU) | 2026-10-15 ~19:00→~19:45 | data40m+forgepgn+forge_sp_all | 768->256 x2->1 SCReLU | FT n256-d40-cont 1e-3 pat3 select-val 0 | best ep10 data40m **0.008384** | needs screlu3 | — | UNPROVEN — DONE, no pack (flat vs n256d40 0.008373) |
| n256-screlu-b (GPU) | 2026-10-15 ~19:53→ | same | 768->256 x2->1 SCReLU | warm screlu-a best, 2e-4, 10ep pat3 select-val 0 | start 0.008384 | — | — | UNPROVEN — training PID 5444 Idle/0xF000 |

### 2026-10-15 ~19:56 PT — Box ablation n128-screlu-ob8 (Strategist pick)
- **Train n128-screlu-ob8**: `nice -n 19 venv/bin/python train_ob.py --data data_mix_d40forge --out nets/n128-screlu-ob8 --hidden 128 --epochs 10 --lr 1e-3 --max-load 4 --act 1 --patience 2 --obuckets 8`, pid 242166, log `logs/train_n128-screlu-ob8.log`. Clone of n128-screlu-a with the only change being NB=8 output buckets (bucket=min(7,(pieces-2)//4), kings included). Existing train_ob.py, no code change. Single thread. Neither trainer sets a seed, so seed matches n128-screlu-a (unseeded). Run val = data_mix_d40forge/val.bin, which is byte-identical to val_shared (data40m shared-val), so selection is on shared-val. Load at start 2.6. Second TODO (not started): leak-free Forge val split by game ID.

| n128-screlu-ob8 | 2026-10-15 19:56→ | data_mix_d40forge | 768->128 x2->8 SCReLU act=1 NB8 | scratch 1e-3 10ep pat2 | bar: beat 0.008713 shared-val (n128-screlu-a) | needs NB8 in screlu3 | not tested | UNPROVEN — training |

## 2026-10-15 ~20:58 PT — hourly keep-going — all UNPROVEN
- **Lock now 1.7.45** (`baseline/dist-v1.7.45`, net md5 **d0e1c9f0**0cd2e00de42ab2e034b6c5bb = n256forgeall ep3). Prior 1.7.44 was mixforge **8220b2a2**. NNUE never edits baseline.
- **Box**: `n128-screlu-ob8` still training (pid **242166**, nice 19, `--act 1` NB=8, data_mix_d40forge). Through **ep6** best shared-val **0.008660** (bar = n128-screlu-a 0.008713 — already beating by ~0.6%). Load ~3.7; left running. No second box train.
- **grok-pc (FoxOS)**: STOP_nnue absent. **GPU n256-screlu-b DONE** ~20:05 PT: early-stop after ep3; best = **epoch 0** data40m-val **0.008384** (ep1 0.008412 / ep2 0.008386 / ep3 0.008385) — **no gain** over screlu-a start; wrote `nets\n256-screlu-b\net_v3.nnue` act=1 (not packed). GPU trainer idle (no `train_gpu` process). **Forge self-play healthy**: ~13.84M pos @ ~1.25M/h (004.part growing), workers `--cpus 12-15`, Win32 Priority **4=Idle** on guard/selfplay/forge PIDs; affinity 0xF000 not re-read this hour (Get-Process blocked previously). D: **167.8 GB** free.
- No new GPU launch (no documented next ablation after screlu-b). forgeall-b remains **NO_PACK**. screlu3 packing still Coder-owned (`dist-cand-screlu3n128-1744` / screlu2-1745 exist). No fastchess. No baseline edits. All UNPROVEN.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n128-screlu-ob8 | 2026-10-15 19:56→ | data_mix_d40forge | 768->128 x2->8 SCReLU NB8 | scratch 1e-3 10ep pat2 | ep6 best **0.008660** shared-val (beats 0.008713) | needs NB8+screlu3 | — | UNPROVEN — training PID 242166 |
| n256-screlu-b (GPU) | 2026-10-15 19:53→~20:05 | data40m+forgepgn+forge_sp_all | 768->256 x2->1 SCReLU | warm screlu-a 2e-4 pat3 select-val 0 | best ep0 **0.008384** (no gain) | — | — | FAIL — early stop; not packed |
| n256-screlu-a (GPU) | 2026-10-15 ~19:00→~19:45 | same | 768->256 SCReLU | FT n256-d40-cont 1e-3 | best ep10 **0.008384** data40m | needs screlu3 | — | UNPROVEN — DONE, flat vs n256d40 0.008373; no pack |

### 2026-10-15 ~21:35 PT — forge whole-game holdout + n256-screlu-c (all UNPROVEN)
- **Lock 1.7.45** = 1.7.44 JS + net d0e1c9f0 (frozen pt `nets\n256-forgeall\net_ep3_frozen.pt` md5 1c22c082657dcd8312f15f6ddf313196, verified on PC).
- **Forge holdout built** (PC `D:\grok-pc-data\forge_holdout\`, script `nnue\build_forge_holdout.py`, log `logs\forge_holdout.log`). Source lines have NO game id → games derived: new game when fullmove decreases OR piece count increases OR result field changes. game_id=`<file>#<ordinal>`; held out if sha1(game_id+"fho1")%10000<500 (5%). Same filters as convert_forge.py (pieces<=30, clip 3000, White-POV), dedup per set, train positions also present in holdout dropped (0 overlap). Sources: forge_selfplay_001/002/003 (md5 5c82679f / 1cb03e14 / b13fafe3) + snapshot of 004.part to last newline `forge_holdout\forge_selfplay_004_snap.txt` (md5 7013ad8f). 17,498,006 lines, 193,592 games (~90 lines/game), **9,851 held-out games**. **val.bin 819,894 pos md5 325c3f33a7ea0793157b1c3f29e4f830**; **train.bin 15,272,952 pos md5 454441d709183ca4f6385c9098cf6de7**; holdout_game_ids.txt md5 34d6da7f90507b33378c1f13fb544062. Caveat: nets trained on old forge_sp_all (forgeall, screlu-a/b, forgeall-b) saw the 001-003 holdout games → their holdout scores are contaminated; only nets trained from now on with forge_holdout/train.bin are clean. Old forge_sp_all/val.bin is now leaky vs the new train.
- **Reference scores** (`score_nets.py`, logs\score_nets.json; matches trainer loss): forge_holdout / data40m-val / forgepgn-val
  - d0e1c9f0 (forgeall ep3 frozen): 0.003315* / 0.008525 / 0.003692
  - n256d40 14623076 (`nets\n256-d40\net_best.pt`, export bytes verified in dist net.nnue): 0.005186 / 0.008373 / 0.005186 (no forge in training → clean)
  - n256-screlu-a net_best: 0.002909* / 0.008384 / 0.003335   (*contaminated, see caveat)
- **train_gpu.py**: added `--obuckets K` (box train_ob.py bucket=min(K-1,(pieces-2)//(32//K)) incl kings; single-head init repeated into all buckets; v3 export NB=K), `--extra-val` (logged per epoch), `--keep-last N` (net_ep<N>.pt). Backup `train_gpu.py.bak_preob`. Smoke H256 NB8 from d0e1c9f0: start val 0.008525 identical to source → init exact.
- **GPU n256-screlu-c STARTED 21:28 PT** (supersedes planned n256-forgeall-c and n256-forgeall-ob8; neither was launched). PID **6900** (launcher 4768), Idle/0xF000 verified x3 re-pins; torch 2 threads. Cmd: `.venv\Scripts\python.exe -u train_gpu.py --data D:\grok-pc-data\data40m,D:\grok-pc-data\forgepgn,D:\grok-pc-data\forge_holdout --out nets\n256-screlu-c --hidden 256 --act 1 --epochs 5 --lr 2e-4 --init nets\n256-screlu-a\net_best.pt --patience 99 --select-val 2 --keep-last 99 --extra-val D:\grok-pc-data\forge_sp_all,D:\grok-pc-data\val_shared --stop-dir <nnue>` (launcher pc_launch\start_n256_screlu_c.ps1). Select = forge holdout; every epoch saved; logs data40m/forgepgn/holdout + shared. ep1: holdout 0.002762 (start 0.002909), data40m 0.008473, forgepgn 0.00318, shared 0.008238.
- **Next GPU: n256-forgeall-ob8** (H256 act0 NB8, init d0e1c9f0 heads copied, lr 5e-4, 6-8 ep, same new selection: --select-val 2 forge holdout, keep all epochs) — not launched.
- **screlu3: PARKED** (Strategist 20:25: +1.6% NPS = noise). **n256-screlu-b: FAIL** (already recorded).

## 2026-10-15 ~21:57 PT — hourly keep-going — all UNPROVEN
- **Lock 1.7.45** (`baseline/dist-v1.7.45`, net md5 **d0e1c9f0**0cd2e00de42ab2e034b6c5bb = n256forgeall). NNUE never edits baseline.
- **Box DONE: n128-screlu-ob8** finished all 10 epochs (~21:34 PT). Best = **epoch 10** shared-val **0.008582** (bar n128-screlu-a 0.008713, −1.5%). Export `nets/n128-screlu-ob8/net_v3.nnue` act=1 NB=8 size 201012 md5 **2861fb6f**a46a6f68fcee7b428c533589; net_best.pt md5 **61378b50**. Log `logs/train_n128-screlu-ob8.log`. **Needs Coder** screlu2ob8 path for real parity+bench (`dist-cand-screlu2ob8-1745` currently has a 394768-byte placeholder net). Box slot **idle**, load ~2.5 — awaiting Strategist next ablation. No second box train started.
- **GPU n256-screlu-c** (from prior ~21:28): select forge holdout; see PC check this hour.
- **Next GPU (queued, not launched): n256-forgeall-ob8** H256 act=0 NB=8 from d0e1c9f0, select forge holdout.
- No fastchess. No baseline edits. All UNPROVEN.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n128-screlu-ob8 | 2026-10-15 19:56→~21:34 | data_mix_d40forge | 768->128 x2->8 SCReLU act=1 NB8 | scratch 1e-3 10ep pat2 | best ep10 shared-val **0.008582** (beats 0.008713) | needs screlu2ob8 parity | — | UNPROVEN — DONE; export md5 2861fb6f; send Coder |
| n256-screlu-c (GPU) | 2026-10-15 21:28→ | data40m+forgepgn+forge_holdout | 768->256 SCReLU | warm screlu-a 2e-4 select holdout | ep1 holdout 0.002762 / shared 0.008238 | — | — | UNPROVEN — training (check PC) |
| n256-screlu-b (GPU) | 2026-10-15 19:53→~20:05 | data40m+forgepgn+forge_sp_all | 768->256 SCReLU | warm screlu-a 2e-4 | best ep0 **0.008384** | — | — | FAIL — not packed |

### 2026-10-15 ~22:01 PT — screlu-c DONE + forgeall-ob8 STARTED (all UNPROVEN)
- **n256-screlu-c DONE** ~21:50 PT: 5/5 ep, select=forge holdout. Best = **ep1** holdout **0.002762** (start 0.002909); ep5 holdout 0.002822. Shared (extra) best ~**0.008181**. data40m-val ~0.00841. net_best.pt md5 **d1294716**1a414c02cad4689ae5497b81 (=ep1); net_v3.nnue md5 **ba972c71**fdd5c89e312a0aef491ecc62; ep1.pt md5 da6bfe0b. Not packing yet (SCReLU; games rank nets). Log copied to box `logs/n256-screlu-c-log.json`.
- **GPU started n256-forgeall-ob8** (Strategist queue): `--act 0 --obuckets 8 --init net_ep3_frozen.pt --lr 5e-4 --epochs 8 --select-val 2` (forge holdout) `--keep-last 99 --extra-val forge_sp_all,val_shared`. Launcher `pc_launch\start_n256_forgeall_ob8.ps1`. PIDs **2536**/6328/**4896** Idle Aff=**0xF000** (61440). start val **0.003315** (= lock holdout ref). ep1 underway ~198k pos/s. STOP_nnue absent. D: **167 GB** free.
- **Forge SP**: `selfplay_out\forge_selfplay_004.txt.part` ~325 MB / **~5.03M lines** @ 21:58–22:00 PT (still growing). 001–003 intact. Workers Idle.
- **Box**: idle after n128-screlu-ob8; awaiting Strategist next ablation. Coder needs screlu2ob8 parity on export md5 **2861fb6f**.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n256-screlu-c (GPU) | 2026-10-15 21:28→21:50 | data40m+forgepgn+forge_holdout | 768->256 SCReLU | warm screlu-a 2e-4 select holdout | best ep1 holdout **0.002762**; shared ~0.008181 | needs screlu | — | UNPROVEN — DONE; not packed |
| n256-forgeall-ob8 (GPU) | 2026-10-15 22:00→ | same | 768->256 x2->8 CReLU NB8 | init ep3_frozen 5e-4 8ep select holdout | start holdout **0.003315** | needs CReLU NB8 engine | — | UNPROVEN — training Idle/F000 |
| n128-screlu-ob8 | 2026-10-15 19:56→~21:34 | data_mix_d40forge | 768->128 x2->8 SCReLU NB8 | scratch 1e-3 | best ep10 shared **0.008582** | needs screlu2ob8 | — | UNPROVEN — DONE; md5 2861fb6f |

| n128-screlu-ob4 | H128 SCReLU NB=4, data_mix_d40forge, 10ep lr1e-3 | running (box PID 1311987, nice 19, 4 thr) | bar ob8 shared-val 0.008582 | UNPROVEN |

### n128-screlu-ob4 (FALLBACK for n128-screlu-ob8-wdl) — UNPROVEN
- Started 2026-10-15 ~22:04 PT on the box. Same as n128-screlu-ob8 except --obuckets 4; --patience 99 (full 10 epochs). Threads 4, nice 19, --max-load 4.
- Why fallback: train_ob.py is eval-only (loss on sigmoid(score) only; implicit WDL lambda 0 / "lambda 1.0 eval" in docstring), and the record format (occ,pcs,stm,castle,score,ep,rsv[3]) carries NO game result. convert_forge.py drops the selfplay result; rsv is all 0 in data_mix_d40forge. Forge rows can't be told apart from Lichess rows, so the result blend can't be applied. To do the WDL run: reconvert forge selfplay with result in rsv[0] plus a "has result" flag.
- Code change: train_ob.py now also saves nets/<run>/net_ep{N}.pt every epoch (one line; backup train_ob.py.bak_preob4).
- Selection: shared-val (data_mix_d40forge/val.bin = val_shared), same as ob8. Bar: ob8 best shared-val 0.008582.
- Game-split forge holdout NOT on box: CopyToBox from grok-pc D:\grok-pc-data\forge_holdout\val.bin was refused (outside local-exec root). Score ob8 net_best.pt and the per-epoch ob4 checkpoints on it once it's copied. Caveat: forge rows in data_mix_d40forge probably include holdout games, so holdout scores are contaminated, but ob4 vs ob8 is still apples to apples.

### 2026-10-15 ~22:06 PT — forge holdout on box + score n128-screlu-ob8 / n128-screlu-a (all UNPROVEN)
- **Holdout copied to box**: grok-pc `D:\grok-pc-data\forge_holdout\val.bin` → `C:\Users\Administrator\grok-pc\nnue\forge_holdout\val.bin` (C: had ~42 GB free; wrote only under nnue\) → CopyToBox → `data_forge_holdout/val.bin`. **md5 ok** `325c3f33a7ea0793157b1c3f29e4f830`; n=819894. Did not touch run_*/orch_*/STOP_*/dist-v*.
- **Scored** with `nice -n 19 venv/bin/python eval_multi.py --vals data_forge_holdout --act 1 --max-load 12` (same loss as trainers / score_nets.py; buckets auto from out.weight). Log `logs/score_forge_holdout_ob8_a.json`. Did not disturb n128-screlu-ob4 (PID 1311989 still running).
- **n128-screlu-ob8**: no `net_ep*.pt` on disk (per-epoch save was added later for ob4; only `net_best.pt` + `net.pt`). Both score identical on holdout (best_epoch was 10).
  - `nets/n128-screlu-ob8/net_best.pt` NB8 H128 SCReLU: holdout **0.004415** (3.8s)
  - `nets/n128-screlu-ob8/net.pt` NB8 H128 SCReLU: holdout **0.004415** (3.3s)
- **n128-screlu-a** `net_best.pt` NB1 H128 SCReLU: holdout **0.004326** (3.1s)
- **Contamination caveat**: both nets trained on `data_mix_d40forge` (includes old forge self-play that overlaps holdout games). Holdout scores are **contaminated** for ranking absolute Elo; ok for relative ob4-vs-ob8 once ob4 epochs are scored the same way. Ref: n256-screlu-a holdout on PC was 0.002849 (H256; different arch).
- **Blockers**: none for copy/score. WDL ablation still blocked (no result in records). ob4 holdout scoring deferred until its `net_ep*.pt` exist / run finishes.

### 2026-10-15 ~22:56 PT — n256-forgeall-ob8 DONE + n256-screlu-ob8 STARTED (all UNPROVEN)
- **n256-forgeall-ob8 DONE** 22:37 PT (8/8 ep, select = forge holdout). Best **ep4** holdout **0.002899** (start/lock ref 0.003315*, −12.5%); ep4 data40m 0.008526 (lock 0.008525, flat), forgepgn 0.003308 (lock 0.003692), shared 0.008294. Later epochs beat the lock on data40m: ep7 data40m **0.008459** / holdout 0.002965 / shared 0.008233; ep8 0.008467 / 0.002945 / 0.008239. *Lock and this net share lineage that saw old forge games, so holdout numbers are relative only.
- PC `nets\n256-forgeall-ob8\`: net_v3.nnue (ep4, act 0, NB8) md5 **dc639f3b**92e4caa7fb6ba25462e02e43; net_best.pt md5 d796f832; net_ep1..8.pt kept. Not packed. Needs CReLU NB8 engine support from Coder (Strategist rule: beats lock on data40m → ping Coder). ep7 export can be made on request.
- **GPU started n256-screlu-ob8** 22:55 PT: `--act 1 --obuckets 8 --init nets\n256-screlu-c\net_best.pt (d1294716) --lr 2e-4 --epochs 8 --select-val 2 --keep-last 99 --extra-val forge_sp_all,val_shared`, data data40m+forgepgn+forge_holdout. Launcher `pc_launch\start_n256_screlu_ob8.ps1`. PIDs 8212/14124/8396 Idle Aff 0xF000 (61440) verified x3. Start holdout **0.002762** (= screlu-c best, init exact). ~182k pos/s.
- **Box n128-screlu-ob4**: ep5 shared-val 0.008760 (ob8 bar 0.008582 at ep10); running PID 1311989 nice 19, 4 thr.
- **Forge SP**: 004.part ~397 MB, growing; workers Idle/0xF000. D: 166.9 GB free. STOP_nnue absent.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n256-forgeall-ob8 (GPU) | 2026-10-15 22:00→22:37 | data40m+forgepgn+forge_holdout | 768->256 x2->8 CReLU NB8 | init d0e1c9f0 5e-4 8ep select holdout | best ep4 holdout **0.002899** (lock 0.003315); ep7 data40m **0.008459** (lock 0.008525) | needs CReLU NB8 engine | — | UNPROVEN — DONE; md5 dc639f3b; not packed |
| n256-screlu-ob8 (GPU) | 2026-10-15 22:55→ | same | 768->256 x2->8 SCReLU NB8 | init screlu-c 2e-4 8ep select holdout | start holdout 0.002762 | needs screlu2ob8 | — | UNPROVEN — training Idle/F000 |
| n128-screlu-ob4 (box) | 2026-10-15 22:04→ | data_mix_d40forge | 768->128 x2->4 SCReLU NB4 | scratch 1e-3 10ep | ep5 shared 0.008760 (bar 0.008582) | — | — | UNPROVEN — training |

### 2026-10-15 ~23:08 PT — n256-forgeall-ob8 ep7 exported (UNPROVEN)
- Strategist request: export ep7 too, so Coder can gate both ep4 and ep7. Strategist leans to ep7 if only one gets a slot. Both are on HOLD behind n256screlu.
- Exported with a one-off script, PC `nnue\_export_ep.py`, which uses the same quantization as train_gpu.py (Idle/0xF000, 4 threads). The script reproduces ep4 as dc639f3b exactly.
- PC `nets\n256-forgeall-ob8\net_v3_ep7.nnue` and box `nets/n256-forgeall-ob8/net_v3_ep7.nnue`: GKNN v3, act 0, H256, NB8, 401,972 bytes, md5 **d98e9e93**c3a007a378a6129a5950b678 (box md5 matches PC).

| n256-forgeall-ob8 ep7 | 2026-10-15 23:08 | data40m+forgepgn+forge_holdout | 768->256 x2->8 CReLU NB8 | ep7 of 8, init d0e1c9f0 5e-4 | data40m **0.008459** (lock 0.008525); holdout 0.002965* | needs CReLU NB8 engine | — | UNPROVEN — md5 d98e9e93; not packed; HOLD |

### 2026-10-15 ~23:50 PT — n256-screlu-ob8 DONE (GPU) + n128-screlu-ob4 DONE (box) (all UNPROVEN)
- **n256-screlu-ob8 DONE** 23:33 PT (8/8 ep, select = forge holdout, init screlu-c d1294716, lr 2e-4). Best **ep1** holdout **0.002756** (init 0.002762, flat −0.2%); ep1 data40m 0.008425, forgepgn 0.003152, forge_sp_all 0.002630, shared 0.008191. Later epochs drift up on holdout but improve data40m/shared: **ep7** holdout 0.002823, data40m **0.008323** (lock 0.008525), forgepgn 0.003197, shared **0.008095**; ep8 0.002814 / 0.008326 / 0.008097. vs forgeall-ob8 (CReLU): better on every set.
- Exports (GKNN v3, act 1, H256, NB8, 401,972 B): ep1 `net_v3.nnue` (box copy `net_v3_ep1.nnue`) md5 **d4ddc9e4**59c30ab4a64cb9e6953134bd; ep7 `net_v3_ep7.nnue` md5 **5877e14c**78e10b06252a3eeff75ad88a. ep7 made with PC `nnue\_export_ep_act.py` (= _export_ep.py + act arg); it reproduces ep1 d4ddc9e4 exactly. net_best.pt md5 795b27de. Box md5s match PC.
- **n128-screlu-ob4 DONE** 23:32 PT (box, 10/10 ep): best ep10 shared-val **0.008651**, worse than n128-screlu-ob8 (0.008582) → ob8 > ob4 at H128. `nets/n128-screlu-ob4/net_v3.nnue` act 1 NB4. Not for packing.
- GPU and box slot now idle. Strategist queue: WDL reconvert (result + has-result flag, new files) → H256 WDL warm from best screlu.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n256-screlu-ob8 (GPU) | 2026-10-15 22:55→23:33 | data40m+forgepgn+forge_holdout | 768->256 x2->8 SCReLU NB8 | init screlu-c 2e-4 8ep select holdout | best ep1 holdout 0.002756; ep7 data40m **0.008323** (lock 0.008525), shared 0.008095 | needs screlu2ob8 | — | UNPROVEN — DONE; ep1 d4ddc9e4, ep7 5877e14c; not packed |
| n128-screlu-ob4 (box) | 2026-10-15 22:04→23:32 | data_mix_d40forge | 768->128 x2->4 SCReLU NB4 | scratch 1e-3 10ep | ep10 shared 0.008651 (ob8 0.008582) | — | — | UNPROVEN — DONE; loses to ob8; not packed |

## WDL reconvert + n128-screlu-ob8-wdl — UNPROVEN (started 2026-10-16 ~00:20 PT)
- Result encoding (format-compatible REC rsv bytes): rsv[0] bit0 = has_result; rsv[1] = WHITE-POV result 0=loss 1=draw 2=win; rsv[2]=0. Old files rsv==0 -> score-only. Trainer: result_stm = rsv[1]/2 (white to move) else 1-rsv[1]/2.
- convert_forge_wdl.py (copy of convert_forge.py; dedup key ignores score+rsv; new files only; STOP_nnue-aware).
- data_forgepgn_wdl: train 1,839,067 (md5 a9e54904c6bc132ed1932bfcb4d63f90) / val 18,576 (md5 004df63df12ae3ba1bc09dfc9406b8c5); identical to data_forgepgn except rsv; 100% has_result (W 549,290 / D 823,848 / L 484,505); mean white cp by result -262/+8/+278.
- data_mix_d40forge_wdl: data40m train (score-only, has_result 0) + data_forgepgn_wdl train = 41,379,994 rows (md5 ba18ed19a119c0f3b63744a113b9ac32); identical to data_mix_d40forge except rsv; val = val_shared (7bd6e227...).
- PC: build_forge_holdout_wdl.py -> D:\grok-pc-data\forge_holdout_wdl (same sources/md5, seed fho1, game ids; Idle/F000, STOP_nnue-aware) — IN PROGRESS, stats.json will hold ids_match_old/counts_match_old.
- train_ob.py: --result-w (blend only where has_result), --extra-val, --select; backup train_ob.py.bak_prewdl. Val losses are score-only (comparable to old bars).
- n128-screlu-ob8-wdl: train_ob.py data_mix_d40forge_wdl, H128 act1 ob8 lr1e-3 bs8192 10 ep, --result-w 0.2, select val+holdout, saves net_ep{N}.pt. PID 2251183, log logs/train_n128-screlu-ob8-wdl.log. Bar: shared 0.008582, holdout 0.004415. UNPROVEN.

### 2026-10-16 ~00:51 PT — NNUE hourly (UNPROVEN)
- Lock **1.7.45** net.md5 **d0e1c9f0** (n256forgeall).
- **Box** `n128-screlu-ob8-wdl` PID 2251183 nice19: ep5/10, shared-val **0.008717**, holdout **0.004505**, d40 0.008918 (bars shared 0.008582 / holdout 0.004415 — still above, trending down). Log `logs/train_n128-screlu-ob8-wdl.log`.
- **PC** `forge_holdout_wdl` DONE (ids_match_old/counts_match_old; train.md5 11099aed / val 5f075dc5). Forge SP ~19.0M healthy Idle/F000.
- **GPU idle** since n256-screlu-ob8 DONE 23:33; keep-going restarting H256 WDL warm (port `--result-w` into `train_gpu`, stage forgepgn_wdl/mix on D, launch `n256-screlu-ob8-wdl` Idle/F000 from screlu-ob8 `net_best`). Stale n128-d40-cont cmd ignored (not in queue).
- Pack HOLD unchanged: n256screlu-1745, screlu-ob8 ep7 **5877e14c**, forgeall-ob8 ep4/ep7.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n128-screlu-ob8-wdl (box) | 2026-10-16 ~00:20→ | data_mix_d40forge_wdl | 768->128 x2->8 SCReLU NB8 | scratch 1e-3 rw0.2 select val+holdout | ep5 shared 0.008717 / holdout 0.004505 | — | — | UNPROVEN — training |
| n256-screlu-ob8-wdl (GPU) | 2026-10-16 ~00:51→ | data40m+forgepgn_wdl+forge_holdout_wdl | 768->256 x2->8 SCReLU NB8 | warm screlu-ob8 2e-4 rw0.2 | pending start | needs screlu2ob8 | — | UNPROVEN — launching |


### 2026-10-16 ~02:05 PT — NNUE hourly (UNPROVEN)
- Lock **1.7.45** (d0e1c9f0). Push on (01:36 → ~13:36 PT Fri); QA owns all match slots.
- **Box n128-screlu-ob8-wdl DONE** ~01:49 PT (10/10 ep, rw 0.2, select val+holdout). Best ep10: shared **0.008609**, holdout **0.004555**, d40 0.008804. Bars (n128-screlu-ob8 score-only): shared 0.008582 / holdout 0.004415 → WDL loses on score-only val (expected partly, since rw blends results into the target; only an Elo test can judge WDL). Export `nets/n128-screlu-ob8-wdl/net_v3.nnue` act1 NB8, md5 2086b437. Not packed.
- **GPU lapse**: the 00:51 run logged "launching" but nothing started; GPU was idle 23:33 → 02:00 (~2.5 h). Fixed now.
- Ported `--result-w` into PC `train_gpu.py` (backup `train_gpu.py.bak_prewdl` f18739b8; new md5 6af604d0; box copy `pc_wdl/train_gpu_pc.py`). Blend only where rsv[0]&1; val losses stay score-only. CPU smoke test on box passed.
- Staged `D:\grok-pc-data\forgepgn_wdl` (train a9e54904 / val 004df63d, = box data_forgepgn_wdl).
- **GPU n256-screlu-ob8-wdl STARTED** 02:00 PT, PID 13920 Idle/0xF000: data40m + forgepgn_wdl + forge_holdout_wdl, H256 SCReLU NB8, init n256-screlu-ob8 net_best (ep1 d4ddc9e4), lr 2e-4, 8 ep, rw 0.2, select forge holdout, extra val forge_sp_all + val_shared. Start val 0.002756 (= ep1). ~227k pos/s, ~5 min/epoch. Launcher `start_n256_screlu_ob8_wdl.ps1`, log `logs\n256-screlu-ob8-wdl.log`.
- Box NNUE slot idle; next box ablation awaiting Strategist.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n128-screlu-ob8-wdl (box) | 2026-10-16 00:20→01:49 | data_mix_d40forge_wdl | 768->128 x2->8 SCReLU NB8 | scratch 1e-3 rw0.2 10ep | ep10 shared 0.008609 / holdout 0.004555 (bars 0.008582 / 0.004415) | — | — | UNPROVEN — DONE; loses on score-only val; not packed |
| n256-screlu-ob8-wdl (GPU) | 2026-10-16 02:00→ | data40m+forgepgn_wdl+forge_holdout_wdl | 768->256 x2->8 SCReLU NB8 | warm screlu-ob8 ep1 2e-4 rw0.2 8ep | start 0.002756 | needs screlu2ob8 | — | UNPROVEN — training |

## 2026-10-16 02:10 PT — GPU utilization audit (grok-pc, n256-screlu-ob8-wdl) — UNPROVEN, no change
- 60 s sample: GPU compute ~16-20%, 3D ~0%, VRAM ~1.1-1.3 GB of 20 GB. Total CPU 100%.
- Bottleneck: CPU-side feats()/dense one-hot build in train_gpu.py (torch 2 threads), sharing CPUs 12-15 with Forge self-play's 2 workers (each ~13k CPU-s vs trainer ~316 CPU-s). ~225k pos/s, ~252 s/epoch.
- No GPU temps readable (no AMD tools / sensors exposed) -> no load added. No second job (would exceed 4-thread cap). Running PID 12180 untouched (Idle/F000).
- Proposed fix (next run, not the current one): preload train set + GPU-side featurization, larger batch (bs 32768, lr x2), so the GPU no longer waits on CPU.

### 2026-10-16 ~02:13 PT — Box ablation n128-screlu-ob8-sp (Strategist pick) — UNPROVEN
- Clone of n128-screlu-ob8 (data_mix_d40forge, H128, act=1 SCReLU, NB8, 10ep, lr 1e-3, bs 8192, score-only rw 0, rng seed 0 / torch unseeded as before) with ONE change: each 8192 batch = 4096 base rows (original ob8 mix, contiguous chunks as before) + 4096 rows drawn uniformly at random from the game-split Forge SP **train side** `data_forge_holdout_train/train.bin` (15,272,952 rows, md5 454441d709183ca4f6385c9098cf6de7 = PC D:\grok-pc-data\forge_holdout\train.bin; holdout games excluded). Steps/epoch kept = len(base)//8192 (same compute/schedule as ob8; each epoch sees a random half of the base chunks).
- New train_ob.py options `--sp-data` / `--sp-frac` (backup `train_ob.py.bak_presp`). patience 10 so all 10 epochs run; net_ep{N}.pt saved every epoch.
- Vals every epoch: shared-val (data_mix_d40forge/val.bin, md5 7bd6e227), holdout (data_forge_holdout/val.bin, md5 325c3f33), data40m. Select = shared+holdout. Bar: ob8 shared 0.008582 / holdout 0.004415.
- No newer SP positions added (would need holdout-id-filtered reconvert of the fresh snapshot; not done).
- Cmd: `run_n128_sp.sh` (nice 19, TZ LA, max-load 4), PID 3181723, log `logs/train_n128-screlu-ob8-sp.log`.

| n128-screlu-ob8-sp | 2026-10-16 02:13→ | data_mix_d40forge + 50% forge_holdout train | 768->128 x2->8 SCReLU NB8 | scratch 1e-3 10ep | bar shared 0.008582 / holdout 0.004415 | — | not tested | UNPROVEN — training PID 3181723 |

## 2026-10-16 02:40 PT — train_gpu2.py (GPU-resident data trainer) + n256-screlu-ob8-wdl final + n256-screlu-ob8-sp launch (all UNPROVEN)
- **train_gpu2.py** (new, grok-pc `nnue\train_gpu2.py`; box copy `gpu2/train_gpu2.py`; train_gpu.py untouched). Records loaded once into VRAM as int16[N,16]; features/shuffle/batching on GPU (DML has no right_shift → floor-div on 16-bit halves). Default bs 32768, lr 2e-3. Adds `--weights` (per-batch share per --data set), `--export-only`, `--parity`. Saves net_ep<N>.pt every epoch.
  - Parity vs train_gpu.py on 8192 rows each of data40m/forgepgn_wdl/forge_holdout_wdl, same net (n256-screlu-ob8 ep1): all 7 feature tensors max diff 0; loss identical (score-only and WDL w=0.2), rel diff 0.0.
  - Export parity: train_gpu2 --export-only and train_gpu.py --epochs 0 on net_ep1.pt → both md5 d4ddc9e459c30ab4a64cb9e6953134bd (= existing _chk_ep1.nnue).
  - Throughput: ~418k pos/s full run (old ~200-245k/s), GPU Engine compute avg 34.2% (min 29, max 37) over 60 s (old ~18%). Remaining limiter: Adam lerp falls back to CPU on DML + per-step sync.
- **n256-screlu-ob8-wdl** (PID 12180, train_gpu.py, rw 0.2, warm n256-screlu-ob8 net_best, lr 2e-4, 8 ep) finished ~02:33 PT. Holdout (select) never beat start 0.002756: ep1 0.003354 … ep8 0.003397. ep7: data40m 0.008279, forgepgn 0.003613, forge_sp_all 0.003238, shared 0.008071. Exported best = epoch 0 = start weights (md5 d4ddc9e4, i.e. no new net). Not packed. Per-epoch nets in nets/n256-screlu-ob8-wdl/net_ep*.pt.
- **n256-screlu-ob8-sp** launched 02:35 PT with train_gpu2.py: score-only (rw 0), warm n256-screlu-ob8 ep1 (d4ddc9e4), lr 4e-4 @ bs 32768, 8 ep, patience 99, batch mix 50% forge_holdout_wdl/train (game-split train side) + 47.7% data40m + 2.3% forgepgn_wdl; select on forge holdout val, also logs data40m, forgepgn, forge_sp_all, val_shared. Newer SP beyond the holdout split NOT included (no game-id-filtered newer file exists yet). PIDs cmd 7860 → venv py 4492 → python 11768, all Idle / affinity 0xF000. Log logs\train_n256-screlu-ob8-sp.log. ~135 s/epoch (~20 min total).

## 2026-10-16 ~02:56 PT — NNUE hourly (all UNPROVEN)
- **n256-screlu-ob8-sp (GPU, train_gpu2.py) DONE** 02:52 PT. Score-only, warm n256-screlu-ob8 ep1 (d4ddc9e4), lr 4e-4 bs 32768, 8 ep, 50% forge_holdout_wdl train side. Best = ep7: forge holdout val 0.002325 (start 0.002756, -16%), shared 0.008360 (n256-screlu-ob8 ep7 was 0.008095, so worse on shared), forge_sp_all 0.002159. ~450k pos/s. Export net_v3.nnue md5 fb2d5425904bc7ae32facf75c626a3c1 (act 1 NB8, grok-pc nets\n256-screlu-ob8-sp\). Not packed. Mixed signal: big holdout gain, shared-val loss.
- grok-pc: train_gpu3.py (GPU-side Adam) optimizer parity PASS (loss maxrel 2.3e-7). forge_sp_new_train built: 6,911,538 rows, holdout leaks 0, md5 4493f1e3. Smoke run smoke_g3_32k (train_gpu3, warm sp ep7, 4 sets incl. sp_new) running at ~545k pos/s, Idle/0xF000.
- Box n128-screlu-ob8-sp PID 3181723 at ep4: shared 0.009228 / holdout 0.002403 (bar 0.008582 / 0.004415): holdout well past bar, shared still behind; ETA ~03:35 PT.

| n256-screlu-ob8-sp (GPU) | 2026-10-16 02:35→02:52 | data40m + forge_holdout_wdl train 50% + forgepgn_wdl | 768->256 x2->8 SCReLU NB8 | warm 4e-4 bs32k 8ep score-only | ep7 holdout 0.002325 / shared 0.008360 | needs screlu2ob8 | — | UNPROVEN — DONE, md5 fb2d5425, not packed |

## 2026-10-16 03:05 PT — grok-pc GPU (all UNPROVEN)
- **n256-screlu-ob8-sp** (PID 11768, train_gpu2, done 02:54 PT): warm d4ddc9e4 (n256-screlu-ob8 ep1), 50% forge_holdout_wdl train + data40m/forgepgn, score-only, 8 ep, lr 4e-4, select holdout.
  Per epoch (holdout / data40m / shared / forge_sp_all[contam]): start 0.002756 | ep1 0.002383/0.008658/0.008401/0.00224 | ep2 0.002355/0.008661/0.008404 | ep3 0.002336/0.008628/0.008371 | ep4 0.002334/0.008628/0.008371 | ep5 0.002326/0.008620/0.008363 | ep6 0.002328/0.008616/0.008359 | **ep7 0.002325/0.008617/0.008360 (best)** | ep8 0.002326/0.008615/0.008358.
  Export ep7 net_v3.nnue md5 fb2d5425904bc7ae32facf75c626a3c1 (pt 73a460a4…). Note: holdout drop partly reflects 50% same-source SP data; shared 0.008360 vs screlu-ob8 ep7 0.008095 shared is WORSE on shared. Not packed.
- **forge_sp_new_train** (D:\grok-pc-data\forge_sp_new_train, build_forge_sp_new.py): 004 rows past snap + 005.part snapshot, same game-boundary ids; 6,911,538 rows, WDL rsv (all has_result), md5 4493f1e34b2f4e38bf9cfaae6c1e12c9; 83,846 new games, holdout games excluded 0 (0 overlap), leak/dup/already-in-train dropped 0. val.bin = dummy 16k rows of train (not a holdout).
- **train_gpu3.py**: copy of train_gpu2 with on-GPU hand-written Adam (GAdam). Parity vs torch Adam CPU, 50 steps, fixed 8192-row batch, H256 SCReLU ob8, lr 1e-3: weights maxrel 3e-6..2.4e-5 (ft; ≤5e-6 of elements >1e-5), loss maxrel ≤2.4e-7 → PASS (one early run showed 2.2e-3 on isolated ft elements: Adam sign-noise on ~0 grads).
  Throughput (DML compute util): gpu2 bs32k 450k pos/s ~31%; gpu3 bs32k 550k ~44%; bs64k 559k ~40%; bs128k 538k ~37%.
- **n256-screlu-ob8-sp2** started 03:01 PT, train_gpu3 bs32768 lr 4e-4, warm sp ep7, weights data40m .477 / forgepgn .023 / forge_holdout_wdl .344 / forge_sp_new_train .156, score-only, 8 ep, select holdout, logs all vals. python PID 13768 (parent 11432, cmd 7844) Idle/0xF000. 60 s util avg 45.8% (34–48), ~590k pos/s. ETA ~03:25 PT.

- 2026-10-16 ~03:10 PT **n256-screlu-ob8-sp25** — UNPROVEN, training on PC GPU concurrently with sp2 (PID 13768). Script train_gpu3s.py (= train_gpu3 + `--select-add`; select metric = forge_holdout_wdl val + val_shared, summed). Warm from nets\n256-screlu-ob8\net_ep7.pt (export 5877e14c); score-only rw 0; bs 32768, lr 4e-4, 8 ep, every epoch saved; mix data40m 0.70 / forgepgn_wdl 0.05 / forge_holdout_wdl 0.17 / forge_sp_new_train 0.08; --chunk 3000000. PID 13560 (child 13796) Idle, 0xF000. ep1: holdout 0.002832, shared 0.008117, data40m val 0.008348 (ep7 reference: shared 0.008095). Combined GPU util ~87% vs ~42% for sp2 alone.

### 2026-10-16 ~03:56 PT — NNUE hourly (all UNPROVEN)
- Lock **1.7.46** (same net.md5 **d0e1c9f0** as 1.7.45). Push on until ~13:36 PT Fri. Box rebooted ~03:37 PT (uptime was ~15–18 min at check); NNUE `venv/` was missing and was recreated (torch 2.14.1+cpu).
- **Box n128-screlu-ob8-sp** interrupted at ep9/10 by reboot. Best ep9 shared **0.009078** / holdout **0.002368** / d40 0.009364 (bars shared 0.008582 / holdout 0.004415). Exported `nets/n128-screlu-ob8-sp/net_v3.nnue` md5 **eb0126ed**. Shared much worse → **FAIL, not packed**.
- **GPU n256-screlu-ob8-sp2 DONE** ~03:18: best ep8 holdout **0.002276** / shared **0.008328** / d40 ~0.008586; export md5 **a28bc822**. Shared worse than screlu-ob8 ep7 (0.008095) → not packed.
- **GPU n256-screlu-ob8-sp25 DONE** ~03:38 (finished after thermal stop of concurrent run): select=holdout+shared, data40m-heavy mix. Best ep8 shared **0.008048** (beats screlu-ob8 ep7 **0.008095**), d40 **0.008277**, forge_sp_all 0.002682, implied holdout ~0.002808. Export md5 **4260c1f2**. **Best shared so far among recent H256 SCReLU runs — HOLD for pack once screlu2ob8 path is ready; not packed this hour.**
- **GPU was idle**; idle temps ~GPU 47 / memJ 70 / hotspot ~50–54. Thermal guard PID 1800 + HWiNFO alive. STOP_nnue absent. Started **one** job `n256-screlu-ob8-sp25c` PIDs **13908/8600** Idle/F000 (warm sp25, lr 2e-4, weights 0.65/0.05/0.15/0.15, select-add shared). No second job (memJ hits ~89–90 under one trainer).
- Forge SP healthy Idle/0xF000 ~**22.88M** pos @ ~1.27M/h. D: **165.5 GB** free.
- Box NNUE slot idle (load ~2.8); awaiting Strategist next ablation after SP FAIL.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n128-screlu-ob8-sp (box) | 2026-10-16 02:13→~03:35 | mix + 50% forge_holdout train | 768->128 x2->8 SCReLU NB8 | scratch 1e-3 9/10 ep | ep9 shared 0.009078 / holdout 0.002368 | — | — | UNPROVEN — FAIL shared; md5 eb0126ed; not packed |
| n256-screlu-ob8-sp2 (GPU) | 2026-10-16 03:01→03:18 | data40m+holdout+sp_new | 768->256 x2->8 SCReLU NB8 | warm sp ep7 4e-4 bs32k | ep8 holdout 0.002276 / shared 0.008328 | needs screlu2ob8 | — | UNPROVEN — DONE; md5 a28bc822; not packed |
| n256-screlu-ob8-sp25 (GPU) | 2026-10-16 03:10→03:38 | data40m 0.70 + SP mix | 768->256 x2->8 SCReLU NB8 | warm ob8 ep7 4e-4 select-add shared | ep8 shared **0.008048** / d40 0.008277 | needs screlu2ob8 | — | UNPROVEN — DONE; md5 4260c1f2; HOLD pack |
| n256-screlu-ob8-sp25c (GPU) | 2026-10-16 ~03:59→ | warm sp25; 0.65/0.05/0.15/0.15 | 768->256 x2->8 SCReLU NB8 | lr 2e-4 8ep select-add shared | training | needs screlu2ob8 | — | UNPROVEN — RUNNING PIDs 13908/8600 Idle/F000 |


### 2026-10-16 ~04:02 PT — Box ablation n128-screlu-ob8-sp15 (Strategist pick) — UNPROVEN
- Clone of n128-screlu-ob8 / run_n128_sp.sh with ONE change: `--sp-frac 0.15` (was 0.5). Same: data_mix_d40forge, H128, act=1 SCReLU, NB8, 10ep, lr 1e-3, bs 8192, score-only rw 0, patience 10, select val+holdout, extra-val holdout+data40m. SP train side `data_forge_holdout_train/train.bin` md5 **454441d7**. Per batch 6963 base + 1229 sp. Bar: shared 0.008582.
- Preflight after ~03:37 reboot: venv recreated (torch 2.14.1+cpu); installed `chess` for signcheck; data md5s OK (sp-train 454441d7, mix train 2b43322b, mix/shared val 7bd6e227). Load at start ~3.2 (<4).
- Cmd: `run_n128_sp15.sh` (nice 19, TZ LA, max-load 4), PID **54326**, log `logs/train_n128-screlu-ob8-sp15.log`. Out `nets/n128-screlu-ob8-sp15`. Every epoch saved.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n128-screlu-ob8-sp15 | 2026-10-16 04:02→ | data_mix_d40forge + 15% forge_holdout train | 768->128 x2->8 SCReLU NB8 | scratch 1e-3 10ep | bar shared 0.008582 | — | not tested | UNPROVEN — training PID 54326 |

### 2026-10-16 03:20–03:36 PT — backfill (missing entry) — UNPROVEN
- sp2 (n256-screlu-ob8-sp2) md5 a28bc822: holdout 0.002276 / shared 0.008328 — not packed. UNPROVEN.
- Thermal guard started, PID 1800 (trips hot spot 88 / mem junction 94 / edge 82).
- sp25 (n256-screlu-ob8-sp25) md5 4260c1f2: shared 0.008048 / d40 0.008277. UNPROVEN.
- One-job GPU temps: edge 65 / hot spot 74 / mem junction 89–90 °C → over the ≤88 mem-junction bar for a second job, so the second job was stopped.

### 2026-10-16 ~04:09 PT — PACK n256-screlu-ob8-sp25 on 1.7.46 — UNPROVEN
- Dist: `/workspace/chess-engine-nnue/dist-cand-n256sp25-1746` = copy of Coder's `chess-engine/dist-cand-n256fob8e7-1746` (screlu2ob8 patch f56faaa3), only net.nnue replaced (nnue.js loads `<dist>/net.nnue`; no embedded net).
- net.nnue md5 **4260c1f24c50712efbf39129154956ea** (GKNN v3 act=1 NB8, from nets/n256-screlu-ob8-sp25/net_v3.nnue). js-tree md5 (sorted *.js) **0db67462** = identical to Coder's dir; lock 1.7.46 js-tree 654484ce, net d0e1c9f0.
- Gates (nice 19, TZ LA, CPUs 0-7; log chess-engine-nnue/gates_sp25_1746.log): perft PASS, movegen 36/36, tactics 6/6, mate suite ALL PASS, mate_distance 5/5 PASS, uci_edge 27/27, draw_rules PASS, insufficient_material 5 FAIL all KNOWN, ep_repetition 1 FAIL KNOWN, label sign PASS. Fuzz/TL/krk of bug_gate.sh NOT run (they use fastchess) — QA to do.
- Bench d9: 167895 nodes, ~281k NPS vs lock 220563 nodes, ~354k NPS (−20.6% NPS; 2 runs each, load ~4).

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n256-screlu-ob8-sp25 → dist-cand-n256sp25-1746 | 2026-10-16 04:09 | data40m 0.70 + SP mix | 768->256 x2->8 SCReLU NB8 | warm ob8 ep7 4e-4 | shared 0.008048 / d40 0.008277 | −20.6% (bench d9) | not tested | UNPROVEN — PACKED, gates PASS (fuzz pending QA) |
- **ep1–8** (still training PID 54326): ep1 shared 0.009444 / holdout 0.003597; ep8 shared **0.008667** / holdout **0.003321** / data40m **0.008902** (bar shared 0.008582). Still above bar; ETA ~2 ep.

### 2026-10-16 ~04:54 PT — NNUE hourly — UNPROVEN
- Lock **1.7.46** (net **d0e1c9f0**). Push until ~13:36 PT Fri. STOP_nnue absent (box+PC).
- **GPU n256-screlu-ob8-sp25c DONE** ~04:14: warm sp25, lr 2e-4, weights 0.65/0.05/0.15/0.15. Shared stuck ~0.008076–0.0081; best export was **epoch 0** (init). net_v3.nnue md5 **4260c1f2** (= sp25, no new weights). **FAIL improve, not packed.**
- **GPU was idle** at check; idle HWiNFO ~04:56: GPU edge **45** / memJ **66** / hotspot **47** °C. D: **165.4 GB** free. Forge SP still running (selfplay_guard + forge_selfplay workers). Thermal guard/HWiNFO up.
- Started **one** next job **n256-screlu-ob8-sp80** (warm sp25, weights 0.80/0.05/0.10/0.05 data40m-heavy, lr 3e-4, 8ep, select-add shared). No second job.
- Box **n128-screlu-ob8-sp15** ep9 shared **0.008660** / holdout 0.003289 (bar 0.008582), load ~3.6, nice 19, 1 ep left. Packed cand still `dist-cand-n256sp25-1746` (4260c1f2, gates PASS, bench −20.6% NPS) awaiting Profiler/QA. All UNPROVEN.
- **GPU n256-screlu-ob8-sp80** launched ~04:57 PIDs **10812/12016**; under load temps ~GPU 53 / memJ 78 / hotspot 60.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n256-screlu-ob8-sp25c (GPU) | 2026-10-16 03:59→04:14 | 0.65/0.05/0.15/0.15 | 768->256 x2->8 SCReLU NB8 | warm sp25 2e-4 8ep | shared ~0.008076 (best ep0=sp25) | — | — | UNPROVEN — FAIL improve; md5 4260c1f2 (=sp25); not packed |
| n256-screlu-ob8-sp80 (GPU) | 2026-10-16 ~04:57→ | 0.80/0.05/0.10/0.05 | 768->256 x2->8 SCReLU NB8 | warm sp25 3e-4 8ep | training | needs screlu2ob8 | — | UNPROVEN — RUNNING PIDs 10812/12016 Idle/F000 |
| n128-screlu-ob8-sp15 (box) | 2026-10-16 04:02→ | mix + 15% forge_holdout | 768->128 x2->8 SCReLU NB8 | scratch 1e-3 | ep9 shared 0.008660 / holdout 0.003289 | — | — | UNPROVEN — training PID 54326; above bar 0.008582 |

### 2026-10-16 ~05:10 PT — n128-screlu-ob8-sp15 DONE (UNPROVEN)
- Finished 10/10 epochs. Best shared-val **0.008647** (ep10) vs bar **0.008582** (n128-screlu-ob8) → **MISSED** (+0.75%). ep10 holdout/data40m in log. Export nets/n128-screlu-ob8-sp15/net_v3.nnue (selected on val+holdout, ep10). SP-share series done at H128. Not packing. UNPROVEN.
- **Launched n128-screlu-ob8-cos** (PID 126873, run_n128_cos.sh): original n128-screlu-ob8 command + `--lr-sched cos` (trainer COPY train_ob_cos.py; live train_ob.py default was StepLR(epochs//3, 0.3), not cos). Cosine per-epoch from 1e-3 (1.0x ep1) to 0.05x at ep10. Same epochs/pat2/unseeded; saves every epoch. Added eval-only `--extra-val holdout,data40m` (selection still on shared val). Bar shared 0.008582. UNPROVEN.
- n128-screlu-ob8-cos **ep1** (14:17 PT): shared 0.009347, holdout 0.004621, data40m 0.009570, train 0.010345 (orig ob8 ep1 'val': 0.009370596588364869). UNPROVEN — training PID 126873.

### 2026-10-16 ~05:55 PT — NNUE hourly (all UNPROVEN)
- Lock still **1.7.46** (net **d0e1c9f0**). `baseline/dist-v1.7.47` exists as staged cut candidate (net **5877e14c** = n256-screlu-ob8 ep7) but QUEUE says **not cut yet** (pcE n256screluob8e7 near H1). Push until ~13:36 PT Fri. STOP_nnue absent (box).
- **Box n128-screlu-ob8-sp15 DONE** earlier (~05:10): best shared **0.008647** vs bar **0.008582** → MISSED; export md5 **e5c55b78**. Not packed.
- **Box n128-screlu-ob8-cos RUNNING** PID **126873** nice19 max-load4: ep3 shared **0.008885** / holdout 0.004562 / d40 0.009091 (bar 0.008582). Box load ~5.1–5.5 (QA SPRTs pcsf+ttcuthist2 + cos); trainer self-throttles at max-load 4.
- Packed HOLD unchanged: `dist-cand-n256sp25-1746` net **4260c1f2** shared **0.008048**, js-tree **0db67462** (= staged 1.7.47 / screlu2ob8; ≠ lock 1.7.46 js **654484ce**). Gates PASS earlier; bench −20.6% NPS vs 1.7.46. On a 1.7.47 cut this becomes **net-only** vs lock.
- **GPU n256-screlu-ob8-sp80 DONE** ~05:13 PT: warm sp25, weights 0.80/0.05/0.10/0.05, lr 3e-4, select-add shared. Best ep8 shared **0.007933** (beats sp25 **0.008048** and screlu-ob8 ep7 **0.008095**). Export md5 **248f6fd8**.
- **PACKED** `dist-cand-n256sp80-1746` (js-tree 0db67462 = screlu2ob8 / staged 1.7.47). Gates PASS (insuf 5 + ep 1 KNOWN fails). Bench d9 vs 1.7.46 (load~4.5 noisy): cand 152369 nodes ~263k/221k NPS; lock 220563 ~309k/274k → about **−15% to −19%** NPS (within 25%).
- **GPU n256-screlu-ob8-sp90 RUNNING** PIDs 12492/8712 Idle/F000 (warm sp80, weights 0.90/0.03/0.05/0.02, lr 2.5e-4). Forge SP up. STOP_nnue absent. D:~165 GB. Temps idle-ish at launch.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n128-screlu-ob8-sp15 (box) | 2026-10-16 04:02→~05:10 | mix + 15% forge_holdout | 768->128 x2->8 SCReLU NB8 | scratch 1e-3 10ep | best shared **0.008647** (bar 0.008582) | — | — | UNPROVEN — DONE MISSED; md5 e5c55b78; not packed |
| n128-screlu-ob8-cos (box) | 2026-10-16 ~05:10→~07:00 | data_mix_d40forge | 768->128 x2->8 SCReLU NB8 | scratch 1e-3 cos 10ep | best ep10 shared **0.008480** (holdout 0.004486, data40m 0.008675) | — | — | UNPROVEN — DONE; beats n128 bar 0.008582 (vs ob8 step-LR); cos helps at H128 |
| n256-screlu-ob8-sp80 (GPU) | 2026-10-16 04:57→05:13 | 0.80/0.05/0.10/0.05 | 768->256 x2->8 SCReLU NB8 | warm sp25 3e-4 8ep | shared **0.007933** | −15..−19% (noisy) | not tested | UNPROVEN — PACKED dist-cand-n256sp80-1746 md5 248f6fd8 |
| n256-screlu-ob8-sp90 (GPU) | 2026-10-16 ~05:58→ | 0.90/0.03/0.05/0.02 | 768->256 x2->8 SCReLU NB8 | warm sp80 2.5e-4 8ep | training | needs screlu2ob8 | — | UNPROVEN — RUNNING Idle/F000 |

### 2026-10-16 ~06:00 PT — PACK n256-screlu-ob8-sp80 on screlu2ob8 JS — UNPROVEN
- Dist: `/workspace/chess-engine-nnue/dist-cand-n256sp80-1746` = copy of sp25 cand tree, net replaced.
- net.nnue md5 **248f6fd830c7f953aaf775cc0c8518c5** (GKNN v3 act=1 NB8). Shared-val **0.007933** (best recent H256).
- Gates (nice 19, TZ LA; log gates_sp80_1746.log): perft PASS, movegen PASS, tactics PASS, mate suite ALL PASS, mate_distance 5/5, uci_edge 27/27, draw_rules PASS, insufficient_material 5 FAIL KNOWN, ep_repetition 1 FAIL KNOWN. No fastchess.
- Bench d9 (bench.js, 2 runs, load~4.5): cand nodes 152369 nps ~263k/221k; lock 1.7.46 nodes 220563 nps ~309k/274k. NPS loss ~15–19% (bar 25%). Profiler ABBA still needed.
- Vs lock 1.7.46 this is **code+net** (js 0db67462 ≠ 654484ce). If QA cuts 1.7.47 (net 5877e14c on same JS), this becomes **net-only**.


### 2026-10-16 ~06:56 PT — NNUE hourly (all UNPROVEN)
- Lock **1.7.47** (baseline/dist-v1.7.47, net **5877e14c** = n256-screlu-ob8 ep7, js 0db67462). QA queue mentions an upcoming "accroot" lock for [0,10]; not cut on disk yet. Push until ~13:36 PT Fri. STOP_nnue absent (box + PC).
- **GPU n256-screlu-ob8-sp90 DONE** 06:12 PT (warm sp80, weights 0.90/0.03/0.05/0.02, lr 2.5e-4, 8 ep, gadam, ~560-640k pos/s). Shared-val ep1 0.007897 → ep7/ep8 **0.007851** (beats sp80 **0.007933**, −1.0%). forge_sp_all extra-val drifted up 0.003479 (ep1) → 0.003558 (ep8) — watch: shared gain may trade off self-play-style positions. Export (ep8 best val+shared) net_v3.nnue md5 **d1e821d4** (d1e821d427a87a9f9cb6ea3d2b59900f), 401972 B. Copied to box nets/n256-screlu-ob8-sp90/.
- **PACKED** `/workspace/chess-engine-nnue/dist-cand-n256sp90-1747` = cp -rp dist-v1.7.47 + net replaced; diff vs lock = net.nnue only. Gates running (gates_sp90_1747.sh/.log).
- GPU sat idle 06:12→06:58 (~45 min gap between hourly runs). **GPU n256-screlu-ob8-sp95 RUNNING** from 06:58 PT, PIDs 12064/5772 Idle/F000 (warm sp90, weights 0.95/0.01/0.03/0.01, lr 2e-4, 8 ep; start_n256_screlu_ob8_sp95.ps1). ~630k pos/s. HWiNFO running.
- **Box n128-screlu-ob8-cos** PID 126873 ep8 shared **0.008513** (beats H128 bar 0.008582, −0.8%) / holdout 0.004532 / d40 0.008706. H128 only; not a candidate vs H256 lock (info for H128/SMP-speed fallback). Load ~3.9.
- KB/HM spec written (KB_HM_SPEC.md, GKNN v4) and kbtest/ lock_kb1/kb4/kb4hm test files exist; no KB net trained yet.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n256-screlu-ob8-sp90 (GPU) | 2026-10-16 05:58→06:12 | 0.90/0.03/0.05/0.02 | 768->256 x2->8 SCReLU NB8 | warm sp80 2.5e-4 8ep | shared **0.007851** | net-only (same JS) | not tested | UNPROVEN — PACKED dist-cand-n256sp90-1747 md5 d1e821d4 |
| n256-screlu-ob8-sp95 (GPU) | 2026-10-16 06:58→ | 0.95/0.01/0.03/0.01 | 768->256 x2->8 SCReLU NB8 | warm sp90 2e-4 8ep | training | — | — | UNPROVEN — RUNNING Idle/F000 |
| n128-screlu-ob8-cos (box) | 2026-10-16 ~05:10→ | data_mix_d40forge | 768->128 x2->8 SCReLU NB8 | scratch 1e-3 cos 10ep | ep8 shared 0.008513 | — | — | UNPROVEN — RUNNING PID 126873 |
- **sp90-1747 gates** (07:00 PT, nice 19, gates_sp90_1747.log): perft PASS, movegen PASS, tactics PASS, mate suite ALL PASS, mate_distance 5/5 ALL PASS, draw_rules PASS, uci_edge 27/27, insufficient_material 5 FAIL KNOWN (same as lock/sp80), ep_repetition 1 FAIL KNOWN. No fastchess.
- Bench d9 H16 (research/prof1746_sp25/bench_hash.js, 2 runs, load ~4): sp90 nodes 189762, 298k/327k NPS; sp80-1747 152394, 295k/302k; lock 1.7.47 219395, 346k/334k. Same JS as lock, so the gap is net-shaped search only: about −5% to −14% NPS (bar 25%). UNPROVEN.
| n256-screlu-ob8-hm (box) | 2026-10-16 07:2x→ | data_mix_d40forge | 768->256 x2->8 SCReLU NB8, HM=1 KB=1 (v4) | warm sp90 v3 (d1e821d4) via train_kb2.py --init-v3, 3e-4 cos 8ep, pat 3 | start val 0.010439 (unmirrored init); ep1 (791 s) val 0.008259, holdout 0.004330, data40m 0.008447 — data_mix val, NOT the shared-val metric of sp90 0.007851; score with val_shared before comparing | — | — | UNPROVEN — RUNNING PID 261254 (run_n256_hm.sh, logs/train_n256-screlu-ob8-hm.log) |
- **train_kb2.py** (07:2x PT) = train_kb.py + `--init-v3` (dequant GKNN v3/v4: ft/QA, out_w/QB, out_b/(QA*QB)) + `--lr-sched cos` (train_ob_cos.py lambda). test_initv3.py: float dequant vs ref_eval_v4 on 20 FENs, max |diff| 0.98 cp PASS. UNPROVEN.
- **gpu2/train_gpu3kb.py** = grok-pc train_gpu3s.py + --hm/--kbuckets (dense GPU kbx(), KB_HM_SPEC math) + --init-v3 + --lr-sched cos + v4 export when KB>1/HM. gpu2/test_gpu3kb_feats.py (box CPU, 4000 rows): features identical to train_kb.py for kb1/kb1hm/kb4/kb4hm (maxdiff 0). NOT copied to / launched on grok-pc; queued after sp95. UNPROVEN.

### 2026-10-16 ~07:55 PT — NNUE hourly (all UNPROVEN)
- Lock **1.7.47** (net 5877e14c) is still the newest baseline on disk. Push until ~13:36 PT Fri. STOP_nnue absent (box + PC). Box load ~4.3 (QA matches); box trainer self-throttles at max-load 4.
- **GPU n256-screlu-ob8-sp95 DONE** 07:12 PT (warm sp90, weights 0.95/0.01/0.03/0.01, lr 2e-4, 8 ep, ~645k pos/s). Shared-val ep1 0.007853 → ep7/ep8 **0.007822** (−0.4% vs sp90 0.007851), BUT forge_sp_all extra-val **0.003871 → 0.003961** (sp90 was 0.00348–0.00356, ~+11% worse). Export ep8 net_v3.nnue md5 **9126db97** (9126DB97EB571D9F131AF2A32113DB84), on PC nets\n256-screlu-ob8-sp95\. **NOT PACKED**: tiny shared gain bought with a clear regression on self-play-style positions; data40m weighting looks saturated. sp90 (d1e821d4) stays the best packed candidate.
- GPU idle 07:12 → 07:52 PT (~40 min gap again between hourly runs).
- **GPU n256-screlu-ob8-hmg RUNNING** from 07:52 PT, PIDs 7516/12180 Idle/F000 (start_n256_screlu_ob8_hmg.ps1). Trainer train_gpu3kb.py md5 743ca859 copied from box gpu2/ (base train_gpu3s.py md5 a4db22e6 identical box/PC). HM=1 KB=1, --init-v3 sp90 net_v3 (d1e821d4), sp90 weights 0.90/0.03/0.05/0.02, lr 3e-4 cos, 8 ep. DML falls back to CPU for addmv (king-square calc) → ~375k pos/s, ~23 min, ETA ~08:16 PT. Start val 0.0211 (unmirrored init). ep1 shared **0.007853**, forge_sp_all **0.003871**.
- **Box n256-screlu-ob8-hm** PID 261254 (train_kb2.py, same idea on box data_mix): ep1 val 0.008259 → ep2 **0.008116** (data_mix val; eval_checkpoint.py can't score HM/ob8 on shared, so GPU hmg gives the comparable shared number). ~13–14 min/epoch, ETA ~09:10 PT.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n256-screlu-ob8-sp95 (GPU) | 2026-10-16 06:58→07:12 | 0.95/0.01/0.03/0.01 | 768->256 x2->8 SCReLU NB8 | warm sp90 2e-4 8ep | shared **0.007822**; forge_sp_all 0.003961 (worse) | — | not tested | UNPROVEN — DONE, NOT PACKED (self-play regression); md5 9126db97 |
| n256-screlu-ob8-hmg (GPU) | 2026-10-16 07:52→ | 0.90/0.03/0.05/0.02 | 768->256 x2->8 SCReLU NB8 HM=1 KB=1 (v4) | init-v3 sp90, 3e-4 cos 8ep | ep1 shared 0.007853 | needs HM JS | — | UNPROVEN — RUNNING Idle/F000 |
| n256-screlu-ob8-hm (box) | 2026-10-16 07:2x→ | data_mix_d40forge | as above | init-v3 sp90, 3e-4 cos 8ep | ep2 mix-val 0.008116 | needs HM JS | — | UNPROVEN — RUNNING PID 261254 |

## n256-screlu-ob8-kb4hm (grok-pc GPU) — QUEUED 2026-10-16 07:56 PT, UNPROVEN
- Chain: grok-pc nnue\chain_kb4hm.ps1, PID 14156 (Idle, aff 0xF000). Waits for hmg python exit (60 s poll), then STOP_nnue + one-GPU-job + temps (hot spot <=80, mem jct <=88) check.
- Cmd: hmg settings (train_gpu3kb.py md5 743ca859, H256 screlu ob8, 8 ep, cos lr 3e-4, weights 0.90,0.03,0.05,0.02, select-add val_shared, keep every epoch) + --kbuckets 4 --hm.
- Init: hmg net_v4.nnue via --init-v3 (load_v3 reads v4; KB1 FT repeated into 4 buckets) -> else hmg net_best.pt via --init -> else sp90 net_v3 with --hm.
- Status: nnue\chain_kb4hm.status; done-marker nnue\chain_kb4hm.done (STARTED ... pids=... or STOPPED). Log logs\n256-screlu-ob8-kb4hm.log.
- hmg at queue time: ep1/8 done, shared 0.008323, sp_all 0.003737 (select val 0.016846); ETA ~08:16 PT.

### 2026-10-16 ~08:20 PT — GPU n256-screlu-ob8-hmg DONE (UNPROVEN)
- Finished 08:14:49 PT (8/8 ep; best = ep8). train 0.007614. **shared val 0.007983** (ep7 0.007986) vs sp90 **0.007851** → **+1.7% WORSE**. Holdout (forge_holdout_wdl) 0.003806; forge_sp_all 0.003694 (sp90 ~0.00348–0.00356, worse); forge_sp_new_train val 0.003625; forgepgn_wdl 0.003884; selection val 0.016157. Shared curve ep1→8: 0.008323, 8161, 8086, 8041, 8012, 7995, 7986, 7983 (still falling slowly). Note: the 07:55 entry "ep1 shared 0.007853" was wrong; ep1 shared was 0.008323.
- net_v4.nnue md5 **d86d7faf**8056a837287b126f6005d9e3, 401980 B; header GKNN v4 H256 NB8 act1(SCReLU) KB1 HM1. Box copy nets/n256-screlu-ob8-hmg/net_v4.nnue.
- ref_eval_v4.py 5 FENs: startpos w 14 / b 14, Italian-ish 14, KPK 33, Q-up 1320 (sane). parity.js on dist-cand-v4load-1747: refresh 0/300 mismatches, inc 2386 evals 0/0/0 mism (1525 king moves, 170 mirror crossings, 731 rank crossings) — PASS (results_hmg.json).
- Verdict: does NOT beat sp90 on shared or self-play val; not a pack candidate. sp90 stays best.
- kb4hm chain: hmg exited 08:15:08, temps hs67 mj83 OK, init hmg net_v4.nnue; **kb4hm STARTED 08:15:28 PIDs 2396,7028** (start val 0.016255). chain_kb4hm.done = STARTED.

| n256-screlu-ob8-hmg (GPU) | 2026-10-16 07:52→08:15 | 0.90/0.03/0.05/0.02 | 768->256 x2->8 SCReLU NB8 HM=1 KB=1 (v4) | init-v3 sp90, 3e-4 cos 8ep | shared **0.007983** (sp90 0.007851, +1.7% worse); sp_all 0.003694 | needs v4load | not tested | UNPROVEN — DONE, NOT PACKED; md5 d86d7faf |
| n256-screlu-ob8-kb4hm (GPU) | 2026-10-16 08:15→ | same | KB4 HM1 v4 | init hmg v4, 3e-4 cos 8ep | start sel-val 0.016255 | needs v4load | — | UNPROVEN — RUNNING PIDs 2396,7028 |

### 2026-10-16 ~08:50 PT — NNUE hourly (all UNPROVEN)
- Lock **1.7.48** (net **5877e14c**, same as 1.7.47). Push until weekly usage hits 100%. STOP_nnue absent (box + PC). Box load ~3.5.
- Progress since ~07:55: **hmg DONE** shared **0.007983** (+1.7% vs sp90 0.007851) → NOT packed (md5 **d86d7faf**). kb4hm chain started 08:15 after temps OK.
- **GPU n256-screlu-ob8-kb4hm RUNNING** ep8 (~1000/1939 at check), PIDs 2396/7028 Idle/F000, ~230k pos/s. Shared ep1→7: 0.007746 → 0.007635 → 0.007575 → 0.007537 → 0.007509 → 0.007491 → **0.007481** (**beats sp90 0.007851 by ~4.7%**). forge_sp_all ~0.00373→0.00380 (sp90 ~0.00348–0.00356, slightly worse). Temps Edge63 HotSpot71 MemJ88 — stay one GPU job (MemJ at second-job ceiling). ETA ~08:55 PT.
- **Box n256-screlu-ob8-hm** PID 261254 ep6/8, best mix-val **0.007933** (data_mix; not shared-val). ETA ~09:15.
- Best packed still **sp90** md5 **d1e821d4** at `dist-cand-n256sp90-1747`. Plan: on kb4hm finish, if ep8 shared still beats sp90, pack net-only with `dist-cand-v4load-1747` JS (md5 459ab123) → `chess-engine-nnue/dist-cand-kb4hm-1748`, gates, then QA. pilot_r2 still datagen-only (lock+progress.log) — not ready to consume.
- Need from Couns: nothing. Need from crew: QA keep testing sp90 net-only vs 1.7.48; after pack, kb4hm+v4load as next net-only.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n256-screlu-ob8-kb4hm (GPU) | 2026-10-16 08:15→ | 0.90/0.03/0.05/0.02 | 768->256 x2->8 SCReLU NB8 KB4 HM1 (v4) | init hmg v4, 3e-4 cos 8ep | ep7 shared **0.007481** (sp90 0.007851) | needs v4load | — | UNPROVEN — RUNNING ep8 PIDs 2396/7028 |
| n256-screlu-ob8-hm (box) | 2026-10-16 07:2x→ | data_mix_d40forge | KB1 HM1 v4 | init-v3 sp90, 3e-4 cos 8ep | ep6 mix-val **0.007933** | needs v4load | — | UNPROVEN — RUNNING PID 261254 |


### 2026-10-16 ~10:05 PT — NNUE hourly (all UNPROVEN)
- Lock **1.7.48** (net 5877e14c). STOP_nnue absent. Box load ~5.7 (no box training started).
- **GPU n256-screlu-ob8-kb4hm DONE** 08:54 PT (8/8, best ep8). train 0.006976, **shared val 0.007479** (sp90 0.007851 → **−4.7%**, best so far); forge_sp_all 0.003802 (sp90 ~0.0035, worse); sel-val 0.015125; val_other 0.003892/0.003957/0.003714. net_v4.nnue md5 **9cc41084**392f05b819bb25cef269b2fd, 1581628 B (KB4 HM1 act1 NB8). Box copy nets/n256-screlu-ob8-kb4hm/net_v4.nnue.
- Packed net-only (+ v4load JS) at `/workspace/chess-engine-nnue/dist-cand-kb4hm-1748` = dist-v1.7.48 + dist-cand-v4load-1747 eval/nnue.js (459ab123) + uci/main.js (nnuev2c startup-error info) + kb4hm net. v4 parity kit on the pack: refresh 0/300, inc 2386 evals 0/0/0 mismatches (1525 king moves, 170 mirror, 731 rank crossings) — PASS (v4_parity/results_kb4hm.json). Gates running → gates_kb4hm_1748.log.
- GPU was idle 08:54→10:00 (the 08:50 follow-up didn't happen). **GPU n256-screlu-ob8-kb4hm-sp80 STARTED ~10:00** PIDs 12972/13452 Idle/F000: warm kb4hm net_v4, weights 0.80/0.05/0.10/0.05, lr 1.5e-4 cos, 6 ep, KB4 HM (start script nnue\start_n256_screlu_ob8_kb4hm_sp80.ps1; temps at start hs47 mj66). Goal: keep shared gain and win back forge_sp_all.
- **Box n256-screlu-ob8-hm DONE** ~09:35: best ep8 mix-val 0.007919 (data_mix, not shared-val; holdout 0.004457). net_v4.nnue written (KB1 HM1). Not packed: kb4hm is clearly better on shared val; needs val_shared eval to compare fairly.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n256-screlu-ob8-kb4hm (GPU) | 2026-10-16 08:15→08:54 | 0.90/0.03/0.05/0.02 | 768->256 x2->8 SCReLU NB8 KB4 HM1 (v4) | init hmg v4, 3e-4 cos 8ep | shared **0.007479** (sp90 0.007851); sp_all 0.003802 | gates pending | not tested | UNPROVEN — PACKED dist-cand-kb4hm-1748; md5 9cc41084 |
| n256-screlu-ob8-hm (box) | 2026-10-16 07:2x→09:35 | data_mix_d40forge | KB1 HM1 v4 | init-v3 sp90, 3e-4 cos 8ep | ep8 mix-val 0.007919 | — | — | UNPROVEN — DONE, NOT PACKED |
| n256-screlu-ob8-kb4hm-sp80 (GPU) | 2026-10-16 10:00→ | 0.80/0.05/0.10/0.05 | KB4 HM1 v4 | init kb4hm v4, 1.5e-4 cos 6ep | start sel-val 0.015194 | — | — | UNPROVEN — RUNNING PIDs 12972/13452 |
- ~10:00 PT gates dist-cand-kb4hm-1748 (gates_kb4hm_1748.log): perft OK, movegen 36/36, tactics 6/6, mate_suite OK, mate_distance OK, draw_rules OK, uci_edge 27/27. Known fails same as sp90 pack: insufficient_material 4 (sp90 had 5; KBvKB same colour now passes), ep_repetition 1. Quick bench.js is too small to judge NPS (KB4 FT is 4x larger, 1.58 MB); needs Profiler ABBA vs 1.7.48. UNPROVEN.

### 2026-10-16 ~10:25 PT — GPU idle guard: kb4hm-sp80 DONE, kb4hm-sp70 STARTED (all UNPROVEN)
- **n256-screlu-ob8-kb4hm-sp80 DONE** ~10:18 PT (6/6 ep, best = ep6). train 0.006515, sel-val 0.015151. **shared val 0.007480** (kb4hm 0.007479 → flat); **forge_sp_all 0.003255** (kb4hm 0.003802 → **−14.4%**, best sp_all of any net; sp90 ~0.0035); val_other 0.003395/0.003429/0.003163 (kb4hm 0.003892/0.003957/0.003714 → ~−13–15%). Shared curve ep1→6: 0.007531, 7509, 7498, 7489, 7483, 7480; sp_all 0.003346→0.003255. ~320k pos/s.
- PC `nets\n256-screlu-ob8-kb4hm-sp80\net_v4.nnue` md5 **d313fbb7**193aeec57b5f15124d4ad02c, 1581628 B (KB4 HM1 act1 NB8, same shape as kb4hm). net_ep1..6.pt kept, log.json, logs\n256-screlu-ob8-kb4hm-sp80.log. Not yet copied to box / packed. Verdict: dominates kb4hm (equal shared, much better self-play/holdout) → should REPLACE kb4hm 9cc41084 as the KB4HM pack net once the kb4hm SIMD repack (Strategist 10:05, hold kb4hm launch) is done. Needs v4 parity + gates on the repack.
- **GPU n256-screlu-ob8-kb4hm-sp70 STARTED ~10:23 PT** PIDs 4492/6688 Idle aff 0xF000: warm kb4hm-sp80 net_v4, weights 0.70/0.07/0.15/0.08 (data40m/forgepgn_wdl/forge_holdout_wdl/forge_sp_new_train), lr 1e-4 cos, 6 ep, KB4 HM, start sel-val 0.015213. Launcher nnue\start_n256_screlu_ob8_kb4hm_sp70.ps1; temps at start hs47 mj68. ETA ~10:45 PT. Goal: check if the self-play/holdout trend continues without losing shared val. STOP_nnue absent.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n256-screlu-ob8-kb4hm-sp80 (GPU) | 2026-10-16 10:00→10:18 | 0.80/0.05/0.10/0.05 | 768->256 x2->8 SCReLU NB8 KB4 HM1 (v4) | init kb4hm v4, 1.5e-4 cos 6ep | shared **0.007480**; sp_all **0.003255** | needs SIMD repack | not tested | UNPROVEN — DONE, NOT PACKED; md5 d313fbb7 |
| n256-screlu-ob8-kb4hm-sp70 (GPU) | 2026-10-16 10:23→ | 0.70/0.07/0.15/0.08 | KB4 HM1 v4 | init kb4hm-sp80 v4, 1e-4 cos 6ep | start sel-val 0.015213 | — | — | UNPROVEN — RUNNING PIDs 4492/6688 |
- 10:24 PT: kb4hm-sp80 v4 export copied to box `/workspace/chess-tools/nnue/nets/kb4hm-sp80/net_v4.nnue` (md5 d313fbb7193aeec57b5f15124d4ad02c verified; also at nets/n256-screlu-ob8-kb4hm-sp80/). Source of truth on grok-pc: C:\Users\Administrator\grok-pc\nnue\nets\n256-screlu-ob8-kb4hm-sp80\net_v4.nnue. Coder packing on kb4hmsimd JS. UNPROVEN.

### 2026-10-16 ~10:48 PT — NNUE hourly (all UNPROVEN)
- Lock 1.7.48 (5877e14c). kb4hm-sp80 (d313fbb7) packed on SIMD JS at chess-engine-nnue/dist-cand-kb4hmsp80simd-1748 (net md5 verified); replaces kb4hm 9cc41084 as KB4HM net-only candidate. Needs Profiler ABBA vs 1.7.48, then QA. GPU kb4hm-sp70 running since 10:23 (idle guard handles finish/chain). Box load ~2.5, no box training. STOP_nnue absent. Status sent to 7 agents priority false.

### 2026-10-16 ~10:50 PT — GPU idle guard: kb4hm-sp70 DONE (no gain), n384-screlu-ob8-kb4hm STARTED (all UNPROVEN)
- **n256-screlu-ob8-kb4hm-sp70 DONE** ~10:43 PT (6/6 ep, ~305-320k pos/s). Selection val got worse every epoch (start 0.015213 → ep6 0.015273), so the trainer exported **epoch 0** = the unchanged kb4hm-sp80 init: PC `nets\n256-screlu-ob8-kb4hm-sp70\net_v4.nnue` md5 **d313fbb7** (byte-identical to sp80). Per-epoch: shared val ep1→6 0.007548, 7549, 7543, 7537, 7533, **0.007532** (sp80 0.007480 → +0.7% worse); forge_sp_all 0.002956 → **0.002864** (sp80 0.003255 → −12%); val_other ep6 0.003042/0.003054/0.002777. ep6 weights kept as net_ep6.pt (md5 ed517191), not exported. Verdict: shifting further to forge data keeps trading shared val for self-play-style val; no clear winner over sp80, NOT packed. kb4hm-sp80 (d313fbb7) stays the best KB4HM net. GPU idle ~10:43→10:49.
- **pilot_r2 datagen finished** (D:\grok-pc-data\pilot_r2: train.bin 54.9 MB = 1,716,364 rows, val.bin 92,727 rows, stats.json, holdout_game_ids; 28,882 games, dupes 948,947, leak 0). Still NOT verified (signcheck/result byte/legacy not checked) → not consumed yet.
- **GPU n384-screlu-ob8-kb4hm STARTED ~10:49 PT** PIDs **13744/7748** Idle aff 0xF000 (61440). Strategist order "H384/H512 run after sp90". Init = function-preserving widen of kb4hm-sp80 H256→H384 (`widen_v4.py` md5 5b971f68, seed 1: new 128 units ftW ~N(0, 31.7 int), ftB 0, outW 0) → `nets/kb4hm-sp80-w384/init_w384.nnue` md5 **381dd076**, 2,372,412 B; ref_eval_v4 identical to sp80 on 4 FENs, and trainer start val **0.015212737** = exactly sp80's. Mix 0.80/0.05/0.10/0.05, lr 2e-4 cos, 8 ep, KB4 HM1 act1 NB8, select val+shared, extra-val forge_sp_all+val_shared. ~269k pos/s → ETA ~11:25 PT. Launcher nnue\start_n384_screlu_ob8_kb4hm.ps1 (box copy pc_launch/). Temps at start hs50 mj70. Bar: shared < 0.007480 with sp_all ≤ ~0.0033. Risk: H384 KB4 FT is 1.5x the H256 one → NPS; v4 SIMD path must handle H=384 (check before packing). STOP_nnue absent.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n256-screlu-ob8-kb4hm-sp70 (GPU) | 2026-10-16 10:23→10:43 | 0.70/0.07/0.15/0.08 | 768->256 x2->8 SCReLU NB8 KB4 HM1 (v4) | init kb4hm-sp80 v4, 1e-4 cos 6ep | ep6 shared 0.007532 / sp_all 0.002864; export = ep0 (= sp80) | — | not tested | UNPROVEN — DONE, NO GAIN, NOT PACKED; export md5 d313fbb7 (=sp80), ep6 pt ed517191 |
| n384-screlu-ob8-kb4hm (GPU) | 2026-10-16 10:49→ | 0.80/0.05/0.10/0.05 | 768->384 x2->8 SCReLU NB8 KB4 HM1 (v4) | init widened kb4hm-sp80 (381dd076), 2e-4 cos 8ep | start sel-val 0.015213 (= sp80) | — | — | UNPROVEN — RUNNING PIDs 13744/7748 |

### 2026-10-16 ~11:30 PT — pilot_r2 PASS, n384 DONE + PACKED, n512 STARTED (all UNPROVEN)
- **pilot_r2 check: PASS** (PILOT_R2_CHECK.md). Format, results (White POV, corr 0.78) and .games are all OK. Small position overlap with val_shared (102), forge_holdout (5,146) and forge_sp_all (5,018), so I made a de-leaked copy, D:\grok-pc-data\pilot_r2_clean (train 1,694,647, 21,717 rows dropped). Train only on the clean copy.
- **n384-screlu-ob8-kb4hm DONE** ~11:21 PT (8/8 ep). Best = ep8: shared **0.007389** (sp80 0.007480, −1.2%), forge_sp_all **0.003208** (sp80 0.003255), holdouts val_other 0.003333/0.003424/0.003123. Export md5 **313c4c09**63b4405682724bf46b1db70e, 2,372,412 B; box copy nets/n384-screlu-ob8-kb4hm/net_v4.nnue.
- **Packed** /workspace/chess-engine-nnue/dist-cand-kb4hmn384simd-1748 = dist-cand-kb4hmsp80simd-1748 with only net.nnue swapped (diff -rq: net.nnue only; nnue.js c4ed2b9d unchanged). v4 parity on the pack's net: 2386 evals, 0 mismatches. Gates (gates_n384_1748.log): perft PASS, movegen 36/0, tactics 6/0, mate suite 10/0, mate_distance 5/5, uci_edge 27, bug_gate PASS (PARTIAL, fuzz skipped because slots were full), 0 new failures, KNOWN 5 (sp80 pack: KNOWN 6). Next: Profiler game_seq speed check vs 1.7.48, then QA net slot.
- **GPU n512-screlu-ob8-kb4hm STARTED ~11:24 PT**, PIDs **2668/13604**, Idle, aff 0xF000. Init = widen_v4.py seed 1 of n384 (313c4c09) H384→H512, new outW=0 → nets\init_n512kb4hm-w512.nnue md5 17c8cac1; ref_eval_v4 identical to n384 on 4 FENs (7/−213/31/−665). Mix: sp80 mix + pilot_r2_clean, 0.76/0.05/0.09/0.05/0.05, lr 2e-4 cos, 8 ep. Start sel-val 0.015073: not comparable to n384's 0.014967, because sel-val now includes pilot val. ~262k pos/s, ETA ~11:58 PT. Temps hs66 mj81.
| n384-screlu-ob8-kb4hm (GPU) | 10:49→11:21 | 0.80/0.05/0.10/0.05 | 768->384 x2->8 SCReLU NB8 KB4 HM1 | widen sp80, 2e-4 cos 8ep | shared 0.007389 / sp_all 0.003208 | dist-cand-kb4hmn384simd-1748 | gates PASS | UNPROVEN — PACKED, md5 313c4c09 |
| n512-screlu-ob8-kb4hm (GPU) | 11:24→ | 0.76/0.05/0.09/0.05/0.05 (+pilot_r2_clean) | 768->512 KB4 HM1 | widen n384 (17c8cac1), 2e-4 cos 8ep | — | — | — | UNPROVEN — RUNNING PIDs 2668/13604 |

### 2026-10-16 ~11:52 PT — NNUE hourly (all UNPROVEN)
- Lock still 1.7.48 (baseline/dist-v1.7.48). Box load 2.4.
- GPU n512-screlu-ob8-kb4hm RUNNING (PIDs 2668/13604 alive, STOP_nnue absent), ep6/8 done 11:47 PT: sel-val 0.014746, shared **0.007279** (n384 0.007389, −1.5%), forge_sp_all 0.003170 (n384 0.003208), val_other 0.003239/0.003433/0.003078/0.002948. ~270k pos/s, ETA ~11:56 PT; idle guard chains next job and exports/packs if it beats n384.
- Waiting: Profiler speed check for dist-cand-kb4hmn384simd-1748 (and kb4hmsp80simd-1748) vs 1.7.48, then QA net-only slot. Status sent to 7 agents priority false.

### 2026-10-16 ~12:03 PT — GPU idle guard: n512 DONE, n384-p2 STARTED (all UNPROVEN)
- **n512-screlu-ob8-kb4hm DONE** ~11:55 PT (8/8 ep, ~262-282k pos/s). Best = ep8: sel-val 0.014734, shared **0.007273** (n384 0.007389, −1.6%; best shared of any net), forge_sp_all **0.003162** (n384 0.003208), val_other 0.003227/0.003427/0.003070/0.002944 (last = pilot_r2 val). Curve flattened late (ep6 0.007279, ep7 0.007274, ep8 0.007273) under cosine. Export PC `nets\n512-screlu-ob8-kb4hm\net_v4.nnue` md5 **e52ebdae**7dd259ad84b86a158f3e9a46, 3,163,196 B (KB4 HM1 act1 NB8 H512); net_ep1..8.pt, net_best.pt, log.json kept; log logs\n512-screlu-ob8-kb4hm.log. Box copy nets/n512-screlu-ob8-kb4hm/net_v4.nnue (md5 verified). NOT packed: v4 SIMD path must be checked for H=512, and NPS risk (KB4 FT is 2x H256, ~3.1 MB). Note: gain vs n384 mixes width and the added pilot_r2_clean data, so n384-p2 below separates them. GPU idle ~11:55→12:02 PT.
- **GPU n384-screlu-ob8-kb4hm-p2 STARTED ~12:02 PT** PIDs **10964/12924** Idle aff 0xF000 (61440). Warm n384 (313c4c09, same shape as packed dist-cand-kb4hmn384simd-1748), same mix as n512 (sp80 mix + pilot_r2_clean 0.76/0.05/0.09/0.05/0.05), lr 1.5e-4 cos, 8 ep, KB4 HM1. Start sel-val 0.015073 (= n512 start, as expected). ~243k pos/s → ETA ~12:35 PT. Launcher nnue\start_n384_screlu_ob8_kb4hm_p2.ps1 (box copy pc_launch/). Temps at start hs60 mj78. Bar: shared < 0.007389 (n384) and ideally near n512's 0.007273; if it gets close, it's a drop-in net swap for the faster n384 pack. STOP_nnue absent. Self-play datagen alive (forge_selfplay → D:\grok-pc-data\selfplay_out\forge_selfplay_006.txt.part, writing).

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n512-screlu-ob8-kb4hm (GPU) | 11:24→11:55 | 0.76/0.05/0.09/0.05/0.05 (+pilot_r2_clean) | 768->512 x2->8 SCReLU NB8 KB4 HM1 (v4) | widen n384 (17c8cac1), 2e-4 cos 8ep | shared **0.007273** / sp_all 0.003162 | H512 SIMD parity 0 mism; gates PASS (fuzz skipped); quick NPS ≈ n384; needs Profiler | not tested | UNPROVEN — PACKED dist-cand-kb4hmn512simd-1748 (net-only vs n384 pack); md5 e52ebdae |
| n384-screlu-ob8-kb4hm-p2 (GPU) | 12:02→ | 0.76/0.05/0.09/0.05/0.05 (+pilot_r2_clean) | 768->384 KB4 HM1 (v4) | warm n384 (313c4c09), 1.5e-4 cos 8ep | start sel-val 0.015073 | — | — | UNPROVEN — RUNNING PIDs 10964/12924 |
- **PACKED dist-cand-kb4hmn512simd-1748 ~12:10 PT** (UNPROVEN): copy of dist-cand-kb4hmn384simd-1748, only net.nnue swapped (e52ebdae; nnue.js c4ed2b9d same). v4 parity (results_n512.json): refresh 0/300, inc 2386 evals 0 mism (inc_vs_fresh/checkAcc/inc_vs_ref), simd on. Gates (gates_n512_1748.log): perft/movegen 36/tactics 6/mate 10/mate_distance 5/5/uci_edge 27 PASS; bug_gate PASS new 0, KNOWN 6 vs n384 5 — extra is pre-existing known "insufficient KBvKB same colour" (eval cp 8; n384 happened to pass it; sp80simd also had 6). Quick 1T NPS d12 x3 (load ~2.8, noisy): n512 med 243.7k/172802 nodes vs n384 230.8k/160185 nodes. Next: Profiler ABBA.

### 2026-10-16 ~12:40 PT — GPU idle guard: n384-kb4hm-p2 DONE, n512-kb4hm-c2 STARTED (all UNPROVEN)
- **n384-screlu-ob8-kb4hm-p2 DONE** ~12:34 PT (8/8 ep, best = ep8, ~270-293k pos/s). train 0.006118, sel-val 0.014854. **shared 0.007332** (n384 0.007389 → −0.8%; n512 0.007273 still best), forge_sp_all **0.003168** (n384 0.003208; ≈ n512 0.003162), val_other 0.003267/0.003402/0.003080/0.002919 (last = pilot_r2 val; n512 0.002944). Shared curve ep5→8: 0.007347, 7336, 7333, 7332 (flat). Export PC `nets\n384-screlu-ob8-kb4hm-p2\net_v4.nnue` md5 **bfa76347**504cc7a87bdc63abc88dacbe, 2,372,412 B (KB4 HM1 act1 NB8 H384, same shape as the dist-cand-kb4hmn384simd-1748 net → drop-in swap); net_ep1..8.pt, net_best.pt, log.json kept; log logs\n384-screlu-ob8-kb4hm-p2.log. Box copy nets/n384-screlu-ob8-kb4hm-p2/net_v4.nnue (md5 verified). Verdict: of n512's −1.6% over n384, about half is the pilot_r2_clean data and half is width. Not packed yet: worth a net-only n384 repack if Profiler shows n512 is too slow; otherwise n512 stays the candidate. GPU idle ~12:34→12:40.
- **GPU n512-screlu-ob8-kb4hm-c2 STARTED ~12:40 PT** PIDs **3816/7036** Idle aff 0xF000 (61440). Warm n512 (e52ebdae, the packed dist-cand-kb4hmn512simd-1748 net), same mix (sp80 mix + pilot_r2_clean 0.76/0.05/0.09/0.05/0.05), re-warmed lr 1e-4 cos, 8 ep, KB4 HM1. No queued Strategist job, so this is a re-warm continue on the best net (n512's curve was flattening only because cosine lr hit ~0). Start sel-val 0.014896. ~248k pos/s → ETA ~13:15 PT. Launcher nnue\start_n512_screlu_ob8_kb4hm_c2.ps1 (box copy pc_launch/). Temps at start hs53 mj72. Bar: shared < 0.007273 → drop-in net swap into the n512 pack. STOP_nnue absent. Self-play datagen alive (forge_selfplay_006.txt.part ~201 MB, writing; PIDs 9308/9896/10456 + guards).

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n384-screlu-ob8-kb4hm-p2 (GPU) | 12:02→12:34 | 0.76/0.05/0.09/0.05/0.05 (+pilot_r2_clean) | 768->384 x2->8 SCReLU NB8 KB4 HM1 (v4) | warm n384 (313c4c09), 1.5e-4 cos 8ep | shared **0.007332** / sp_all 0.003168 | same shape as n384 pack | not tested | UNPROVEN — DONE, NOT PACKED; md5 bfa76347 |
| n512-screlu-ob8-kb4hm-c2 (GPU) | 12:40→ | 0.76/0.05/0.09/0.05/0.05 (+pilot_r2_clean) | 768->512 KB4 HM1 (v4) | warm n512 (e52ebdae), 1e-4 cos 8ep | start sel-val 0.014896 | — | — | UNPROVEN — RUNNING PIDs 3816/7036 |

### 2026-10-16 ~12:47 PT — n512-kb4hm-c2 STOPPED, n384-kb4hm-c3 STARTED (all UNPROVEN)
- **n512-screlu-ob8-kb4hm-c2 STOPPED ~12:46 PT** at ep1 batch ~1000/1991 (no epoch finished, nothing exported). Killed only its train_gpu3kb.py PIDs **3816/7036**. Why: QA parked H512 as too slow (Profiler: n384 reaches d10 25.6% faster than n512; n512 NPS −14.3% vs 1.7.48), so more H512 training has no slot. QA wants an H384 net that clearly beats 0.007389 at n384 speed.
- **GPU n384-screlu-ob8-kb4hm-c3 STARTED ~12:46 PT** PIDs **12360/11860** Idle aff 0xF000 (61440). Warm n384-kb4hm-p2 (bfa76347, shared 0.007332; drop-in for dist-cand-kb4hmn384simd-1748), same mix (sp80 mix + pilot_r2_clean 0.76/0.05/0.09/0.05/0.05), lr 1e-4 cos, **10 ep**, KB4 HM1, selection = val + val_shared (--select-add, same as p2). Start sel-val **0.014944** (p2 final float 0.014854; the +0.6% gap is int-export quantization on warm reload, same pattern as n512→c2 0.014734→0.014896). Trainer doesn't print start shared on its own; ep1 shared (~12:51 PT) is the first direct check vs 0.007332. ~278k pos/s, ~4.3 min/ep → ETA ~13:30 PT. Launcher nnue\start_n384_screlu_ob8_kb4hm_c3.ps1 (box copy pc_launch/). Temps at start hs59 mj78. Bar: shared clearly < 0.007389 (ideally < 0.007332) → net-only swap into the n384 pack. STOP_nnue absent.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n512-screlu-ob8-kb4hm-c2 (GPU) | 12:40→12:46 | 0.76/0.05/0.09/0.05/0.05 (+pilot_r2_clean) | 768->512 KB4 HM1 (v4) | warm n512 (e52ebdae), 1e-4 cos 8ep | start sel-val 0.014896; no epoch done | — | — | UNPROVEN — STOPPED (QA parked H512 as too slow); PIDs 3816/7036 killed |
| n384-screlu-ob8-kb4hm-c3 (GPU) | 12:46→ | 0.76/0.05/0.09/0.05/0.05 (+pilot_r2_clean) | 768->384 KB4 HM1 (v4) | warm n384-p2 (bfa76347), 1e-4 cos 10ep | start sel-val 0.014944 | same shape as n384 pack | — | UNPROVEN — RUNNING PIDs 12360/11860 |
- c3 ep1 (~12:50 PT): sel-val 0.014866, **shared 0.007338** (p2 0.007332 → start matches within quantization), forge_sp_all 0.003172, val_other 0.003277/0.003410/0.003074/0.002937. 228 s/ep at ~286k pos/s → ETA ~13:28 PT.

### 2026-10-16 ~12:52 PT — hourly: n384-p2 PACKED (all UNPROVEN)
- **PACKED dist-cand-kb4hmn384p2simd-1748** (built ~12:41 PT, recorded here at the hourly run): copy of dist-cand-kb4hmn384simd-1748 with only net.nnue swapped to n384-kb4hm-p2 (md5 bfa76347; diff -rq: net.nnue only; nnue.js c4ed2b9d unchanged). v4 parity v4_parity/results_n384p2.json: 0 mismatches. Gates (gates_n384p2_1748.log, 12:43 PT): perft PASS, movegen 36/0, tactics 6/0, mate suite 10/0, mate_distance 5/5, uci_edge 27, bug_gate PASS (PARTIAL, fuzz skipped, slots full), new 0, KNOWN 5. Same shape/speed class as the n384 pack, shared 0.007332 vs 0.007389 → supersedes dist-cand-kb4hmn384simd-1748 as the H384 net-only candidate. Next: Profiler confirm (net-only swap, same shape) then QA net-only slot vs 1.7.48.
- GPU n384-kb4hm-c3 running (ep1 shared 0.007338, ETA ~13:28 PT). n512 pack parked by QA (NPS −14.3% vs 1.7.48).

- **PACKED dist-cand-kb4hmn384p2simd-1748 ~12:55 PT** (UNPROVEN): copy of dist-cand-kb4hmn384simd-1748, only net.nnue swapped for nets/n384-screlu-ob8-kb4hm-p2/net_v4.nnue (md5 bfa76347504cc7a87bdc63abc88dacbe verified; shared 0.007332 vs n384 0.007389). diff -rq: net.nnue only. v4 parity (v4_parity/results_n384p2.json): refresh 0/300, inc 2386 evals, 0 mismatches all checks, simd on. Gates (gates_n384p2_1748.log): perft PASS, movegen 36/0, tactics 6/0, mate suite 10/0, mate_distance 5/5, uci_edge 27, bug_gate PASS (PARTIAL, fuzz skipped: slots full), new 0, KNOWN 5 (= n384). Bench H256 (prof1748_n384 bench_hash.js): d9 140626, d10 209328 (n384 re-run d10 249869, matches). Next: Profiler game_seq speed check, then QA net slot.

### 2026-10-16 ~13:25 PT — GPU idle guard: n384-kb4hm-c3 DONE, n384-kb4hm-c4 STARTED (all UNPROVEN)
- **n384-screlu-ob8-kb4hm-c3 DONE** ~13:21 PT (10/10 ep, best = ep9 (last), ~271-326k pos/s). train 0.006047, sel-val 0.014763. **shared 0.007288** (p2 0.007332 → −0.6%; n384 0.007389 → −1.4%; ≈ n512 0.007273 at n384 speed), forge_sp_all **0.003173** (p2 0.003168), val_other 0.003260/0.003424/0.003085/0.002942 (last = pilot_r2 val). Shared curve ep6→9: 0.007295, 7292, 7290, 7288 (still slowly falling). Export PC `nets\n384-screlu-ob8-kb4hm-c3\net_v4.nnue` md5 **1dfe6122**14f04e95b63fef4d53888af0, 2,372,412 B (KB4 HM1 act1 NB8 H384, same shape as dist-cand-kb4hmn384p2simd-1748 net → drop-in net-only swap); net_ep1..9.pt, net_best.pt, log.json kept; log logs\n384-screlu-ob8-kb4hm-c3.log. Box copy nets/n384-screlu-ob8-kb4hm-c3/net_v4.nnue (md5 verified). Meets QA's bar (clearly < 0.007389 at n384 speed). NOT packed yet: next step is a net-only repack of dist-cand-kb4hmn384p2simd-1748 with this net (parity + gates), superseding p2. GPU idle ~13:21→13:23.
- **GPU n384-screlu-ob8-kb4hm-c4 STARTED ~13:23 PT** PIDs **10776/12696** Idle aff 0xF000 (61440). Warm c3 (1dfe6122), same mix (sp80 mix + pilot_r2_clean 0.76/0.05/0.09/0.05/0.05), lr **8e-5** cos, 10 ep, KB4 HM1, select val + val_shared. Start sel-val 0.014854 (c3 float 0.014763; quantization gap on warm reload as before). ~276k pos/s → ETA ~14:05 PT. Launcher nnue\start_n384_screlu_ob8_kb4hm_c4.ps1 (box copy pc_launch/). Temps at start hs61 mj78. No Strategist job queued; continuation chosen because c3's shared curve was still falling. Bar: shared < 0.007288 → net-only swap. STOP_nnue absent. Self-play datagen alive (forge_selfplay_006.txt.part ~251 MB, writing; PIDs 9308/9896/10456 + guards). Note: forge_selfplay_005.txt (complete, 648 MB) may not be in forge_sp_new_train yet — candidate fresh data for a later run.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| n384-screlu-ob8-kb4hm-c3 (GPU) | 12:46→13:21 | 0.76/0.05/0.09/0.05/0.05 (+pilot_r2_clean) | 768->384 x2->8 SCReLU NB8 KB4 HM1 (v4) | warm n384-p2 (bfa76347), 1e-4 cos 10ep | shared **0.007288** / sp_all 0.003173 | same shape as n384 pack | not tested | UNPROVEN — DONE, NOT PACKED; md5 1dfe6122 |
| n384-screlu-ob8-kb4hm-c4 (GPU) | 13:23→ | 0.76/0.05/0.09/0.05/0.05 (+pilot_r2_clean) | 768->384 KB4 HM1 (v4) | warm c3 (1dfe6122), 8e-5 cos 10ep | start sel-val 0.014854 | — | — | UNPROVEN — RUNNING PIDs 10776/12696 |

### 2026-10-16 ~13:27 PT: auto_queue supervisor started on grok-pc (UNPROVEN)
- c3 note: the trainer exported epoch 10 (sel-val 0.014762), shared **0.007287** (ep9 0.007288), md5 1dfe6122.
- `nnue\auto_queue.ps1` (md5 c54021af) is running detached at Idle priority, PID 1380. It waits for c4 (10776/12696) and records it, then runs a1 H384 7e-5, c3 H512 1e-4 from e52ebdae, a2 H384 5e-5, then repeats H384 at decaying lr until STOP_nnue. New nets go in F:\grok-pc-nnue-auto\nets\<job>. Results are in nnue\AUTO_RESULTS.md, auto_results.csv and AUTO_BEST.txt, backed up to D:\grok-pc-data\auto_backup. See AUTO_README.md (box mirror: nnue/auto_results/).
- **PACKED dist-cand-kb4hmn384c3simd-1748 ~13:25 PT** (UNPROVEN): copy of dist-cand-kb4hmn384p2simd-1748, only net.nnue swapped for nets/n384-screlu-ob8-kb4hm-c3/net_v4.nnue (md5 1dfe612214f04e95b63fef4d53888af0 verified; shared 0.007288 vs p2 0.007332). diff -rq: net.nnue only. v4 parity (v4_parity/results_n384c3.json): refresh 0/300, inc 2386 evals, 0 mismatches all checks, simd on. Gates (gates_n384c3_1748.log): perft PASS, movegen 36/0, tactics 6/0, mate suite 10/0, mate_distance 5/5, uci_edge 27, bug_gate PASS (PARTIAL, fuzz skipped: slots full), new 0, KNOWN 5 (= p2). Bench H256 (prof1748_n384 bench_hash.js): d9 165424, d10 245500 (p2 140626/209328). Supersedes p2 as H384 net-only candidate. Next: Profiler game_seq, then QA net slot.
- **PACKED dist-cand-kb4hmn384c3simd-1749 ~13:36 PT** (UNPROVEN): copy of baseline/dist-v1.7.49 (chess-engine/baseline) + eval/nnue.js c4ed2b9d, uci/main.js 31a45e5e, net.nnue 1dfe6122 from c3-1748 (the exact 3 files where c3-1748 differs from 1.7.48). diff -rq vs 1.7.49: those 3 only; vs c3-1748: move/movegen.js only (9077e904). v4 parity (v4_parity/results_n384c3_1749.json): refresh 0/300, inc 2372 evals, 0 mismatches, simd on. Gates (gates_n384c3_1749.log): perft PASS, movegen 36/0, tactics 6/0, mate 10/0, mate_distance 5/5, uci_edge 27, bug_gate PASS (PARTIAL, fuzz skipped: slots full), new 0, KNOWN 5. Bench H256 d10 245541 (c3-1748 245500). Next: Profiler vs 1.7.49 and n384p2-1749, QA net slot, fuzz still owed.

### 2026-10-16 ~13:52 PT — hourly (all UNPROVEN)
- Lock now 1.7.49. dist-cand-kb4hmn384c3simd-1749 (net 1dfe6122) is gated (PASS, fuzz skipped) and QA has it on pcE (run_match_1749_pcE ... tlcheck seen in grok-pc process list 13:50 PT). Still owed: Profiler NPS confirm vs 1.7.49, fuzz.
- GPU n384-kb4hm-c4 (PIDs 10776/12696) ep7/10: sel-val 0.014706, **val_shared 0.007260** (c3 0.007287 → −0.4%), forge_sp_all 0.003182, ~318-336k pos/s, ETA ~14:01 PT. auto_queue PID 1380 alive (chains a1 after c4). STOP_nnue absent. Self-play datagen (forge_selfplay + selfplay_guard) alive.

### 2026-10-16 ~14:04 PT — GPU idle guard (all UNPROVEN)
- **n384-screlu-ob8-kb4hm-c4 DONE ~14:00 PT** (pc 23:00): best = ep10, **val_shared 0.007257** (new best; c3 0.007287, n512 0.007273), forge_sp_all 0.003177, md5 01c2c0822dc98e5bc683c2ec29d59872. Net on PC at nnue\nets\n384-screlu-ob8-kb4hm-c4\net_v4.nnue (+net_ep*.pt, log.json); full per-epoch record in PC AUTO_RESULTS.md. NOT copied to box, NOT packed (drop-in net-only swap for dist-cand-kb4hmn384c3simd-1749).
- auto_queue (PID 1380) chained the next job itself at 14:00 PT: **auto-n384-kb4hm-a1** (PIDs 14012/3076, Idle): warm c4 01c2c082, same 5-source mix 0.76/0.05/0.09/0.05/0.05, lr 7e-5 cos 10ep, out F:\grok-pc-nnue-auto\nets\auto-n384-kb4hm-a1-10162300. GPU busy (sensor row 14:03 PT). Self-play datagen (forge_selfplay 9308 + selfplay_guard) alive. STOP_nnue absent.

### 2026-10-16 ~14:55 PT — hourly: auto-a1 DONE + PACKED (all UNPROVEN)
- **auto-n384-kb4hm-a1-10162300 DONE ~14:40 PT** (auto_queue job, pc 23:00→23:40): warm c4 01c2c082, mix 0.76/0.05/0.09/0.05/0.05 (data40m, forgepgn_wdl, forge_holdout_wdl, forge_sp_new_train, pilot_r2_clean), H384 lr 7e-5 cos 10ep bs32768 KB4 HM1 ob8, select val_shared. Best ep10 **val_shared 0.007233** (new best; c4 0.007257, c3 0.007287, n512 0.007273), forge_sp_all 0.003182, md5 **95ee653c6709d083528daaa293fa46f9**. PC: F:\grok-pc-nnue-auto\nets\auto-n384-kb4hm-a1-10162300 (+ staged copy nnue\nets\auto-n384-kb4hm-a1-10162300); box: nets/auto-n384-kb4hm-a1-10162300/{net_v4.nnue,log.json,settings.txt}.
- **PACKED dist-cand-kb4hmn384a1simd-1749** (UNPROVEN): cp -a of dist-cand-kb4hmn384c3simd-1749 with only net.nnue swapped (diff -rq: net.nnue only; md5 95ee653c verified). v4 parity v4_parity/results_n384a1_1749.json: refresh 0/300, inc 2372 evals, 0 mismatches, simd on. Gates running: chess-engine-nnue/gates_n384a1_1749.log (fuzz skipped). Supersedes c3-1749 as the H384 net-only candidate if gates pass; c4 (01c2c082) skipped (a1 strictly better, same lineage).
- auto_queue (PID 1380) chained **auto-n512-kb4hm-c3-10162340** (H512 1e-4 from e52ebdae) at 14:40 PT; note QA parked H512 for NPS (−14.3%), so this net is only useful if H512 gets un-parked. Self-play datagen alive. STOP_nnue absent. Free: C 40.1 / D 164.2 / F 173.9 GB.

| id | date (PT) | data | arch | epochs/lr | val loss | NPS vs lock | Elo | status |
|---|---|---|---|---|---|---|---|---|
| auto-n384-kb4hm-a1 (GPU, auto_queue) | 14:00→14:40 | 0.76/0.05/0.09/0.05/0.05 (+pilot_r2_clean) | 768->384 KB4 HM1 (v4) | warm c4 (01c2c082), 7e-5 cos 10ep | shared **0.007233** / sp_all 0.003182 | same shape as c3 pack | not tested | UNPROVEN — PACKED dist-cand-kb4hmn384a1simd-1749, gates running; md5 95ee653c |
| auto-n512-kb4hm-c3 (GPU, auto_queue) | 14:40→15:13 | same mix | 768->512 KB4 HM1 (v4) | warm n512 (e52ebdae), 1e-4 cos 8ep | shared **0.007235** (ep8) / sp_all 0.003177 | H512 parked (−14.3%) | not tested | UNPROVEN — DONE, NOT packed (H512 parked; ≈ a1 0.007233 at H384); md5 98778fb4 |
| auto-n384-kb4hm-a2 (GPU, auto_queue) | 15:13→ | same mix | 768->384 KB4 HM1 (v4) | warm a1 (95ee653c), 5e-5 cos 10ep | — | — | — | UNPROVEN — RUNNING |

- 2026-10-16 ~15:16 PT GPU idle guard: **auto-n512-kb4hm-c3-10162340 DONE 15:13 PT** (pc 23:40→00:13): warm n512 e52ebdae, same 5-source mix, H512 lr 1e-4 cos 8ep. Best ep8 **val_shared 0.007235** (prev H512 best 0.007273; a1 H384 0.007233 still overall best), forge_sp_all 0.003177, md5 **98778fb41ac22e3e5f0cb55e0fac8596**. PC: F:\grok-pc-nnue-auto\nets\auto-n512-kb4hm-c3-10162340\net_v4.nnue. Not packed: H512 parked by QA for NPS and it gives no loss edge over H384 a1. UNPROVEN.
- auto_queue (PID 1380) chained **auto-n384-kb4hm-a2-10170013** at 15:13 PT (PIDs 5456/8584): warm a1 95ee653c, same mix, H384 lr 5e-5 cos 10ep, out F:\grok-pc-nnue-auto\nets\auto-n384-kb4hm-a2-10170013. Self-play datagen (forge_selfplay 9308 + 2 workers, selfplay_guard) alive. STOP_nnue absent. UNPROVEN.
| auto-n384-kb4hm-a2 (GPU, auto_queue) | 15:13→15:45 | same mix | 768->384 KB4 HM1 (v4) | warm a1 (95ee653c), 5e-5 cos 10ep | shared **0.007219** (ep10) / sp_all 0.003184 | same shape as a1 pack | not tested | UNPROVEN — DONE, new best, NOT yet packed (net-only swap candidate for dist-cand-kb4hmn384a1simd-1749); md5 cf1bd00f |
| auto-n384-kb4hm-r1 (GPU, auto_queue) | 15:45→ | same mix | 768->384 KB4 HM1 (v4) | warm a2 (cf1bd00f), 3.5e-5 cos 8ep | — | — | — | UNPROVEN — RUNNING |

- 2026-10-16 ~15:52 PT GPU idle guard: **auto-n384-kb4hm-a2-10170013 DONE 15:45 PT** (pc 00:13→00:45): warm a1 95ee653c, same 5-source mix, H384 lr 5e-5 cos 10ep. Best ep10 **val_shared 0.007219** (new best; a1 0.007233, H512 c3 0.007235), forge_sp_all 0.003184 (a1 0.003182, flat), md5 **cf1bd00fdbcd7969a74d315b8cb216e8**. PC: F:\grok-pc-nnue-auto\nets\auto-n384-kb4hm-a2-10170013\net_v4.nnue. Not packed yet (small −0.000014 shared gain; next: net-only swap of the a1-1749 pack + parity). UNPROVEN.
- auto_queue (PID 1380) chained **auto-n384-kb4hm-r1-10170045** at 15:45 PT (PIDs 13892/5660, Idle, affinity 0xF000): warm a2 cf1bd00f, same mix, H384 lr 3.5e-5 cos 8ep, out F:\grok-pc-nnue-auto\nets\auto-n384-kb4hm-r1-10170045. Self-play datagen (selfplay_guard + forge_selfplay 6624/9308) alive. STOP_nnue absent. GPU temps from HWiNFO in range. UNPROVEN.
- **PACKED dist-cand-kb4hmn384a2simd-1749 ~15:55 PT** (UNPROVEN): cp -a of dist-cand-kb4hmn384a1simd-1749, only net.nnue swapped for nets/auto-n384-kb4hm-a2/net_v4.nnue (md5 cf1bd00fdbcd7969a74d315b8cb216e8 verified; copied F: -> pc staging nnue\nets\auto-n384-kb4hm-a2-10170013 -> box, since F: is outside local-exec root; shared 0.007219 vs a1 0.007233). diff -rq: net.nnue only. v4 parity (v4_parity/results_n384a2_1749.json): refresh 0/300, inc 2372 evals, 0 mismatches all checks, simd on. Gates (chess-engine-nnue/gates_n384a2_1749.log): perft PASS, movegen 36/0, tactics 6/0, mate 10/0, mate_distance 5/5, uci_edge 27, bug_gate PASS (PARTIAL, fuzz skipped: slots full), new 0, KNOWN 6 (a1: 5) — the extra is known-class "insufficient KBvKB same colour" (a2 cp 2, a1 passes; net eval, not a draw-rule code change). Bench H256 d10 (prof1748_n384 bench_hash.js): a2 236967 nodes, a1 262519 (NPS not comparable: gates running concurrently). a1-1749 gates: DONE 14:54 PT, all PASS (PARTIAL, fuzz skipped), KNOWN 5. Next: Profiler a2 vs 1.7.49 (+a1 re-time), QA chooses a2 vs a1; fuzz still owed for both.

### 2026-10-16 ~15:58 PT — hourly (all UNPROVEN)
- Lock still 1.7.49 (baseline/dist-v1.7.49). Box load 4.1 (no box training; GPU work is on grok-pc).
- Profiler a1-1749 (net 95ee653c) vs 1.7.49 (prof1749_a1, 5 ABBA, game_seq d10 T1): nodes −36%, time-to-d10 −16.7% (5/5 faster), NPS −23.6% → ≤25% gate PASS but close (c3-1749 same shape measured −13.5%; spread is likely load noise).
- dist-cand-kb4hmn384a2simd-1749 (net cf1bd00f, shared 0.007219) packed + gated 15:53 PT: PASS (PARTIAL, fuzz skipped), KNOWN 6 vs a1 5 (extra = KBvKB same-colour eval cp 2; net eval, not code). Preferred H384 net-only candidate over a1/c3 on val loss; still needs Profiler NPS vs 1.7.49 and QA fuzz/TL/[0,10].
- GPU: auto_queue r1 (auto-n384-kb4hm-r1-10170045, warm a2, 3.5e-5 cos 8ep) running since 15:45 PT. Datagen alive per 15:52 guard. STOP_nnue absent.
| auto-n384-kb4hm-r1 (GPU, auto_queue) | 15:45→16:14 | same mix | 768->384 KB4 HM1 (v4) | warm a2 (cf1bd00f), 3.5e-5 cos 8ep | shared **0.007211** (ep7) / sp_all 0.003186 | same shape as a2 pack | not tested | UNPROVEN — DONE, new best, NOT packed (net-only swap candidate for dist-cand-kb4hmn384a2simd-1749); md5 55d8f913 |
| auto-n384-kb4hm-r2 (GPU, auto_queue) | 16:14→16:45 | same mix | 768->384 KB4 HM1 (v4) | warm r1 (55d8f913), 2.45e-5 cos 8ep | shared **0.007207** (ep7) / sp_all 0.003184 | same shape as a2 pack | not tested | UNPROVEN — DONE, new best (tiny), NOT packed; md5 f4c42da6 |
| auto-n384-kb4hm-r3 (GPU, auto_queue) | 16:46→ | same mix | 768->384 KB4 HM1 (v4) | warm r2 (f4c42da6), 1.715e-5 cos 8ep | — | — | — | UNPROVEN — RUNNING |

- 2026-10-16 ~16:22 PT GPU idle guard: **auto-n384-kb4hm-r1-10170045 DONE 16:14 PT** (pc 00:45→01:14): warm a2 cf1bd00f, same 5-source mix, H384 lr 3.5e-5 cos 8ep. Best ep7 **val_shared 0.007211** (new best; a2 0.007219, −0.000008), forge_sp_all 0.003186 (a2 0.003184, flat), md5 **55d8f913fef542483aea07b014afe4c5**. PC: F:\grok-pc-nnue-auto\nets\auto-n384-kb4hm-r1-10170045\net_v4.nnue. Not packed (tiny gain; diminishing returns on this lineage). UNPROVEN.
- auto_queue (PID 1380) chained **auto-n384-kb4hm-r2-10170114** at 16:14 PT (PIDs 13320/7856, Idle, affinity 0xF000): warm r1 55d8f913, same mix, H384 lr 2.45e-5 cos 8ep, out F:\grok-pc-nnue-auto\nets\auto-n384-kb4hm-r2-10170114 (ep1 checkpoint 16:18 PT). Self-play datagen (selfplay_guard 9100/10368 + forge_selfplay 9308/6624 + 2 workers) alive. STOP_nnue absent. No job started by guard (GPU busy). UNPROVEN.

- 2026-10-16 ~16:52 PT GPU idle guard: **auto-n384-kb4hm-r2-10170114 DONE 16:45 PT** (pc 01:14→01:45): warm r1 55d8f913, same 5-source mix, H384 lr 2.45e-5 cos 8ep. Best ep7 **val_shared 0.007207** (new best; r1 0.007211, −0.000004, diminishing), forge_sp_all 0.003184 (flat), md5 **f4c42da60008c7504536767dd0f6ed45**. PC: F:\grok-pc-nnue-auto\nets\auto-n384-kb4hm-r2-10170114\net_v4.nnue. Not packed (tiny gain over a2 cf1bd00f 0.007219; LR-decay chain is flattening).
- auto_queue (PID 1380) chained **auto-n384-kb4hm-r3-10170146** at 16:46 PT (python PID 412, Idle, affinity 0xF000): warm r2 f4c42da6, same mix, H384 lr 1.715e-5 cos 8ep (ep1 checkpoint 16:50 PT). Self-play datagen alive (forge_selfplay_006.txt.part growing, 525 MB at 16:51 PT). STOP_nnue absent. No job started by guard (GPU busy). nvidia-smi not on PATH this run; job judged live from process + fresh checkpoints. All UNPROVEN.
- 2026-10-16 ~16:57 PT NNUE hourly: lock 1.7.49 (unchanged). auto_queue PID 1380 alive; **auto-n384-kb4hm-r3-10170146** training (python PID 412, ep2 checkpoint 16:54 PT, warm r2 f4c42da6, 1.715e-5 cos 8ep). AUTO_BEST H384 = r2 f4c42da6 0.007207 (not packed; tiny gain over packed a2 cf1bd00f). Self-play datagen alive (forge_selfplay_006.txt.part 532 MB, growing). STOP_nnue absent. Free C 40 / D 164 / F 173 GB. Box load 4.16, so no box work this hour. Nothing new to pack or gate; no messages sent. All UNPROVEN.
- 2026-10-16 ~17:24 PT GPU idle guard: **auto-n384-kb4hm-r3-10170146 DONE 17:18 PT** (pc 01:46→02:18): warm r2 f4c42da6, same 5-source mix, H384 lr 1.715e-5 cos 8ep. Best ep7 **val_shared 0.007205** (new best; r2 0.007207, −0.000002, LR-decay chain nearly flat), forge_sp_all 0.003182 (flat), md5 **d741d7ac248c8818c19bfb48f66573ab**. PC: F:\grok-pc-nnue-auto\nets\auto-n384-kb4hm-r3-10170146\net_v4.nnue. Not packed (gain over packed a2 cf1bd00f 0.007219 is tiny). UNPROVEN.
- auto_queue (PID 1380) chained **auto-n384-kb4hm-r4-10170218** at 17:18 PT (python PIDs 10776/13316, Idle, affinity 0xF000): warm r3 d741d7ac, same mix, H384 lr 1.2005e-5 cos 8ep, out F:\grok-pc-nnue-auto\nets\auto-n384-kb4hm-r4-10170218. Self-play datagen (selfplay_guard 9100/10368 + forge_selfplay 9308/6624 + 2 workers) alive. STOP_nnue absent. No job started by guard (GPU busy). Note: further r-chain steps give ~0.000002 each; Strategist/hourly should consider a new experiment after r4 instead of r5. All UNPROVEN.

### 2026-10-17 ~07:06 PT — GPU idle guard (all UNPROVEN)
- **GPU BUSY** (live process + HWiNFO util): **auto-n384-kb4hm-r46-10171550** running. Wrapper PID 12776 + train PID 6868, Idle, affinity 0xF000. Warm **r3** d741d7ac, H384 lr **1e-5** cos 8ep, same 5-source mix, out F:\grok-pc-nnue-auto\nets\auto-n384-kb4hm-r46-10171550. auto_queue PID 1380 + thermal_guard PID 1800 alive. No second GPU job started.
- Temps (HWiNFO gpu_sensors.csv, PC clock ~9h ahead of real PT): hot spot **70 C**, memory junction **88 C**, GPU util **55%**, edge/GPU temp 61 C. STOP_nnue absent.
- **AUTO_BEST still r3**: H384 shared **0.007205** md5 **d741d7ac** (auto-n384-kb4hm-r3-10170146). NOT packed.
- Catch-up: auto_queue kept chaining LR-flat repeats **r4…r45** overnight (all warm r3, lr 1e-5 cos 8ep); every recorded shared stayed **0.007205** (same md5 a8f1d7b4 on several), none beat r3, none packed. Chain is fully flat — after r46, prefer a **new experiment** over more rN.
- **Datagen was DEAD**: forge_selfplay_006 finished PC ~03:07 Oct 17 (~18:07 PT Oct 16) with `Engine returned no score`; selfplay_guard exit 1. No live selfplay processes; no .part. **Restarted** selfplay_guard PID **8828** (Idle 0xF000) → forge_selfplay 2 workers on CPUs 12-15 → new file **D:\grok-pc-data\selfplay_out\forge_selfplay_007.txt.part** (growing). Engine PIDs 7896/10344 Idle 0xF000.
- Parent: no WakeParent/message Couns needed for GPU (busy, not idle-start). Optional note: datagen was down ~13h and is back; LR chain still flattening.

### 2026-10-17 ~07:49 PT GPU idle guard
- **auto-n384-kb4hm-r47-10171609 DONE** ~07:36 PT (PC 16:36): best ep7 shared **0.007205**, md5 **a8f1d7b4** — byte-identical duplicate of r44–r46 (warm r3, lr 1e-5 cos 8ep, same 5-source mix). Not better than AUTO_BEST r3 d741d7ac. NOT packed. UNPROVEN.
- **GPU BUSY**: auto_queue chained **auto-n384-kb4hm-r48-10171636** at 07:36 PT (PIDs 12172/11060), same deterministic config again; at ep3 (net.pt written 07:48 PT). auto_queue 1380 + thermal_guard 1800 alive; STOP_nnue absent. No action taken (job running). Note: r48 will almost certainly reproduce a8f1d7b4 again — auto_queue needs a new experiment instead of more rN repeats.
- Datagen alive: selfplay_guard 8828, forge_selfplay 6328/6504 → D:\grok-pc-data\selfplay_out\forge_selfplay_007.txt.part (62.9 MB, growing).

### 2026-10-17 ~07:50 PT — hourly (all UNPROVEN)
- GPU busy: **auto-n384-kb4hm-r48-10171636** (PIDs 12172/11060, Idle, 0xF000) started 07:37 PT, warm r3 d741d7ac, lr 1e-5 cos 8ep. r47 DONE 07:36 PT: shared 0.007205, md5 a8f1d7b4 = byte-identical to r44–r46 (deterministic repeat). AUTO_BEST unchanged: H384 r3 d741d7ac 0.007205 (not packed), H512 c3 98778fb4 0.007235.
- Cause: auto_queue fallback lr floors at 1e-5 and parent stays r3 when nothing strictly beats it, so every rN is the same run. **Fix:** backed up auto_queue.ps1 (md5 c54021af → nnue\auto_queue.ps1.bak_c54021af_1017), appended 4 new queue entries (state qi=3 so they run next): s1 H384 lr 4e-5 cos 12ep, s2 H384 lr 2e-5 cos 12ep, c4 H512 lr 5e-5 cos 10ep (from 98778fb4), s3 H384 lr 1e-5 cos 16ep. New md5 cb1346ad; parse OK; dry-run picked qi=3. Restarted supervisor: killed 1380, new auto_queue PID 10740 adopted r48 (will record it as "adopted", then launch s1). After s3 the old rN fallback resumes, so add more experiments before then (~3–4 h).
- thermal_guard 1800 alive; temps hot spot 73 C, mem junction 89 C (queue waits to launch above 80/88). Datagen alive: selfplay_guard 8828 (+13440), forge_selfplay 6328/6504, forge 7896/10344; forge_selfplay_007.txt.part 61 MB, growing. STOP_nnue absent. Free C 39 / D 163 / F 171 GB.
- PC also running QA orch_1750 slots (pcE: dist-cand-kb4hmn384a2simd-1750 gain test) — QA's, not touched. Box load 2.2; no box work this hour. No messages sent.

### 2026-10-17 ~08:15 PT — new self-play data + queue de-stuck (Engine NNUE executor, all UNPROVEN)
- **r4…r48 FAILED to beat r3**: all warm r3 d741d7ac, lr 1e-5 cos 8ep, old 5-source mix. Best shared stayed 0.007205. r43–r48 all produced md5 **a8f1d7b4** (byte-identical: same parent, same data, seed 0, lr at the floor). Not packed. Retired.
- **New data sp_new_v1** (D:\grok-pc-data\sp_new_v1; check report SP_NEW_V1_CHECK.md = PASS). Sources: the 005 tail past forge_sp_new_train's prefix, all of 006, and a 007 prefix snapshot (41,456,162 B). **train 16,845,176 (md5 9b6aa8c5ee07a94495a4ecbd155d6894) / val 341,864 (md5 daf456eee6194b4c52a928f929d35166)**, split by game (2% of 210,411 games). Rows keep result + has_result (WDL format). Leak-dropped 800 rows (val_shared 398, ...). **Exact re-check: 0 leaks** against val_shared, holdout val, sp_all val, data40m val, forgepgn val and pilot val. Decode check: 192,404 of 192,411 sampled rows byte-identical to python-chess, 0 in check, 0 invalid.
- **kbdraw_v1** (D:\grok-pc-data\kbdraw_v1): 190,800 / 10,042 synthetic dead draws (KBvKB same colour 55%, ...), score 0, draw. Aimed at a2's KBvKB +2 cp. md5 8d48a920 / 0eee503f. 0 leaks.
- Tools (grok-pc nnue\, copies in nnue/sp_new/): build_sp_new_v1.py, check_sp_new_v1.py, build_kbdraw_v1.py, build_sp_chunk.py (incremental converter for finished files, tested in a sandbox on a 46 MB 007 prefix: 63,275/924 rows, ledger and job append OK), auto_override.py (md5 074ad40e), auto_jobs.json.
- Trainer: train_gpu3kb.py got a top-of-file hook plus `--seed` (743ca859 → c56c199f). CPU parity old vs new vs new --seed 0 gives the identical net md5 c0a778c3. WDL support already existed (`--result-w`). data40m has has_result=0, so lichess stays at λ=1.0.
- Queue: auto_queue.ps1 is **not edited by me**. At 16:49 pc (07:49 PT) another agent replaced it with md5 cb1346ad (adds s1, s2, c4 H512, s3 on the OLD data) and restarted the supervisor as **PID 10740**. PID 1380 was already gone by then; I never touched it. The hook rewrites H384 `rN`/`sN` slots into the next pending job of auto_jobs.json: 24 distinct jobs, a signature repeat guard, a dup-md5 flag, 3 jobs auto-added per converted chunk, and a wait (never repeat) when empty. **s1** (old data, warm r3 lr 4e-5 cos 12ep, launched 08:11 PT, PIDs 13192/4568) is theirs and was left to run. The next H384 slot (s2) becomes **x1** = W1 mix (data40m .72, forgepgn .05, holdout .06, sp_new_train .03, pilot .04, **sp_new_v1 .097**, **kbdraw .003**), warm r3, lr 5e-5 cos 8ep, result-w 0. Then x2 (WDL 0.2), x3 (lr 1e-4 10ep), x4 (W2, SP .157), x5/x6, then the grid. c4 H512 stays theirs.

### 2026-10-23 06:00-06:25 PT — Forge RESIDUAL net pipeline (Engine NNUE executor; ALL UNPROVEN until QA locks)
**Tools** (box: /workspace/chess-tools/nnue/forge_resid/; PC: F:\forge_nnue_train\tools\; HCE source = Forge 6.4.24 @1ab50b2d, eval.cpp sha256 21b82c53…, source tree = grok-pc forge_push\build\1ab50b2d, same files/hashes as forge_1ab50b2d.srcfiles.sha256.txt):
- `hce_dump.cpp/.exe` (md5 exe ee7edee0d71f25d26f7d8a1f6537cc0a; g++ 15.2 ucrt64 -O2 static): streams `FEN|score|result`, writes int16 `Evaluator::evaluate_uncached` (stm cp) per line, header FHCE+n, `.info` sidecar with line count/bad/clamped. All 14 files: lines==records, bad=0, clamped=0.
- `fen2bin.cpp/.exe` (md5 exe 64c098e57e7ae765f254a2299019478d): `FEN|score|result` -> `.pos` (32-byte nibble board, int16 score, meta stm+white result). All 14 files lines==records, bad=0. Checked vs python-chess feature_index on 20,000 random positions of 014: 0 mismatches (features, stm, score, result).
- `train_resid.py` (md5 fe1d12817a250baa86bcbb9362fda3e4): derived from train_nnue.py (md5 5A161C70…, untouched): --residual (logit = net + K*hce/400, output layer zero init), --baseline-only, whole-file holdout, blend ramp 1.0->0.6 over progress, cosine LR + 300 warmup, batch 4096, per-epoch .pt/.inc/.bin/.json, --resume, QAT int16 scale 4096, export FORGE_NNUE_RESIDUAL 1. Loss = MSE(sigmoid(logit), blend*sigmoid(K*score/400) + (1-blend)*stm_result): same definition as tools/tune/nnue_train.cpp (lambda_cpp = 1 - blend; same offset K*hce/400; read from source, not numerically cross-run).
- `check_export.py`+`nnue_check.cpp`: python QAT forward vs forge::nnue::evaluate built with the exported .inc: smoke epoch2 net, 10,000 positions: exact vs trunc(python cp) 10000/10000 (engine truncates float cp to int; max float diff 1.000). PASS.
- HCE spot check vs engine binary forge_1ab50b2d.exe (UseNNUE=false, `go depth 1`, there is no `eval` command): 400 random 014 positions; engine score == -HCE(child after bestmove) in 317/400; for the 106 whose child has no capture/promo/check (so qsearch == stand-pat) 106/106 exact, max diff 0. Other diffs are qsearch effects.
**Data** (D:\grok-pc-data\forge_push\nnue_data\{pos,hce}\; md5 list F:\forge_nnue_train\data_md5s.txt): forge_selfplay_001..014. Train = 001..012 = 85,360,235 positions. Holdout (whole files, never trained) = 013+014 = 16,388,575 positions. 015 (.part) NOT used. Source txt md5s match the sealed .md5 files. Caveats: labels are Forge's own 5000-node search score; same game-source engine, so holdout is in-distribution; files can share opening positions; 013/014 split is by file, not by game id (a game may straddle a file boundary at most once).
**Baseline (HCE alone), holdout FULL n=16,388,096 (479 tail rows dropped by batching):** mse vs teacher (blend 1.0) **0.005070**; blend 0.6 **0.017052**; blend 0.4 0.031162; blend 0.8 0.008355; result-only 0.075621. (4M random subset: 0.005074 / 0.017059.)
**Shipped net (1ab50b2d src/nnue_weights.inc, residual H128), same holdout/loss:** teacher 0.004922 (+2.92% vs HCE), b0.6 0.016713 (+1.99%), result-only 0.074995 (+0.83%).
**Smoke** smoke_resid_h128_01 (2M pos from 001/002, 2 ep, bs4096 lr1e-3, 4M-sub val 2M): init check OK (residual init == HCE: 0.005067/0.017056 both). ep1 teacher 0.004907 (+3.16%), ep2 teacher 0.005230 (blend moved toward results, expected) / b0.6 0.016626 (+2.52%). ~400k pos/s (2M in 5s/epoch), GPU used (DirectML 7900 XT, GPU util ~60%, hot spot 58 C, mem junction 74 C during the real run).
**FULL run started** `resid_h128_e10_a` 2026-10-23 06:11 PT (PC 15:11): H128 residual, 10 epochs, bs4096, lr 1e-3 cosine->1e-5, warmup 300, blend 1.0->0.6, seed 1, QAT on, Idle, CPUs 0-11 (affinity 0x0FFF; never 12-15). run dir F:\forge_nnue_train\runs\resid_h128_e10_a (+ .log beside it), cmd: `python -u train_resid.py --train D:\...\nnue_data\pos\forge_selfplay_0*.pos --holdout ..\forge_selfplay_013.pos ..\forge_selfplay_014.pos --hce-dir ..\hce --residual --init-check --epochs 10 --batch-size 4096 --lr 1e-3 --blend-start 1.0 --blend-end 0.6 --run-dir ... --val-positions 4000000 --final-full-val --log-every 60`. ~150 s/epoch (545k pos/s), ETA ~25 min. PID: venv stub 4444 / python 3012 (priority set to Idle after start). Epoch 1 holdout: teacher 0.004151 (**+18.2% vs HCE**, shipped net +2.9%), b0.6 0.015514 (+9.1%). Strength unknown; nothing gated or packed.

### 2026-10-23 06:11-06:42 PT — FULL residual run `resid_h128_e10_a` RESULT (UNPROVEN; nothing gated, packed or engine-built)
- Run dir (PC): `F:\forge_nnue_train\runs\resid_h128_e10_a\` (settings_*.txt, per-epoch .pt/.inc/.bin/.json, log `..\resid_h128_e10_a.log`). Train = 001..012 (85,360,235 pos), holdout = 013+014 (whole files). 10 epochs, bs 4096, lr 1e-3 cosine (min 1%), blend 1.0->0.6, residual, QAT, Idle on CPUs 0-11. Finished 1,710 s (~28.5 min, ~500k pos/s). GPU hot spot ~58C, mem junction ~74C throughout.
- Holdout MSE (4.0M-pos val subset each epoch; teacher = score-only target, b0.6 = 0.6 score + 0.4 result target). HCE alone = 0.005074 / 0.017059:
  | ep | teacher | vs HCE | b0.6 | vs HCE |
  | 1 | 0.004151 | +18.2% | 0.015514 | +9.1% |
  | 2 | 0.004112 | +19.0% | 0.015331 | +10.1% |
  | 3 | 0.004124 | +18.7% | 0.015171 | +11.1% |
  | 4 | 0.004157 | +18.1% | 0.015056 | +11.7% |
  | 5 | 0.004207 | +17.1% | 0.014947 | +12.4% |
  | 6 | 0.004277 | +15.7% | 0.014865 | +12.9% |
  | 7 | 0.004367 | +13.9% | 0.014795 | +13.3% |
  | 8 | 0.004473 | +11.8% | 0.014754 | +13.5% |
  | 9 | 0.004592 | +9.5% | 0.014738 | +13.6% |
  | 10 | 0.004700 | +7.4% | 0.014736 | +13.6% |
  FINAL full holdout (16,388,096 pos): net 0.004701 / 0.014740 vs HCE 0.005070 / 0.017052. Shipped net (non-residual) was only +2.9% teacher.
- Reading: teacher MSE is best at epoch 2 and rises as the result-blend ramps (target moves toward game results, so teacher-only MSE is expected to rise); b0.6 MSE (the final-blend target) keeps improving and plateaus at ep 9-10. Net correction magnitude grows (max |net cp| 644 at ep2 vs 1086 at ep10). Candidates for strength test: ep10 (final blend, best b0.6) and ep2 (best teacher, closest to pure eval imitation). Loss does NOT predict strength; only the QA gate does.
- Export check (check_export.py: python QAT forward vs forge::nnue::evaluate from 1ab50b2d built with the exported .inc, 10,000 random positions from file 014): ep10 exact vs trunc(py cp) 9999/10000 (max diff 1), ep2 10000/10000. PASS both. Engine build flag: FORGE_NNUE_RESIDUAL 1 is in the .inc.
- md5: ep10 .inc da65098ce0612b7f18706547b0a57c84, .pt 48a5494cc1819c6632706cd919aeaed8, .bin 28a7017c2c2a5922ea43a99093c9d242. ep2 .inc 86d82c6456cede470a69b9776f157c24, .pt 5e33f7efe9b2dd18f37ba9a2d02dcac3, .bin 8f3a487ae0d4c9f2bb88d5466ee33faa.
- Caveats: holdout is in-distribution (same engine selfplay/teacher, split by file not game), possible shared opening positions across files; the +18% is therefore optimistic. Numeric cross-run vs C++ trainer not done (loss equivalence from source read only). Not gated. QA owns gating; baseline match should be vs 6.4.24 (1ab50b2d). Coder must pack the .inc into nnue_weights.inc and build; nnue.cpp/engine changes go through Coder.

### 2026-10-23 06:43-07:25 PT — Residual runs b and c (UNPROVEN; nothing gated/packed)
Common: H128 residual QAT, train = forge_selfplay_001..012 .pos (85,360,235 pos; the exact 12 files, md5s in `F:\forge_nnue_train\data_md5s.txt`), holdout = 013+014 (16,388,575 pos; 4.0M-pos val subset per epoch, full holdout at end). No newer sealed selfplay file existed (015 is still `.txt.part`, no .md5), so none added. Trainer `F:\forge_nnue_train\tools\train_resid_v2.py` md5 7640ffe617c04b24f93080deeba76149. v2 = train_resid.py plus an extra b0.8 holdout metric only (training unchanged; ckpts compatible). Idle priority, CPUs 0-11, bs 4096, lr 1e-3 cosine (min 1%, warmup 300).
HCE alone: teacher 0.005070 / b0.6 0.017052 / b0.8 0.008355 (full holdout).
Concurrency attempt: started c (PID 11220) ~5 min into b; hot spot rose 69->83C within ~30 s (limit for concurrency 80C, memj 84-86C), so I killed c (only my PIDs 11220/14140) and renamed its empty dir/logs to `resid_h128_e14_c_ABORTED_concurrent*`. Run c then re-run SEQUENTIALLY after b. Solo b peaked hot 76C / memj 90C (memj briefly above the 88C concurrency threshold, below the 92C hard limit).

#### b `resid_h128_e10_b` — pure teacher target (blend 1.0 fixed), 10 epochs. DONE (1,538 s)
- Dir `F:\forge_nnue_train\runs\resid_h128_e10_b\`, log `...\runs\resid_h128_e10_b.log`, cmd `...\resid_h128_e10_b.cmd.txt`, settings `settings_1792795432.txt`. Target used = teacher (so teacher column is the training target; b0.6/b0.8 are for comparison).
| ep | teacher | vs HCE | b0.6 | b0.8 |
| 1 | 0.004147 | +18.3% | 0.015620 | 0.007176 |
| 2 | 0.004089 | +19.4% | 0.015550 | 0.007112 |
| 3 | 0.004055 | +20.1% | 0.015481 | 0.007061 |
| 4 | 0.004034 | +20.5% | 0.015453 | 0.007036 |
| 5 | 0.004008 | +21.0% | 0.015410 | 0.007002 |
| 6 | 0.003987 | +21.4% | 0.015372 | 0.006972 |
| 7 | 0.003971 | +21.7% | 0.015351 | 0.006954 |
| 8 | 0.003960 | +22.0% | 0.015331 | 0.006938 |
| 9 | 0.003954 | +22.1% | 0.015316 | 0.006928 |
| 10 | 0.003952 | +22.1% | 0.015316 | 0.006927 |
- FINAL FULL holdout (16.39M): teacher 0.003952, b0.6 0.015317, b0.8 0.006928 (HCE 0.005070/0.017052/0.008355). Monotonic improvement; best = final = epoch 10 on all three metrics. Train MSE 0.003845 vs holdout 0.003952 (small gap, no sign of overfit).
- vs run a ep10 (blend 1.0->0.6): a ep10 full 0.004701/0.014740. a ep2 teacher 0.004112. b ep10 is best teacher-loss of all (-16% vs a ep10, -3.9% vs a ep2) but worse b0.6 than a (expected: a trained toward b0.6).
- Export check ep10 (10,000 pos vs forge::nnue::evaluate built with the .inc): exact vs trunc(py) 9999/10000, max diff 1. PASS. max|net cp| = 970.
- ep10 md5: .inc 24cf95a411f5f81cb291b0581fe5a06d, .pt a58f917a6aa518b50f2e5f2c32ef0b67, .bin 308ad264770f9922a3ce825e36326dea.

#### c `resid_h128_e14_c` — blend 1.0->0.8, 14 epochs, cosine 1e-3. started 07:12 PT (PC 16:12), PID 13228, dir `F:\forge_nnue_train\runs\resid_h128_e14_c\`; result appended when finished.

#### c `resid_h128_e14_c` RESULT — blend 1.0->0.8, 14 epochs. DONE (2,403 s; ~3 min/epoch, slower once QA/parent pinned it to CPUs 0-5). UNPROVEN.
- Dir `F:\forge_nnue_train\runs\resid_h128_e14_c\` (log `..\resid_h128_e14_c.log`, cmd `..\resid_h128_e14_c.cmd.txt`, settings `settings_1792796998.txt`). PIDs 13228 (+stub 352). Target actually used at epoch e = blend(e)*teacher + (1-blend)*result; blend went 1.0 -> 0.8 linearly over training (ep14 end = 0.8, so b0.8 column ~ target of the last epochs).
- Thermals: sampled max hot 76C / memj 90C during the first ~45% of c (monitor session was interrupted afterwards, not sampled); no abort.
| ep | train_mse | teacher | vs HCE | b0.6 | b0.8 |
| 1 | 0.004233 | 0.004147 | +18.3% | 0.015582 | 0.007157 |
| 2 | 0.004105 | 0.004093 | +19.3% | 0.015470 | 0.007074 |
| 3 | 0.004129 | 0.004069 | +19.8% | 0.015364 | 0.007009 |
| 4 | 0.004195 | 0.004059 | +20.0% | 0.015303 | 0.006974 |
| 5 | 0.004294 | 0.004047 | +20.2% | 0.015229 | 0.006931 |
| 6 | 0.004422 | 0.004043 | +20.3% | 0.015161 | 0.006895 |
| 7 | 0.004575 | 0.004040 | +20.4% | 0.015102 | 0.006864 |
| 8 | 0.004754 | 0.004047 | +20.2% | 0.015040 | 0.006836 |
| 9 | 0.004959 | 0.004056 | +20.1% | 0.014983 | 0.006812 |
| 10 | 0.005189 | 0.004065 | +19.9% | 0.014941 | 0.006796 |
| 11 | 0.005445 | 0.004075 | +19.7% | 0.014901 | 0.006781 |
| 12 | 0.005729 | 0.004090 | +19.4% | 0.014869 | 0.006772 |
| 13 | 0.006041 | 0.004112 | +19.0% | 0.014838 | 0.006768 |
| 14 | 0.006382 | 0.004130 | +18.6% | 0.014820 | 0.006768 |
- Best teacher = ep7 (0.004040); best b0.6 = ep14; best b0.8 = ep13/14 (tie, 0.006768 on the 4.0M subset).
- FULL holdout (16,388,096 pos), computed from the EXPORTED .inc via eval_inc.py (so it also proves .inc == trainer loss: ep14 0.004131/0.014824 equals the trainer's own final-full line): teacher / b0.6 / result-only(b0.0) / b0.8:
  - c ep7: 0.004041 / 0.015105 / 0.072297
  - c ep14: 0.004131 / 0.014824 / 0.071459 / b0.8 0.006771
  - b ep10: 0.003952 / 0.015317 / 0.072961 / b0.8 0.006928
  - a ep2: 0.004110 / 0.015331 / 0.072760
  - a ep10: 0.004701 / 0.014740 / 0.070395
  - HCE alone: 0.005070 / 0.017052 / 0.075621 / b0.8 0.008355
- Export parity (10,000 pos, forge::nnue::evaluate from 1ab50b2d built with the .inc; run on CPUs 0-5 Idle): c ep7 exact 10000/10000 PASS (max|net cp| 986); c ep14 exact 10000/10000 PASS (max|net cp| 1025). (a ep2 644, a ep10 1086, b ep10 970 from earlier checks.)
- md5: c ep7 .inc 5871a23c19ef4ec1bfdae78076fa91d5, .pt 83006b8c89c17c5def892e8f6019cd0b, .bin 92b1bac9feac2dd9fe345d15d573ddcb. c ep14 .inc 3fb898781b9bc788d7d8ab22f4be8fdd, .pt 432907ba970e88c6ddcd27210eba4eee, .bin 57715eb8314492c5739b31939f51bab2.
- Copies on box (md5-verified vs PC): `/workspace/chess-tools/nnue/forge_resid/resid_h128_e14_c_ep07.inc`, `..._e14_c_ep14.inc`, `resid_h128_e10_b_ep10.inc`, and `train_resid_v2.py` (md5 7640ffe617c04b24f93080deeba76149; adds b0.8 metric only). PC tool added: `launch_py_cpu0_5.ps1` (Idle, affinity 0x3F). PC staging copies on C: deleted.
- Reading: all three new/old families trade teacher MSE against result-fit: lower teacher MSE (b ep10 0.003952) vs better outcome fit (a ep10 b0.6 0.014740 / result-only 0.0704). c ep7 is a middle point (teacher within 2.2% of b ep10, b0.6 1.4% better than b ep10). Loss does not prove strength. NOT gated by me; QA owns that. No further runs started (per instruction).
- 2026-10-23 08:3x PT push check: GPU idle (no train job), no new sealed selfplay (015 still .part, 290 MB), no variant request; a ep2/ep10, b ep10, c ep14 in QA PC gate chain (CR_PASS); c ep7 not yet packed (after b/c verdicts). No action.
- 2026-10-23 09:3x PT push check: GPU idle (no train job), no new sealed selfplay (015 still .part, 424 MB), no verdict or variant request seen; a/b/c candidates still with QA. No action.
- 2026-10-23 10:3x PT push check: GPU idle (no train job), no new sealed selfplay (015 still .part, 548 MB), no verdict or variant request seen; a/b/c candidates still with QA. No action.
- 2026-10-23 11:3x PT push check: QA gate verdicts read from PC RESULT.md (all Gate 1b settings, 1000-game cap SPRT [0,10] normalized): gate2 a ep10 (da65098c) vs 6.4.24 H1 +156.3 ±27.3 (230 g); gate3 a ep2 vs 6.4.24 60.9% (322 g); gate4 b ep10 (24cf95a4) vs 6.4.24 H1 +104.6 ±24.2 (284 g); gate5 c ep14 (3fb89878) vs 6.4.24 H1 +127.1 ±23.9 (254 g); gate7 a ep10 vs c ep14 H1 +26.6 ±12.2; gate8 a ep10 vs 5101c252 H1 71.55% (232 g). Gate 9 (Sol a52efa5f) and Gate 10 (rfpavg-epa on ep10) are QA's. Reading: the blend-to-0.6 target (run a) beat pure teacher (b) and blend-to-0.8 (c), so the next run uses the a target. c ep7 pack no longer needed (a ep10 > c ep14). Sealed 015 appeared (10,000,000 pos, md5 3666476d verified).

### 2026-10-23 11:34 PT — Run d `resid_h128_e16_d` STARTED (UNPROVEN)
- Target = run a's winning recipe: blend 1.0->0.6 linear, but 16 epochs and +10M data. H128 residual QAT, cosine lr 1e-3 (min 1%, warmup 300), bs 4096, seed 1, trainer train_resid_v2.py md5 7640ffe6.
- Train = forge_selfplay_001..012 + 015 (95,360,235 pos, 13 files); holdout = 013+014 (16,388,575 pos, same as a/b/c, so losses are comparable). HCE-alone subset 0.005074/0.017059; init check OK.
- 015 converted with fen2bin.exe (10,000,000 records, bad 0) and hce_dump.exe (bad 0, clamped 0) to D:\grok-pc-data\forge_push\nnue_data\{pos,hce}\forge_selfplay_015.*.
- Launch: F:\forge_nnue_train\tools\run_d_chain.ps1 (md5-checks 015, converts, launches via launch_py_cpu0_5.ps1). Log F:\forge_nnue_train\runs\resid_h128_e16_d.log, chain log ...e16_d.chain.log, cmd ...e16_d.cmd.txt. PIDs 8612/4824, Idle. Affinity cut from CPUs 0-5 to 0-3 right after start because total CPU was 82% with Gate 9 + selfplay running; after the cut 72-73%. ~520k pos/s at start (~50-60 min total).
- Failure note: the first chain launch (PID 1264) had a bad nested `powershell -File ... -PyArgs` call; killed it (and its hce_dump child) before training started, nothing partial left, relaunched the fixed script (PID 12652).
- Thermals at start: hot spot 53 C, mem junction 72 C. RAM free 13 GB, C: 33 GB, F: 168 GB free.

#### d `resid_h128_e16_d` RESULT — blend 1.0->0.6, 16 epochs, +015 data. DONE 12:24 PT (2,953 s, ~525-550k pos/s). UNPROVEN.
- 4.0M-subset holdout per epoch (teacher / b0.6 / b0.8): ep12 0.004404/0.014706/0.006848, ep13 0.004482/0.014681, ep14 0.004556/0.014669, ep15 0.004635/0.014663 (best b0.6), ep16 0.004702/0.014665/0.006977.
- FINAL FULL holdout (16,388,096, same as a/b/c): ep16 teacher 0.004704 / b0.6 **0.014670** / b0.8 0.006981. vs a ep10 0.004701/0.014740: same teacher loss, b0.6 0.5% better (small; loss does not prove strength).
- Export parity ep16 (check_export.py, 10,000 pos from 014 vs forge::nnue::evaluate 1ab50b2d): exact 10000/10000, max|net cp| 1026. PASS. (Failure note: first try failed with g++ not found because PATH was set only in the child env; rerun with msys64 on PATH passed.)
- md5 ep16: .inc 9ef19b400e8b7509e123f9811db90101, .pt e2de12da9c483b468227eb8741734df6, .bin 0405eb3d103463007fd6ed523c778c96. Box copy forge_resid/resid_h128_e16_d_ep16.inc (md5 verified; staged via PC grok-pc\nnue\stage_d16).
- Sent to QA (pack + 1000-game gate vs a ep10, the current best net) and Code Review.

### 2026-10-23 12:31 PT — Run e `resid_h256_e12_e` STARTED (UNPROVEN)
- Why: GPU idle after d; width is the next lever (d's 16 epochs only matched a on loss). H256 smoke `smoke_resid_h256_01` (2M pos, 1 ep) passed init check and saved .inc/.bin (H256 .inc 996 KB).
- Settings: train_resid_v2.py --shape 256 --residual, run a's recipe blend 1.0->0.6, 12 epochs, cosine lr 1e-3 (warmup 300, min 1%), bs 4096, seed 1. Train 001..012+015 (95,360,235 pos), holdout 013+014 (same as a-d). Init check OK (0.005074/0.017059).
- Launch via launch_py_cpu0_3.ps1 (Idle, CPUs 0-3): PID 10344 / child 8760. Log F:\forge_nnue_train\runs\resid_h256_e12_e.log, cmd ...e12_e.cmd.txt. ~583k pos/s, ETA ~13:10 PT. Trainer ~22% of total CPU; selfplay running, no gate games at start.
- Caveat: an H256 net needs an engine build whose nnue.cpp accepts hidden=256 (check_export prints hidden=); confirm with Coder before packing.

### 2026-10-23 12:27-12:40 PT — H256 smoke + Run e `resid_h256_e12_e` STARTED (UNPROVEN)
- trainer: `train_resid_v2.py --shape 256` (unchanged file, md5 7640ffe617c04b24f93080deeba76149). `--shape` builds ft 768->256 (per perspective), out 2*256->1, SCReLU, QAT; exported .inc has `static_assert(InputCount == 768 && HiddenSize == 256 ...)` + FORGE_NNUE_RESIDUAL 1; NnueW1[196608], so Coder must build with `-DFORGE_NNUE_HIDDEN=256` (default is 128; nnue.hpp:16 `#ifndef FORGE_NNUE_HIDDEN`).
- H256 smoke: `F:\forge_nnue_train\runs\smoke_resid_h256_01\` (2.0M pos, 488 steps, 1 epoch, 4 s; holdout subset 1.0M: teacher 0.005129 vs HCE 0.005077 -> NOT better, as expected after 488 steps; b0.6 0.016661 vs 0.017049). Export parity with the 1ab50b2d source built with `-DFORGE_NNUE_HIDDEN=256` (tools\check_export2.py = check_export.py + that -D, env HID=256; md5 fae1442e346c6ab7cd30e074220a0910): 10,000 pos exact 10000/10000 vs trunc(python cp), max|net cp| 152, PASS. i.e. the 256 .inc parses, passes the static_asserts and the engine evaluate() == python forward.
- Box copy for Coder: `/workspace/chess-tools/nnue/forge_resid/h256_smoke.inc` md5 ea5347b4bdba0077938ba53ede294321 (smoke .pt md5 651993840624484fb152c41b151c7d78). This is a weak smoke net - for build/parity only, never for play.
- Run e: dir `F:\forge_nnue_train\runs\resid_h256_e12_e\`, settings_1792816229.txt (md5 0fdd430af9971a104b0acf58abc1cd2e), log `..\resid_h256_e12_e.log`, cmd `..\resid_h256_e12_e.cmd.txt`. Started 12:30 PT (PC 21:30:28), PIDs 8760 (+stub 10344), Idle, affinity 0xF (CPUs 0-3). Train = 13 files 001..012+015 (95,360,235 pos; 015 source md5 3666476d10d15e1cad48b24f61b251cc matches sealed .md5, pos md5 7d544f2d9b67722242949e7c3a506173, hce md5 7d0082d477f7e1e32095610fc71d7ba0, 10,000,000 lines/0 bad), holdout 013+014 (16,388,575). 12 epochs, bs 4096, lr 1e-3 cosine, blend 1.0->0.6, --val-positions 4M, --final-full-val. ~590-610k pos/s, ~155 s/epoch -> ~32 min total, finish ~13:03-13:08 PT (PC ~22:05).
- Epoch 1: teacher 0.004014 (+20.88% vs HCE), b0.6 0.015323 (+10.17%), b0.8 0.006962 — already better than h128 run d at epoch 1 (0.004144 / 0.015540).
- GPU guard: `F:\forge_nnue_train\tools\gpu_guard.ps1` (md5 1231b17aa3e6cc3c742d86598d0a981c; PID 7904, Idle, CPUs 0-3) SUSPENDS the trainer PIDs if hot spot >80C or memory junction >90C and resumes at <=76C/<=86C (no kill, no lost work); log `..\resid_h256_e12_e.guard.log` (absent = no events). The existing grok-pc gpu_thermal_guard.ps1 (trips STOP_nnue at hs>=88/mj>=94) was left alone. Sensor read at start: hot 64C, memj 80C.

## PC infra: GPU guard v2 + training supervisor + queue (UNPROVEN, 2026-10-23 PT ~12:5x)
- `F:\forge_nnue_train\tools\gpu_guard.ps1` v2 (old PID-list guard kept as `gpu_guard_v1.ps1.bak`). Single-instance (mutex), Idle, CPUs 0-3, PID 14080 at the time of writing. Reads the real HWiNFO columns ("GPU Hot Spot Temperature", "GPU Memory Junction Temperature") from the tail of gpu_sensors.csv every 2 s. Finds targets dynamically (every python.exe whose command line has `train_resid_v2.py`, refreshed every 10 s). SUSPENDS (NtSuspendProcess, no work lost) at hot >= 79 C or memory junction >= 89 C; RESUMES at hot <= 74 and memj <= 84; suspends if the CSV is stale/unparsable > 45 s. Log: `F:\forge_nnue_train\gpu_guard.log`. Observed on run e: hot spot peaks 72-76 C (never > 80), the memory junction is the binding limit (touches 89-92 C within seconds, guard suspends for ~15 s about every few minutes). Old system guard `grok-pc\nnue\gpu_thermal_guard.ps1` (STOP_nnue at 88/94) left alone.
- `F:\forge_nnue_train\tools\nnue_supervisor.ps1` (PID 7924 at start 21:51 PC = 12:51 PT; Idle, CPUs 0-3). Single-instance via named mutex, so a relaunch by QA's auto-restart (`powershell -NoProfile -ExecutionPolicy Bypass -File F:\forge_nnue_train\tools\nnue_supervisor.ps1`) is safe. Loop every 60 s; adopts a running train_resid_v2.py job (never starts a second); starts the guard if missing; launches the next queue.txt line via launch_py_cpu0_3.ps1 only if: no STOP_nnue (F:\forge_nnue_train\STOP_nnue, C:\...\grok-pc\nnue\STOP_nnue) and no F:\forge_nnue_train\PAUSE_supervisor, fresh temps with hot < 80 and memj < 88, free RAM >= 9 GB, C: >= 20 GB, F: >= 30 GB, < 2 consecutive failures. Never reuses a run dir. A run that ends without a "Finished:" line but has checkpoints is resumed (max 3x, `--resume <latest .pt>`). Queue empty -> auto experiment with a new timestamped name (lr 7e-4 / 2e-3 / blend-end 0.5 / 0.7 combos, 16 epochs, new seed; shape follows the last `@cond` result). Newly sealed `forge_selfplay_NNN.txt` with a matching `.md5` are converted (fen2bin + hce_dump, md5 checked first) and then automatically included in the train set (holdout stays 013+014). To pause it: create `F:\forge_nnue_train\PAUSE_supervisor`. Files: `queue.txt`, `queue_state.json`, `supervisor.log` (all in F:\forge_nnue_train).
- queue.txt after run e: `@cond resid_h256_e12_e | resid_h256_e12_f --shape 256 --epochs 12 --lr 1e-3 --blend-end 0.5 | resid_h128_e16_g_lr7e4 --shape 128 --epochs 16 --lr 7e-4 --blend-end 0.6`. Rule "e beats a ep10": FINAL FULL HOLDOUT b0.6 <= 0.014666 (>= 0.5% better than a ep10 0.014740) AND teacher <= 0.004701. This is a loss-only rule (in-distribution holdout, optimistic); QA's strength gate is the real judge.
- Supervisor test: parse check clean after fixing 3 `"$var:"` interpolation errors; Build-Args/Next-Auto/Final-Metrics/Get-Temps/Convert-NewData exercised offline (no launch); live: adopted e (queue_state.json: running, source adopted), nothing else started.

## P6 step 0: piece-count histogram + result-vs-score contradictions (UNPROVEN, measured 2026-10-23 PT ~12:5x)
- Script `forge_resid/p6_hist.py` (md5 fc5be8069e00ca2123dec8578ddb9c08), result `p6_hist_result.json` (md5 24bc4faa1a9c55375f18e0aab2b5f0f8) / `p6_hist_result.txt`. Ran on the PC at Idle, CPU 4 only, `launch_py_cpu4.ps1`, ~20 s. Training set only (001..012 + 015), every 19th record = 5,018,963 of 95,360,235 positions, bad meta 0. Piece count = non-empty nibbles (kings included). Contradiction = score > +150 and the STM lost, or score < -150 and the STM won (result converted to STM POV from the white-POV meta); draws are NOT counted as contradictions.
- Overall: |score| > 150 in 51.85% of positions; contradiction 0.623% of all positions = 1.201% of the |score|>150 positions.
| pieces | % of positions | |score|>150 % | contradiction % of all | % of strong-score | STM L/D/W % |
|---|---|---|---|---|---|
| 2-6 | 11.46 | 62.0 | 0.002 | 0.003 | 25.9/48.1/25.9 |
| 7-10 | 18.54 | 71.1 | 0.070 | 0.099 | 34.4/32.9/32.7 |
| 11-14 | 14.18 | 66.8 | 0.308 | 0.462 | 35.8/29.0/35.2 |
| 15-18 | 11.53 | 59.7 | 0.677 | 1.134 | 36.1/28.3/35.6 |
| 19-22 | 10.70 | 50.4 | 1.088 | 2.157 | 36.2/28.3/35.5 |
| 23-26 | 11.37 | 39.3 | 1.299 | 3.304 | 36.2/28.0/35.8 |
| 27-30 | 14.04 | 28.9 | 1.173 | 4.051 | 36.5/27.3/36.2 |
| 31-32 | 8.18 | 15.8 | 0.720 | 4.566 | 35.7/29.7/34.7 |
- Per-piece-count % (2..32) is in the JSON (`per_piece_count_pct`). Caveat: sampling every 19th record of consecutive game positions is unbiased for the mixture but positions within a game are correlated.

## Run e RESULT: resid_h256_e12_e FINISHED (UNPROVEN, PT 12:30 -> 14:09 on 2026-10-23; 2265 s of training, plus guard suspends)
- 12 epochs, H256 residual, a's recipe (blend 1.0 -> 0.6, cosine lr 1e-3, batch 4096), train = 001..012 + 015 (95,360,235 pos), holdout 013+014. Settings md5 0fdd430af9971a104b0acf58abc1cd2e. Run dir `F:\forge_nnue_train\runs\resid_h256_e12_e`.
- Holdout per epoch (4M-position sample; teacher / b0.6 / b0.8): ep1 .004014/.015323/.006962; ep2 .003959/.015138/.006841; ep3 .003964/.014996/.006773; ep4 .003983/.014887/.006728; ep5 .004023/.014781/.006695; ep6 .004083/.014701/.006685; ep7 .004152/.014620/.006679; ep8 .004234/.014576/.006698; ep9 .004338/.014540/.006732; ep10 .004459/.014523/.006783; ep11 .004566/.014521/.006836; ep12 .004676/.014528/.006895.
- FINAL FULL HOLDOUT (ep12, n=16,388,096): teacher 0.004679, b0.6 0.014534, b0.8 0.006900 (HCE alone 0.005070 / 0.017052 / 0.008355). vs a ep10 (H128) 0.004701 / 0.014740: teacher -0.5%, b0.6 -1.4%. vs d ep16 0.004704 / 0.014670. As with H128 the blend ramp trades teacher MSE for b0.6: best teacher is ep2 (sample .003959), best b0.6 is ep11 (sample .014521); ep12 is the end of the schedule. Full-holdout loss only measured for ep12 (ep2/ep11 only on the 4M sample).
- Parity (check_export2.py, HID=256, 10,000 random positions of file 014, engine 1ab50b2d built with -DFORGE_NNUE_HIDDEN=256): ep2 exact 10000/10000 (max|net cp| 824) PASS; ep12 exact 10000/10000 (max|net cp| 1207) PASS. ep11 not parity-checked (same export code path).
- Files (md5): ep2 `.inc` 3bd78c28bcdc7d7778aa46df42c76634, `.pt` b480ae50e43c0edeae2a0408fff0a3e1, `.bin` 7881c5ee4a0d1157463ed43a978badd1. ep11 `.inc` 0f0c51f01e1e5f587332d75182d92874, `.pt` a3e609e502cfd83c843d13aa4b93f67f, `.bin` c0d6c7ea33c60561f813f2165b6ea7c9. ep12 `.inc` 6d22f612c855e17c62d396d32da99ea4, `.pt` 553c8b70874214fcce52dec62abc1e5a, `.bin` 3dcbe78324e17bbe7eb61892c04c23db. Box copies (md5 verified): `forge_resid/resid_h256_e12_e_ep02.inc`, `_ep11.inc`, `_ep12.inc`. All 12 epochs' .inc/.pt/.bin are in the PC run dir. Needs engine build `-DFORGE_NNUE_HIDDEN=256` and `FORGE_NNUE_RESIDUAL 1`.
- Caveats: in-distribution holdout (same engine's selfplay, split by file) -> gains are optimistic; strength unknown until QA's gate. H256 NPS not measured (no g++ on the box; engine files not to be changed) - expect NNUE eval cost ~2x H128 in the accumulator update.
- Thermals during e: hot spot 62-79 C, memory junction 80-92 C; the guard suspended e 8 times (about 15-30 s each), no work lost.
- Supervisor reaction: cond "e beats a ep10" (b0.6 0.014534 <= 0.014666 and teacher 0.004679 <= 0.004701) = TRUE -> launched `resid_h256_e12_f` (H256, blend-end 0.5, otherwise identical) at 22:09:13 PC = 13:09 PT, PID 10316/14196. Guard tuning log: hot spot jumped 66 -> 84 C inside one poll at 22:13:28 PC (run f start; the guard suspended at once, back to 66 C in 8 s). I tested v2b (76/88, resume 71/83) but it suspended ~40% of the time, so the final setting is v2c: suspend hot >= 77 / memj >= 89, resume hot <= 72 / memj <= 84, poll 1 s (backups gpu_guard_v2a/v2b.ps1.bak). Guard PID 9704.
- 2026-10-23 13:29 PT hourly check: resid_h256_e12_f running (PID 10316/14196, ep6/12 done, holdout teacher .004215 b0.6 .014648 on 4M sample), supervisor 7924 + guard 9704 alive, guard suspending on memj 90 as designed, no STOP/PAUSE. No action; supervisor chains the next run (queue empty after f -> auto experiment). UNPROVEN.

## Run f RESULT: resid_h256_e12_f FINISHED, NOT a candidate (UNPROVEN, PT 13:09 -> 13:51 on 2026-10-23)
- H256 residual, same as e but blend-end 0.5 (args `--shape 256 --epochs 12 --lr 1e-3 --blend-end 0.5`), settings_1792818552.txt md5 41014edb90bd780559b63c0cd47b9373. 2463 s.
- Sample holdout: ep9 teacher .004639 b0.6 .014560; ep10 .004835/.014580; ep11 .005005/.014616; ep12 .005178/.014660.
- FINAL FULL HOLDOUT (ep12): teacher 0.005181 (WORSE than HCE 0.005070), b0.6 0.014666, b0.8 0.007217. Worse than e ep12 (0.004679 / 0.014534) on every metric. Conclusion: blend-end 0.5 overshoots; keep blend-end 0.6 or higher. Not sent for packing.
- ep12 md5: .inc 27641a08be04d79a54e6c05fee387a63, .pt b4669eb6522d4de6137282a3ee260aa0, .bin bcd2821c3ab8c49d2cab4971477488f0. Kept in PC run dir only (no box copy).
- Supervisor chained auto run `resid_h256_e16_auto000_lr7e4_b06_s2_2610232251` (H256, 16 ep, lr 7e-4, blend-end 0.6, seed 2) at 13:51 PT, PID 7152/8284.
- 2026-10-23 14:28 PT hourly check: auto000 at ep11/16 (sample ep11 teacher .004248 b0.6 .014529, roughly level with e ep11 .004566/.014521 and better on teacher), ETA ~14:45 PT. Supervisor 7924 + guard 9704 alive (33 suspends, memj binding), no STOP/PAUSE. No action.

## Run auto000 RESULT: resid_h256_e16_auto000_lr7e4_b06_s2_2610232251 FINISHED (UNPROVEN, PT 13:51 -> 14:47 on 2026-10-23)
- H256 residual, args `--shape 256 --epochs 16 --lr 7e-4 --blend-end 0.6 --seed 2` (supervisor auto run). Run dir `F:\forge_nnue_train\runs\resid_h256_e16_auto000_lr7e4_b06_s2_2610232251`.
- Sample holdout (teacher / b0.6): ep2 .003959/.015175; ep4 .003938/.014955 (best teacher); ep8 .004062/.014653; ep12 .004321/.014510; ep14 .004490/.014490 (best b0.6); ep16 .004651/.014497.
- FINAL FULL HOLDOUT (ep16, supervisor): teacher 0.004655, b0.6 0.014506. NEW BEST by loss: vs e ep12 0.004679/0.014534 = teacher -0.5%, b0.6 -0.2% (marginal; in-distribution holdout).
- md5 ep16: .inc ab049d955337b256ec82e22d6848a5e5, .bin 122edfb7fbc86917b29faa15b8172b7d, .pt 173912de381de2e5733dcab769c30784; ep14 .inc bd195cbddb58d86ebac93d026d7dfc6c. PC only, no box copy, parity (check_export2.py HID=256) NOT yet run. Needs `-DFORGE_NNUE_HIDDEN=256`, residual 1.
- Supervisor chained `resid_h256_e16_auto001_lr2e3_b06_s3_2610232347` (H256, 16 ep, lr 2e-3, blend-end 0.6, seed 3) at 14:47 PT, PID 13740/1552.
- 2026-10-23 15:29 PT hourly check: auto001 at ep12/16 (sample teacher .004393 b0.6 .014645, behind auto000 at ep12 .004321/.014510, so lr 2e-3 looks too high), ETA ~15:45 PT. Supervisor 7924 + guard 9704 alive (56 suspends, memj binding), no STOP/PAUSE, RAM free 7.6 GB, C: 32 GB, D: 123 GB, F: 168 GB. GPU busy, no action. Sent auto000 note to QA + Code Review.

## Run auto001 RESULT: resid_h256_e16_auto001_lr2e3_b06_s3_2610232347 FINISHED, NOT a candidate (UNPROVEN, PT 14:47 -> 15:43 on 2026-10-23)
- H256, 16 ep, lr 2e-3, blend-end 0.6, seed 3. FINAL FULL HOLDOUT teacher 0.004757, b0.6 0.014648: worse than auto000 (0.004655/0.014506) and e. lr 2e-3 too high. PC run dir only, not sent for packing.
- Supervisor chained `resid_h256_e16_auto002_lr1e3_b05_s4_2610240043` (H256, 16 ep, lr 1e-3, blend-end 0.5, seed 4) at 15:43 PT, PIDs 8560/13908.
- 2026-10-23 16:25 PT hourly check: auto002 at ep11/16 (sample teacher .004519 b0.6 .014545; teacher already trailing auto000 as expected with blend-end 0.5), ETA ~16:45 PT. Supervisor 7924 + guard 9704 alive (memj-bound suspends), no STOP/PAUSE, RAM free 8.7 GB, C: 32 / D: 123 / F: 168 GB free.
- Queue steering (queue.txt backup queue.txt.bak_1024a): appended `resid_h256_e16_h_lr7e4_b07_s5` (lr 7e-4, blend-end 0.7, 16 ep, seed 5) and `resid_h256_e20_i_lr5e4_b06_s6` (lr 5e-4, blend-end 0.6, 20 ep, seed 6), so the supervisor runs these instead of more blend-end 0.5 / lr 2e-3 auto combos. Note: supervisor launch needs free RAM >= 9 GB (8.7 GB while auto002 trains; should clear when it exits) - check next hour that h started.

## Run auto002 RESULT: resid_h256_e16_auto002_lr1e3_b05_s4_2610240043 FINISHED, NOT a candidate (UNPROVEN, PT 15:43 -> ~16:40 on 2026-10-23)
- H256, 16 ep, lr 1e-3, blend-end 0.5, seed 4. FINAL FULL HOLDOUT teacher 0.005204 (worse than HCE 0.005070), b0.6 0.014663, b0.8 0.007227. Confirms run f: blend-end 0.5 overshoots. PC run dir only, not sent for packing.
- Supervisor started queued `resid_h256_e16_h_lr7e4_b07_s5` (lr 7e-4, blend-end 0.7, seed 5) at ~16:41 PT (PID 11756/10696), so the RAM gate cleared.
- 2026-10-23 17:25 PT hourly check: h at ep14/16; sample ep13 teacher .004133 b0.6 .014514 (ahead of auto000 ep12 .004321/.014510 on teacher, level on b0.6), ETA ~17:40 PT; `i` (lr 5e-4, blend-end 0.6, 20 ep) queued next. Supervisor 7924 + gpu_guard 10836 alive (new PID vs 9704), selfplay alive, no STOP, RAM free 7.1 GB, C 32 / D 123 / F 168 GB. No action.

## GPU guard v3 (infra, UNPROVEN) - 2026-10-24 02:20 PC clock = 02:20 Vienna (CEST) = 17:20 PT Fri 10-23
- Why: QA found gpu_guard v2c (suspend hot>=77 / memj>=89, resume <=72/<=84, poll 1 s) let peaks reach hot 85 / memj 92 (~102 suspends). Couns's limits are 80 / 90.
- Diagnosis: HWiNFO writes gpu_sensors.csv every 2.0 s (default polling; HWiNFO64.INI has only LogFile=..., no interval key; HKCU\Software\HWiNFO64\Sensors holds only window layout). Not changed, HWiNFO not restarted. Under full load memj sits at 87-88 and hot 74-75; at each epoch-end holdout eval memj jumps +4 C (88 -> 92) inside one 2 s sample, and keeps rising 2-3 C after a suspend, so a purely reactive guard cannot hold 90.
- v3 (F:\forge_nnue_train\tools\gpu_guard.ps1, md5 16f62eb36da2bbd5258c648c774bb3f2; copy gpu_guard_v3.ps1; v2c backup gpu_guard_v2c.ps1.bak_20261024_021949; box copy pc_tools/gpu_guard_v3.ps1): HARD suspend hot>=75 or memj>=86, resume hot<=70 and memj<=82; CSV stale >20 s -> suspend. DUTY: while memj>=84 or hot>=72 (off at <=81/<=69), for 120 s after a new trainer PID, or while LEVEL>=1, the trainer rests max(1,LEVEL) s of every 4 s. LEVEL 0..3: +1 when >=4 hard suspends in 10 min (max once per 5 min), -1 after 20 min with none. Poll 0.5 s (parses only when the CSV changes), targets refreshed every 2 s. Suspend/resume only (NtSuspendProcess), never kills; try/finally resumes what it suspended; startup resumes all trainers; same mutex Global\forge_nnue_gpu_guard, same path and command line as QA's forge_watchdog. Status file F:\forge_nnue_train\gpu_guard_status.txt.
- Restart: v2c PID 9704 stopped, trainer 11756/10696 resumed by hand, v3 started PID 10836 (Idle, affinity 0xF).
- 10 min watch 02:20:40-02:30:40 Vienna (300 CSV samples): max hot 73, max memj 90 (only 02:20:42-44, carried-over heat right after the switch; 88-89 after that), 0 samples above 90, 16 hard suspends, LEVEL 0 -> 1 (02:25:39) -> 2 (02:30:39). GPU busy (util>=30) 0.597, guard run fraction 0.618 (v2c window before: max 76/92, busy 0.95). Next 170 s at LEVEL 2: max hot 66, memj 86, busy 0.48. memj barely drops with duty cycling (hovers 84-86 while hot falls to ~60), so the memory junction is the binding limit and throughput is roughly halved. Run h keeps going (ep13 02:24, ep14 02:29).
- queue.txt NOT changed: a smaller batch would not obviously cut memj and would confound comparisons with earlier runs; duty cycling already holds the limits.

## Run h RESULT: resid_h256_e16_h_lr7e4_b07_s5 FINISHED, NEW BEST by loss (UNPROVEN, Vienna 01:41 -> 02:54 on 2026-10-24 = PT 16:41 -> 17:54 Fri 10-23)
- H256 residual, args `--shape 256 --epochs 16 --lr 7e-4 --blend-end 0.7 --seed 5`, settings_1792831297.txt. Run dir `F:\forge_nnue_train\runs\resid_h256_e16_h_lr7e4_b07_s5`. Train = 001..012 + 015 (016 not yet included).
- Sample holdout (teacher / b0.6 / b0.8): ep13 .004133/.014514/.006616; ep14 .004177/.014494/.006629.
- FINAL FULL HOLDOUT (ep16, supervisor): teacher 0.004265, b0.6 0.014471 (json val b0.8 0.006660). vs auto000 ep16 0.004655/0.014506: teacher -8.4%, b0.6 -0.2%. vs HCE 0.005074/0.017059. Blend-end 0.7 beats 0.6 and 0.5; trend says milder blend helps teacher a lot at no b0.6 cost.
- md5 ep16: .inc 57a30ece2e6f07437be54b84ceebb42e, .bin 6028f04c58213adc570ca473ad886444, .pt 86732b8b700079d4e96dba0a674e9a90. PC only (CopyToBox refused: F: outside local-exec root). Parity (check_export2.py HID=256) NOT yet run; same export path as e (which passed 10000/10000). Needs `-DFORGE_NNUE_HIDDEN=256`, residual 1. Sent to QA + Code Review.
- Supervisor then converted selfplay 016 (10,000,000 records, bad 0, md5 ok) and launched queued `resid_h256_e20_i_lr5e4_b06_s6` at 02:55 Vienna (PID 1816/3240), now training WITH 016, so i is not directly comparable to h. i ep4 sample: teacher .003903 b0.6 .014966.
- 2026-10-24 03:26 Vienna hourly check: GPU busy on i (ep4/20), gpu_guard v3 at LEVEL 3 (max hot 74, memj 90 in window, 22 hard suspends), no STOP_nnue, box load 0.33. Queue steering (backup queue.txt.bak_1024b, new md5 107fd722576d70fece3ca23b744c8aa1): appended `resid_h256_e16_j_lr7e4_b08_s7` (lr 7e-4, blend-end 0.8, 16 ep, seed 7) after i.

## Run h ep16 box copy + export parity; HWiNFO CSV growth (UNPROVEN) - 2026-10-24 ~03:28-03:40 Vienna (CEST) = 18:28-18:40 PT Fri 10-23
- Box copy: `/workspace/chess-tools/nnue/forge_resid/resid_h256_e16_h_ep16.inc` md5 **57a30ece2e6f07437be54b84ceebb42e** (= PC epoch016-step000372496.inc). Path: F: -> staging C:\Users\Administrator\grok-pc\stage_h16 (md5 checked) -> CopyToBox -> staging copy and folder deleted.
- Export parity (PC, tools\check_export2.py md5 fae1442e, HID=256, 10,000 random positions of selfplay_out\forge_selfplay_014.txt, nnue_check built from the 1ab50b2d source with -DFORGE_NNUE_HIDDEN=256, Idle CPUs 0-3): **exact 9999/10000** vs trunc(python cp), max|diff| 1 (one position on a truncation boundary), mean|diff| 0.4998 vs float, max|net cp| 1122 -> **PASS** (criterion: max|d|<1.001 and >99.9% exact). Log F:\forge_nnue_train\parity_h_epoch016.log. Failure note: the first try failed with "g++ not found" (msys64 only on the child PATH, same as the ep16 d note); rerun with C:\msys64\ucrt64\bin on PATH passed; the failed stderr is kept as parity_h_epoch016_try1_gpp_notfound.log.err.
- gpu_sensors.csv (C:\...\nnue\tools\hwinfo, created 10-16 03:19 PC clock): 680,536,307 B at 03:28:11 -> 681,212,615 B at 03:39:02 PC clock (10.85 min) = **3.57 MB/h** (lifetime average ~3.5 MB/h, 681 MB over 192 h, so the rate is steady). 6-day projection: +~513 MB -> **~1.2 GB** total, well under the 5 GB rotation threshold. C: free 32.4 GB (stays ~31.9 GB after 6 days, above the 20 GB floor). **No rotation added.** gpu_guard.ps1 unchanged (v3, md5 16f62eb36da2bbd5258c648c774bb3f2, PID 10836 untouched; status file updating, last 03:29:19 hot 58 memj 78 lvl 3). HWiNFO was not touched; truncation was not tested because it is not needed.
- 2026-10-24 04:26 Vienna hourly check: GPU busy on run i (PIDs 1816/3240, ep10/20 written 04:24), gpu_guard v3 LEVEL 3 (window max hot 74, memj 90, 30 hard suspends), no STOP_nnue, box load 0.67. j queued next. No action. UNPROVEN.
- 2026-10-24 05:30 Vienna hourly check: GPU busy on run i (PIDs 1816/3240, ep16/20 written 05:23, ETA ~05:55 Vienna), gpu_guard v3 LEVEL 2 (window max hot 74, memj 90, 38 hard suspends), no STOP_nnue, box load 0.17. j queued next. No action. UNPROVEN.

## Run i RESULT: resid_h256_e20_i_lr5e4_b06_s6 FINISHED, NOT best (UNPROVEN) - Vienna 02:55 -> 05:56 on 2026-10-24
- H256, `--epochs 20 --lr 5e-4 --blend-end 0.6 --seed 6`, train includes selfplay 016 (not directly comparable to h). 2.107B positions in 10878 s.
- FINAL FULL HOLDOUT ep20: teacher 0.004609, b0.6 0.014445, b0.8 0.006821 (HCE 0.005070/0.017052/0.008355). vs h ep16 0.004265/0.014471: teacher +8.1% worse, b0.6 -0.2% (flat). Best sample ep: ep19 teacher .004549 b0.6 .014437. Lower lr 5e-4 does not help; h stays best by loss.
- md5 ep20: .inc 4c5a96fee0c8c486c92444e2163771c1, .bin eac605ffe2346606e38110560a5c8275, .pt 8f166a6fb7f38e76b7fab5985078a8bc. PC only, not packed, no parity run.
- Supervisor chained j (resid_h256_e16_j_lr7e4_b08_s7, PIDs 2312/5716) at 05:57 Vienna; ep4 at 06:28. gpu_guard v3 LEVEL 2 (max hot 74, memj 90, 47 hard suspends), no STOP_nnue.
- Queue (backup queue.txt.bak_1024c, new md5 5dac2942c065c557f0eb7cdb70820b0c): appended `resid_h256_e16_k_lr7e4_b07_s8` = h recipe retrained with 016, to separate data vs lr effect.
- 2026-10-24 07:31 Vienna hourly check: GPU busy on run j (PIDs 2312/5716, ep10/16 written 07:30, ETA ~08:30 Vienna), gpu_guard v3 LEVEL 3 (window max hot 74, memj 90, 56 hard suspends), no STOP_nnue, box load 0.75. k queued next. No action. UNPROVEN.

## Run j RESULT: resid_h256_e16_j_lr7e4_b08_s7 FINISHED, BEST TEACHER LOSS so far (UNPROVEN) - Vienna 05:57 -> 08:25 on 2026-10-24
- H256 residual, `--epochs 16 --lr 7e-4 --blend-end 0.8 --seed 7`; train includes selfplay 016 + 017 (not directly comparable to h, which had neither).
- FINAL FULL HOLDOUT ep16 (supervisor): teacher 0.003968, b0.6 0.014544 (json val b0.8 0.006546). vs h ep16 0.004265/0.014471: teacher -7.0%, b0.6 +0.5% (slightly worse). vs HCE 0.005074/0.017059. Milder blend keeps improving teacher loss at a small b0.6 cost; strength must be decided by a gate.
- md5 ep16: .inc cee0ec8d4d6dbb1114a415881149640c, .bin 91c6e516e4af9b1b76b5fed9502c5704, .pt b3e4a4b8ea85824324f4b3224d6ebb61. PC only (F:\forge_nnue_train\runs\resid_h256_e16_j_lr7e4_b08_s7\epoch016-step000421760.*). No parity run yet (same export path as h, which passed 9999/10000). Needs -DFORGE_NNUE_HIDDEN=256, residual 1. Sent to QA + Code Review.
- Supervisor converted selfplay 018 (10M records, bad 0) and launched k (resid_h256_e16_k_lr7e4_b07_s8, PIDs 13756/9704) at 08:26 Vienna; k trains with 016+017+018.
- Queue (backup queue.txt.bak_1024d): appended `resid_h256_e16_l_lr7e4_b09_s9` (blend-end 0.9, lr 7e-4, 16 ep, seed 9) after k. Note: the first append left a leading/trailing space on the two new lines (Windows arg quoting); lines were trimmed, final queue md5 ed342f0beaf02c861ec9f8a75acc3e6f.
- gpu_guard v3 LEVEL 3 (window max hot 74, memj 90, 63 hard suspends), no STOP_nnue, box load 0.71.
- 2026-10-24 09:27 Vienna hourly check: GPU busy on run k (PIDs 13756/9704, ep6/16 written 09:21, ETA ~10:55 Vienna), no STOP_nnue, box load 1.81. l queued next. No action. UNPROVEN.

## Run j ep16 box copy + export parity (UNPROVEN) - 2026-10-24 ~09:44-09:50 Vienna (CEST) = 00:44-00:50 PT Sat 10-24
- Box copy: `/workspace/chess-tools/nnue/forge_resid/resid_h256_e16_j_ep16.inc` md5 **cee0ec8d4d6dbb1114a415881149640c** (1,109,641 B; = PC runs\resid_h256_e16_j_lr7e4_b08_s7\epoch016-step000421760.inc). Path: F: -> staging C:\Users\Administrator\grok-pc\stage_j (md5 checked) -> CopyToBox (md5 checked on box) -> staging folder deleted. Finished run folder not modified (parity work dir was the staging copy).
- Export parity (PC, tools\check_export2.py, HID=256, 10,000 random positions of D:\grok-pc-data\selfplay_out\forge_selfplay_014.txt, nnue_check built from the 1ab50b2d source with -DFORGE_NNUE_HIDDEN=256, Idle CPUs 0-3 via launch_py_cpu0_3.ps1, msys64 on PATH): **exact 10000/10000** vs trunc(python cp), max|diff| 0, mean|diff| 0.5040 vs float, max|net cp| 1003 -> **PASS** (same criterion as h). Log F:\forge_nnue_train\parity_j_epoch016.log.
- Losses (full holdout): teacher 0.003968 (best so far), b0.6 0.014544 (h ep16 0.004265/0.014471). Pack request for Engine Coder (handed to Engine NNUE to send): H256 float only (never INT16), -DFORGE_NNUE_HIDDEN=256, FMA 0, FORGE_NNUE_RESIDUAL 1, ep10 base, like fc_nnue_h256_e16h_ep16_ep10base; then CR, then QA queues it next to h ep16. Trainer k / supervisor / gpu_guard / queue untouched. UNPROVEN.

## Queue fill for the 6-day GPU chain (UNPROVEN) - 2026-10-24 ~10:00 Vienna (CEST) = 01:00 PT Sat 10-24
- Backup: F:\forge_nnue_train\queue.txt.bak_1024e (md5 ed342f0beaf02c861ec9f8a75acc3e6f = previous queue). Lines written in single quotes, trimmed, appended as ASCII with CRLF (no BOM, as before). Checked: no trailing or double spaces. **New queue md5 011117233fdf21e19364f1d693f757c3.**
- Appended after k (running) and l (b0.9, queued). These are 5 H256 runs; the supervisor adds all sealed converted self-play files (016-018 and any later ones) plus the standard args by itself:
  - `resid_h256_e16_m_lr7e4_b08_s10 --shape 256 --epochs 16 --lr 7e-4 --blend-end 0.8 --seed 10` (j recipe, new seed, all latest data)
  - `resid_h256_e24_n_lr7e4_b075_s11 --shape 256 --epochs 24 --lr 7e-4 --blend-end 0.75 --seed 11` (longer schedule)
  - `resid_h256_e16_o_lr6e4_b08_s12 --shape 256 --epochs 16 --lr 6e-4 --blend-end 0.8 --seed 12`
  - `resid_h256_e16_p_lr8e4_b07_s13 --shape 256 --epochs 16 --lr 8e-4 --blend-end 0.7 --seed 13`
  - `resid_h256_e16_q_lr7e4_b085_s14 --shape 256 --epochs 16 --lr 7e-4 --blend-end 0.85 --seed 14`
- All flags are checked against the argparse in train_resid_v2.py. No run-dir name collisions. Run k is at ep10/16 (ep9 holdout sample teacher 0.003941, b0.6 0.014624; ETA ~10:55 Vienna). gpu_guard 09:58:31: hot 57, memj 82, LEVEL 3, duty on, max(hot 74, memj 90), 75 hard suspends. No STOP_nnue or PAUSE_supervisor. Trainer, supervisor, gpu_guard, self-play, gates and finished runs were not touched. Runs take ~2.5 h each with current data (n ~3.7 h), so k+l+m..q comes to ~18 h. The supervisor auto-generates runs once the queue is empty.

## Run i ep20 + auto000 ep16 box copy + export parity (UNPROVEN) - 2026-10-24 ~10:00-10:09 Vienna (CEST) = 01:00-01:09 PT Sat 10-24
- Box copy run i: `/workspace/chess-tools/nnue/forge_resid/resid_h256_e20_i_ep20.inc` md5 **4c5a96fee0c8c486c92444e2163771c1** (1,104,479 B; = PC runs\resid_h256_e20_i_lr5e4_b06_s6\epoch020-step000514440.inc).
- Box copy auto000: `/workspace/chess-tools/nnue/forge_resid/resid_h256_auto000_ep16.inc` md5 **ab049d955337b256ec82e22d6848a5e5** (1,113,395 B; = PC runs\resid_h256_e16_auto000_lr7e4_b06_s2_2610232251\epoch016-step000372496.inc).
- Path for both: F: -> staging C:\Users\Administrator\grok-pc\stage_i / stage_a0 (md5 checked) -> CopyToBox (md5 checked on box) -> staging folders deleted. Finished run folders not modified (parity work dir was the staging copy; source .inc md5 re-checked after, unchanged; no check_ dir in the runs).
- Export parity (PC, tools\check_export2.py, HID=256, 10,000 random positions of D:\grok-pc-data\selfplay_out\forge_selfplay_014.txt, nnue_check built from the 1ab50b2d source with -DFORGE_NNUE_HIDDEN=256, Idle CPUs 0-3 via launch_py_cpu0_3.ps1, msys64 on PATH; run one at a time):
  - run i ep20: **exact 10000/10000** vs trunc(python cp), max|diff| 0, mean|diff| 0.4975 vs float, max|net cp| 1470 -> **PASS**. Log F:\forge_nnue_train\parity_i_epoch020.log. (A first launch failed before compiling because g++ was not on the launcher PATH; relaunched with msys64 on PATH; same log overwritten.)
  - auto000 ep16: **exact 10000/10000**, max|diff| 0, mean|diff| 0.4994, max|net cp| 1091 -> **PASS**. Log F:\forge_nnue_train\parity_auto000_epoch016.log.
- Losses (full holdout): run i ep20 teacher 0.004609, b0.6 **0.014445 (best b0.6 so far)**; auto000 ep16 teacher 0.004655, b0.6 0.014506 (h ep16 0.004265/0.014471; j ep16 0.003968/0.014544). Pack request for Engine Coder (to be sent by Engine NNUE): H256 float only (never INT16), -DFORGE_NNUE_HIDDEN=256, FMA 0, FORGE_NNUE_RESIDUAL 1, ep10 base, like fc_nnue_h256_e16h_ep16_ep10base; then CR, then QA gate vs h256_e12 lock. Trainer k / supervisor / gpu_guard / self-play / gates / queue untouched; no STOP_nnue. UNPROVEN.

## Sol independent-teacher data (sol_indep) converted + queued as run s (UNPROVEN) - 2026-10-24 ~10:00-11:20 Vienna (CEST) = 01:00-02:20 PT Sat 10-24
- Source: Sol's independent-teacher dataset (forge-sol-buckets8 QA_REVIEW.md / FINAL_REPORT.md; Couns OK via QA). Data commit 442d5647612591a2d5a387c0513f5b482c07d6e8, branch forge/independent-teacher-data-20261023, 27 files, 723,367,402 B. Teacher = Stockfish depth 3, side-to-move cp, capped 1000, mates dropped, quiet teacher moves only; whole-game split, seed 2026102302. python-chess (GPL-3) was used by Sol as a TOOL only; nothing from it is vendored. Ideas only, no code copied.
- Integrity: archive sha256 2183a7eb4a514d2fae803989452592092b077dcaea54f95128a07d13a93af8f1 OK; all 23 parts OK. Members (sha256 OK vs RECOVERY-MANIFEST): train npz audit-prepared/train.npz (= alias prepared/train.npz) b866bba2379de3b1d9a6763485d479ade65dab2e70c6f9ad1ed0eb14ba02df76; prepared/train-provenance.jsonl.gz d64f688e5b429959ddc9c2429448f60655e950f240aaecc3b982aeed7b1b665c; prepared/validation.npz f5ba757011827e8c6fd1afd3b1b566fa5edb98bbb144a5888bebd728d477d6b2; prepared/validation-provenance.jsonl 5a857b45f8949d011ac05493e288914dd4ab97ffca6346dadca90937ba9d6d1b.
- **AUDIT split: NEVER decoded, trained on or tuned against.** audit-prepared/validation.npz sha256 97bb6205e4db5f27956f50577010aa0016534ded3c1bf9680f1b219af98f0d97 (audit manifest 949c045f..., freeze bd6da90f...). Recorded only.
- Conversion (PC, Idle, CPUs 0-3): tools in D:\grok-pc-data\forge_push\nnue_data\sol_indep\tools\ (sol_convert.py own code -> FEN|stm_cp|white_result text, checks every row's FEN features == npz features; then our fen2bin + hce_dump (Forge 1ab50b2d HCE = 6.4.24)). sol_convert.py md5 1ae10a60feda5be988d8d05cc3d887eb, eval_extra.py md5 6b03d099584b2c9d5d94c0246f5f7b09 (box copies in chess-tools/nnue/sol_indep/) -> for Code Review.
  - train: 5,390,457 rows, feature mismatch 0, bad result 0, bad score 0; perspective 0 = side to move on every row; white results 0/0.5/1 = 2,174,440 / 993,488 / 2,222,529; mean score 17.4, mean |score| 449.3. val: 295,653 rows, mismatch 0, results 122,857 / 56,493 / 116,303. fen2bin + hce_dump bad=0 clamped=0 both splits.
  - Two complete pipeline runs (10:50 and 11:02 Vienna) gave identical md5s (deterministic). (Log pipeline_try2_completed_1050.log was first thought to have died; it had finished.)
  - Cross-check: our hce_dump HCE == Sol's npz HCE on 100.000000% of rows (max|diff| 0) for train and val -> rows aligned, same HCE. Scale: Sol SF mean|cp| 449 vs our HCE 361 (ratio 1.24, corr 0.903); our self-play teacher (file 018) mean|cp| 330 vs HCE 274 (ratio 1.20, corr 0.962). Scales similar; Sol uses the same sigmoid K 2.25/400.
- Files (D:\grok-pc-data\forge_push\nnue_data\sol_indep\), md5 / bytes: sol_indep_train.pos d0cb16868bc2913b3a748d5c78e05d43 / 188,666,011; sol_indep_train.hce e7b41be7a0a1f2778e93047ff7c5c287 / 10,780,930; sol_indep_train.txt 9687584f1cbb61daf8db0d6a2b7cf526 / 373,112,321; sol_indep_val.pos 4f070f9bf54a286f332b9c26c3285d34 / 10,347,871; sol_indep_val.hce ed4aed2f9be84849db9e7d0f799c6510 / 591,322; sol_indep_val.txt 1a8482fb9c532790865a7737a4ca92d1 / 20,410,530. Hardlink D:\grok-pc-data\forge_push\nnue_data\hce\sol_indep_train.hce -> same file (md5 e7b41be7... checked) so the trainer finds hce_dir\<stem>.hce.
- **Trainer change: NONE.** train_resid_v2.py unchanged (no v3). Sol rides on the queue line's own --train (supervisor adds Train-Files only when args lack --train): glob forge_selfplay_[0-9][0-9][0-9].pos (still picks up newly sealed files at launch; trainer drops holdout 013/014) + sol_indep_train.pos. Teacher = raw SF d3 cp in the usual blend ramp 1.0 -> 0.8, game results in the (1-blend) term. Smoke (CPU, trainer's own expand/load_set/make_batch): 17 train files (001-012, 015-018 + sol), 123,363,531 positions, Sol = 4.37% at 1x weight; Sol load OK. (2-3x weight would need extra hardlinks with distinct names; not done.)
- Queue (F:\forge_nnue_train\queue.txt): another Engine NNUE task inserted the b8 line before l at 11:14 Vienna (its backup bak_1024g) and swapped in supervisor v2 (per-line --script; lines without it behave as v1, so run s is compatible). Backup queue.txt.bak_1024f md5 98e3a8069190a64fa137bf9489a64f1c, then inserted (single-quoted, trimmed, ASCII, CRLF, no BOM, compare-and-swap on md5) right after l:
  - `# 2026-10-24 11:2x Vienna (Engine NNUE sol_indep): ...`
  - `resid_h256_e16_s_lr7e4_b08_sol_s15 --shape 256 --epochs 16 --lr 7e-4 --blend-end 0.8 --seed 15 --train D:\grok-pc-data\forge_push\nnue_data\pos\forge_selfplay_[0-9][0-9][0-9].pos D:\grok-pc-data\forge_push\nnue_data\sol_indep\sol_indep_train.pos`
  - New queue md5 e117e17e80f449f582cbcc23b515e798. Order: k (done 11:10) -> b8 -> l -> **s** -> m n o p q. Could not go before l (k finished before data was ready). k took 2h44m, so s starts roughly 15:30-16:30 Vienna (06:30-07:30 PT) if PAUSE_supervisor (b8 task's file) is removed soon.
- After run s: evaluate on Sol val as an EXTRA split (CPU): `python tools\eval_extra.py --pos D:\grok-pc-data\forge_push\nnue_data\sol_indep\sol_indep_val.pos --hce-dir D:\grok-pc-data\forge_push\nnue_data\sol_indep --pt <ckpt.pt>...` (refuses any "audit" path). Compare s vs j/l on our full holdout as usual.
- Caveats: (1) Sol's own SF-only val rose each epoch -> overfitting risk; watch Sol val per epoch, not only our holdout. (2) Audit split stays unseen (sha above). (3) **Every net trained on this data must get the rook-underpromotion test** - `8/k1P5/2K5/8/8/8/8/8 w - - 0 1` expects c7c8r and mirror `8/8/8/8/8/2k5/K1p5/8 b - - 0 1` expects c2c1r - result recorded here. (4) python-chess GPL-3 = tool only, not vendored. (5) SF d3 cp scale vs our Forge teacher (similar, ratio 1.24 vs 1.20 to HCE). (6) Sol ~4.4% of data at 1x. (7) Supervisor files.txt for run s lists only the auto Train-Files list (not Sol); real list in the trainer log / cmd.txt / settings. Trainer k / gpu_guard / self-play / gates / finished runs untouched; no baseline/ written; no fastchess/SPRT; STOP_nnue absent; WATCHDOG_NO_NNUE untouched. UNPROVEN.

## buckets8 (8 piece-count output heads) H256 run b8 - trainer, parity, queue (UNPROVEN) - 2026-10-24 ~09:40-11:35 Vienna (CEST) = 00:40-02:35 PT Sat 10-24
- Order: Couns via QA. Build a real 8-head net for the buckets8 engine (Sol dwqww bde3dc9d; Engine Coder's tree fc_buckets8_h256e12). Ideas only from Sol, no Sol code in the trainer.
- **Layout (Engine Coder README_BUCKETS8.md = Sol bde3dc9d):** head = clamp((popcount(all occupied, both kings incl.) - 1) >> 2, 0, 7) on the evaluated position (2-4 pcs -> 0, 5-8 -> 1, ..., 29-32 -> 7). Shared FT: NnueW1[196608] [feature][hidden], NnueB1[256] unchanged; NnueW2[4096] head-major, W2[h*512+j] = stm hidden j, W2[h*512+256+j] = opp hidden j; NnueB2[8]; int16 round(w*4096), float inference, K 2.25, residual, 768 features, sq^56 flip. cp = trunc(out*400/2.25). Our export writes `#define FORGE_NNUE_OUTPUT_BUCKETS 8` (Sol's spelling) after `#define FORGE_NNUE_RESIDUAL 1`; Coder's nnue.cpp accepts it as an alias of FORGE_NNUE_OUTPUT_HEADS (proven: Coder tree builds and runs on our exports, below). For the step-2 handoff the define line can be renamed to FORGE_NNUE_OUTPUT_HEADS 8 with no other change.
- **Trainer (new file, v2 untouched, no v3 collision):** F:\forge_nnue_train\tools\train_resid_b8.py md5 **6841644df994e8cb984dfde6a16906bb** (box b8/train_resid_b8.py). = train_resid_v2 + 8-head Linear(512,8) with one-hot head select (no gather, DirectML safe); bucket_of(codes) = clamp((nonzero codes - 1)//4, 0, 7); --init-from .inc/.pt (+--init-md5) copies a single head into all 8; --export-init writes epoch000-step000000000.inc; --init-check with init-from = 8-head init must equal the single-head ref overall and in every bucket (1e-6); per-bucket holdout MSE (teacher, b0.6, b0.8 + HCE gains) each epoch and FINAL (FINAL FULL HOLDOUT line format kept for the supervisor); --extra-data off by default (refuses audit paths / holdout files; sol_indep not used here); --guard-tag ignored (lets gpu_guard v3's train_resid_v2\.py regex see the trainer).
- Tools: tools\check_export_b8.py md5 a021221b8671baa422cde6edfd9920d7 (step-0/export parity: Sol nnue.cpp/hpp on the 1ab50b2d tree, SSE + AVX2-no-FMA, vs single-head ref); tools\parity_heads_b8.py md5 **f9daa2d641c028d03475b1d461bb0813** (trainer-vs-engine head parity + (k+1)*64 control, engine = **Engine Coder's tree** tools\coder_fc_buckets8_h256e12: src/nnue.cpp 2a7c7beb..., include/forge/nnue.hpp 5b211e75..., tools/nnue/heads_parity.cpp 810facb0..., make_heads_inc.py d0c65730...; MSYS2 g++ -O3 -ffp-contract=off -fno-fast-math -march=znver5 -DFORGE_NNUE_HIDDEN=256 -DFORGE_NNUE_WEIGHTS_FILE); tools\make_b8_smoke.py md5 88298cec00b0326e2599ad39a5f4b2dd; tools\sol_b8_bde3dc9d\ (test harness only).
- **Smoke (CPU, Idle, CPUs 0-3, 60k prefixes of 001 train / 013 eval, F:\forge_nnue_train\b8_smoke):** INIT CHECK OK (8-head == single-head e12 overall and all 8 buckets, teacher 0.004831 / b0.6 0.015189); train MSE 0.003971 -> 0.003261 -> 0.003040; eval teacher 0.004831 -> 0.004571 (3 epochs). Step-0 .inc md5 f27f053aed25b4e1a8f709a3501144e6.
- **Step-0 parity (check_export_b8, 10,000 positions of 014, 1,250 per bucket):** python b8 vs engine exact (trunc) 10000/10000 in every bucket, SSE == AVX2 10000/10000, engine 8-head == single-head e12 (6d22f612...) net cp 10000/10000 in every bucket -> **PASS**. Python: step-0 W1 == e12, B1 == e12, all 8 W2 rows == e12 W2, B2 = 8 x 110 (e12 B2 110). Smoke ep3 (distinct heads, B2 113 112 109 120 122 119 112 109): exact 10000/10000, SSE == AVX2 -> PASS. (First launch failed: g++ not on PATH for Popen; relaunched with msys64 on PATH.)
- **QA/DR head parity + control (parity_heads_b8.py, 150 FENs per head x 8 = 1,200 from holdout 014, seed 7; trainer head = bucket_of on the .pos record the trainer reads; .pos record == FEN line codes+stm 1200/1200; every FEN logged with both heads in heads_b8.tsv):**
  - Smoke ep3 (a8998b17...): head trainer == engine 1200/1200, pieces 1200/1200, control-decoded head == trainer head 1200/1200 (unique hypothesis 1200/1200), python vs engine cp exact 1200/1200 trained and control -> **PASS** (F:\forge_nnue_train\b8_smoke\heads_ep3\). (Try 1 decoded the control head from the integer cp shift alone; trunc noise made 24/1200 ambiguous -> FAIL; fixed to decode with the python float out: exactly one h gives trunc(py_cp + 2.78*(h+1)) == control engine cp.)
  - **Live run b8 ep1 (trained, epoch001-step000029466.inc md5 d24813c43c4a5c8f6edd7b0e13ba7c38, pt 65f6039d...)**: make_heads_inc check OK hidden 256, heads 8, residual 1, only head0 identical to head0, B2 [59 54 87 131 121 116 107 80]; control B2 [123 182 279 387 441 500 555 592] check OK; head trainer == engine 1200/1200 (150/150 every head), pieces 1200/1200, **control-decoded head == trainer head 1200/1200** (shift mean per head 2.78/5.43/8.23/11.04/13.78/16.55/19.15/21.94 cp vs expected 2.78*(h+1)), python vs engine cp exact 1200/1200 (trained) and 1200/1200 (control), incremental == refresh (acc_mismatch 0) -> **PASS**. Log F:\forge_nnue_train\b8_smoke\heads_live_ep1.log, tsv heads_live_ep1\heads_b8.tsv. Rerun on the final ep8 .inc/.pt with the same command.
- **Supervisor (now QA's - do not touch):** I wrote v2 (box b8/nnue_supervisor_v2.ps1 md5 **3210732057d92a5c3dc1f81680527ff9**, LF, no BOM) from v1 (md5 11be70d04c078a0e23ca9597a8b58ef5). Diff: header comment; Get-Train regex train_resid_v2\.py -> train_resid\w*\.py (so a b8 trainer counts as running, no 2nd GPU job); Build-Args parses optional `--script <file>` (removed from args; must match ^train_resid_\w+\.py$ and exist in tools; non-v2 script gets `--guard-tag train_resid_v2.py` appended for gpu_guard v3; bad/missing -> $null); Launch marks the run failed when Build-Args returns $null. Lines without --script behave exactly as v1 (tested with AST-extracted functions on the PC). Backup of v1: F:\forge_nnue_train\tools\nnue_supervisor_v1.ps1.bak_1024g (md5 11be70d0...). Swapped at 11:14:38 Vienna with no trainer running (v1 PID 7924 stopped, v2 PID 3880 started Idle, affinity 0xF). At 11:24:54 QA replaced it with its own v2.1-qa (md5 19ac93cc5a3e3d5e554aebdcd48d39c4, PID 12716; QA backup nnue_supervisor.ps1.bak_20261024_qa); b8 trainer kept running.
- **GPU idle gap (for the record):** I created F:\forge_nnue_train\PAUSE_supervisor ~10:45 so no run launched after k (smoke needed RAM; PC had ~3.6 GB free during k). k ended 11:10:32, PAUSE removed 11:15:03, b8 launched 11:15:50 -> GPU idle ~5 min 20 s.
- **Run k result (finished 11:10:32 Vienna):** FINAL FULL holdout teacher 0.004224, **b0.6 0.014412 (new best b0.6)**, b0.8 0.006612; runs\resid_h256_e16_k_lr7e4_b07_s8\epoch016-step000460832.*.
- **Queue:** backup queue.txt.bak_1024g (md5 011117233fdf21e19364f1d693f757c3); inserted (single-quoted, trimmed, ASCII, CRLF) before l a comment + `resid_h256_b8_ft8_e12init_lr3e4_b08_s16 --script train_resid_b8.py --shape 256 --epochs 8 --lr 3e-4 --blend-end 0.8 --seed 16 --init-from F:\forge_nnue_train\runs\resid_h256_e12_e\epoch012-step000279372.inc --init-md5 6d22f612c855e17c62d396d32da99ea4 --export-init` -> md5 98e3a8069190a64fa137bf9489a64f1c (name not in queue_state, no run dir). The sol_indep task then added run s after l (md5 e117e17e...). Order: k (done) -> **b8 (running)** -> l -> s -> m n o p q.
- **Run b8 live:** launched 11:15:50 Vienna (02:15 PT), PID 8284/9980, gpu_guard targets=8284,9980 (hot 62, memj 78 at 11:20). Data 001-012, 015-019 (120.7M positions, 019 partial 2.72M), holdout 013+014 (3,997,696 subset). INIT CHECK OK on the full data (8-head == single-head, overall teacher 0.004676 / b0.6 0.014528, all 8 buckets). ~240k pos/s, 491 s/epoch. ep1: holdout teacher **0.003804** (init 0.004676), b0.6 0.014980 (init 0.014528, blend still 0.975), b0.8 0.006685; per bucket teacher 0.003517/0.002715/0.003460/0.005124/0.005984/0.005372/0.003631/0.001927. **ETA ~12:30 Vienna = 03:30 PT** incl. final full holdout.
- Coder step 2: drop the final ep8 .inc as src/nnue_weights.inc in fc_buckets8_h256e12 (no code change; rename define to OUTPUT_HEADS optional), build float FMA 0, bench vs lock, CR, then QA gate vs h256_e12. No Sol data used -> underpromotion test not required for this net. Trainer l..q / gpu_guard / self-play / gates / finished runs untouched; no baseline/; no fastchess/SPRT; STOP_nnue absent; WATCHDOG_NO_NNUE untouched. UNPROVEN.

## Run k RESULT + ep16 box copy + export parity (UNPROVEN) - 2026-10-24 ~11:10-11:32 Vienna (CEST) = 02:10-02:32 PT Sat 10-24
- Run resid_h256_e16_k_lr7e4_b07_s8 (h recipe, seed 8, +selfplay 016-018) finished 11:10:32 Vienna (9764 s). FINAL FULL HOLDOUT n=16,388,096: teacher 0.004224, **b0.6 0.014412 (new best b0.6)**, b0.8 0.006612 (HCE 0.005070/0.017052/0.008355). Per-epoch sample holdout b0.6 fell monotonically to ep16 (ep12 0.014490 ... ep16 0.014405) while teacher rose (0.004046 -> 0.004221), so ep16 picked on b0.6. vs h ep16 0.004265/0.014471, j ep16 0.003968/0.014544, i ep20 0.004609/0.014445.
- Box copy: `/workspace/chess-tools/nnue/forge_resid/resid_h256_e16_k_ep16.inc` md5 **a0542f7e13da80851cfa2b58cf989ffb** (1,112,129 B; = PC runs\resid_h256_e16_k_lr7e4_b07_s8\epoch016-step000460832.inc; .pt md5 fcc63d3b...). Path F: -> C:\Users\Administrator\grok-pc\stage_k (md5 checked) -> CopyToBox (md5 checked) -> staging deleted. Source .inc md5 re-checked unchanged; no check_ dir in the run folder.
- Export parity (PC, tools\check_export2.py, HID=256, 10,000 positions of D:\grok-pc-data\selfplay_out\forge_selfplay_014.txt, nnue_check from 1ab50b2d with -DFORGE_NNUE_HIDDEN=256, Idle CPUs 0-3 via launch_py_cpu0_3.ps1, msys64 on PATH): **exact 10000/10000**, max|diff| 0, mean|diff| 0.4945 vs float, max|net cp| 1102 -> **PASS**. Log F:\forge_nnue_train\parity_k_epoch016.log.
- Pack request sent to Engine Coder (priority, same recipe as fc_nnue_h256_e16h_ep16_ep10base, CR deadline 16:30 Vienna); FYIs to CR and QA. GPU busy on b8 run (PID 9980, ep2/8); queue has l, s, m, n, o, p, q un-run (md5 e117e17e unchanged). gpu_guard 11:20 hot 62 memj 78. Trainer/supervisor/self-play/gates untouched; no STOP_nnue. UNPROVEN.

## Run b8 (8 output heads, ft from e12) RESULT + ep8 box copy + head/export parity (UNPROVEN) - 2026-10-24 ~12:07-12:35 Vienna (CEST) = 03:07-03:35 PT Sat 10-24
- Run resid_h256_b8_ft8_e12init_lr3e4_b08_s16 (train_resid_b8.py, 8 heads, init from h256_e12 6d22f612, lr 3e-4, blend-end 0.8, 8 ep, seed 16) finished 12:06:57 Vienna. FINAL FULL HOLDOUT n=16,388,096: **teacher 0.003925 (new best teacher; j ep16 0.003968)**, b0.6 0.014513 (+0.7% vs best k ep16 0.014412), b0.8 0.006513 (best; k 0.006612). Per bucket FINAL teacher 0.003692/0.002833/0.003537/0.005235/0.006139/0.005518/0.003784/0.002037. Sample-holdout ep7 teacher 0.003895 / b0.6 0.014543 vs ep8 0.003924 / 0.014511; ep8 picked (only epoch with full holdout, better b0.6). Competitive -> packed.
- Box copy: `/workspace/chess-tools/nnue/forge_resid/resid_h256_b8_ft8_ep8.inc` md5 **09227945fea71225af619eab4ad37fcb** (= PC runs\resid_h256_b8_ft8_e12init_lr3e4_b08_s16\epoch008-step000235728.inc; .pt f8fc8193b7bbadad085d103d72c58ee7). Defines: FORGE_NNUE_RESIDUAL 1, FORGE_NNUE_OUTPUT_BUCKETS 8. Path F: -> C:\Users\Administrator\grok-pc\stage_b8ep8 (md5 ok) -> CopyToBox (md5 ok) -> staging deleted; source md5 re-checked unchanged; run folder untouched (work dirs in F:\forge_nnue_train\b8_smoke\).
- Head parity (parity_heads_b8.py, Coder tree nnue.cpp 2a7c7beb / nnue.hpp 5b211e75 / heads_parity.cpp 810facb0, 150 FENs x 8 heads from 014): head trainer==engine 1200/1200, pieces 1200/1200, control-decoded head 1200/1200, cp exact 1200/1200 trained and control, acc_mismatch 0 -> **PASS**. B2 [56 48 110 139 145 131 119 125]. Log F:\forge_nnue_train\b8_smoke\heads_live_ep8.log.
- Export parity (check_export_b8.py, 10,000 positions of forge_selfplay_014.txt, 1,250 per bucket): exact 10000/10000 every bucket (SSE and AVX2), max|diff| 1.000, mean 0.4972, max|net cp| 1143, SSE==AVX2 10000/10000 -> **PASS**. Log F:\forge_nnue_train\parity_b8_epoch008.log. Idle, CPUs 0-3, msys64 on PATH.
- Pack request to Engine Coder (priority, CR deadline 16:30 Vienna): drop this .inc as src/nnue_weights.inc in fc_buckets8_h256e12 (no code change), float only, FMA 0, H256, residual, bench vs lock, then CR, then QA gate vs h256_e12. FYIs to CR and QA. No Sol data -> underpromotion test not required.
- GPU: run l (b0.9, seed 9) training since ~12:07 at ~690k pos/s (~3 min/epoch; ep7 sample teacher 0.003807, b0.6 0.014971), ETA ~13:00 Vienna. Queue md5 e117e17e unchanged; un-run s, m, n, o, p, q (6). gpu_guard 12:32 hot 70 memj 76; RAM free 10.1 GB. No STOP_nnue/PAUSE. UNPROVEN.

## Run l RESULT + ep16 box copy + export parity (UNPROVEN) - 2026-10-24 ~13:00-13:30 Vienna (CEST) = 04:00-04:30 PT Sat 10-24
- Run resid_h256_e16_l_lr7e4_b09_s9 (h recipe, blend-end 0.9, seed 9, all sealed self-play) finished ~13:00 Vienna (3173 s, ~620k pos/s). FINAL FULL HOLDOUT n=16,388,096: **teacher 0.003789 (new best; b8 ep8 0.003925, j ep16 0.003968)**, b0.6 0.014715 (+2.1% vs best k ep16 0.014412), b0.8 0.006546 (b8 0.006513). Sample holdout teacher flat ep13-16 (0.003781-0.003790), b0.6 fell to ep16 0.014713; ep16 picked (full holdout, best b0.6). Competitive -> packed.
- Box copy: `/workspace/chess-tools/nnue/forge_resid/resid_h256_e16_l_ep16.inc` md5 **c6a5b6d1b8abc8d9b8a87e4e1c5fd541** (1,108,469 B; = PC runs\resid_h256_e16_l_lr7e4_b09_s9\epoch016-step000471456.inc; .pt 91015a1b945c4b025337718fe631b031). F: -> C:\Users\Administrator\grok-pc\stage_l (md5 ok) -> CopyToBox (md5 ok) -> staging deleted; source md5 re-checked; run folder untouched (parity ran on the staged .pt/.inc).
- Export parity (check_export2.py, HID=256, 10,000 positions of forge_selfplay_014.txt, Idle CPUs 0-3 via launch_py_cpu0_3.ps1, msys64 on PATH): **exact 10000/10000**, max|diff| 0 vs trunc, mean|diff| 0.4988 vs float, max|net cp| 1134 -> **PASS**. Log F:\forge_nnue_train\parity_l_epoch016.log.
- Pack request to Engine Coder (priority, CR deadline 16:30 Vienna; recipe = fc_nnue_h256_e16h_ep16_ep10base with only weights swapped, float, FMA 0, residual 1). FYIs to CR and QA.
- GPU: run s (Sol indep data, b0.8, seed 15) training since ~13:01, ep8/16 at ~715k pos/s, ETA ~13:50 Vienna. Queue md5 e117e17e unchanged; un-run m, n, o, p, q (5). gpu_guard 13:22 hot 54 memj 74. No STOP_nnue/PAUSE. UNPROVEN.

## Queued experiment GPU90 bs16384 (run "g90", UNPROVEN, not yet started) - 2026-10-24 ~13:50 Vienna (CEST) = 04:50 PT Sat 10-24
- **Line inserted** (grok-pc F:\forge_nnue_train\queue.txt, line 19, directly after the running run s, before m; single-quoted, trimmed, ASCII, CRLF, no comment line added): `resid_h256_e16_g90_bs16k_lr14e4_b07_s8 --shape 256 --epochs 16 --lr 1.4e-3 --blend-end 0.7 --seed 8 --batch-size 16384 --warmup-steps 150`
- **Why:** Couns wants ~90% GPU. Crew vote 6/7 for GPU90; QA bench (GPU90_PLAN.md): 4096 721k pos/s 66-70% GPU, 8192 1.31M 85%, **16384 1.62M 90-91% (hot 63, memj 80)**, 32768 rejected (memj 82, guard 83). Loader not the bottleneck (~5 ms fixed DirectML dispatch/step). CR PASS 13:48 Vienna (train_resid_v2.py md5 7640ffe6: --batch-size l.305, --warmup-steps l.308; total_steps=(N//batch)*epochs so 16 ep = same positions seen; cosine LR + blend on step/total_steps; ~N mod 16384 dropped per epoch, negligible).
- **LR:** 7e-4 x sqrt(4) = 1.4e-3 (Adam sqrt rule, DR/Malladi 2022).
- **Warmup deviation:** 150 steps vs the voted 300 (QA's suggestion): 150 x 16384 = ~2.46M positions vs k's default 300 x 4096 = ~1.23M. 300 steps would be ~4.9M.
- **Flag differences vs k** (k queue line `resid_h256_e16_k_lr7e4_b07_s8 --shape 256 --epochs 16 --lr 7e-4 --blend-end 0.7 --seed 8`; k cmd.txt otherwise only supervisor standard args): lr 7e-4 -> 1.4e-3; batch 4096 (default) -> 16384; warmup 300 (default) -> 150. Same: shape 256, epochs 16, blend 1.0->0.7, seed 8, script train_resid_v2.py, holdout 013+014, hce-dir D:\grok-pc-data\forge_push\nnue_data\hce, --residual --init-check --final-full-val --log-every 60 (all auto-added). No --train override (no Sol data -> underpromotion test not required).
- **Known data difference:** supervisor auto-adds all sealed self-play; k trained on 001-012, 015-018 (117,973,074 pos); g90 will get at least 019 too (95.3 MB .pos, ~2.72M pos) plus any file sealed before launch. Compare at equal positions seen.
- **Acceptance (before switching other queued lines to 16384):** final full holdout within 1% of k (teacher 0.004224 -> <=0.004266, b0.6 0.014412 -> <=0.014556) at equal positions seen; >=1.8x pos/s vs the 4096 runs on the same box state (l/s ~620k pos/s -> >=~1.12M); hot <=80, memj <=90 (guard 83). Own net-only gate, never pooled with 4096 checkpoints. **Fallback** `bs 8192 lr 9.9e-4` is a different line and needs its own CR before queueing.
- **Queue:** backup `F:\forge_nnue_train\queue.txt.bak_1024h` md5 e117e17e80f449f582cbcc23b515e798 (= old); new queue md5 **27465bb6d446ed862d7cde2e5793f19f**; Compare-Object: exactly one line added (=>), nothing removed/reordered; 24 -> 25 lines. Order now: s (running) -> **g90** -> m n o p q.
- **State at insert:** run s training (PID 14284, Idle, ep15/16 ~616k pos/s, ETA ~13:55 Vienna); supervisor v2.1-qa PID 12716 heartbeat 13:48. No PAUSE/STOP file. gpu_guard 13:49 hot 52, memj 72 (max 64/82), GPU util 61%, 95 W. (nnue\tools\hwinfo\gpu_sensors.csv not found on F:/D:/C: within depth 5; temps from gpu_guard_status.txt / adlx_sensors.csv.) Supervisor/trainer/self-play/gates/finished runs untouched. CR note 1 (record warmup deviation in QUEUE_PENDING.md for QA's tally) recorded here; QUEUE_PENDING.md itself not edited. UNPROVEN.

## Runs s and g90 RESULTS + ep16 box copies + export parity (UNPROVEN) - 2026-10-24 ~14:27-14:35 Vienna (CEST) = 05:27-05:35 PT Sat 10-24
- **Run s** resid_h256_e16_s_lr7e4_b08_sol_s15 (train = sol_indep\sol_indep_train.pos, lr 7e-4, b0.8, seed 15, bs4096) finished 13:58 Vienna (~605k pos/s). FINAL FULL HOLDOUT n=16,388,096: teacher 0.004004 (+5.7% vs best l 0.003789), **b0.6 0.014504 (+0.6% vs best)**, b0.8 0.006548. Competitive on b0.6 -> packed. ep16 (only epoch with full holdout).
  - Box: `forge_resid/resid_h256_e16_s_sol_ep16.inc` md5 **247fd729c6b523c89840d8c60d8a87ce** (1,109,340 B; = PC runs\...\epoch016-step000492512.inc; .pt 74763f9076015c626ec3c8976004a84c). Sol data -> **underpromotion test required**.
  - Parity (check_export2.py, HID=256, 10,000 pos of forge_selfplay_014.txt, Idle CPUs 0-3, staged copy): exact 10000/10000, max|diff| 0 vs trunc, mean 0.4955, max|net cp| 1005 -> **PASS**. Log F:\forge_nnue_train\parity_s_epoch016.log.
- **Run g90** resid_h256_e16_g90_bs16k_lr14e4_b07_s8 (k recipe, bs16384, lr 1.4e-3, warmup 150) finished 14:23 Vienna (~1.37-1.38M pos/s = 2.2x the bs4096 runs; 124,384 steps x 16384 = 2.04B positions seen vs k 1.89B, extra = newer sealed self-play). FINAL FULL HOLDOUT n=16,384,000: teacher 0.004205 (k 0.004224), **b0.6 0.014396 (NEW BEST; k 0.014412)**, b0.8 0.006594. gpu_guard max hot 64 / memj 82. **GPU90 acceptance PASS** (loss within 1% of k - actually better - and >=1.8x pos/s). Own net-only gate.
  - Box: `forge_resid/resid_h256_e16_g90_ep16.inc` md5 **ceb7dd619d7457cff4fc5aec3f4f6ee6** (1,112,660 B; = PC runs\...\epoch016-step000124384.inc; .pt 18dcec7ac70a0434f05dc02c2796e2fd).
  - Parity: exact 10000/10000, max|diff| 0, mean 0.4981, max|net cp| 1127 -> **PASS**. Log F:\forge_nnue_train\parity_g90_epoch016.log.
- Copies: F: -> C:\Users\Administrator\grok-pc\stage_g90 / stage_s (md5 ok) -> CopyToBox (md5 ok) -> staging deleted; source md5 re-checked unchanged; run folders untouched.
- Pack request to Engine Coder (priority, CR deadline 16:30 Vienna, g90 first): weights-only swap of fc_nnue_h256_e16h_ep16_ep10base, float, FMA 0, residual 1. FYIs to CR and QA.
- GPU: run m (resid_h256_e16_m_lr7e4_b08_s10, bs4096) training since ~14:24 (PIDs 14084/13852). Queue md5 27465bb6 unchanged; un-run n, o, p, q (4). gpu_guard 14:27 hot 56 memj 76. No STOP_nnue/PAUSE. Next: propose moving remaining/new queue lines to bs16384 (g90 recipe) given 2.2x throughput at equal-or-better loss. UNPROVEN.

## Queue switch n/o/p/q -> bs16384 (UNPROVEN, not yet started) - 2026-10-24 ~14:36 Vienna (CEST) = 05:36 PT Sat 10-24
- **CR PASS 14:35 Vienna.** grok-pc F:\forge_nnue_train\queue.txt: backup `queue.txt.bak_1024i` md5 27465bb6d446ed862d7cde2e5793f19f (= old); new md5 **7c6ec28c6213e180f10011ff90b4a7b2**. Line-by-line diff: only lines 22-25 changed, 25 -> 25 lines, CRLF kept (25/25), no BOM. m (line 21, bs4096) unchanged and training. None of n/o/p/q had a run dir or a queue_state entry before the edit.
  - L22 `resid_h256_e24_n_bs16k_lr14e4_b075_s11 --shape 256 --epochs 24 --lr 1.4e-3 --blend-end 0.75 --seed 11 --batch-size 16384 --warmup-steps 150` (was lr 7e-4 bs4096)
  - L23 `resid_h256_e16_o_bs16k_lr12e4_b08_s12 --shape 256 --epochs 16 --lr 1.2e-3 --blend-end 0.8 --seed 12 --batch-size 16384 --warmup-steps 150` (was lr 6e-4)
  - L24 `resid_h256_e16_p_bs16k_lr16e4_b07_s13 --shape 256 --epochs 16 --lr 1.6e-3 --blend-end 0.7 --seed 13 --batch-size 16384 --warmup-steps 150` (was lr 8e-4)
  - L25 `resid_h256_e16_q_bs16k_lr14e4_b085_s14 --shape 256 --epochs 16 --lr 1.4e-3 --blend-end 0.85 --seed 14 --batch-size 16384 --warmup-steps 150` (was lr 7e-4)
  - LR rule: bs4096 lr x 2 (sqrt of the 4x batch), warmup 150 (~2.46M positions), as for g90.
- **Watch item, p:** lr 1.6e-3 is above the highest lr tested at 16k (g90 1.4e-3). Compare p's ep1 holdout loss with o and q (g90 ep1 sample: teacher 0.003975 / b0.6 0.015330). If p diverges or sits clearly higher, add a rerun of p at 1.4e-3 as a new line (CR pre-approved).
- **bs8192 fallback rule (CR-approved):** batch 8192, lr = the line's bs4096 lr x 1.414, warmup 300; only for lines not yet started; back up queue.txt and log both md5s plus the throttle count; name suffix `_fb8k`.
- **g90 result** (resid_h256_e16_g90_bs16k_lr14e4_b07_s8, 13:58:33-14:24:35 Vienna, 85 s/epoch vs k ~407-488 s): FINAL FULL HOLDOUT teacher 0.004205 / b0.6 0.014396 / b0.8 0.006594 vs k 0.004224 / 0.014412 / 0.006612, so it passes the within-1% check. Note: "not worse, gain not credited to batch; data +2.3% confound". **Measured data difference:** g90's log reads `train: 127,381,087 positions from 18 files` vs k's 117,973,074 from 16 files (+019 2.72M, +020 6.69M) = **+8.0%**, not +2.3%; please reconcile. Full-holdout n 16,384,000 vs k 16,388,096 (remainder dropped at bs16384).
- **State at edit:** run m training (PID 14084/13852, Idle, ep4 ~736k pos/s), launched 14:24:37. No PAUSE/STOP file. gpu_guard 14:36 hot 56, memj 76 (max 64/82). Supervisor/trainer/self-play/gates/finished runs untouched. UNPROVEN.

## Run m finished + export parity (UNPROVEN) - 2026-10-24 ~15:33-15:40 Vienna (CEST) = 06:33-06:40 PT Sat 10-24
- **Run m** resid_h256_e16_m_lr7e4_b08_s10 (lr 7e-4, b0.8, seed 10, bs4096, default self-play data) finished 15:18 Vienna (~211-224 s/epoch). FINAL FULL HOLDOUT n=16,388,096: teacher 0.003943 (+4.1% vs best l 0.003789), **b0.6 0.014497 (+0.7% vs best g90 0.014396)**, b0.8 0.006514. Competitive on b0.6 -> packed. ep16 (b0.6 still falling at ep16; only epoch with full holdout).
  - Box: `forge_resid/resid_h256_e16_m_ep16.inc` md5 **ed2c7099bf086cad37eefad671264677** (1,111,055 B; = PC runs\...\epoch016-step000497568.inc; .pt b106b4cf81da178d5038586fa130d0d7).
  - Parity (check_export2.py, HID=256, 10,000 pos of selfplay_out\forge_selfplay_014.txt, Idle CPUs 0-3 via launch_py_cpu0_3.ps1, on the staged .pt/.inc): exact 10000/10000, max|diff| 0 vs trunc, mean 0.4953, max|net cp| 1078 -> **PASS**. Log F:\forge_nnue_train\parity_m_epoch016.log. Failure note: try 1 failed "g++ not found" (msys64 must be on the launcher's PATH, not only the child's); kept as parity_m_epoch016_try1_gpp_notfound.log.err.
  - Copies: F: -> stage_m (md5 ok) -> CopyToBox (md5 ok) -> staging deleted; source re-checked unchanged; run folder untouched.
  - Pack request to Engine Coder (priority; CR deadline 16:30 Vienna noted; after g90 and s). FYIs to CR and QA.
- GPU: run n (resid_h256_e24_n_bs16k_lr14e4_b075_s11) training since ~15:19, ep9/24 at 15:32 (~1.43M pos/s; PIDs 11292/3232); ep8 sample holdout teacher 0.003847 / b0.6 0.014868. Queue now 161 lines, md5 5a826aa61e8e1f6fd8524f99a8b21ef9 (6-day fill f001-f136 appended); un-run o, p, q + f001-f136. gpu_guard 15:35 hot 60 memj 81 (max 64/82). No STOP_nnue/PAUSE. C 28 GB, D 108 GB, F 167 GB free; RAM free ~15 GB. UNPROVEN.

## Queue: --val-positions 1000000 on all not-yet-started lines (UNPROVEN) - 2026-10-24 ~15:38 Vienna (CEST) = 06:38 PT Sat 10-24
- **CR PASS 15:35 Vienna.** Goal: shorter per-epoch holdout check (default 4,000,000 -> 1,000,000 random positions; train_resid_v2.py l.314/338) to shrink the per-epoch GPU dips (n showed 0-32% util about once per epoch).
- grok-pc F:\forge_nnue_train\queue.txt (after QA's 6-day install): backup `queue.txt.bak_1024j` md5 5a826aa61e8e1f6fd8524f99a8b21ef9 (= old); new md5 **ed8d5d688e901c1c61d2e7cca9337e9e**. Appended ` --val-positions 1000000` to 139 lines: L23 o, L24 p, L25 q, L26-161 f001-f136. 161 -> 161 lines; line diff: 139 changed, every one = old line + suffix exactly, 0 other changes; CRLF 161/161, no BOM. Comments, the resolved @cond, finished lines (h..m) and running n (L22) unchanged.
- Pre-checks: no line had --val-positions before (nothing skipped). nnue_supervisor.ps1 (md5 bf4ddf16, read only) Build-Args l.63 adds --final-full-val to every launched line unless already present (n's cmd.txt has it), so all f-lines keep the full 16.39M holdout at the end. Resumes use the args stored in queue_state.json, not queue.txt; no run was in needs_resume (only n running). No run dir for o/p/q/f*.
- **Rule:** per-epoch val in .json and the HCE baseline subset no longer match earlier 4M runs; compare runs and pick epochs only by the FINAL FULL HOLDOUT line.
- Supervisor/trainer/guard/self-play/gates/finished runs untouched; no PAUSE/STOP. UNPROVEN.

## Runs n and o finished + export parity, packed (UNPROVEN) - 2026-10-24 ~16:32-16:37 Vienna (CEST) = 07:32-07:37 PT Sat 10-24
- **Run n** resid_h256_e24_n_bs16k_lr14e4_b075_s11 (bs16384, lr 1.4e-3, blend-end 0.75, seed 11, 24 epochs) finished 15:57 Vienna. FINAL FULL HOLDOUT n=16,384,000: teacher 0.004065, **b0.6 0.014423 (+0.19% vs best g90 0.014396; 2nd best)**, b0.8 0.006537. Competitive -> packed. ep24 (only epoch with full holdout).
  - Box: `forge_resid/resid_h256_e24_n_ep24.inc` md5 **5a1cab10710fb802f92884d5ca54a7df** (1,116,387 B; = PC runs\...\epoch024-step000186576.inc; .pt 95d51b3f92bf4d79ccb01fad3e35f3f9).
  - Parity (check_export2.py, HID=256, 10,000 pos of D:\grok-pc-data\selfplay_out\forge_selfplay_014.txt, Idle CPUs 0-3 via launch_py_cpu0_3.ps1, on staged .pt/.inc): exact 10000/10000, max|diff| 0 vs trunc, mean 0.5021, max|net cp| 1036 -> **PASS**. Log F:\forge_nnue_train\parity_n_epoch024.log.
- **Run o** resid_h256_e16_o_bs16k_lr12e4_b08_s12 (bs16384, lr 1.2e-3, blend-end 0.8, seed 12) finished 16:23 Vienna. FINAL FULL HOLDOUT n=16,384,000: teacher 0.003939 (+4.0% vs best l 0.003789), **b0.6 0.014503 (+0.7% vs g90)**, b0.8 0.006514. Competitive on b0.6 -> packed. ep16.
  - Box: `forge_resid/resid_h256_e16_o_ep16.inc` md5 **368c9f100aa861a5e3898317835ba442** (1,107,307 B; = PC epoch016-step000124384.inc; .pt de1b3b3607e67d2fdd2d2900b9109df0).
  - Parity: exact 10000/10000, max|diff| 0, mean 0.5032, max|net cp| 1112 -> **PASS**. Log F:\forge_nnue_train\parity_o_epoch016.log.
- Copies: F: -> stage_n/stage_o (md5 ok) -> CopyToBox (md5 ok) -> staging deleted; sources re-checked unchanged; run folders untouched. Note: the first launch attempt failed before starting python (empty pos path; the file is on D:, not under grok-pc\nnue); no log was written.
- Pack requests to Engine Coder (priority; n first, both after g90/s/m; the 16:30 CR deadline had just passed). FYIs to CR and QA.
- GPU: run p (resid_h256_e16_p_bs16k_lr16e4_b07_s13) training, ep8 at 16:35 (~1.43M pos/s; PIDs 9796/11364). gpu_guard 16:34 hot 61 memj 82 (10-min max 62/82). Queue md5 now **c2948d3723494b826160ce3684c4425c** (changed by someone else since ed8d5d68; not edited by me); plenty of un-run lines (q + f001-f136). No STOP_nnue. C 28 GB, D 107 GB, F 167 GB free. Self-play running. UNPROVEN.

## Runs p and q finished + export parity, packed (UNPROVEN) - 2026-10-24 ~17:31-17:35 Vienna (CEST) = 08:31-08:35 PT Sat 10-24
- **Run p** resid_h256_e16_p_bs16k_lr16e4_b07_s13 (bs16384, lr 1.6e-3, blend-end 0.7, seed 13, v2 trainer) finished 16:48 Vienna. FINAL FULL HOLDOUT n=16,384,000: teacher 0.004214 (+11.2% vs best l 0.003789), **b0.6 0.014406 (+0.07% vs best g90 0.014396; 2nd best b0.6 overall)**, b0.8 0.006604. Competitive on b0.6 -> packed. ep16.
  - Box: `forge_resid/resid_h256_e16_p_ep16.inc` md5 **6ad348acb0f88d39a3141990c4378a45** (= PC epoch016-step000124384.inc; .pt 9342b4a1c17b896184dc298508e5e379).
  - Parity (check_export2.py, HID=256, 10,000 pos of D:\grok-pc-data\selfplay_out\forge_selfplay_014.txt, Idle CPUs 0-3, staged copies): exact 10000/10000, max|diff| 0 vs trunc, mean 0.5037, max|net cp| 964 -> **PASS**. Log F:\forge_nnue_train\parity_p_epoch016.log.
- **Run q** resid_h256_e16_q_bs16k_lr14e4_b085_s14 (bs16384, lr 1.4e-3, blend-end 0.85, seed 14) finished 17:15 Vienna. FINAL FULL HOLDOUT: **teacher 0.003861 (+1.9% vs best l; 3rd best teacher)**, b0.6 0.014609 (+1.5% vs g90), b0.8 0.006529. Competitive on both -> packed. ep16.
  - Box: `forge_resid/resid_h256_e16_q_ep16.inc` md5 **e3317599d17db0f33cf48f54971fe0a1** (= PC epoch016-step000124384.inc; .pt 3cb69fc4bbe07af45942d0f1eb865974).
  - Parity: exact 10000/10000, max|diff| 0, mean 0.5032, max|net cp| 1159 -> **PASS**. Log F:\forge_nnue_train\parity_q_epoch016.log.
- Copies: F: -> stage_p/stage_q (md5 ok) -> CopyToBox (md5 ok) -> staging deleted; sources re-checked unchanged; run folders untouched.
- Pack requests to Engine Coder (p first, then q; both after the earlier g90/s/m/n/o requests; after QA's 16:30 CR deadline). FYIs to CR and QA.
- Note: blend-end 0.85 (q) trades b0.6 for teacher, in line with j/l; lr 1.6e-3 (p) helps b0.6 but costs teacher.
- GPU: f001 (resid_h256_e16_f001_bs16k_lr14e4_b07_s20) training on **train_resid_v3a.py** (v3a deployed; PIDs 10388/2356), ep11 at 17:31. gpu_guard 17:24 hot 62 memj 82 (10-min max 64/84), occasional throttle r=0.2. Queue md5 **c25b3ec850bd7bd7fbc2ed08f6780488** (changed by someone else; not edited by me); 152 command lines, f002-f136 un-run. No STOP_nnue. C 28 GB, D 107 GB, F 167 GB free, RAM 13.1 GB free. Total CPU read 88% (self-play/other work; above the ~70% guide, not mine to stop). Self-play running. UNPROVEN.

## train_resid_v3a deploy: smoke PASS, queue switched, first reading (UNPROVEN) - 2026-10-24 07:30-08:37 PT (PC clock = Vienna, -9 h)
- Trainer: **train_resid_v3a.py md5 3c39b1c34c6c34b1b8f7ae23bac43839** (CR PASS) = v3 96916314 + 1 argparse line `--guard-tag` (ignored). v3 is not usable via the supervisor: it always adds `--guard-tag train_resid_v2.py` to non-v2 scripts, which v3 rejects (argparse exit 2), and gpu_guard only targets command lines containing train_resid_v2.py. On the PC at F:\forge_nnue_train\tools\train_resid_v3a.py (md5 verified). v3 96916314 left there unused, with train_resid_v3.SUPERSEDED.txt beside it. Live v2 16d4c8cd unchanged.
- Queue: ed8d5d68 -> backup .bak_1024k (ed8d5d68) -> smoke insert after running p (161->163 lines) **c2948d3723494b826160ce3684c4425c** -> backup .bak_1024l (c2948d37) -> switch **c25b3ec850bd7bd7fbc2ed08f6780488** (163 lines; 136 lines changed, f001-f136, each only gained `--script train_resid_v3a.py` after the name; CRLF 163/163, no BOM). q had already started on v2 (the smoke finished faster than expected), so it was not switched. These two queue edits were mine (the earlier "changed by someone else" notes above refer to them).
- Smoke (queue lines, DML, H256 bs16384 lr 1.2e-3 b0.8 warmup 150 seed 99, 2 ep, --max-train 32000000, --val-positions 1000000, sync 32, same 18 train files + supervisor args):
  | | v2ref (07:48:57 PT) | v3a (07:50:00 PT) | rel diff |
  |---|---|---|---|
  | ep1 train_mse / holdout teacher / b0.6 / b0.8 | 0.004651 / 0.004281 / 0.015588 / 0.007230 | same | 0 |
  | ep2 train_mse / holdout teacher / b0.6 / b0.8 | 0.005683 / 0.004307 / 0.015349 / 0.007123 | same | 0 |
  | FINAL FULL HOLDOUT teacher / b0.6 / b0.8 (n=16,384,000) | 0.004304 / 0.015353 / 0.007122 | same | 0 |
  | epoch time | 21 s / 21 s | 19 s / 19 s | |
  | total (Finished) | 55 s | 49 s | |
  - **Bit-identical on DML**: all 8 outputs per run (.pt/.inc/.bin/.json, ep1+ep2) have equal md5s (ep2 .inc 6714f4f1df607bc30d9c63db19dca017). v3a exited cleanly: Finished line written, empty .log.err, no leftover python process. Free RAM min 19.9 GB (v3a) / 20.2 GB (v2ref), sampled every 5 s. **PASS.**
  - Boundary gap (not logged directly; = total minus sum of epoch times, which also includes eval, saves and the final full holdout): smoke v2 13 s vs v3a 11 s. Production v2 runs o/p: 101/102 s per 16 epochs (~6.3 s per epoch).
- First v3a production line f001 (resid_h256_e16_f001_bs16k_lr14e4_b07_s20, started 08:16:06 PT, Idle, affinity 0-3, guard targets it; sync 128):
  - Epochs 1-3 at **73 s** (vs o 81 s), 1.60-1.70M pos/s, GPU mean of readings >=20% about 84% (08:16-08:20 PT), memj 84.
  - gpu_guard then soft-throttled on memj 83-84 (r 0.1-0.2, run_frac 0.85, a few duty-cycle suspends): epochs 4-15 at 81-86 s, about 1.55M pos/s cumulative.
  - 10-min reading 08:26:10-08:36:10 PT (5 s samples, n=118): GPU mean 73.1% (min 9, max 97), mean of readings >=20% 73.6%, hot spot max 63, memj max 82 (84 earlier in the run), power about 172 W, free RAM min 12.9 GB. Baselines on v2 (same sampler): p 74.7% / 78.6% (>=20%), q 74.4% / 78.4%, memj max 82.
  - throttle_fallback_watch counted 3 memj>=83 events, at 08:19, 08:23 and 08:29 PT. A 4th within 60 min triggers the _fb8k rewrite (that rewrite keeps `--script`).
  - Verdict: v3a removes the boundary gap and is about 10% faster while unthrottled, but at bs16384 the extra GPU load brings memj to 84 and the guard takes the gain back. The limit is now heat (memj), not the trainer. UNPROVEN.
- Sampler (read only, Idle, ends 10:30 PT): F:\forge_nnue_train\nnue_v3mon\mon.ps1 -> mon.csv; switch script switch_v3a.ps1 is in the same folder.

## P29 BlendDown: run f ep12 (blend-end 0.5) box copy + export parity; blend-down queue diff PROPOSED, not applied (UNPROVEN) - 2026-10-24 ~17:40-17:45 Vienna (CEST)
- Why: Strategist P29 (FORGE_IDEA_BOARD 17:45): gates vs h256_e12 lock get worse as blend-end rises (e12 b0.6 = lock; h b0.7 -4.2; j b0.8 -11.1; l b0.9 -44.5 H0) while teacher loss improves, so teacher loss is a negative signal across blend-ends. f (b0.5) was rejected by loss only, never gated.
- **Run f** = `resid_h256_e12_f` (NOT auto002; auto002 is the separate 16-ep b0.5 run). Recipe from settings_1792818552.txt (md5 41014edb) / cmd.txt: train_resid_v2.py, H256 residual, 12 epochs, batch 4096, lr 1e-3 cosine (min_lr_frac 0.01), warmup 300, blend 1.0 -> 0.5, sigmoid_k 2.25, QAT on, seed 1 (default), val_positions 4M, --final-full-val. Train = 13 files 001..012 + 015 (95,360,235 pos), holdout 013+014. Ran 22:09-22:51 PC 2026-10-23 (2463 s, ~475k pos/s).
- **f FINAL FULL HOLDOUT (ep12, n=16,388,096): teacher 0.005181, b0.6 0.014666, b0.8 0.007217** (HCE 0.005070 / 0.017052 / 0.008355; lock e ep12 0.004679 / 0.014534 / 0.006900). Teacher is 2.2% worse than HCE alone. Only ep12 has a full holdout; 4M sample ep9 .004639/.014560, ep12 .005178/.014660.
- Box copy: `/workspace/chess-tools/nnue/forge_resid/resid_h256_e12_f_b05_ep12.inc` md5 **27641a08be04d79a54e6c05fee387a63** (1,129,413 B) = PC runs\resid_h256_e12_f\epoch012-step000279372.inc (.pt b4669eb6522d4de6137282a3ee260aa0, .bin bcd2821c3ab8c49d2cab4971477488f0). F: -> C:\Users\Administrator\grok-pc\stage_f (md5 ok) -> CopyToBox (md5 ok) -> source re-checked unchanged -> staging deleted. Run folder untouched (parity work dir was in the staging copy).
- Export parity (check_export2.py, HID=256, 10,000 pos of D:\grok-pc-data\selfplay_out\forge_selfplay_014.txt, Idle CPUs 0-3 via launch_py_cpu0_3.ps1, msys64 on PATH, staged .pt/.inc): **exact 10000/10000**, max|diff| 0 vs trunc, mean 0.4987, max|net cp| 1206 -> **PASS**. Log F:\forge_nnue_train\parity_f_epoch012.log (empty .err). Build: same as e12 lock (-DFORGE_NNUE_HIDDEN=256, residual 1, float, FMA 0), weights only.
- **Queue diff PROPOSED (not applied; needs CR PASS + crew vote):** `forge_resid/p29/queue_blenddown_proposed.txt` md5 **ee0680a9e40b45d8b1c0712876cb17ec** (165 lines, CRLF 165/165, no BOM, ASCII), base copy `p29/queue_c25b3ec8_current.txt` (c25b3ec8, 163 lines), diff `p29/queue_blenddown.diff` (md5 a12222c4). Changes: (a) 134 un-run lines f003-f136 (L30-163): only `--blend-end` value and the name's `_bNN` suffix changed, 0.7->0.6 (67), 0.8->0.5 (33), 0.75->0.55 (17), 0.65->0.45 (17); epochs, lr, seed, Sol --train, --script, bs, warmup, val unchanged (token-checked). (b) +2 lines after running f002 (L29): a comment and `resid_h256_e12rec_b04_s200 --script train_resid_v3a.py --shape 256 --epochs 12 --lr 2e-3 --blend-end 0.4 --seed 200 --batch-size 16384 --warmup-steps 150 --val-positions 1000000` (e12 lock recipe at the GPU90 rule: bs4096 -> 16384, lr 1e-3 x2, warmup 300 -> 150). f001 (done) and f002 (running since 17:39 Vienna) unchanged. Supervisor picks the first queue line not in queue_state/runs, so the e12rec line would run right after f002.
- Risks: f and auto002 (b0.5) were both worse than HCE on teacher; skill pitfall says blend < ~0.6 can make nets worse than HCE. After the rewrite 67 lines sit at 0.6 and 67 below 0.6 (0.55/0.5/0.45), plus 0.4 for e12rec. Suggest gating f ep12 first and only applying (b) plus the 0.7->0.6 part if f does not gate badly. Not node-identical. UNPROVEN.
- **PHASE 1 proposal (17:44 Vienna, box only, not applied; supersedes the 0.5/0.45 mapping above until f ep12 is gated).** Live queue re-read: md5 **13c921bd69eca4037a756ab4998361bc** (163 lines). Changed since c25b3ec8 by the _fb8k throttle fallback at 17:42:56 Vienna (backup queue.txt.bak_fb8k_20261024_174256 = c25b3ec8): all 134 un-run f003-f136 are now bs8192, lr x0.707, warmup 300, name suffix _fb8k. f001 done; f002 running (only f001/f002 have run dirs).
  - `p29/queue_blenddown_phase1.txt` md5 **9b737cc428434102f91de881c01f95ef** (165 lines, CRLF, no BOM, ASCII, trimmed), diff `p29/queue_blenddown_phase1.diff` (753125bb), base copy `p29/queue_13c921bd_current.txt`. (a) The option-2 comment + `resid_h256_e12rec_b04_s200` line (bs16384 lr 2e-3 warmup 150), unchanged text, after f002 (L30-31). (b) 134 lines -> `--blend-end 0.6` + `_b06_` name: 0.7 x67, 0.8 x33, 0.75 x17, 0.65 x17; only those two tokens change. 152 run names, all unique; f-line seeds unique.
  - Variant `p29/queue_blenddown_phase1_fb8k_variant.txt` md5 3744bf6a5cb37a022c3bff11268b9d4b (diff be66ff5f): the same, but the option-2 line follows the active fallback: `resid_h256_e12rec_b04_s200_fb8k ... --lr 1.414e-3 --batch-size 8192 --warmup-steps 300`, with a phase-1 comment. UNPROVEN.

## P29 BlendDown PHASE 1 APPLIED to queue.txt (UNPROVEN) - 2026-10-24 17:46:53 Vienna (CEST)
- Approval: CR PASS (variant 3744bf6a, diff be66ff5f, base 13c921bd) + crew vote 6/7. Applied by Engine NNUE.
- Pre-checks: live md5 13c921bd69eca4037a756ab4998361bc (= base); no f003-f136 or e12rec name in queue_state.json or runs\ (only f001 done, f002 running).
- Backup `F:\forge_nnue_train\queue.txt.bak_1024m` md5 13c921bd69eca4037a756ab4998361bc (verified). Wrote the staged box file (p29/queue_blenddown_phase1_fb8k_variant.txt, staged md5 verified, staging deleted) with [IO.File]::WriteAllBytes.
- Live queue.txt now **3744bf6a5cb37a022c3bff11268b9d4b**: 37,284 B, 165 lines, CRLF 165/165, no BOM. 153 non-comment lines (= 152 unique run names + the resolved @cond line); all unique.
- Content: `resid_h256_e12rec_b04_s200_fb8k --script train_resid_v3a.py --shape 256 --epochs 12 --lr 1.414e-3 --blend-end 0.4 --seed 200 --batch-size 8192 --warmup-steps 300 --val-positions 1000000` after f002 (e12 lock recipe at the _fb8k rule); f003-f136 blend-end 0.65/0.7/0.75/0.8 -> 0.6 with _b06_ names (67/33/17/17 = 134), everything else unchanged.
- Supervisor PID 12716 untouched; f002 still running (PIDs 6972/7036, ep6 ~1.59M pos/s at 17:47). Simulating the supervisor's queue loop: next launch = resid_h256_e12rec_b04_s200_fb8k. Phase 2 (some lines to 0.5) waits for f ep12's gate. UNPROVEN.

## Runs f001, f002, e12rec finished; f001 + e12rec parity PASS, pack requested; f002 not packed (UNPROVEN) - 2026-10-24 18:31-18:40 Vienna (CEST)
- GPU check 18:32: f003 `resid_h256_e32_f003_bs16k_lr14e4_b06_s22_fb8k` running since 18:23:18 (PIDs 7052/8376, v3a via --script, ep8 ~1.44M pos/s); gpu_guard 18:34 hot 60 memj 80, lvl 0. Queue md5 3744bf6a (unchanged since my phase-1 apply), f004-f136 un-run (133 lines). STOP_nnue absent. Free RAM 12.5 GB, C: 28.3 GB. Self-play untouched.
- **f001** `resid_h256_e16_f001_bs16k_lr14e4_b07_s20` (v3a, bs16384, lr 1.4e-3, blend-end 0.7, seed 20, 16 ep) DONE 17:39. FINAL FULL HOLDOUT: teacher 0.004215, **b0.6 0.014403 (new best b0.6, just ahead of p 0.014406 and k 0.014412)**. ep16 .inc md5 **b55ac19bed08f3d35aa3c9853842c42a** (.pt 22fad849624c7948e0630bd038914218) -> box `forge_resid/resid_h256_e16_f001_b07_ep16.inc`. Parity: exact 10000/10000, max|diff| 0 vs trunc, mean 0.4945, max cp 1124 -> PASS (F:\forge_nnue_train\parity_stage_f001_epoch016.log). Packed: requested (Coder).
- **f002** `resid_h256_e16_f002_bs16k_lr12e4_b08_s21` (v3a, bs16384, lr 1.2e-3, blend-end 0.8, seed 21) DONE 18:04. FINAL FULL HOLDOUT: teacher 0.003941, b0.6 0.014506. Competitive on loss but **not packed**: blend-end 0.8 (j b0.8 gated -11.1 vs e12; P29 says teacher loss is a negative signal across blend-ends). Kept on the PC; can be packed later if a b0.8 net ever gates well.
- **e12rec** `resid_h256_e12rec_b04_s200_fb8k` (v3a, e12 lock recipe at _fb8k: bs8192, lr 1.414e-3, warmup 300, blend-end 0.4, seed 200, 12 ep; 19 min) DONE 18:23. FINAL FULL HOLDOUT: teacher 0.005675 (12% worse than HCE 0.005077), b0.6 0.014780 (+2.6% vs best), b0.8 n/a in supervisor line (ep12 json sample b0.8 0.007530). Packed anyway as the P29 blend-down probe (direction the gates point to; loss across blends not comparable). ep12 .inc md5 **8c4304ca58e62590ff2c61407e791598** (.pt 9f04d72616217ec980d801c93b85e45e) -> box `forge_resid/resid_h256_e12rec_b04_s200_fb8k_ep12.inc`. Parity: exact 10000/10000, max|diff| 0, mean 0.5006, max cp 1130 -> PASS (parity_stage_e12rec_epoch012.log). Pack requested (Coder).
- Staging (C:\Users\Administrator\grok-pc\stage_f001, stage_e12rec): md5 equal at source/stage/box, sources re-hashed unchanged after parity, staging deleted. Run folders untouched. UNPROVEN.

## Run f003 finished; ep32 parity PASS, pack requested (UNPROVEN) - 2026-10-24 19:26-19:40 Vienna (CEST)
- GPU check 19:26: f004 `resid_h256_e16_f004_bs16k_lr14e4_b06_sol_s23_fb8k` running (PIDs 13100/6884, v3a, Idle; ep8 holdout-subset teacher 0.004042 b0.6 0.014571; ep9 ~1.43M pos/s). Queue md5 3744bf6a unchanged; 133 queue lines without a run folder. STOP_nnue absent. Free RAM 11.8 GB, C: 28.3 GB. Self-play untouched.
- **f003** `resid_h256_e32_f003_bs16k_lr14e4_b06_s22_fb8k` (v3a, bs8192, lr 9.898e-4, warmup 300, blend-end 0.6, seed 22, 32 ep, 2964 s; the `bs16k_lr14e4` in the name is stale, the `_fb8k` suffix is what ran) DONE. FINAL FULL HOLDOUT (n=16.4M): teacher 0.004606, **b0.6 0.014371 (new best b0.6; f001 0.014403, p 0.014406)**, b0.8 0.006782; HCE 0.005070/0.017052/0.008355. Per-epoch subset b0.6 flat 0.01436-0.01437 from ep26-32 while teacher rose 0.00426->0.00461 (longer run trades teacher for blend). Picked ep32 (the epoch the full holdout measured).
- **Corrected 2026-10-24 20:05 Vienna (CEST):** this entry said bs16384 / lr 1.4e-3 (from the run name). The _fb8k throttle fallback (17:42:56 Vienna) rewrote the queue line to bs8192 / lr 9.898e-4 / warmup 300 before launch. Evidence: F:\forge_nnue_train\runs\resid_h256_e32_f003_bs16k_lr14e4_b06_s22_fb8k\settings_1792891397.txt L1 (argv) + L33-46 (epochs 32, batch_size 8192, lr 0.0009898, warmup_steps 300, blend_end 0.6, seed 22), run .log L8 `batch=8192 lr=0.0009898`, queue.txt (3744bf6a) L32. e12rec run_name `resid_h256_e12rec_b04_s200_fb8k` confirmed from its run dir (settings_1792890253.txt L1).
- ep32 .inc md5 **80a35e2fd31c5294ebe9d0bc8198817e** (.pt 611b4b673d0ae070ab20aab7a962e9ef) -> box `forge_resid/resid_h256_e32_f003_b06_ep32.inc`. md5 equal at source/stage/box; source re-hashed after parity unchanged; staging C:\Users\Administrator\grok-pc\stage_f003 deleted; run folder untouched.
- Parity (HID=256, 10000 pos forge_selfplay_014.txt, Idle CPUs 0-3): exact 10000/10000, max|diff| 0 vs trunc, mean 0.5011, max cp 1250 -> PASS (F:\forge_nnue_train\parity_stage_f003_epoch032.log). First attempt failed before compiling because g++ (C:\msys64\ucrt64\bin) was not on the launching shell's PATH (subprocess lookup uses the parent PATH, not the env the script builds); kept as parity_stage_f003_epoch032_nopath.log.err.
- Pack requested from Coder (same recipe as fc_nnue_h256_e16h_ep16_ep10base); FYIs to CR and QA.

## Runs f004, f005 finished; both parity PASS, pack requested (UNPROVEN) - 2026-10-24 20:24-20:30 Vienna (CEST)
- GPU check 20:25: f006 `resid_h256_e48_f006_bs16k_lr10e4_b06_s25_fb8k` running since 20:23:03 (PIDs 2336/4960, v3a); gpu_guard 20:25 hot 59 memj 78 (10-min max 64/84), lvl 0. Queue md5 3744bf6a unchanged; 152 run lines, 35 run dirs. STOP_nnue absent. Free RAM 13.7 GB, C: 28.1 GB. Self-play untouched. Supervisor converted forge_selfplay_021 at 19:39 (now in the f005+ train glob).
- **f004** `resid_h256_e16_f004_bs16k_lr14e4_b06_sol_s23_fb8k` (v3a, bs8192, lr 9.898e-4, warmup 300, blend-end 0.6, seed 23, 16 ep; train = forge_selfplay_[0-9][0-9][0-9].pos + **sol_indep_train.pos**; settings_1792894403.txt L1; name's bs16k_lr14e4 is stale) DONE 19:39. FINAL FULL HOLDOUT: teacher 0.004576, b0.6 0.014407 (+0.25% vs f003). First b0.6 net with Sol data. ep16 .inc md5 **4c8ba6ddc43b49869d9d2e692c448b28** (.pt b0d555dd1c17916fde3cd53b7f9f9d22) -> box `forge_resid/resid_h256_e16_f004_b06_sol_ep16.inc` (1,116,843 B). Parity: exact 10000/10000, max|diff| 0 vs trunc, mean 0.4953, max cp 1001 -> PASS (F:\forge_nnue_train\parity_stage_f004_epoch016.log). Pack requested (Coder, after f005).
- **f005** `resid_h256_e24_f005_bs16k_lr10e4_b06_s24_fb8k` (v3a, bs8192, lr 7.07e-4, warmup 300, blend-end 0.6, seed 24, 24 ep; self-play 001-012,015-021, no Sol; settings_1792895997.txt L1) DONE 20:23. FINAL FULL HOLDOUT: teacher 0.004570, **b0.6 0.014357 (new best b0.6; f003 0.014371)**. ep24 .inc md5 **0ae059d15aa0bc3c3e7f01aa56d9f4fd** (.pt b59bea15fba849b28aaef972be802ff2) -> box `forge_resid/resid_h256_e24_f005_b06_ep24.inc` (1,108,046 B). Parity: exact 10000/10000, max|diff| 0, mean 0.4983, max cp 1355 -> PASS (parity_stage_f005_epoch024.log). Pack requested (Coder, first).
- md5 equal at source/stage/box; sources re-hashed after parity unchanged; staging C:\Users\Administrator\grok-pc\stage_f004/stage_f005 deleted; run folders untouched. msys64 prepended to PATH in the launching shell (script box copy forge_resid/scripts/stage_parity_f004_f005.ps1). UNPROVEN.

## train_resid_v3b (RAM / DML-leak fix) built + box smoke PASS, queue diff PROPOSED (UNPROVEN) - 2026-10-24 21:30-22:00 Vienna
- Finding: trainer private memory grows ~24 KB per training step on DirectML (v2 and v3a alike, independent of batch size; QA mon.csv slopes p/q v2 -110..-116 MB/min, f001 -130, f003/f004 bs8k -262/-266). CPU on the box: no growth. f006 (e48, 805k steps) reached 28.4 GB private at ep45 21:46; commit 47.4/48.3 GB (fixed 16 GB pagefile).
- **train_resid_v3b.py md5 b6758004d19837c8d34d401ee7af5fd5** (v3work/v3b/; diff v3a_to_v3b.diff f97f80ba): --dev-scalars 1 (blend/1-blend and Adam -lr/bc1, bc2s as preallocated device tensors via copy_), int32 shuffle order in 1 reused buffer (--order-buffers 2 option), --mmap-data (off), MEM private/avail log lines + --max-ram-gb warning; --guard-tag kept.
- Box smoke (CPU, seed 99, 2 ep, max-train 32M synthetic, H256 bs8192 150 steps/ep): all 8 outputs md5-identical for v3a, v3b, v3b --mmap-data, --order-buffers 2, --dev-scalars 0 (ep2 .inc e2550a7d). Peak RSS v3a 2218 MB, v3b 1851 MB; mmap private 0.57 GB. DML bit-identity and the leak fix need a PC smoke. Probe: v3work/v3b/dml_leak_probe.py (2e543b26), not run on PC.
- Est. f006-size RAM without leak: v3a ~9.6-10.1 GB, v3b ~7.9-8.4 GB, v3b --mmap-data ~2.8-3.3 GB private.
- Queue diff PROPOSED, not applied: base 3744bf6a (fresh 21:45) -> queue_v3b_cap400k_proposed.txt **715a795a91e10d76e9f8a85cd5607241**: 130 not-started lines -> train_resid_v3b.py; 65 lines e24/e32/e48 -> e20 (names renamed) to cap ≤400k steps (max 348,560). Needs CR PASS.

## Run f006 finished (OOM at ep48 start, auto-resumed); ep48 parity PASS, pack requested (UNPROVEN) - 2026-10-24 21:27-22:15 Vienna (CEST)
- GPU check 21:27: f006 running (PIDs 2336/4960, v3a, ep36), gpu_guard 21:24 hot 57 memj 78 (10-min max 58/79), lvl 0. Queue md5 3744bf6a unchanged; 130 un-run lines (next f007, f008). STOP_nnue absent. C: 28 GB free. Self-play untouched (PIDs 8520/7860 + workers). **Free RAM only 1.1 GB of 31.6** (trainer PID 4960 private 24.1 GB, commit free 4.7 GB) - below the 4 GB limit; nothing stopped.
- **f006 crash + resume:** at 21:51:40 the trainer died starting ep48: `numpy _ArrayMemoryError: Unable to allocate 1.02 GiB` in train_resid_v3a.py L468 epoch_feed (`np.random.default_rng(seed*1000+e).permutation(N).astype(int64)`; N = 137,381,087 train positions from 19 files). Supervisor marked needs_resume at 21:52:11, resumed from epoch047-step000788190.pt (resume1.log, empty .err), finished ep48 + final full holdout, DONE 21:54:13; f007 launched 21:54:15. After the restart, free RAM is 16.3-16.7 GB with f007 running, so the trainer's memory seemed to grow during the 48-epoch run (13.7 GB free at 20:25, 1.1 GB at ep36). Hunch only (unverified): per-epoch memory growth in v3a's prefetch/permutation path, or simply 137M positions + the int64 permutation at the edge. Long runs (32/48 ep) are at risk; auto-resume recovered this one. Needs a v3b check (own copy, CR, smoke) before it bites a run that cannot resume.
- **f006** `resid_h256_e48_f006_bs16k_lr10e4_b06_s25_fb8k` (v3a, bs8192, lr 7.07e-4, warmup 300, blend-end 0.6, seed 25, 48 ep; train self-play 001-012,015-021 = 137.4M pos, no Sol; holdout 013+014; settings_1792898583.txt L1 + resume settings_1792903932.txt; the name's bs16k_lr10e4 is stale) DONE. FINAL FULL HOLDOUT (n=16,384,000): teacher 0.004593, **b0.6 0.014341 (new best b0.6; f005 0.014357, f003 0.014371)**, b0.8 0.006761; HCE 0.005070/0.017052/0.008355. Subset b0.6 flat 0.01433-0.01434 from ep43-48. Picked ep48 (the full-holdout epoch).
- ep48 .inc md5 **0fae54a4c0c437432ddb5da85512b5f4** (.pt 7550a5f0bf2f1a438be2fe9a04f62716) -> box `forge_resid/resid_h256_e48_f006_b06_ep48.inc` (1,115,142 B). md5 equal at source/stage/box; source re-hashed after parity unchanged; staging C:\Users\Administrator\grok-pc\stage_f006 deleted; run folder untouched.
- Parity (check_export2.py, HID=256, 10000 pos forge_selfplay_014.txt, Idle CPUs 0-3, msys64 on PATH; script forge_resid/scripts/stage_parity_f006.ps1): exact 10000/10000, max|diff| 0 vs trunc, mean 0.5017, max cp 1187 -> PASS (F:\forge_nnue_train\parity_stage_f006_epoch048.log, empty .err).
- Pack requested from Coder (same recipe as fc_nnue_h256_e16h_ep16_ep10base); FYIs to CR and QA. UNPROVEN.

### 2026-10-24 21:57-21:59 Vienna - v3b trainer deploy + queue cap400k applied (CR PASS w/ conditions, /workspace/forge-hashes/CR_PASS_nnue_v3b.txt md5 6ef0c95f)
- **C2a deploy:** `F:\forge_nnue_train\tools\train_resid_v3b.py` written 21:57:18, PC md5 **b6758004d19837c8d34d401ee7af5fd5** (= box v3work/v3b). Beside qa_adam_dml.py: PC md5 1c9ccbcd differs from the box copy c20b9d60 only in the final 2 bytes (CRLF vs LF LF at EOF); code identical. No other file in tools\ touched.
- **C2b queue swap:** live queue was **3744bf6a5cb37a022c3bff11268b9d4b** (37,284 B, re-checked immediately before replace). Backup `F:\forge_nnue_train\queue.txt.bak_1024n` md5 3744bf6a (= live). New queue.txt written 21:58:54: **380f478b08bd832623600cd7a32da759**, 37,284 B, 165 lines, 165 CRLF, no BOM (PC md5 = box file v3work/v3b/deploy/queue_v3b_cap400k_rebuilt_1024n.txt).
- Rebuilt from the live queue because f007 had started (21:54:15, PIDs 3780/7120): CR's transformation (v3a -> v3b script; --epochs 24/32/48 -> 20 with _eNN_ -> _e20_) applied only to lines not in queue_state.json and without a run dir. 129 lines changed (f008-f136). Compared with CR's 715a795a, the only difference is line 36, f007 `resid_h256_e16_f007_bs16k_lr14e4_b06_s26_fb8k`, left byte-identical in its live v3a form (it was 16 ep, so only its script would have changed). Started lines left as they were: n, v3smoke_v3a, f001-f007, e12rec. No duplicate names, no collision with the 36 run dirs.
- Effect: f007 runs to the end on v3a (16 ep, ~268k steps). From f008 on, every line runs v3b, at most 20 ep / <=348,560 steps at today's N. The leak fix is UNPROVEN until the first v3b run's MEM lines or the probe run on the PC in a QA slot.
- Not touched: processes, supervisor, QA scripts, self-play, gates, run folders; no PAUSE/STOP files. (One aborted first swap attempt at 21:58:33 failed before replace because PowerShell variables are case-insensitive; the live queue was unchanged and the backup was already written and verified.)
- **dml_leak_probe.py CR M1 fix (box only, not run on PC):** md5 2e543b26 -> **4db8a1ab3ec9acf6e6f0e4345268b7b8** (old copy dml_leak_probe.py.bak_2e543b26). tensor mode copies [blend, 1-blend, -lr/bc1, bc2s] into a preallocated sc[4] (no per-step .to(dev)); w1/w2 updates use the same ops in all modes, only the scalar source differs; new tensor_reuse mode copies from one reused host tensor; CHECK line prints w1/w2 sums. Box CPU smoke (300 steps, bs1024): float = tensor = tensor_reuse w1sum 2.957525573e+03, w2sum -2.665873082e-02 (identical).

## Run f007 finished; ep16 parity PASS, pack requested; first v3b run f008 shows no RAM leak (UNPROVEN) - 2026-10-24 22:29-22:40 Vienna (CEST)
- GPU check 22:29: f008 `resid_h256_e20_f008_bs16k_lr12e4_b06_sol_s27_fb8k` running since ~22:20 on **train_resid_v3b.py** (PIDs 12104/12408), ep5 subset teacher 0.003930 b0.6 0.014802. gpu_guard 22:24 hot 59 memj 79 (10-min max 61/81), lvl 0. Queue md5 380f478b unchanged; 128 un-run lines (next f009, f010). STOP_nnue absent. Free RAM 17.8 GB, C: 28.2 GB, CPU 57%. Self-play untouched (PIDs 8520/7860 + workers).
- **v3b leak check (first PC run, f008):** MEM lines flat: after-load 6.14 GB, ep1 6.95, epoch001-007 6.94-6.96 GB private, sys_avail ~17.9 GB steady (v3a runs grew ~265 MB/min at bs8192). Early evidence the DML leak is fixed; keep watching to the end of f008.
- **f007** `resid_h256_e16_f007_bs16k_lr14e4_b06_s26_fb8k` (v3a, bs8192, lr 9.898e-4, warmup 300, blend-end 0.6, seed 26, 16 ep; train self-play 001-012,015-021, no Sol; settings L1; name's bs16k_lr14e4 is stale) DONE 22:20 (1547 s). FINAL FULL HOLDOUT (n=16,384,000): teacher 0.004565, b0.6 0.014367 (+0.18% vs best f006 0.014341), b0.8 0.006759; HCE 0.005070/0.017052/0.008355. Competitive -> packed. Picked ep16 (full-holdout epoch).
- ep16 .inc md5 **eaf55cb926df074db6888a7e08300f00** (.pt 0c39f5edf130ec1d1c35056e9b52e66b) -> box `forge_resid/resid_h256_e16_f007_b06_ep16.inc` (1,115,338 B). md5 equal at source/stage/box; source re-hashed after parity unchanged; staging C:\Users\Administrator\grok-pc\stage_f007 deleted; run folder untouched.
- Parity (check_export2.py, HID=256, 10000 pos forge_selfplay_014.txt, Idle CPUs 0-3, msys64 on PATH; script forge_resid/scripts/stage_parity_f007.ps1): exact 10000/10000, max|diff| 0 vs trunc, mean 0.4994, max cp 1074 -> PASS (F:\forge_nnue_train\parity_stage_f007_epoch016.log, empty .err).
- Pack requested from Coder (same recipe as fc_nnue_h256_e16h_ep16_ep10base, queued after f006); FYIs to CR and QA. UNPROVEN.

## Runs f008, f009 finished (both v3b); parity PASS, pack requested; v3b RAM leak fix holds (UNPROVEN) - 2026-10-24 23:29-23:40 Vienna (CEST)
- GPU check 23:29: f010 `resid_h256_e16_f010_bs16k_lr12e4_b06_s29_fb8k` running on train_resid_v3b.py (PIDs 13752/13604, ep4). gpu_guard 23:24 hot 58 memj 78 (10-min max 61/82), lvl 0. Queue md5 380f478b unchanged; 126 un-run lines (next f011, f012). STOP_nnue absent. Free RAM 17.9 GB, C: 28.2 GB, CPU 45%. Self-play untouched (PIDs 8520/7860 + workers).
- **v3b leak fix confirmed over full runs:** f008 trainer private 6.94-6.96 GB flat ep1-20 (348,560 steps), f009 6.73-6.75 GB flat ep1-16; sys_avail ~17.6-18.1 GB throughout.
- **f008** `resid_h256_e20_f008_bs16k_lr12e4_b06_sol_s27_fb8k` (v3b, bs8192, lr 8.484e-4, warmup 300, blend-end 0.6, seed 27, 20 ep; train forge_selfplay_[0-9][0-9][0-9].pos + sol_indep_train.pos; settings_1792905619.txt L1; name's bs16k_lr12e4 is stale) DONE 22:55 (2086 s). FINAL FULL HOLDOUT (n=16,384,000): teacher 0.004576, b0.6 0.014389 (+0.33% vs best f006 0.014341), b0.8 0.006776. Competitive -> packed. Picked ep20 (full-holdout epoch).
  - ep20 .inc md5 **1a2ea39884024703f4009129dfc15c97** (.pt 194d142ab48d08b866930ec94d3c41fc) -> box `forge_resid/resid_h256_e20_f008_b06_sol_ep20.inc` (1,111,339 B).
  - Parity: exact 10000/10000, max|diff| 0 vs trunc, mean 0.4986, max cp 1046 -> PASS (F:\forge_nnue_train\parity_stage_f008_epoch020.log, empty .err).
- **f009** `resid_h256_e16_f009_bs16k_lr14e4_b06_s28_fb8k` (v3b, bs8192, lr 9.898e-4, warmup 300, blend-end 0.6, seed 28, 16 ep; self-play 001-012,015-021, no Sol; settings_1792907724.txt L1) DONE 23:22 (1597 s). FINAL FULL HOLDOUT: teacher 0.004576, b0.6 0.014390 (+0.34%), b0.8 0.006777. Competitive -> packed. Picked ep16.
  - ep16 .inc md5 **eee839babc2c958482207b0d56403245** (.pt 4dc11cdb007f249004a83733c4fe3492) -> box `forge_resid/resid_h256_e16_f009_b06_ep16.inc` (1,116,163 B).
  - Parity: exact 10000/10000, max|diff| 0, mean 0.4991, max cp 1173 -> PASS (parity_stage_f009_epoch016.log, empty .err).
- md5 equal at source/stage/box; sources re-hashed after parity unchanged; staging stage_f008/stage_f009 deleted; run folders untouched. Script: forge_resid/scripts/stage_parity_f008_f009.ps1.
- Note: f004-f009 all land within 0.5% on b0.6 (0.014341-0.014407); seed noise dominates at this recipe. Pick packs by gate games (P29).
- Pack requested from Coder (same recipe as fc_nnue_h256_e16h_ep16_ep10base, after f007); FYIs to CR and QA. UNPROVEN.

## Runs f010, f011 finished (v3b); parity PASS, pack requested (UNPROVEN) - 2026-10-25 00:23-00:35 Vienna (CEST)
- GPU check 00:23: f012 `resid_h256_e16_f012_bs16k_lr14e4_b06_sol_s31_fb8k` just started on train_resid_v3b.py (PIDs 14080/3120). gpu_guard hot 43 memj 65. Queue md5 380f478b unchanged; 124 un-run lines (next f013, f014). STOP_nnue absent. Free RAM 17.4 GB, C: 28.2 GB, CPU 65%. Self-play untouched (PIDs 8520/7860 + workers). v3b RAM flat ~6.73-6.80 GB in both runs.
- **f010** `resid_h256_e16_f010_bs16k_lr12e4_b06_s29_fb8k` (v3b, bs8192, lr 8.484e-4, warmup 300, blend-end 0.6, seed 29, 16 ep; self-play 001-012,015-021, no Sol; settings_1792909348.txt L1) 1597 s. FINAL FULL HOLDOUT (n=16,384,000): teacher 0.004573, b0.6 0.014389 (+0.33% vs best f006 0.014341), b0.8 0.006774. Competitive -> packed. Picked ep16.
  - ep16 .inc md5 **d8e332e9f717442f88288c2d0dc3755b** (.pt b7d7ad97684717b0f68cc118f1d97305) -> box `forge_resid/resid_h256_e16_f010_b06_ep16.inc` (1,107,333 B).
  - Parity: exact 10000/10000, max|diff| 0 vs trunc, mean 0.4998, max cp 1247 -> PASS (F:\forge_nnue_train\parity_stage_f010_epoch016.log, empty .err).
- **f011** `resid_h256_e20_f011_bs16k_lr14e4_b06_s30_fb8k` (v3b, bs8192, lr 9.898e-4, warmup 300, blend-end 0.6, seed 30, 20 ep; same data as f010; settings_1792910973.txt L1) 1992 s. FINAL FULL HOLDOUT: teacher 0.004577, b0.6 0.014375 (+0.24%), b0.8 0.006770. Competitive -> packed. Picked ep20.
  - ep20 .inc md5 **2623b4346ee2b8fd962c20291467c7b4** (.pt 8b898a80665f7fdd55ac0f37ec55a183) -> box `forge_resid/resid_h256_e20_f011_b06_ep20.inc` (1,118,752 B).
  - Parity: exact 10000/10000, max|diff| 0, mean 0.4952, max cp 1201 -> PASS (parity_stage_f011_epoch020.log, empty .err).
- md5 equal at source/stage/box; sources re-hashed after parity unchanged; staging stage_f010/stage_f011 deleted; run folders untouched. Script: forge_resid/scripts/stage_parity_f010_f011.ps1.
- f004-f011 all within 0.5% on b0.6 (seed noise); pick by gate games (P29).
- Pack requested from Coder (same recipe as fc_nnue_h256_e16h_ep16_ep10base, after f009); FYIs to CR and QA. UNPROVEN.

## Runs f012, f013 finished (v3b); parity PASS, pack requested (UNPROVEN) - 2026-10-25 01:27-01:35 Vienna (CEST)
- GPU check 01:27: f014 `resid_h256_e20_f014_bs16k_lr10e4_b06_s33_fb8k` running on train_resid_v3b.py (PIDs 10412/13580). Queue md5 380f478b unchanged; 122 un-run lines (next f015, f016). STOP_nnue absent. Free RAM 16.8 GB, C: 28.1 GB, CPU 57%. Self-play untouched (PIDs 8520/7860 + workers).
- **f012** `resid_h256_e16_f012_bs16k_lr14e4_b06_sol_s31_fb8k` (v3b, bs8192, lr 9.898e-4, warmup 300, blend-end 0.6, seed 31, 16 ep; data forge_selfplay_[0-9][0-9][0-9].pos + sol_indep_train.pos; settings_1792913018.txt L1) 1659 s. FINAL FULL HOLDOUT (n=16,384,000): teacher 0.004568, b0.6 0.014390 (+0.34% vs best f006 0.014341), b0.8 0.006772. Competitive -> packed. Picked ep16.
  - ep16 .inc md5 **1f0bca9a5e8d0418c8c8cdb394f26bbd** (.pt c7b4465b464fea32363a58d932e4e535) -> box `forge_resid/resid_h256_e16_f012_b06_sol_ep16.inc` (1,115,502 B).
  - Parity: exact 10000/10000, max|diff| 0 vs trunc, mean 0.4955, max cp 1202 -> PASS (parity_stage_f012_epoch016.log, empty .err).
- **f013** `resid_h256_e20_f013_bs16k_lr10e4_b06_s32_fb8k` (v3b, bs8192, lr 7.07e-4, warmup 300, blend-end 0.6, seed 32, 20 ep; self-play 001-012,015-021, no Sol; settings_1792914702.txt L1) 1992 s. FINAL FULL HOLDOUT: teacher **0.004561 (new best teacher in the f-series)**, b0.6 0.014373 (+0.22%), b0.8 0.006761. Competitive -> packed. Picked ep20.
  - ep20 .inc md5 **6d0ede668acdf804f8e99c0b4e16f2c0** (.pt 1c0bdcc404c383b7ec0dc53f43689b8d) -> box `forge_resid/resid_h256_e20_f013_b06_ep20.inc` (1,107,236 B).
  - Parity: exact 10000/10000, max|diff| 0, mean 0.5004, max cp 1722 -> PASS (parity_stage_f013_epoch020.log, empty .err).
- md5 equal at source/stage/box; sources re-hashed after parity unchanged; staging stage_f012/stage_f013 deleted; run folders untouched. Script: forge_resid/scripts/stage_parity_f012_f013.ps1.
- f004-f013 all within 0.5% on b0.6 (seed noise); pick by gate games (P29).
- Pack requested from Coder (same recipe as fc_nnue_h256_e16h_ep16_ep10base, after f011); FYIs to CR and QA. UNPROVEN.

## Run f014 finished (v3b); parity PASS, pack requested (UNPROVEN) - 2026-10-25 02:27-02:35 Vienna (CEST)
- GPU check 02:27: f015 `resid_h256_e16_f015_bs16k_lr14e4_b06_s34_fb8k` running on train_resid_v3b.py (PIDs 13768/2296, ep13/16). gpu_guard hot 60 memj 79 (10-min max 60/82). Queue md5 380f478b unchanged; 121 un-run lines (next f016, f017). STOP_nnue absent. Free RAM 16.7 GB, C: 28.1 GB, CPU 47%. Self-play untouched (PIDs 8520/7860 + workers).
- **f014** `resid_h256_e20_f014_bs16k_lr10e4_b06_s33_fb8k` (v3b, bs8192, lr 7.07e-4, warmup 300, blend-end 0.6, seed 33, 20 ep; self-play 001-012,015-022 (first run with 022), no Sol; settings_1792916775.txt L1) 2135 s. FINAL FULL HOLDOUT (n=16,384,000): teacher **0.004559 (new best teacher in the f-series)**, b0.6 0.014345 (+0.03% vs best f006 0.014341), b0.8 0.006746 (best b0.8 so far in the f-series). Competitive -> packed. Picked ep20 (ep18/19 1M-holdout b0.6 0.014345/0.014344 equal; ep20 best on full teacher).
  - ep20 .inc md5 **4eb578933a18996b446d4272dfc8aecb** (.pt ce7306ea533c51733c0cef094e024522) -> box `forge_resid/resid_h256_e20_f014_b06_ep20.inc` (1,105,355 B).
  - Parity: exact 10000/10000, max|diff| 0 vs trunc, mean 0.5005, max cp 1330 -> PASS (F:\forge_nnue_train\parity_stage_f014_epoch020.log, empty .err).
- md5 equal at source/stage/box; source re-hashed after parity unchanged; staging stage_f014 deleted; run folder untouched. Scripts: forge_resid/scripts/final_f014.ps1, stage_parity_f014.ps1, parity_check_f014.ps1, cleanup_f014.ps1.
- Pack requested from Coder (same recipe as fc_nnue_h256_e16h_ep16_ep10base, after f013); FYIs to CR and QA. UNPROVEN.

## Runs f015, f016 finished (v3b); parity PASS, pack requested (UNPROVEN) - 2026-10-25 02:26-02:35 Vienna (CET; DST ended, grok-pc clock still reads 03:26 CEST-style)
- GPU check 02:26 CET: f017 `resid_h256_e16_f017_bs16k_lr14e4_b06_s36_fb8k` running on train_resid_v3b.py (PIDs 14048/8212, ep9/16). gpu_guard hot 59 memj 78 (10-min max 60/82). Queue md5 380f478b unchanged; 119 un-run lines (next f018, f019). STOP_nnue absent. Free RAM 16.6 GB, C: 28.0 GB, CPU 90% snapshot (self-play + parity starting; watch). Self-play untouched (PIDs 8520/7860 + workers).
- **f015** `resid_h256_e16_f015_bs16k_lr14e4_b06_s34_fb8k` (v3b, bs8192, lr 9.898e-4, warmup 300, blend-end 0.6, seed 34, 16 ep; self-play 001-012,015-022, no Sol; settings_1792918941.txt L1) 1718 s. FINAL FULL HOLDOUT (n=16,384,000): teacher 0.004564, b0.6 0.014364 (+0.16% vs best f006 0.014341), b0.8 0.006758. Competitive -> packed. Picked ep16 (only full-holdout epoch; ep15 1M b0.6 0.014367 vs ep16 0.014369, equal).
  - ep16 .inc md5 **ebf341beca7f6b17d83f42d42a73b21d** (.pt e13956ba54f7be736fb2f72e3c9c5bf9) -> box `forge_resid/resid_h256_e16_f015_b06_ep16.inc` (1,115,021 B).
  - Parity: exact 10000/10000, max|diff| 0 vs trunc, mean 0.5006, max cp 1226 -> PASS (F:\forge_nnue_train\parity_stage_f015_epoch016.log, empty .err).
- **f016** `resid_h256_e20_f016_bs16k_lr12e4_b06_sol_s35_fb8k` (v3b, bs8192, lr 8.484e-4, warmup 300, blend-end 0.6, seed 35, 20 ep; data forge_selfplay_[0-9][0-9][0-9].pos + sol_indep_train.pos; settings_1792920685.txt L1) 2221 s. FINAL FULL HOLDOUT: teacher **0.004557 (new best teacher in the f-series)**, b0.6 0.014356 (+0.10%), b0.8 0.006750. Competitive -> packed. Picked ep20.
  - ep20 .inc md5 **fd44a1781666f3ffbba7dc960a4d0302** (.pt 5377e8d8ce54fc05ebd24d2701762045) -> box `forge_resid/resid_h256_e20_f016_b06_sol_ep20.inc` (1,113,112 B).
  - Parity: exact 10000/10000, max|diff| 0, mean 0.5030, max cp 992 -> PASS (parity_stage_f016_epoch020.log, empty .err).
- md5 equal at source/stage/box; sources re-hashed after parity unchanged; staging stage_f015/stage_f016 deleted; run folders untouched. Scripts: forge_resid/scripts/final_f015_f016.ps1, stage_parity_f015_f016.ps1, parity_check_f015_f016.ps1, cleanup_f015_f016.ps1.
- f004-f016 all within 0.5% on b0.6 (seed noise); pick by gate games (P29).
- Pack requested from Coder (same recipe as fc_nnue_h256_e16h_ep16_ep10base, after f014); FYIs to CR and QA. UNPROVEN.

## Runs f017, f018 finished (v3b); parity PASS, pack requested (UNPROVEN) - 2026-10-25 03:23-03:30 Vienna (CET; grok-pc clock reads 04:23 CEST-style)
- GPU check 03:23 CET: f019 `resid_h256_e20_f019_bs16k_lr14e4_b06_s38_fb8k` running on train_resid_v3b.py (PIDs 6780/5700, ep8/20, RAM flat ~7.3 GB). gpu_guard hot 59 memj 78 (10-min max 60/80). Queue md5 380f478b unchanged; 117 un-run lines (next f020, f021). STOP_nnue absent. Free RAM 16.5 GB, C: 28 GB, CPU 48%. Self-play untouched.
- **f017** `resid_h256_e16_f017_bs16k_lr14e4_b06_s36_fb8k` (v3b, bs8192, lr 9.898e-4, warmup 300, blend-end 0.6, seed 36, 16 ep; self-play 001-012,015-022, no Sol; settings_1792922970.txt L1) 1710 s. FINAL FULL HOLDOUT: teacher 0.004558, b0.6 0.014364 (+0.16% vs best f006 0.014341), b0.8 0.006755. Competitive -> packed. Picked ep16 (ep14-16 1M b0.6 0.014371/0.014368/0.014370, equal; only full-holdout epoch).
  - ep16 .inc md5 **77c20eabcc978f3518e6ada1bfca48bd** (.pt 7ed61dfa3bf8d84a81f3ff798deb0812) -> box `forge_resid/resid_h256_e16_f017_b06_ep16.inc` (1,116,463 B).
  - Parity: exact 10000/10000, max|diff| 0 vs trunc, mean 0.4942, max cp 1117 -> PASS (parity_stage_f017_epoch016.log, empty .err).
- **f018** `resid_h256_e16_f018_bs16k_lr12e4_b06_s37_fb8k` (v3b, bs8192, lr 8.484e-4, warmup 300, blend-end 0.6, seed 37, 16 ep; self-play 001-012,015-023 = first run with selfplay_023, no Sol; settings_1792924727.txt L1) 1763 s. FINAL FULL HOLDOUT: teacher **0.004548 (new best teacher in the f-series)**, b0.6 0.014362 (+0.15%), b0.8 0.006748. Competitive -> packed. Picked ep16.
  - ep16 .inc md5 **368a6779c019681628ac7772996e9fbc** (.pt d0b85e4a108f9c10c6c20e97f8e66ba6) -> box `forge_resid/resid_h256_e16_f018_b06_ep16.inc` (1,109,832 B).
  - Parity: exact 10000/10000, max|diff| 0, mean 0.5034, max cp 1257 -> PASS (parity_stage_f018_epoch016.log, empty .err).
- md5 equal at source/stage/box; sources re-hashed after parity unchanged; staging stage_f017/stage_f018 deleted; run folders untouched. Scripts: forge_resid/scripts/*_f017_f018.ps1.
- f004-f018 all within 0.5% on b0.6 (seed noise); pick by gate games (P29).
- Pack requested from Coder (same recipe as fc_nnue_h256_e16h_ep16_ep10base, after f016); FYIs to CR and QA. UNPROVEN.
