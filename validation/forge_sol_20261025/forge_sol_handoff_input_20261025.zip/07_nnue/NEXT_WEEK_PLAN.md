# Forge residual NNUE: next-week plan (Engine NNUE). Everything UNPROVEN unless QA locked it.
Written 2026-10-24 ~08:45 PT from box files only (grok-pc not touched). Source keys:
**N** = forge_resid/NETS.md:line (identical to nnue/NETS.md), **Q** = forge-hashes/QUEUE_PENDING.md:line,
**LC** = forge-hashes/LOCK_CHECK_h256_e12.md, **IB** = chess-tools/research/FORGE_IDEA_BOARD.md:470 (Strategist P29),
**F** = nnue/queue_fill_6day.txt (md5 9ae931fb), **C3** = forge_resid/CHANGES_v3.md.

## 1. Scoreboard: finished H256 nets (FINAL FULL HOLDOUT, n≈16.39M, files 013+014)
HCE alone: teacher 0.005070 / b0.6 0.017052 [N:1191]. All residual, float, H256. "data" = training positions.
Only **e ep12 (h256_e12)** is locked: Gate 13 H1 +37.95 ±15.18 vs ep10, LOCK by crew vote 8-0 at 09:46 Vienna (00:46 PT) [LC; Q:84].

| net | .inc md5 | ep | lr | blend-end | bs | data | teacher | b0.6 | gate vs h256_e12 |
|---|---|---|---|---|---|---|---|---|---|
| e ep12 | 6d22f612 | 12 | 1e-3 | 0.6 | 4096 | 95.36M (001-012+015) | 0.004679 | 0.014534 | **LOCK** [N:1329] |
| f ep12 | 27641a08 | 12 | 1e-3 | 0.5 | 4096 | 95.36M | 0.005181 | 0.014666 | never gated [N:1340] |
| auto000 | ab049d95 | 16 | 7e-4 | 0.6 | 4096 | 95.36M (inferred, pre-016) | 0.004655 | 0.014506 | not gated [N:1348] |
| auto001 | n/a | 16 | 2e-3 | 0.6 | 4096 | 95.36M (inferred) | 0.004757 | 0.014648 | no [N:1354] |
| auto002 | n/a | 16 | 1e-3 | 0.5 | 4096 | 95.36M (inferred) | 0.005204 | 0.014663 | never gated [N:1360] |
| h | 57a30ece | 16 | 7e-4 | 0.7 | 4096 | 95.36M | 0.004265 | 0.014471 | **G26 cap 1000g −4.17 ±10.28** [Q:364] |
| i | 4c5a96fe | 20 | 5e-4 | 0.6 | 4096 | +016 | 0.004609 | 0.014445 | no [N:1389] |
| j | cee0ec8d | 16 | 7e-4 | 0.8 | 4096 | +016+017 | 0.003968 | 0.014544 | **G30 cap 1000g −11.1 ±10.6** [Q:581] |
| k | a0542f7e | 16 | 7e-4 | 0.7 | 4096 | 117.97M (16 files) | 0.004224 | 0.014412 | G61 queued, no verdict in files [Q:367] |
| b8 (8 heads, ft from e12) | 09227945 | 8 | 3e-4 | 0.8 | 4096 | 120.7M | 0.003925 | 0.014513 | G85 queued [Q:593] |
| l | c6a5b6d1 | 16 | 7e-4 | 0.9 | 4096 | all sealed SP | 0.003789 | 0.014715 | **G78 H0 −44.5 ±18.1 (432g)** [Q:716] |
| s (Sol +4.4%) | 247fd729 | 16 | 7e-4 | 0.8 | 4096 | SP + 5.39M Sol | 0.004004 | 0.014504 | G89 queued; underpromo 16/16 [Q:688-694] |
| g90 | ceb7dd61 | 16 | 1.4e-3 | 0.7 | 16384 | 127.38M (18 files) | 0.004205 | **0.014396** | G88 running: ~609g −0.0 ±12.5 (08:14 PT) [Q:tail] |
| m | ed2c7099 | 16 | 7e-4 | 0.8 | 4096 | all sealed SP | 0.003943 | 0.014497 | G90 queued [Q:"16:19 e16m"] |
| n | 5a1cab10 | 24 | 1.4e-3 | 0.75 | 16384 | all sealed SP | 0.004065 | 0.014423 | packed, not queued [N:1533] |
| o | 368c9f10 | 16 | 1.2e-3 | 0.8 | 16384 | all sealed SP | 0.003939 | 0.014503 | packed [N:1536] |
| p | 6ad348ac | 16 | 1.6e-3 | 0.7 | 16384 | all sealed SP | 0.004214 | 0.014406 | packed [N:1544] |
| q | e3317599 | 16 | 1.4e-3 | 0.85 | 16384 | all sealed SP | 0.003861 | 0.014609 | packed [N:1547] |

Not nets: v3a smoke (2 ep, 32M, bit-identical to v2 on DML, PASS) [N:1558-1566]; f001 running on v3a [N:1568].
All export parities PASS (10,000/10,000 or 9,999/10,000) where run [N:1382-1547].

## 2. What the losses tell us
- **Teacher loss is a NEGATIVE signal for games across blend-ends (Strategist P29, verified in Q).** Same lr 7e-4, 16 ep;
  only blend-end and seed (and data) differ: e12 b0.6 lock → h b0.7 −4.2 → j b0.8 −11.1 → l b0.9 −44.5 (H0), while teacher
  loss fell 0.004679 → 0.004265 → 0.003968 → 0.003789 [IB; Q:364,581,716]. Monotonic dose-response.
- **Same pattern at H128:** run a (blend→0.6) beat b (pure teacher 1.0) and c (→0.8): gate7 a vs c H1 +26.6 ±12.2;
  vs 6.4.24 a +156.3, c +127.1, b +104.6, while b had the best teacher loss [N:1274]. Two widths, same direction.
- **b0.6 is the less-wrong loss:** gate order e12 > h > j > l vs b0.6 0.014534 / 0.014471 / 0.014544 / 0.014715: l is worst
  on both, but h beats e12 on b0.6 and still lost −4.2 (within noise). b0.6 differences of <0.5% do not predict a gate.
- **Blend-end 0.5 was rejected only by loss** (f, auto002: teacher worse than HCE), never by games [IB; N:1340,1360].
  Given the trend, "worse teacher" is not evidence against it.
- **lr:** at bs4096, 5e-4 (i) and 2e-3 (auto001) were no better than 7e-4 [N:1354,1389]. At bs16384, 1.6e-3 (p) gave the
  2nd-best b0.6 but the worst teacher of the bs16k set [N:1544,1552]. lr effects are ≤0.2% on b0.6, inside the confounds.
- **Epochs:** n (24 ep) 0.014423 vs g90 (16 ep) 0.014396: no gain from 24 ep [N:1533]. i (20 ep) ≈ h (16 ep) [N:1389].
- **bs16384:** g90 within 1% of k (actually better) at 2.2× pos/s [N:1498]. **Confound:** g90 trained on +8.0% data
  (127.38M vs 117.97M) [N:1514], so no gain is credited to batch size. Data grows with every sealed self-play file
  (95.36M → 127.38M during this week), so cross-run loss deltas mix data, seed and recipe.
- **Comparisons:** after the --val-positions 1M switch, only FINAL FULL HOLDOUT lines are comparable [N:1529].
  Holdout is in-distribution and split by file, not game [N:1190], so all loss gains are optimistic.

## 3. This week's fill queue f001-f136 (F, md5 9ae931fb; live queue c25b3ec8, v3a script [N:1557])
- 136 lines, seeds 20-155, all bs16384 / warmup 150: an 8-line block ×17. blend-end: 0.65 ×17, 0.7 ×68, 0.75 ×17, 0.8 ×34;
  lr 1.0e-3 ×34, 1.2e-3 ×34, 1.4e-3 ×68; epochs 16/24/32/48; 34 lines add Sol data (F, counted).
- **Will answer:** seed noise at fixed recipe (17 repeats per line type), 32/48-epoch vs 16, lr 1.0-1.4e-3 at 16k, Sol 1× at
  b0.75/0.8, effect of growing self-play data.
- **Won't answer:** the top question. **No line has blend-end ≤0.6**, and every line sits in the 0.65-0.8 range where gates
  went −4 to −11 [IB]. Seed repeats only shrink loss noise, which does not predict games (section 2). No gate is attached.
- **Expected finish:** 3,400 epochs total (F). At 73-86 s/epoch on v3a [N:1569-1570] plus ~100 s/run overhead [N:1567]
  ≈ 73-85 h from f001's start (08:16 PT Sat) → **~Tue Oct 27 09:00 PT to Tue Oct 27 21:00 PT**, later as data grows.
  After that the supervisor runs auto experiments [N:1307].
- **Recommendation (needs CR diff + backup + md5s, NOT done here):** rewrite not-started f-lines so at least half run
  blend-end 0.6 / 0.5 / 0.4 at the g90 recipe; keep a few 0.7 lines as controls.

## 4. Next week, ranked by expected Elo per GPU-hour
GPU is cheap (one bs16k 16-ep run ≈ 25 min [N:1514]); **the scarce resource is gate slots** (~2.75 h each, 59-60 queued ≈
162-165 h [Q:688; Q:"16:19 e16m"]). So rank by Elo per gate slot too, and gate few nets.

1. **Blend-end ≤0.6 (top question).** P29 option 1: pack f ep12 (b0.5, 27641a08), parity, gate vs h256_e12 (cap 1000).
   Option 2: e12 recipe at b0.4, new seed [IB]. Then b0.5/0.4 at the g90 recipe on current data.
   Cost: GPU ~0.5 h/run, 1-2 gate slots. Test: net-only SPRT [0,10] vs lock. Bar: H1, or cap ≥+5 → confirm.
   Strategist estimate +5..+15 at p≈0.35 [IB]. Also reorder: gates of o (0.8), q (0.85) behind it [IB].
2. **Selection rule (free).** Choose nets by games, not teacher loss; screen with b0.6 / result-only loss; never pack a
   net only because teacher loss improved. Stop packing b≥0.75 nets unless a ≤0.6 net loses.
3. **Data from the strongest lock.** Self-play labels are Forge's own 5000-node search [N:1190]; h256_e12 (+37.95 vs ep10)
   is now the strongest engine. Cost: CPU only (self-play cores), 0 GPU until retrain. Test: one g90-recipe run on
   lock-labelled data at the winning blend-end vs same recipe on old data, gated. Bar: ≥+5 cap or H1.
4. **Leak-free holdout split by game id.** Today's split is by file; games can straddle files and openings repeat
   [N:1190]. Cost: CPU conversion only. Test: rescore e12/h/j/l on it; check rank order vs G26/G30/G78. Bar: the
   holdout metric ranks the 4 gated nets in gate order. Without this, losses stay a weak screen.
5. **Result (WDL) term.** The .pos records already carry the game result and the (1−blend) term trains on it [N:1186-1187],
   so the WDL field exists; the lever IS the blend-end (item 1). Contradictions are 0.62% of positions, rising to 4.6%
   of strong-score positions in 31-32 piece positions [N:1313-1323]: a piece-count-dependent blend is a later idea.
6. **Sol positions.** s (+4.4% Sol, b0.8) b0.6 0.014504 [N:1495]; wait for G89. If ≥ lock, retest Sol at blend ≤0.6;
   if minus, drop the 34 Sol fill lines. Underpromotion test required for every Sol net [N:1443].
7. **buckets8 follow-up.** b8 (ft from e12, b0.8) best b0.8 loss [N:1469]; box nps 0.963 of lock [Q:576]; G85 queued.
   Only if G85 ≥0: retrain b8 at blend ≤0.6. Cost ~1 h GPU, 1 gate.
8. **Width H384/H512.** H256 already costs ~15-17% nps vs H128 (box ratio 0.826 [LC:110]; CR ~15% [CR_PASS_nnue_h256_e12]),
   yet gained +37.95 [LC]. H384+ needs faster inference first: int16 Gate 21 was H128-only and dropped post-lock
   ("needs a new H256 design") [Q:41,60]; Sol 3afd230 AVX-512 float kernels are bit-exact, OFF-default, nps unproven
   [forge-hashes/SOL_WORK_AUDIT_20261024.md:37]. Order: PC nps of AVX-512 → int16 H256 design → only then H384.
   Bar: H384 needs ≥ lock Elo at equal time; low priority this week.
9. **Training throughput.** bs16384 is memj-limited, not trainer-limited: v3a 73.1% GPU mean, memj 82-84, guard throttles
   [N:1571-1573]. Options: bs12288 (lr ×√, new CR line), fan curve (hardware: Couns's call). Since GPU is not the
   bottleneck (item 1 note), this is the lowest priority. Bar: ≥+10% pos/s at memj ≤83 with equal FINAL loss.
10. **LR schedule / distillation.** lr shows ≤0.2% b0.6 effects (section 2); distilling from a stronger net only after
   item 3. Low priority.

## 5. Pipeline lessons (from this week)
- **Check supervisor-injected args before writing a trainer:** it appends `--guard-tag train_resid_v2.py` to non-v2 scripts,
  and gpu_guard targets that string; v3 rejected it (argparse exit 2), so v3a added one ignored line [N:1556; N:1455].
- **CR diff before any queue edit**, then backup + md5 old/new + line diff, single-quoted, trimmed, CRLF, no BOM
  [N:1491,1506,1527,1557]. QA logged the 15:36 Vienna edit as "no backup" although bak_1024j existed [Q:"15:36:51"; N:1527]: tell QA+CR at once.
- **Compare only FINAL FULL HOLDOUT lines** (per-epoch val subset changed 4M → 1M) [N:1529].
- **Pick by games, not teacher loss** (section 2). Loss rules like "e beats a" [N:1308] are screens, never verdicts.
- **Read the trainer header before origin claims**; train_resid.py derives from train_nnue.py (md5 5A161C70) [N:1187].
- **PAUSE files need an expiry**: a PAUSE_supervisor idled the GPU ~5 min [N:1456; Q:283].
- **g++ PATH:** parity failed 3× because msys64 was only on the child PATH [N:1287,1382,1520].
- **Data confounds:** log the training position count of every run and compare at equal data, or say it differs [N:1514].
