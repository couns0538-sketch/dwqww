#!/usr/bin/env python3
"""GrokChess 768->H clipped-ReLU trainer. --profile forge uses the Forge trainer."""
from __future__ import annotations
import sys
if __name__ in ("__main__", "__mp_main__"):
    from runtime import early_setup
    early_setup()
import argparse
import json
import math
import multiprocessing as mp
from pathlib import Path
import random
import signal
import sqlite3
import time
import numpy as np
import torch
from torch import nn
from torch.utils.data import IterableDataset, DataLoader, get_worker_info
from dataio import paths
from grok_format import GrokNet, features, QA, QB
from grok_export import export
from runtime import atomic, json_write, digest
from training_data import build_index, target_values, validation_fens


def fake_quant(tensor, scale, low, high):
    scaled = tensor * scale
    rounded = torch.sign(scaled) * torch.floor(torch.abs(scaled) + .5)
    quantized = torch.clamp(rounded, low, high) / scale
    return tensor + (quantized - tensor).detach()


class GrokModel(nn.Module):
    def __init__(self, hidden=64, qat=True):
        super().__init__()
        if not 8 <= hidden <= 1024:
            raise ValueError("Grok hidden width H must be 8..1024")
        self.shape, self.qat = [hidden], qat
        self.ft = nn.Linear(768, hidden)
        self.tail = nn.ModuleList([nn.Linear(2 * hidden, 1)])
        self.outB_anchor = 0
        nn.init.normal_(self.ft.weight, std=.01)
        nn.init.constant_(self.ft.bias, .25)
        nn.init.normal_(self.tail[0].weight, std=.01)
        nn.init.zeros_(self.tail[0].bias)

    def forward(self, x):
        w, b = self.ft.weight, self.ft.bias
        ow, ob = self.tail[0].weight, self.tail[0].bias
        if self.qat:
            w = fake_quant(w, QA, -32768, 32767)
            b = fake_quant(b, QA, -32768, 32767)
            ow = fake_quant(ow, QB, -32768, 32767)
            ob = fake_quant(ob, QA * QB, -(1 << 31), (1 << 31) - 1)
        a = torch.clamp(torch.nn.functional.linear(x, w, b), 0., 1.)
        return torch.nn.functional.linear(a.reshape(x.shape[0], -1), ow, ob) + self.outB_anchor / (QA * QB)

    def load_net(self, net):
        h = self.shape[0]
        if h != net.hidden:
            raise ValueError("Initial .nnue H does not match --hidden")
        with torch.no_grad():
            self.ft.weight.copy_(torch.from_numpy(np.array(net.ftW, dtype=np.float32).reshape(768, h).T.copy() / QA))
            self.ft.bias.copy_(torch.tensor(list(net.ftB), dtype=torch.float32) / QA)
            self.tail[0].weight.copy_(torch.tensor(list(net.outW), dtype=torch.float32).reshape(1, 2*h) / QB)
            self.tail[0].bias.zero_()
        # Store an exact integer anchor; float32 alone can lose low int32 bits.
        self.outB_anchor = net.outB


class Positions(IterableDataset):
    def __init__(self, index, validation=False, buffer=8192, seed=1):
        self.index, self.validation, self.buffer, self.seed = str(index), validation, buffer, seed

    def __iter__(self):
        worker = get_worker_info()
        wid, workers = (worker.id, worker.num_workers) if worker else (0, 1)
        db = sqlite3.connect(self.index)
        try:
            max_id = db.execute("SELECT MAX(id) FROM positions").fetchone()[0]
            lo, hi = max_id * wid // workers, max_id * (wid + 1) // workers
            query = db.execute("SELECT fen,cp,z FROM positions WHERE split=? AND id>? AND id<=? ORDER BY id",
                               (int(self.validation), lo, hi))
            rng = random.Random(self.seed + wid)
            buffer = []
            for row in query:
                if self.validation or not self.buffer:
                    yield self.sample(row)
                elif len(buffer) < self.buffer:
                    buffer.append(row)
                else:
                    k = rng.randrange(len(buffer))
                    old, buffer[k] = buffer[k], row
                    yield self.sample(old)
            rng.shuffle(buffer)
            for row in buffer:
                yield self.sample(row)
        finally:
            db.close()

    @staticmethod
    def sample(row):
        fen, cp, z = row
        w, b, turn = features(fen)
        return ((w, b) if turn == 0 else (b, w)), target_values(cp, z, turn == 1)


def collate(samples):
    x = np.zeros((len(samples), 2, 768), dtype=np.float32)
    y = np.empty((len(samples), 2), dtype=np.float32)
    for i, (active, targets) in enumerate(samples):
        for p in (0, 1):
            x[i, p, active[p]] = 1
        y[i] = targets
    return x, y


def loader_init(worker_id):
    signal.signal(signal.SIGINT, signal.SIG_IGN)
    from runtime import early_setup
    early_setup()
    torch.set_num_threads(1)


def select_device(name, device_name='7900 XT'):
    if name == 'directml':
        try:
            import torch_directml
        except ImportError as exc:
            raise ValueError('Install requirements-directml.txt in a Python 3.10 venv') from exc
        devices = [(i, torch_directml.device_name(i)) for i in range(torch_directml.device_count())]
        matches = [i for i, label in devices if device_name.lower() in label.lower()]
        if not matches:
            raise ValueError(f'DirectML device {device_name!r} not found; adapters: {devices}')
        i = matches[0]
        print(f'DirectML: {torch_directml.device_name(i)}', flush=True)
        return torch_directml.device(i)
    if name == 'rocm':
        if not torch.version.hip or not torch.cuda.is_available():
            raise ValueError('ROCm PyTorch is unavailable; use DirectML on Windows or an AMD-supported ROCm environment')
        return torch.device('cuda')
    return torch.device('cpu')


def loss_value(logits, targets, blend):
    prediction = torch.sigmoid(logits)
    return blend * (prediction - targets[:, :1]).square() + (1-blend) * (prediction - targets[:, 1:]).square()


def save_checkpoint(path, model, optimizer, payload):
    opt = optimizer.state_dict()
    opt['state'] = {k: {n: t.detach().cpu() if torch.is_tensor(t) else t for n, t in state.items()}
                    for k, state in opt['state'].items()}
    record = dict(payload, model={k: v.detach().cpu() for k, v in model.state_dict().items()},
                  optimizer=opt, outB_anchor=model.outB_anchor)
    atomic(path, lambda f: torch.save(record, f), replace=True)


def load_model(path):
    data = torch.load(path, map_location='cpu', weights_only=False)
    model = GrokModel(data['config']['hidden'], data['config']['qat'])
    model.load_state_dict(data['model'])
    model.outB_anchor = data.get('outB_anchor', 0)
    return model, data


def commit_epoch(directory, model, optimizer, record, improved):
    """Publish best first: last.pt must never refer to an unpublished best loss."""
    if improved:
        save_checkpoint(directory / 'best.pt', model, optimizer, record)
        json_write(directory / 'best.json', {k: v for k, v in record.items() if k != 'config'}, replace=True)
    save_checkpoint(directory / 'last.pt', model, optimizer, record)


def recover_best(directory, saved_loss, config):
    """A crash after best.pt but before last.pt is safe and explicitly reconciled."""
    path = directory / 'best.pt'
    if not path.exists():
        if math.isfinite(saved_loss):
            raise ValueError('last.pt refers to a missing best.pt; restore best.pt before resuming')
        return saved_loss
    _, saved = load_model(path)
    if saved['config'] != config or not math.isfinite(saved['validation_loss']):
        raise ValueError('best.pt does not match this training run')
    if saved['validation_loss'] > saved_loss:
        raise ValueError('best.pt is older than the best loss in last.pt; restore the matching checkpoint')
    json_write(directory / 'best.json', {k: v for k, v in saved.items()
               if k not in ('config', 'model', 'optimizer', 'outB_anchor')}, replace=True)
    return min(saved_loss, saved['validation_loss'])


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--profile', choices=['grok', 'forge'], default='grok')
    p.add_argument('--input', '--data', dest='input', nargs='+', required=True)
    p.add_argument('--hidden', '--shape', type=int, help='H=8..1024; default 64 or initial net H')
    p.add_argument('--init-net')
    p.add_argument('--run-dir', default='runs/grok')
    p.add_argument('--index')
    p.add_argument('--resume', action='store_true')
    p.add_argument('--device', choices=['directml', 'rocm', 'cpu'], default='directml')
    p.add_argument('--device-name', default='7900 XT')
    p.add_argument('--epochs', type=int, default=10)
    p.add_argument('--batch-size', type=int, default=1024)
    p.add_argument('--loader-workers', type=int, default=2)
    p.add_argument('--buffer', type=int, default=8192)
    p.add_argument('--lambda', dest='blend', type=float, default=.8, help='Eval weight; 1 = teacher only')
    p.add_argument('--learning-rate', type=float, default=.001)
    p.add_argument('--validation-fraction', type=float, default=.02)
    p.add_argument('--seed', type=int, default=1)
    p.add_argument('--no-qat', action='store_true')
    p.add_argument('--no-export', action='store_true')
    p.add_argument('--net')
    p.add_argument('--cpus', default='12-15')
    a = p.parse_args(argv)
    from file_lock import FileLock
    with FileLock(Path(a.run_dir).resolve() / 'training.lock'):
        return train(a, p)


def train(a, p):
    if a.epochs < 1 or a.batch_size < 1 or a.loader_workers < 0 or a.buffer < 0:
        p.error('epochs/batch must be positive; loader-workers/buffer non-negative')
    if not 0 <= a.blend <= 1 or not math.isfinite(a.learning_rate) or a.learning_rate <= 0:
        p.error('lambda must be 0..1 and learning-rate finite and positive')
    torch.set_num_threads(1); torch.set_num_interop_threads(1)
    random.seed(a.seed); np.random.seed(a.seed); torch.manual_seed(a.seed)
    initial = GrokNet.load(a.init_net) if a.init_net else None
    hidden = a.hidden if a.hidden is not None else initial.hidden if initial else 64
    model = GrokModel(hidden, not a.no_qat)
    if initial: model.load_net(initial)
    directory = Path(a.run_dir).resolve(); directory.mkdir(parents=True, exist_ok=True)
    index = Path(a.index).resolve() if a.index else directory / 'positions.sqlite3'
    stats = build_index(paths(a.input), index, a.validation_fraction, a.seed)
    print(json.dumps(stats), flush=True)
    config = {'hidden': hidden, 'qat': not a.no_qat, 'blend': a.blend, 'seed': a.seed,
              'learning_rate': a.learning_rate, 'batch_size': a.batch_size,
              'validation_fraction': a.validation_fraction, 'index': str(index),
              'loader_workers': a.loader_workers, 'buffer': a.buffer,
              'init_net_sha256': digest(a.init_net) if a.init_net else None,
              'checkpoint_schema': 2}
    config_path = directory / 'config.json'
    if config_path.exists():
        if not a.resume: raise ValueError('Run already exists. Use --resume or a new --run-dir')
        if json.loads(config_path.read_text()) != config:
            raise ValueError('Run configuration changed. Start a new run or fine-tune --init-net')
    else: json_write(config_path, config)
    start_epoch, best, global_steps = 0, float('inf'), 0
    if a.resume and (directory / 'last.pt').exists():
        model, saved = load_model(directory / 'last.pt')
        if saved['config'] != config: raise ValueError('last.pt does not match the run configuration')
        start_epoch, best, global_steps = saved['completed_epochs'], saved['best_loss'], saved['steps']
    if a.resume:
        best = recover_best(directory, best, config)
    device = select_device(a.device, a.device_name); model.to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=a.learning_rate, foreach=False)
    if a.resume and (directory / 'last.pt').exists():
        optimizer.load_state_dict(saved['optimizer'])
        for state in optimizer.state.values():
            for name, value in state.items():
                if torch.is_tensor(value) and name != 'step': state[name] = value.to(device)
    stop = False
    def interrupt(signum, frame):
        nonlocal stop
        stop = True
    old = signal.signal(signal.SIGINT, interrupt)
    try:
        for epoch in range(start_epoch, a.epochs):
            kwargs = {'batch_size': a.batch_size, 'num_workers': a.loader_workers,
                      'collate_fn': collate, 'worker_init_fn': loader_init}
            if a.loader_workers: kwargs['multiprocessing_context'] = 'spawn'
            loader = DataLoader(Positions(index, buffer=a.buffer, seed=a.seed + epoch), **kwargs)
            model.train(); total = count = 0; last_print = time.monotonic()
            for x, y in loader:
                if stop: break
                x, y = torch.from_numpy(x).to(device), torch.from_numpy(y).to(device)
                optimizer.zero_grad(set_to_none=True)
                loss = loss_value(model(x), y, a.blend).mean()
                value = float(loss.detach().cpu())
                if not math.isfinite(value): raise ValueError('Non-finite training loss; best checkpoint preserved')
                loss.backward(); optimizer.step()
                total += value * len(x); count += len(x); global_steps += 1
                if time.monotonic() - last_print >= 60:
                    print(f'Epoch {epoch+1}: {count:,}/{stats["train"]:,} loss={total/count:.8f}', flush=True)
                    last_print = time.monotonic()
            if stop:
                save_checkpoint(directory / 'last.pt', model, optimizer,
                                {'config': config, 'completed_epochs': epoch, 'steps': global_steps,
                                 'best_loss': best, 'partial_epoch_replayed_on_resume': True})
                print('Interrupted: saved last.pt. Resume replays the partial epoch.', flush=True)
                return 130
            model.eval(); val_total = val_count = 0
            with torch.no_grad():
                val_loader = DataLoader(Positions(index, validation=True), batch_size=a.batch_size, collate_fn=collate)
                for x, y in val_loader:
                    if stop: break
                    x, y = torch.from_numpy(x).to(device), torch.from_numpy(y).to(device)
                    val_total += float(loss_value(model(x), y, a.blend).sum().cpu()); val_count += len(x)
            if stop:
                save_checkpoint(directory / 'last.pt', model, optimizer,
                                {'config': config, 'completed_epochs': epoch, 'steps': global_steps,
                                 'best_loss': best, 'partial_epoch_replayed_on_resume': True})
                print('Interrupted during validation; last.pt saved, best.pt preserved.', flush=True)
                return 130
            if val_count != stats['validation'] or count != stats['train']:
                raise ValueError('Training/validation row counts changed; checkpoint not advanced')
            validation = val_total / val_count
            if not math.isfinite(validation): raise ValueError('Non-finite validation loss; best checkpoint preserved')
            improved = validation < best; best = min(best, validation)
            record = {'config': config, 'completed_epochs': epoch+1, 'steps': global_steps,
                      'best_loss': best, 'validation_loss': validation, 'train_loss': total/count,
                      'train_positions': count, 'validation_positions': val_count}
            commit_epoch(directory, model, optimizer, record, improved)
            with open(directory / 'epochs.jsonl', 'a', encoding='utf-8') as log:
                log.write(json.dumps(dict(record, best_checkpoint_updated=improved)) + '\n')
            print(f'Epoch {epoch+1}: train={total/count:.8f} validation={validation:.8f} best={best:.8f}' + (' [saved best]' if improved else ''), flush=True)
        if not a.no_export:
            signal.signal(signal.SIGINT, old)
            model, _ = load_model(directory / 'best.pt')
            export(model, a.net or directory / 'net.nnue', validation_fens(index))
    finally: signal.signal(signal.SIGINT, old)
    return 0


if __name__ == '__main__':
    mp.freeze_support()
    try:
        profile_parser = argparse.ArgumentParser(add_help=False)
        profile_parser.add_argument('--profile', choices=['grok', 'forge'])
        profile, remaining = profile_parser.parse_known_args()
        legacy_data = any(arg == '--data' or arg.startswith('--data=') for arg in remaining)
        if profile.profile == 'forge' or (profile.profile is None and legacy_data):
            sys.argv = [sys.argv[0]] + remaining
            from forge_train import main as forge_main
            raise SystemExit(forge_main())
        raise SystemExit(main())
    except KeyboardInterrupt:
        print('Interrupted; completed checkpoints retained.', file=sys.stderr); raise SystemExit(130)
    except (ValueError, OSError, RuntimeError, sqlite3.Error) as exc:
        print(f'Error: {exc}', file=sys.stderr); raise SystemExit(1)
