# train_resid_v3b.py: RAM / leak derivative of train_resid_v3a.py (UNPROVEN until CR + PC smoke + QA)

- **v3b md5 `b6758004d19837c8d34d401ee7af5fd5`**. Base: v3a `3c39b1c34c6c34b1b8f7ae23bac43839` (CR PASS).
- Unified diff: `v3work/v3b/v3a_to_v3b.diff` (md5 `f97f80ba5385e83d8d277dc74b9727bf`, 299 lines).
- Needs `qa_adam_dml.py` (QA's file, unchanged) next to it, as v3a does. The `--guard-tag` argparse line is kept unchanged.
- PC leak probe, **not run on the PC**: `v3work/v3b/dml_leak_probe.py` (md5 `2e543b2634cc048072abd38e1cfcdeaa`). It is for QA or a CR-approved GPU slot.

## Why
- PC 2026-10-24: the trainer's private memory grows **~24 KB per training step**, the same in v2 and v3a and at both bs16384 and bs8192.
  - QA monitor `nnue_v3mon\mon.csv`, free-RAM slopes: p (v2) -116 MB/min, q (v2) -109, f001 (v3a, bs16k) -130, f003 (v3a, bs8k) -262, f004 (v3a, bs8k) -266.
  - f006 PID 4960: 12 GB at the start, 28.4 GB private at ep45 (21:46). About +200 MB/min.
  - The memory is returned when the process exits.
- The same v3a on CPU (box, 1000 steps, H256, bs8192) is flat at 752-756 MB, so the leak is on the DirectML side.
- Hypothesis (unproven): DirectML keeps state for each new Python-float scalar. These change every step: lr (cosine), blend and 1-blend, Adam's -lr/bc1 for 4 params, and bc2s during the first ~37k steps.
- Without the leak, f006 would need ~9.5-10 GB. The leak adds ~19 GB over 805k steps.

## Changes (all bit-identical on CPU: box smoke below)
1. **`--dev-scalars 1` (default)**
   - blend and 1-blend go into a preallocated 2-float device tensor. One `copy_` from a CPU float32 tensor per step updates it, and `targets_t()` uses it.
   - Adam: `AdamDMLDevScalars`, a subclass of QA's AdamDML built by `make_adam_devscalars`. [-lr/bc1, bc2s] sit in a preallocated 2-float device tensor, updated by one `copy_` per step.
   - Same op order as the CPU kernels: `addcdiv_(m, denom, value=s)` is `self + (s*m)/denom` and is replaced by `p.add_((m*s)/denom)`; `v.sqrt()/bc2s` divides by a 0-dim tensor.
   - Python float `g["lr"]` is still set (state_dict format unchanged). It costs 2 tiny H2D copies per step.
   - `--dev-scalars 0` gives exactly v3a's scalar path.
   - **DirectML bit-identity is NOT proven.** The DML kernels for addcdiv and scalar-tensor broadcast ops may round differently than the CPU ones. A PC smoke is needed (v3a vs v3b, md5 of outputs).
2. **int32 shuffle order, one reused buffer (`--order-buffers 1`, default)**
   - The buffer is filled by an in-place chunked arange plus `Generator.shuffle`, which gives the same order as `permutation(N)`. Checked equal for N = 1e3, 32e6 and 137,381,087, seeds 99000 and 25001 (numpy 2.5.4 box; the PC numpy version is not checked).
   - The next epoch's order is built as soon as the current producer has packed its last batch, overlapping the last ≤6 batches, the eval and the save.
   - That shuffle costs ~7 s CPU at N=137M (box), and part of it can lengthen the epoch boundary.
   - `--order-buffers 2` uses 2 int32 buffers (ping-pong) and keeps v3a's full overlap at +0.55 GB.
3. **`--mmap-data` (default off)**
   - The train set stays as per-file `np.memmap` views (`CatMap`, gather per file via searchsorted). Holdout is still loaded.
   - It takes 37 B/pos off private and commit (file-backed pages are reclaimable).
   - It can be slower on the PC if pages are not cached. Throughput on DML is not measured.
4. **Memory logging**
   - A `MEM <tag> trainer_private=..GB sys_avail=..GB` line after load, at each log interval and after each epoch save.
   - Windows: PrivateUsage / ullAvailPhys via ctypes. Linux: RssAnon / MemAvailable.
   - `--max-ram-gb X` prints a WARNING line when private > X. It never stops training.
   - The existing log lines are unchanged; the MEM lines are new, separate lines.
5. The `finally` block closes the current producer before the epoch builder. This is needed because a 1-buffer builder waits for it.

## RAM (f006 size: train 137,381,087 pos / 19 files, holdout 16,388,575; 35 B/pos .pos + 2 B/pos .hce)
| buffer | v3a | v3b default | v3b --mmap-data |
|---|---|---|---|
| train boards/score/meta/hce (37 B/pos) | 5.08 GB | 5.08 GB | ~0 private (file cache) |
| holdout (37 B/pos) | 0.61 GB | 0.61 GB | 0.61 GB |
| shuffle order | 2 x int64 = 2.20 GB | 1 x int32 = 0.55 GB | 0.55 GB |
| full-holdout idx int64 / val idx | 0.14 GB | 0.14 GB | 0.14 GB |
| prefetch queues (2 x 6 x 2.2 MB) | 0.03 GB | 0.03 GB | 0.03 GB |
| torch + DML runtime (est.) | ~1.5-2 GB | ~1.5-2 GB | ~1.5-2 GB |
| **sum without leak** | **~9.6-10.1 GB** | **~7.9-8.4 GB** | **~2.8-3.3 GB** |
| DML leak at 24 KB/step | +19 GB @805k steps | 0 if the fix works, else +9.6 GB @400k | same |

## Box smoke (CPU, nice 19): seed 99, 2 epochs, --max-train 32M (32 x 1M synthetic files), H256, bs8192, 150 steps/epoch, warmup 100, init-check, final-full-val
- Script: `v3work/v3b/smoke.sh`. Runs: `v3work/v3b/runs/s_*`.
- **All 8 outputs (ep1+ep2 .pt/.inc/.bin/.json) have identical md5s** across all 5 runs: v3a, v3b, v3b --mmap-data, v3b --order-buffers 2, v3b --dev-scalars 0.
  - ep2 .pt `c9e47b40466da1db9d95a5f690c80c25`, .inc `e2550a7d1219552924d4aec890e6a68c`, .bin `82037d17509743279505c0ded40ecab7`.
  - ep1 .inc `046ee6b6...` differs from ep2, so the weights moved. The log lines (BASELINE, INIT, EPOCH, FINAL FULL HOLDOUT) are identical.
- Peak RSS (ru_maxrss), N=32M:

| run | peak RSS | private after ep2 |
|---|---|---|
| v3a | **2218 MB** | |
| v3b | **1851 MB** (-367 MB; expected 2 x 256 MB int64 -> 128 MB int32 = -384) | 1.61 GB |
| v3b --mmap-data | 1884 MB VmRSS incl. file pages | **0.57 GB** |
| v3b --order-buffers 2 | 1989 MB | |
| v3b --dev-scalars 0 | 1856 MB | |

- The box CPU shows no leak in any mode, so the leak fix can only be tested on the PC (`dml_leak_probe.py`, or a v3b smoke slot reading the MEM lines).

## PC leak probe
- Usage: `python dml_leak_probe.py --steps 20000 [--warmup 1000 --every 2000 --batch 8192 --hidden 256 --modes const,float,tensor]`
- Each mode runs in its own child process and prints PrivateUsage growth per step after warmup.
- Expected if the hypothesis holds: float about 20+ KB/step, const and tensor about 0.
- CPU sanity on the box: all modes about 0 KB/step.
- Run it only in a QA / CR-approved GPU slot (one GPU job at a time, Idle, CPUs 0-3).

## Proposed queue diff (NOT applied; needs CR PASS + crew rules)
- Base: fresh copy of the live queue 21:45 Vienna, md5 **3744bf6a5cb37a022c3bff11268b9d4b** (165 CRLF lines, no BOM) -> `queue_3744bf6a_live.txt`.
- Proposed: `queue_v3b_cap400k_proposed.txt`, md5 **715a795a91e10d76e9f8a85cd5607241** (165 CRLF lines, no BOM, ASCII, no quotes, trimmed).
- Diff: `queue_v3b_cap400k.diff` (md5 bfacc869396b5e25a9d31681d9dc560d). Per-line table: `queue_v3b_cap400k_lines.tsv`.
- 130 not-started lines (f007 onward; all v3a bs8192) changed. Started/finished lines and f006 are untouched.
  - `--script train_resid_v3a.py` -> `train_resid_v3b.py` (all 130).
  - Cap of ≤400k total steps until the fix is proven on the PC: epochs >20 -> 20, and the name's `_eNN_` -> `_e20_` so the name matches what runs (65 lines).
- Math (bs8192, steps/epoch = floor(N/8192)):
  - self-play only, N = 137,381,087 -> 16,770 steps/epoch:
    - e16: 268,320 (kept)
    - e24 -> e20: 402,480 -> 335,400
    - e32 -> e20: 536,640 -> 335,400
    - e48 -> e20: 804,960 -> 335,400
  - + Sol (sol_indep_train.pos, 5,390,457 pos), N = 142,771,544 -> 17,428 steps/epoch:
    - e16: 278,848 (kept)
    - e32 -> e20: 557,696 -> 348,560
  - Growth headroom: e20 stays ≤400k while N ≤ 163.84M (~+21M, about 2 more sealed 10M-files beyond Sol lines). e16 stays ≤400k while N ≤ 204.8M.
- Worst case if the fix fails: 400k x 24 KB = 9.6 GB leak + ~8 GB base = ~17.6 GB.
- Note: fewer epochs compress the cosine/blend schedule, so the e24/e32/e48 recipes become e20 recipes.
- Deploy needs `train_resid_v3b.py` copied to `F:\forge_nnue_train\tools\` (md5 verified). Rebase if the queue md5 changes before apply.
