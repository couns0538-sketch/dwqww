# train_resid_v3.py — speed-only derivative of train_resid_v2.py

- v3: `forge_resid/train_resid_v3.py`, md5 `96916314df49cae5f2b6f5720b5c0ea4`, 531 lines, LF line endings, no BOM.
- Base: the **live PC v2**, `F:\forge_nnue_train\tools\train_resid_v2.py`, md5 `16d4c8cdfa51195001cc919393d28b7a`. This is QA's patch of 7640ffe6 from 2026-10-24 11:59, which added `--adam-impl` and `--loss-sync-every`. The box copy `forge_resid/train_resid_v2.py` (7640ffe6) does not have `--loss-sync-every`. The live file was rebuilt on the box byte-for-byte (md5 verified) at `v3work/train_resid_v2.py`. Neither v2 was edited.
- Diff for Code Review: `v3work/train_resid_v2_to_v3.diff` (`diff -u` live v2 → v3, 187 lines, +87/−17). A reference diff against the 7640ffe6 original is in `v3work/train_resid_v2orig7640_to_v3.diff`.

## Changes (same math, same data order, same loss for a given seed)
1. **The epoch boundary now overlaps.** `epoch_feed(e)` builds the same `default_rng(seed*1000+e).permutation(N)` order as v2, then its `Prefetcher`. `EpochPrep` runs it in a background thread: epoch e+1 is built while epoch e trains, and is swapped in at the boundary. Only one build runs at a time, so at most 2 orders exist (v2 also briefly held 2 at the boundary). `.astype(np.int64, copy=False)` gives the same values and skips a temporary copy when the order is already int64. A `try/finally` closes the builder and the prefetcher (stop event, drain, join) on any exit, including exceptions.
2. **Packed H2D.** `pack_batch` runs in the prefetcher thread and fills one contiguous float32 buffer of B×68 values: 64 codes, stm, wres, score, hce_logit. `to_dev` does one `.to(dev)`, then slices on the device. `codes`/`stm` become int64 via `.long()`; the others stay float32. hce_logit uses the same numpy expression as v2. All values fit exactly in float32. Each step sends 4.4 MB at bs16384 instead of 1.4 MB, in 1 copy instead of 5. Pinned memory isn't used because DirectML has none. `evaluate()` uses the same path.
3. **`--loss-sync-every` default is now 128** (was 32). The flag is kept.
- Unchanged: all CLI flags; the .pt/.inc/.bin/.json formats; the EPOCH, FINAL FULL HOLDOUT and Finished lines; `--final-full-val`; `--val-positions`; resume.

## Box verification (CPU torch 2.14.1, numpy 2.5.4, OMP 4 threads, nice 19)
- Synthetic Forge-format data (FPOS/FHCE). Run A: 219k train positions, H128, bs2048, 3 epochs. Run B: 40.8M train positions, H256, bs16384, 3×25 steps. Both used `--loss-sync-every 32` and adam-impl dml.
- **Bit-identical:** the permutation md5s match for every epoch. Every .inc and .bin md5 matches. Model and Adam state max abs diff is 0.0. Per-epoch train_mse, holdout and FINAL FULL HOLDOUT are identical.
- **Resume from an epoch-1 .pt:** v3 matches v2's uninterrupted run bitwise in 2 of 2 tries. v2 matched in 2 of 3 tries; in the third, v2 drifted from its own repeat by up to 1.9e-4 in the float weights. That is CPU-torch nondeterminism in v2 itself, not something v3 introduced.
- **Boundary gap**, main thread, from the "Saved" print to the first train batch: v2 1858 / 1738 ms at 40.8M positions (about 5.5 s at 127M if it scales linearly). v3 0.4 / 0.0 ms. Peak RSS: v2 2832 MB, v3 2778 MB.
- **Exception path:** a failure injected in step 1 and in mid-epoch 2 left 0 threads alive afterwards.
- `--adam-impl torch` with the default sync of 128 ran to completion. `py_compile` passes.

## Risks
- **DirectML:** float32→int64 `.long()` and `.view` on a device slice have not been tested on DML; v2 only cast uint8→int64. A short PC smoke run is needed before use.
- **Windows threads:** the builder thread does the 127M permutation (numpy releases the GIL) while the epoch trains on CPUs 0-3 at Idle priority, about 5 s of CPU per epoch. The next epoch's prefetcher starts early and holds 6 batches (about 26 MB).
- **RAM:** the next order (about 1.0 GB at 127M) now lives for the whole epoch instead of only at the boundary. On numpy 1.x on Windows, `permutation` returns int32, so building it briefly needs about 0.5 GB more.
