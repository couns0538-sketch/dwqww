#!/usr/bin/env python3
"""Export check: python (training-side, QAT) forward vs forge::nnue::evaluate built with the exported .inc.
usage: check_export.py <epoch.pt> <epoch.inc> <pos.txt> [n=10000]  (run on the PC; needs g++ at C:\\msys64\\ucrt64\\bin)"""
import sys, os, subprocess, shutil, random
import numpy as np, torch
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import train_resid as T
pt, inc, txt = sys.argv[1:4]; n = int(sys.argv[4]) if len(sys.argv) > 4 else 10000
src = r"F:\forge_nnue_train\tools\1ab50b2d"; work = os.path.join(os.path.dirname(os.path.abspath(inc)), "check_" + os.path.basename(inc)[:-4])
os.makedirs(work, exist_ok=True)
shutil.copy(inc, os.path.join(work, "nnue_weights.inc")); shutil.copy(os.path.join(src, "src", "nnue.cpp"), os.path.join(work, "nnue.cpp"))
exe = os.path.join(work, "nnue_check.exe")
env = dict(os.environ); env["PATH"] = r"C:\msys64\ucrt64\bin;" + env["PATH"]
subprocess.check_call(["g++", "-O2", "-std=c++20", "-ffp-contract=off", "-static", "-I" + os.path.join(src, "include"), os.path.join(os.path.dirname(os.path.abspath(__file__)), "nnue_check.cpp"),
                       os.path.join(work, "nnue.cpp"), os.path.join(src, "src", "bitboard.cpp"), os.path.join(src, "src", "board.cpp"), os.path.join(src, "src", "eval.cpp"), os.path.join(src, "src", "eval_params.cpp"), "-o", exe], env=env)
rng = random.Random(7); lines = []
with open(txt) as f:
    for i, l in enumerate(f):
        if rng.random() < n / 6.3e6 * 1.2: lines.append(l)
        if len(lines) >= n: break
open(os.path.join(work, "in.txt"), "w").write("".join(lines))
out = subprocess.run([exe, os.path.join(work, "in.txt")], capture_output=True, text=True)
print(out.stderr.strip())
rows = [list(map(int, l.split())) for l in out.stdout.strip().split("\n")]
eng = np.array(rows)
# python side
ck = torch.load(pt, map_location="cpu", weights_only=True)
m = T.NNUE(ck["config"]["hidden"], qat=True, residual=True); m.load_state_dict(ck["model"]); m.eval()
import tempfile
# build batch via fen2bin-equivalent: use python-chess to make codes
import chess
codes = np.zeros((len(lines), 64), np.int64); stm = np.zeros(len(lines), np.int64)
for j, l in enumerate(lines):
    b = chess.Board(l.split("|")[0].strip()); stm[j] = 0 if b.turn else 1
    for sq, pc in b.piece_map().items():
        codes[j, sq] = pc.piece_type + (0 if pc.color else 6)
with torch.no_grad():
    out = m(torch.from_numpy(codes), torch.from_numpy(stm), torch.zeros(len(lines))).numpy()  # logit, hce 0
py_cp = out * 400.0 / 2.25
d = py_cp - eng[:, 0]
print(f"n={len(lines)} python-vs-engine net cp: max|diff|={np.abs(d).max():.3f} mean|diff|={np.abs(d).mean():.4f} "
      f"(engine truncates to int; expect <1) max|net cp|={np.abs(eng[:,0]).max()}")
tr = np.trunc(py_cp) - eng[:, 0]
print(f"vs trunc(python cp): exact {int((tr == 0).sum())}/{len(tr)}, max|diff|={int(np.abs(tr).max())} (engine truncates float cp to int)")
print("PASS" if np.abs(d).max() < 1.001 and (tr == 0).mean() > 0.999 else "FAIL")
