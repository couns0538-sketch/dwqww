#!/usr/bin/env python3
"""Evaluate an existing Forge nnue_weights.inc (residual or standalone) on the holdout with train_resid's loss.
usage: eval_inc.py <nnue_weights.inc> [--standalone]"""
import re, sys, os, numpy as np, torch
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import train_resid as T
inc = open(sys.argv[1]).read()
residual = re.search(r"#define FORGE_NNUE_RESIDUAL\s+(\d)", inc)
residual = bool(int(residual.group(1))) if residual else False
def arr(name):
    m = re.search(name + r"\[\d+\]\s*=\s*\{([^}]*)\}", inc, re.S)
    return np.array([int(x) for x in m.group(1).replace("\n", " ").split(",") if x.strip()], np.float32)
w1, b1, w2 = arr("NnueW1"), arr("NnueB1"), arr("NnueW2")
b2 = float(re.search(r"NnueB2\s*=\s*(-?\d+)", inc).group(1))
H = len(b1)
m = T.NNUE(H, qat=False, residual=residual)
with torch.no_grad():
    m.ft.weight.copy_(torch.from_numpy(w1.reshape(768, H).T / 4096.0)); m.ft.bias.copy_(torch.from_numpy(b1 / 4096.0))
    m.out.weight.copy_(torch.from_numpy(w2.reshape(1, 2 * H) / 4096.0)); m.out.bias.fill_(b2 / 4096.0)
print(f"{sys.argv[1]}: H={H} residual={residual}", flush=True)
dev = T.device_for("directml")
m.to(dev)
Hd = r"D:\grok-pc-data\forge_push\nnue_data"
hold = T.load_set([Hd + r"\pos\forge_selfplay_013.pos", Hd + r"\pos\forge_selfplay_014.pos"], Hd + r"\hce")
idx = np.arange(hold["n"], dtype=np.int64)
r, n = T.evaluate(m, hold, idx, dev, 2.25, 4096, blends=(1.0, 0.6, 0.0))
b, _ = T.evaluate(m, hold, idx, dev, 2.25, 4096, blends=(1.0, 0.6, 0.0), baseline=True)
print(f"FULL holdout n={n:,}: net teacher={r[1.0]:.6f} b0.6={r[0.6]:.6f} b0.0(result only)={r[0.0]:.6f} | HCE alone teacher={b[1.0]:.6f} b0.6={b[0.6]:.6f} b0.0={b[0.0]:.6f}")
print(f"net vs HCE: teacher {100*(1-r[1.0]/b[1.0]):+.2f}%  b0.6 {100*(1-r[0.6]/b[0.6]):+.2f}%  result-only {100*(1-r[0.0]/b[0.0]):+.2f}%")
