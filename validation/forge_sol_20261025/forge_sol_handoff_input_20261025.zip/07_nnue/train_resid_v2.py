#!/usr/bin/env python3
"""Forge-768 residual NNUE trainer (GPU, DirectML/CPU). Own code, derived in structure from the
supplied train_nnue.py (md5 5A161C70...), but fed from pre-converted binaries:

  *.pos  (tools/fen2bin.cpp)  nibble boards + int16 teacher score (STM cp) + meta (stm, WHITE result)
  *.hce  (tools/hce_dump.cpp) int16 Forge-1ab50b2d evaluate_uncached (STM cp), line-aligned with .pos

Model/export are the same Forge net (768 -> H per perspective, SCReLU, 2H -> 1, int16 QAT, scale 4096).
--residual: logit = net(x) + K*hce/400, output layer starts at zero => first forward == HCE alone,
export writes FORGE_NNUE_RESIDUAL 1.  Loss = MSE(sigmoid(logit), blend*sigmoid(K*score/400) + (1-blend)*stm_result).
Holdout = whole files (never trained on).  Blend ramps linearly over training progress.
"""
from __future__ import annotations
import argparse, glob, json, math, os, queue, sys, threading, time, uuid
from pathlib import Path
import numpy as np
import torch
from torch import nn
import torch.nn.functional as F

FEATURES = 768
SCALE = 4096.0
K_DEFAULT = 2.25


# ----------------------------------------------------------------------------- data
def read_pos_header(path):
    with open(path, "rb") as f:
        h = f.read(16)
    if h[:4] != b"FPOS" or int.from_bytes(h[4:8], "little") != 1:
        raise ValueError(f"bad pos header {path}")
    return int.from_bytes(h[8:16], "little")


def load_set(pos_files, hce_dir, limit=None, need_hce=True):
    """Load pos(+hce) files into RAM, in the given order. limit = max positions (takes file prefixes)."""
    ns, picks = [], []
    total = 0
    for p in pos_files:
        n = read_pos_header(p)
        if limit is not None and total + n > limit:
            n_use = limit - total
        else:
            n_use = n
        if n_use <= 0:
            break
        picks.append((p, n, n_use))
        total += n_use
    boards = np.empty((total, 32), np.uint8)
    score = np.empty(total, np.int16)
    meta = np.empty(total, np.uint8)
    hce = np.empty(total, np.int16)
    o = 0
    for p, n, n_use in picks:
        b = np.memmap(p, np.uint8, "r", 16, (n, 32))
        s = np.memmap(p, np.int16, "r", 16 + n * 32, (n,))
        m = np.memmap(p, np.uint8, "r", 16 + n * 34, (n,))
        boards[o:o + n_use] = b[:n_use]; score[o:o + n_use] = s[:n_use]; meta[o:o + n_use] = m[:n_use]
        if (m[:n_use] == 255).any():
            raise ValueError(f"bad records in {p}")
        if need_hce:
            hp = Path(hce_dir) / (Path(p).stem + ".hce")
            with open(hp, "rb") as f:
                h = f.read(16)
            if h[:4] != b"FHCE" or int.from_bytes(h[8:16], "little") != n:
                raise ValueError(f"hce header/count mismatch {hp} vs {p}")
            hh = np.memmap(hp, np.int16, "r", 16, (n,))
            if (hh[:n_use] == -32768).any():
                raise ValueError(f"bad hce in {hp}")
            hce[o:o + n_use] = hh[:n_use]
            del hh
        del b, s, m
        o += n_use
    return dict(boards=boards, score=score, meta=meta, hce=hce, n=total, files=[(p, n_use) for p, n, n_use in picks])


def make_batch(d, idx):
    b = d["boards"][idx]
    codes = np.empty((len(idx), 64), np.uint8)
    codes[:, 0::2] = b & 15
    codes[:, 1::2] = b >> 4
    m = d["meta"][idx]
    return (codes, (m & 1), (m >> 1), d["score"][idx], d["hce"][idx])


class Prefetcher:
    def __init__(self, d, order, batch, depth=6):
        self.q = queue.Queue(depth)
        self.d, self.order, self.batch = d, order, batch
        self.t = threading.Thread(target=self.run, daemon=True)
        self.t.start()

    def run(self):
        try:
            n = len(self.order)
            for i in range(0, n - self.batch + 1, self.batch):
                idx = np.sort(self.order[i:i + self.batch])
                self.q.put(make_batch(self.d, idx))
            self.q.put(None)
        except BaseException as e:  # noqa
            self.q.put(e)

    def __iter__(self):
        while True:
            x = self.q.get()
            if x is None:
                return
            if isinstance(x, BaseException):
                raise x
            yield x


def eval_order(n, batch):
    """Sequential order for evaluation incl. the tail (as full batches only; tail dropped is reported)."""
    return np.arange(n, dtype=np.int64)


# ----------------------------------------------------------------------------- model
def features(codes, black):
    """codes [B,64] int64 (0 empty, 1..6 white PNBRQK, 7..12 black); black [B] int64 perspective colour.
    Returns [B,64] feature index (768 = empty) == forge::nnue::feature_index."""
    sq = torch.arange(64, device=codes.device).unsqueeze(0)
    c = codes - 1
    color = torch.div(c, 6, rounding_mode="floor")
    typ = c - color * 6
    bl = black.unsqueeze(1)
    rel = (color != bl).long()
    rsq = torch.where(bl == 1, sq ^ 56, sq.expand_as(codes))
    f = (rel * 6 + typ) * 64 + rsq
    return torch.where(codes > 0, f, torch.full_like(f, FEATURES))


def dense(codes, black):
    f = features(codes, black)
    x = torch.zeros(codes.shape[0], FEATURES + 1, device=codes.device).scatter_(1, f, 1.0)
    return x[:, :FEATURES]


class NNUE(nn.Module):
    def __init__(self, hidden, qat=True, residual=True):
        super().__init__()
        self.hidden, self.qat, self.residual = hidden, qat, residual
        self.ft = nn.Linear(FEATURES, hidden)
        self.out = nn.Linear(2 * hidden, 1)
        nn.init.normal_(self.ft.weight, std=0.02)
        nn.init.zeros_(self.ft.bias)
        nn.init.zeros_(self.out.bias)
        if residual:
            nn.init.zeros_(self.out.weight)  # first forward == HCE alone

    def q(self, p):
        if not self.qat:
            return p
        scaled = p * SCALE
        rounded = torch.sign(scaled) * torch.floor(torch.abs(scaled) + 0.5)
        qv = torch.clamp(rounded, -32767, 32767) / SCALE
        return p + (qv - p).detach()

    def forward(self, codes, stm, hce_logit):
        xs = dense(codes, stm)
        xo = dense(codes, 1 - stm)
        w, b = self.q(self.ft.weight), self.q(self.ft.bias)
        hs = torch.clamp(F.linear(xs, w, b), 0.0, 1.0).square()
        ho = torch.clamp(F.linear(xo, w, b), 0.0, 1.0).square()
        out = F.linear(torch.cat([hs, ho], 1), self.q(self.out.weight), self.q(self.out.bias)).squeeze(1)
        return out + hce_logit if self.residual else out

    @torch.no_grad()
    def project_weights(self):
        for p in self.parameters():
            p.clamp_(-32767 / SCALE, 32767 / SCALE)


def targets(score_t, stm_t, wres_t, k, blend):
    """score int16 STM cp, wres = white result*2 (0,1,2). Returns teacher, stm_result, blended target."""
    teacher = torch.sigmoid(torch.clamp(score_t * (k / 400.0), -40, 40))
    white = wres_t * 0.5
    stm_res = torch.where(stm_t == 0, white, 1.0 - white)
    return teacher, stm_res, blend * teacher + (1.0 - blend) * stm_res


def to_dev(batch, dev, k):
    codes, stm, wres, score, hce = batch
    codes = torch.from_numpy(codes).to(dev).long()
    stm = torch.from_numpy(stm.astype(np.int64)).to(dev)
    wres = torch.from_numpy(wres.astype(np.float32)).to(dev)
    score = torch.from_numpy(score.astype(np.float32)).to(dev)
    hce_l = torch.from_numpy(hce.astype(np.float32) * (k / 400.0)).to(dev)
    return codes, stm, wres, score, hce_l


@torch.no_grad()
def evaluate(model, d, idx_all, dev, k, batch, blends=(1.0, 0.6), baseline=False, limit_batches=None):
    """MSE on positions idx_all. Returns dict blend -> mse. baseline=True ignores the net (HCE alone)."""
    sums = {b: 0.0 for b in blends}
    cnt = 0
    model.eval()
    nb = len(idx_all) // batch
    if limit_batches:
        nb = min(nb, limit_batches)
    pf = Prefetcher(d, idx_all[: nb * batch], batch)
    for bt in pf:
        codes, stm, wres, score, hce_l = to_dev(bt, dev, k)
        logit = hce_l if baseline else model(codes, stm, hce_l)
        pred = torch.sigmoid(logit)
        for b in blends:
            _, _, tg = targets(score, stm, wres, k, b)
            sums[b] += float(F.mse_loss(pred, tg, reduction="sum").cpu())
        cnt += len(codes)
    model.train()
    return {b: sums[b] / max(cnt, 1) for b in blends}, cnt


# ----------------------------------------------------------------------------- export
def atomic_write(path, write):
    temp = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
    try:
        with open(temp, "xb") as dst:
            write(dst)
            dst.flush()
            os.fsync(dst.fileno())
        if path.exists():
            raise FileExistsError(str(path))
        os.rename(temp, path)
    finally:
        if temp.exists():
            temp.unlink()


def export_forge(model, stem, k, residual):
    hidden = model.hidden
    arrays = [model.ft.weight.detach().cpu().t().contiguous().numpy().ravel(),
              model.ft.bias.detach().cpu().numpy(),
              model.out.weight.detach().cpu().numpy().ravel(),
              model.out.bias.detach().cpu().numpy()]
    if not all(np.isfinite(v).all() for v in arrays):
        raise RuntimeError("Non-finite parameters; refusing to export")
    quant = []
    for v in arrays:
        sc = v.astype(np.float64) * SCALE
        r = np.sign(sc) * np.floor(np.abs(sc) + 0.5)
        if (np.abs(r) > 32767).any():
            raise ValueError("Weights exceed int16 range")
        quant.append(r.astype(np.int16))
    lines = ["// Generated by train_resid.py; Forge-768 network.",
             "#include <cstdint>", f"#define FORGE_NNUE_RESIDUAL {1 if residual else 0}",
             f"static_assert(forge::nnue::InputCount == 768 && forge::nnue::HiddenSize == {hidden},",
             '              "NNUE shape mismatch; rebuild with the correct FORGE_NNUE_HIDDEN");',
             'static_assert(forge::nnue::SigmoidK == 2.25F, "NNUE output scale mismatch");',
             'static_assert(forge::nnue::WeightScale == 4096.0F && forge::nnue::OutputScale == 4096.0F,',
             '              "NNUE quantization scale mismatch");']
    for name, v in zip(("NnueW1", "NnueB1", "NnueW2"), quant[:3]):
        lines.append(f"static const std::int16_t {name}[{len(v)}] = {{")
        lines.extend("  " + ", ".join(map(str, v[i:i + 24])) + "," for i in range(0, len(v), 24))
        lines.append("};")
    lines.append(f"static const std::int16_t NnueB2 = {int(quant[3][0])};")
    atomic_write(stem.with_suffix(".inc"), lambda dst: dst.write(("\n".join(lines) + "\n").encode("ascii")))
    raw = b"".join(np.asarray(v, dtype="<f4").tobytes() for v in arrays)
    atomic_write(stem.with_suffix(".bin"), lambda dst: dst.write(raw))


def cpu_copy(v):
    if torch.is_tensor(v):
        return v.detach().cpu().clone()
    if isinstance(v, dict):
        return {a: cpu_copy(b) for a, b in v.items()}
    if isinstance(v, list):
        return [cpu_copy(b) for b in v]
    return v


def device_for(name, index=None, requested="7900 XT"):
    if name == "cpu":
        return torch.device("cpu")
    import torch_directml
    names = [torch_directml.device_name(i) for i in range(torch_directml.device_count())]
    if index is None:
        m = [i for i, n in enumerate(names) if requested.lower() in n.lower()]
        if not m:
            raise ValueError(f"GPU {requested!r} not found: {names}")
        index = m[0]
    print(f"DirectML GPU {index}: {names[index]}", flush=True)
    return torch_directml.device(index)


# ----------------------------------------------------------------------------- main
def expand(patterns):
    out = []
    for p in patterns:
        out.extend(sorted(glob.glob(p)))
    return sorted(set(out))


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--train", nargs="+", help="train .pos files/globs (hce files expected in --hce-dir)")
    ap.add_argument("--holdout", nargs="+", required=True, help="holdout .pos files (whole files)")
    ap.add_argument("--hce-dir", required=True)
    ap.add_argument("--device", choices=["directml", "cpu"], default="directml")
    ap.add_argument("--device-index", type=int)
    ap.add_argument("--shape", type=int, default=128, help="hidden width H")
    ap.add_argument("--residual", action="store_true")
    ap.add_argument("--baseline-only", action="store_true", help="report HCE-alone loss on the holdout and exit")
    ap.add_argument("--epochs", type=int, default=8)
    ap.add_argument("--batch-size", type=int, default=4096)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--min-lr-frac", type=float, default=0.01)
    ap.add_argument("--warmup-steps", type=int, default=300)
    ap.add_argument("--blend-start", type=float, default=1.0)
    ap.add_argument("--blend-end", type=float, default=0.6)
    ap.add_argument("--sigmoid-k", type=float, default=K_DEFAULT)
    ap.add_argument("--no-qat", action="store_true")
    ap.add_argument("--max-train", type=int, default=0, help="limit training positions (file prefixes); 0 = all")
    ap.add_argument("--val-positions", type=int, default=4_000_000, help="fixed random holdout subset per epoch (0 = all)")
    ap.add_argument("--final-full-val", action="store_true")
    ap.add_argument("--steps-per-epoch", type=int, default=0)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--run-dir", default="forge-resid-run")
    ap.add_argument("--resume")
    ap.add_argument("--log-every", type=float, default=30.0)
    ap.add_argument("--init-check", action="store_true", help="assert residual init val == baseline val")
    a = ap.parse_args()
    k = a.sigmoid_k
    if k != K_DEFAULT:
        print("WARNING: export needs sigmoid-k 2.25", flush=True)
    torch.manual_seed(a.seed)
    dev = device_for(a.device, a.device_index)
    run = Path(a.run_dir)
    run.mkdir(parents=True, exist_ok=bool(a.resume) or a.baseline_only)
    (run / f"settings_{int(time.time())}.txt").write_text(" ".join(sys.argv) + "\n" + json.dumps(vars(a), indent=1))
    t0 = time.time()
    hold_files = expand(a.holdout)
    hold = load_set(hold_files, a.hce_dir)
    print(f"holdout: {hold['n']:,} positions from {len(hold_files)} files ({time.time() - t0:.0f}s)", flush=True)
    rng = np.random.default_rng(12345)
    if a.val_positions and a.val_positions < hold["n"]:
        val_idx = np.sort(rng.choice(hold["n"], a.val_positions, replace=False))
    else:
        val_idx = np.arange(hold["n"], dtype=np.int64)
    full_idx = np.arange(hold["n"], dtype=np.int64)
    model = NNUE(a.shape, qat=not a.no_qat, residual=a.residual or a.baseline_only).to(dev)
    base_sub, nb = evaluate(model, hold, val_idx, dev, k, a.batch_size, baseline=True)
    print(f"BASELINE HCE-alone holdout subset n={nb:,}: mse_teacher(blend1.0)={base_sub[1.0]:.6f} mse_blend0.6={base_sub[0.6]:.6f}", flush=True)
    if a.baseline_only:
        full, nf = evaluate(model, hold, full_idx, dev, k, a.batch_size, baseline=True)
        print(f"BASELINE HCE-alone holdout FULL n={nf:,}: mse_teacher={full[1.0]:.6f} mse_blend0.6={full[0.6]:.6f}", flush=True)
        # extra blends for reference
        ex, _ = evaluate(model, hold, full_idx, dev, k, a.batch_size, blends=(0.0, 0.4, 0.8), baseline=True)
        print("BASELINE extra blends full: " + " ".join(f"b{b}={v:.6f}" for b, v in ex.items()), flush=True)
        return 0
    if a.init_check:
        init, _ = evaluate(model, hold, val_idx, dev, k, a.batch_size)
        print(f"INIT residual net: mse_teacher={init[1.0]:.6f} mse_b0.6={init[0.6]:.6f} (baseline {base_sub[1.0]:.6f}/{base_sub[0.6]:.6f})", flush=True)
        if abs(init[1.0] - base_sub[1.0]) > 1e-6 or abs(init[0.6] - base_sub[0.6]) > 1e-6:
            print("INIT CHECK FAILED", flush=True)
            return 3
        print("INIT CHECK OK (residual init == HCE alone)", flush=True)
    train_files = expand(a.train)
    train_files = [f for f in train_files if f not in hold_files]
    t1 = time.time()
    train = load_set(train_files, a.hce_dir, limit=a.max_train or None)
    N = train["n"]
    print(f"train: {N:,} positions from {len(train['files'])} files ({time.time() - t1:.0f}s load)", flush=True)
    spe = N // a.batch_size
    if a.steps_per_epoch:
        spe = min(spe, a.steps_per_epoch)
    total_steps = spe * a.epochs
    opt = torch.optim.Adam(model.parameters(), lr=a.lr, foreach=False)
    start_epoch, step = 0, 0
    if a.resume:
        ck = torch.load(a.resume, map_location="cpu", weights_only=True)
        model.load_state_dict(ck["model"]); opt.load_state_dict(ck["optimizer"])
        start_epoch, step = ck["next_epoch"], ck["step"]
        print(f"resumed {a.resume}: next_epoch={start_epoch} step={step}", flush=True)
    config = {"hidden": a.shape, "residual": bool(a.residual), "qat": not a.no_qat, "sigmoid_k": k,
              "features": "forge768-relative-pieces-rank-flip", "epochs": a.epochs, "steps_per_epoch": spe}

    def lr_at(s):
        if s < a.warmup_steps:
            return a.lr * (s + 1) / a.warmup_steps
        pr = (s - a.warmup_steps) / max(1, total_steps - a.warmup_steps)
        return a.lr * (a.min_lr_frac + (1 - a.min_lr_frac) * 0.5 * (1 + math.cos(math.pi * min(pr, 1.0))))

    def blend_at(s):
        pr = min(1.0, s / max(1, total_steps - 1))
        return a.blend_start + (a.blend_end - a.blend_start) * pr

    print(f"steps/epoch={spe:,} total={total_steps:,} batch={a.batch_size} lr={a.lr} cosine blend {a.blend_start}->{a.blend_end}", flush=True)
    tstart = time.time(); last = tstart; seen = 0; ls = 0.0
    for ep in range(start_epoch, a.epochs):
        order = np.random.default_rng(a.seed * 1000 + ep).permutation(N).astype(np.int64)[: spe * a.batch_size]
        pf = Prefetcher(train, order, a.batch_size)
        ep_loss = 0.0; ep_n = 0; te = time.time()
        for bt in pf:
            codes, stm, wres, score, hce_l = to_dev(bt, dev, k)
            for g in opt.param_groups:
                g["lr"] = lr_at(step)
            blend = blend_at(step)
            _, _, tg = targets(score, stm, wres, k, blend)
            opt.zero_grad(set_to_none=True)
            pred = torch.sigmoid(model(codes, stm, hce_l))
            loss = F.mse_loss(pred, tg)
            v = float(loss.detach().cpu())
            if not math.isfinite(v):
                raise RuntimeError("non-finite loss")
            loss.backward(); opt.step(); model.project_weights()
            step += 1; n = len(codes); seen += n; ls += v * n; ep_loss += v * n; ep_n += n
            now = time.time()
            if now - last >= a.log_every:
                print(f"ep{ep + 1} step {step:,}/{total_steps:,} blend={blend:.3f} lr={lr_at(step):.2e} train_mse={ls / seen:.6f} {seen / (now - tstart):,.0f} pos/s", flush=True)
                last = now
        vs, nv = evaluate(model, hold, val_idx, dev, k, a.batch_size, blends=(1.0, 0.6, 0.8))
        print(f"EPOCH {ep + 1}/{a.epochs} done in {time.time() - te:.0f}s train_mse={ep_loss / max(ep_n, 1):.6f} | HOLDOUT n={nv:,} "
              f"mse_teacher={vs[1.0]:.6f} (HCE {base_sub[1.0]:.6f}, {100 * (1 - vs[1.0] / base_sub[1.0]):+.2f}%) "
              f"mse_b0.6={vs[0.6]:.6f} (HCE {base_sub[0.6]:.6f}, {100 * (1 - vs[0.6] / base_sub[0.6]):+.2f}%) mse_b0.8={vs[0.8]:.6f}", flush=True)
        stem = run / f"epoch{ep + 1:03d}-step{step:09d}"
        payload = {"config": config, "model": cpu_copy(model.state_dict()), "optimizer": cpu_copy(opt.state_dict()),
                   "next_epoch": ep + 1, "step": step, "val": {str(b): v for b, v in vs.items()}}
        atomic_write(stem.with_suffix(".pt"), lambda dst: torch.save(payload, dst))
        export_forge(model, stem, k, bool(a.residual))
        atomic_write(stem.with_suffix(".json"), lambda dst: dst.write((json.dumps({**config, "val": payload["val"], "baseline": {str(b): v for b, v in base_sub.items()}}, indent=1) + "\n").encode()))
        print(f"Saved {stem.name} (.pt .inc .bin .json)", flush=True)
    if a.final_full_val:
        full, nf = evaluate(model, hold, full_idx, dev, k, a.batch_size, blends=(1.0, 0.6, 0.8))
        bfull, _ = evaluate(model, hold, full_idx, dev, k, a.batch_size, blends=(1.0, 0.6, 0.8), baseline=True)
        print(f"FINAL FULL HOLDOUT n={nf:,}: net mse_teacher={full[1.0]:.6f} mse_b0.6={full[0.6]:.6f} mse_b0.8={full[0.8]:.6f} | HCE {bfull[1.0]:.6f}/{bfull[0.6]:.6f}/b0.8 {bfull[0.8]:.6f}", flush=True)
    print(f"Finished: {seen:,} positions in {time.time() - tstart:.0f}s", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
