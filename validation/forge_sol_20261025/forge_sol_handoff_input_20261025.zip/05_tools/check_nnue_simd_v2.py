#!/usr/bin/env python3
"""Check that an AVX2 build actually widens the NNUE output arithmetic.

Accepted lowerings of the max(0, x) clamp in forge::nnue::evaluate:
  * x86-64-v3 (AVX2):          vmaxps on %ymm
  * znver5 (AVX-512VL):        a 256-bit compare into a mask register
                               (vcmpps / vcmp<pred>ps %ymm -> %k) followed by
                               masked zeroing ({%k}{z}) or vblendmps on %ymm.
The mask path is data-flow checked (see find_mask_clamp). A zmm-only clamp
FAILs by the 256-bit contract.
Always required: 256-bit vminps, vmulps and vaddps. Any FMA (vfmadd/vfnmadd/
vfmsub/vfnmsub, any form) is a FAIL because it changes the rounding contract.
"""
import argparse
import re
import subprocess

# --- AVX-512VL mask clamp --------------------------------------------------
# AT&T order (objdump): vcmp<pred>ps SRC2, SRC1, %kN  sets kN[i] = SRC1[i] <pred> SRC2[i].
# objdump prints the predicate as a mnemonic (imm 0x0e -> vcmpgtps); the raw
# "vcmpps $imm" form is still parsed for safety. For mask = (x > 0) the compare
# must be "x GT 0" with x = SRC1 and the zero vector = SRC2. Accepted predicates
# are only the greater-than family, true exactly when SRC1 > SRC2:
#   0x0e GT_OS  (vcmpgtps)      0x1e GT_OQ  (vcmpgt_oqps)
#   0x06 NLE_US (vcmpnleps)     0x16 NLE_UQ (vcmpnle_uqps)
# (NLE is also true on NaN; accumulators are never NaN, and a NaN lane would be
# caught by bench/forge_tests.) lt/le/eq/ngt/... are rejected (CR MEDIUM-2), as
# is a gt/nle compare whose SRC1 is a register zeroed in the body (0 > x).
# Data flow (CR MEDIUM-1): a LATER ymm instruction must use the same %kN as a
# write mask, either "{%kN}{z}" zero-masking with x as a source operand, or
# "vblendmps x, other, dst{%kN}" (dst = kN ? x : other). The search stops if
# %kN is redefined first. Only %k1..%k7 are accepted (k0 cannot be a write
# mask; a k0 + kmov route is rejected, a false FAIL in the safe direction).
GT_MNEMONICS = {"gt", "gt_os", "gt_oq", "nle", "nle_us", "nle_uq"}
GT_IMMS = {0x06, 0x0e, 0x16, 0x1e}
CMP_RE = re.compile(r"^vcmp([a-z_]*)ps\s+(?:\$(0x[0-9a-f]+|\d+),)?"
                    r"%ymm(\d+),%ymm(\d+),%k([0-7])\s*$")
ZERO_RE = re.compile(r"^(?:vxorps|vpxor|vpxord|vpxorq)\s+%[xy]mm(\d+),%[xy]mm\1,%[xy]mm\1\s*$")


def instructions(body):
    for line in body.splitlines():
        parts = line.split("\t")
        if len(parts) >= 3:
            yield re.sub(r"^\{evex\}\s*", "", parts[-1].strip())


def find_mask_clamp(body):
    insns = list(instructions(body))
    zeroed = set()
    for i, ins in enumerate(insns):
        z = ZERO_RE.search(ins)
        if z:
            zeroed.add(z.group(1))
        m = CMP_RE.search(ins)
        if not m:
            continue
        pred, imm, src2, src1, k = m.groups()
        if k == "0":
            continue
        if pred:
            if pred not in GT_MNEMONICS or imm:
                continue
        elif imm is None or int(imm, 0) not in GT_IMMS:
            continue
        if src1 in zeroed:
            continue
        x = f"%ymm{src1}"
        for later in insns[i + 1:]:
            if re.search(rf",%k{k}\s*$", later):
                break
            if f"%ymm" in later and f"{{%k{k}}}{{z}}" in later:
                sources = later.split("{")[0].rsplit(",", 1)[0]
                if re.search(rf"{re.escape(x)}(?!\d)", sources):
                    return "vcmpps+masked-zeroing"
            bl = re.match(rf"vblendmps\s+%ymm(\d+),%ymm\d+,%ymm\d+\{{%k{k}\}}", later)
            if bl and f"%ymm{bl.group(1)}" == x:
                return "vcmpps+vblendmps"
    return None


parser = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
parser.add_argument("object", help="nnue object file or unstripped executable")
args = parser.parse_args()
assembly = subprocess.check_output(["objdump", "-Cd", args.object], text=True)
match = re.search(r"^[0-9a-f]+ <forge::nnue::evaluate\([^\n]*>:\n(.*?)(?=\n[0-9a-f]+ <|\Z)",
                  assembly, re.M | re.S)
if not match:
    raise SystemExit("FAIL: NNUE evaluate symbol not found")
body = match.group(1)

# FMA check first, so a fused build can never PASS whatever else it contains.
if re.search(r"\bvf(?:n)?m(?:add|sub)", body):
    raise SystemExit("FAIL: fused arithmetic changes the rounding contract")

for instruction in ("vminps", "vmulps", "vaddps"):
    if not re.search(r"\b" + instruction + r"\b[^\n]*%ymm", body):
        raise SystemExit(f"FAIL: NNUE output has no 256-bit {instruction}")

clamp = None
if re.search(r"\bvmaxps\b[^\n]*%ymm", body):
    clamp = "vmaxps"
else:
    clamp = find_mask_clamp(body)
if clamp is None:
    raise SystemExit("FAIL: NNUE output has no 256-bit max(0,x) clamp "
                     "(neither vmaxps nor AVX-512VL vcmpps + masked zeroing/vblendmps)")
print(f"PASS: NNUE output uses 256-bit clamp ({clamp})/min/multiply/add without fused arithmetic")
