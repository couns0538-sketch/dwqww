#!/usr/bin/env python3
"""CR zero-retention runner for tools/nnue_million_oracle (proposed fix F1/F2).
Writes NOTHING to disk. Spawns one or two oracle producers, streams stdout in
record batches, compares OFF vs ON bytes in memory, keeps an independent sha256
and byte count per stream, validates header/trailer, and (--self-check) asserts
incremental accumulator+eval == fresh refresh, bit for bit, in every record.
Pure Python + numpy optional; no external cmp (Windows/PC friendly).
Exit: 0 PASS, 1 mismatch/drift, 2 producer/stream/format error."""
import argparse, hashlib, struct, subprocess, sys
H, T, HID = 64, 256, 256
F = 2 * HID; PRE = 104; ACC = F * 4 + 8; REC = PRE + 2 * ACC

def read_exact(f, n):
    b = bytearray()
    while len(b) < n:
        m = f.read(n - len(b))
        if not m: break
        b += m
    return bytes(b)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--off", required=True); ap.add_argument("--on")
    ap.add_argument("--positions", type=int, default=1000000)
    ap.add_argument("--self-check", action="store_true", help="incremental == refresh bit-exact per record")
    ap.add_argument("--expect-sha", help="expected full-stream sha256 (e.g. e2ccf250... for lock 1M)")
    ap.add_argument("--batch", type=int, default=2000)
    a = ap.parse_args()
    sides = [("off", a.off)] + ([("on", a.on)] if a.on else [])
    procs = {s: subprocess.Popen([p, "--positions", str(a.positions)], stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE) for s, p in sides}
    sha = {s: hashlib.sha256() for s, _ in sides}; nbytes = {s: 0 for s, _ in sides}
    rc = 0; first_diff = None; self_bad = 0; first_self = None
    def take(n):
        out = {}
        for s, _ in sides:
            b = read_exact(procs[s].stdout, n); sha[s].update(b); nbytes[s] += len(b); out[s] = b
            if len(b) != n: raise RuntimeError(f"{s} truncated stream")
        return out
    try:
        hd = take(H)
        for s, _ in sides:
            h = struct.unpack("<16I", hd[s])
            if h[:4] != (0x314F4D4E, 1, HID, REC) or (h[4] | h[5] << 32) != a.positions:
                raise RuntimeError(f"{s} bad header")
        if a.on and hd["off"] != hd["on"]: first_diff = first_diff or "header"
        done = 0
        while done < a.positions:
            n = min(a.batch, a.positions - done); ch = take(n * REC)
            if a.on and first_diff is None and ch["off"] != ch["on"]:
                i = next(k for k in range(n * REC) if ch["off"][k] != ch["on"][k])
                first_diff = f"record {done + i // REC} byte {i % REC}"
            if a.self_check:
                for s, _ in sides:
                    b = ch[s]
                    for r in range(n):
                        o = r * REC + PRE
                        if b[o:o + ACC] != b[o + ACC:o + 2 * ACC]:
                            self_bad += 1; first_self = first_self or f"{s} record {done + r}"
            done += n
        tr = take(T)
        for s, _ in sides:
            t = struct.unpack("<64I", tr[s])
            if t[:2] != (0x544F4D4E, 1) or procs[s].stdout.read(1): raise RuntimeError(f"{s} bad trailer/extra bytes")
        if a.on and tr["off"] != tr["on"]: first_diff = first_diff or "trailer"
    except Exception as e:
        print(f"FAIL(stream): {e}"); rc = 2
    for s, _ in sides:
        err = procs[s].stderr.read().decode(errors="replace").strip(); code = procs[s].wait()
        print(f"{s}: exit={code} bytes={nbytes[s]} sha256={sha[s].hexdigest()} | {err}")
        if code != 0: rc = max(rc, 2)
        if a.expect_sha and sha[s].hexdigest() != a.expect_sha: print(f"FAIL: {s} sha != expected"); rc = max(rc, 1)
    if first_diff: print(f"FAIL: OFF/ON mismatch at {first_diff}"); rc = max(rc, 1)
    if a.self_check:
        print(f"self-check incremental==refresh: bad_records={self_bad}" + (f" first={first_self}" if first_self else ""))
        if self_bad: rc = max(rc, 1)
    print("PASS" if rc == 0 else f"RESULT rc={rc}"); return rc
if __name__ == "__main__": sys.exit(main())
