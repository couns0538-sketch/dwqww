Forge FINAL locked build: h256_e12 (commit 1ab50b2d + NNUE net md5 6d22f612, H256 float)
Packaged 2026-10-24 17:35 Vienna by Engine QA.

windows/forge_h256_e12.exe  - the exact exe that won Gate 13 (H1, +37.95 +/-15.18 vs ep10) and is the base of every gate now running.
   sha256 456743D9C065D2DEC2D9A52EF23992F36908EFC1243B6916EDAB9A8AB3C7FDFA (znver5 / Zen 5 build; needs a Zen 5-class CPU)
linux/forge_h256_e12_linux  - box (Linux) build of the same source, sha256 e3df99cd...367b
source/h256_e12_src.zip     - full source tree (net embedded in src/nnue_weights.inc), with build script, build log, and per-file sha256 list
docs/                       - lock check, CR pass, idea-source notes, README

Use: UCI engine. Recommended: Threads 1+, Hash 16+, OwnBook off for testing.
Bench (T1, H16): d11 308972 / d13 745494 / d16 2460422 / d20 11901452 / d22 31111774
perft5 4865609, kiwipete 193690690
