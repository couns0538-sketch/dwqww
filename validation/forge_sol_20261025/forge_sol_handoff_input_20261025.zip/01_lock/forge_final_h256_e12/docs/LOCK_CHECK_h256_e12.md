# LOCK_CHECK h256_e12 (Gate 13 candidate)
Written 2026-10-24 ~03:59 Europe/Vienna (CEST). Status: NOT LOCKED. Items are still open (see the end of this file).

## Candidate identity (PC Gate 13 exe)
- exe: `C:\Users\Administrator\grok-pc\forge_push\bin\forge_h256_e12.exe`
- sha256 `456743D9C065D2DEC2D9A52EF23992F36908EFC1243B6916EDAB9A8AB3C7FDFA`. Matches the Gate 13 RUN_INFO and the chain_gates9 runner SHA map.
- source: `/workspace/forge-coder/fc_nnue_h256_e12_ep12_ep10base`. Compared with the PC ep10 tree (73-file manifest, 0 problems), the only change is `src/nnue_weights.inc`.
- net `.inc`: sha256 74C4009D…275B1B, md5 6D22F612C855E17C62D396D32DA99EA4. Matches the CR.
- compile flags (build_h256_e12.log, PC, 2026-10-23 22:44 Vienna), g++ 15.2.0 MSYS2 Rev14, direct g++ with every flag given explicitly:
  `g++ -std=c++20 -O3 -DNDEBUG -DFORGE_NNUE_HIDDEN=256 -ffp-contract=off -fno-fast-math -march=znver5 -static -pthread -Iinclude src/{bitboard,board,book,eval,eval_params,nnue,search,uci}.cpp -o forge_h256_e12.exe`
  This is confirmed as -DFORGE_NNUE_HIDDEN=256 plus the full znver5 set (-march=znver5 -ffp-contract=off -fno-fast-math -O3 -DNDEBUG -static -pthread). No int16 and no tunables.

## Gate 13 (H1)
- h256_e12 vs plain ep10 (forge_nnue_ep10.exe 42D387C6…5B0B), started 02:37:18 Vienna. Runner chain_gates9, srand 20261028, start=1.
- 478 games, W/L/D 95/43/340 (55.44%), Ptnml [0,26,144,60,9].
- Elo +37.95 ±15.18, nElo 78.54 ±31.15, LLR 2.95 → **H1**. 0 time losses, 0 crashes, 0 orphans.

## PC pre-gate bench (2026-10-24 ~03:53 Vienna, Threads=1 Hash=16, exact [int64] compare)
- d11 308972 MATCH, d13 745494 MATCH, d20 11901452 MATCH, d22 31111774 MATCH. d16 2460422 (info only). uciok True.
- The chain_gates22 runner repeats this bench (PreBench d11/13/20/22) right before Gate 13b starts, and aborts if any value differs.

## Box checks
- **Fuzz/self-play smoke: PASS.** Run at nice 19, one process, single thread, Hash 16, about 3 s total.
  - Binary: Coder's box build `fc_nnue_h256_e12_ep12_ep10base/build_release/forge`, sha256 e3df99cd…367b. Its bench matches the CR.
  - Checks: 250 random-walk positions (1–120 random plies, go depth 1–6) and 6 self-play games (random 2–8 ply openings, go nodes 3000, up to 160 plies). In total 1046 searches and 804 self-play plies.
  - **0 illegal bestmoves, engine exit code 0, no crash.**
  - Coder's uci_smoke (artifacts/uci_smoke.log) also shows uciok, 40 self-play plies and 0 illegal moves.
  - Script and log: `/workspace/forge-push-stage/fuzz_h256e12/{fuzz.py,fuzz.log}`.
- **Box bench nodes** (Threads=1 Hash=16, nice 19; node counts only, no nps):

  | build | d11 | d13 |
  |---|---|---|
  | 6.4.24 (base_1ab50b2d) | 292545 | 862693 |
  | ep10 (fc_nnue_ep10_1ab50b2d) | 315955 | 851522 |
  | h256_e12 | 308972 | 745494 |

  The h256_e12 numbers match the CR and the PC exactly. The ep10 numbers match the locked ep10 values.
- **forge_tests / ctest: 13/14**, from Coder's `artifacts/ctest.log`. Only forge_tests fails, with the 4 known lines:
  - WAC 001 expected g3g6 got f6h5
  - WAC 001 score 661 below 31997
  - 2× "unrestricted search chooses the winning rook underpromotion over stalemating queen promotion"

  SEE contract: 504 assertions, 0 failures. This is the known 13/14 pattern (FORGE_KNOWN_TEST_FAILURES.md).
- **WAC300 tactics** (Coder; not run by me): **PENDING**. At about 03:58 Vienna it was still running, chunks of 50 at mt=1000.
  - chunk0: ep10 49/50, h256_e12 49/50
  - chunk1: h256_e12 49/50, ep10 49/50

  Cite the final result from `fc_nnue_h256_e12_ep12_ep10base/artifacts/tactics_wac300/run.log` when Coder posts it.
- **Box nps** (Profiler, 14 ABBA pairs; not run by me): **PENDING**, no result posted yet.
  - For reference only: Coder's earlier artifacts/timing_summary.txt gives a bench20 ratio H256/ep10 of about 0.84 (run2, 8 pairs, median 0.8402). This is not the Profiler result.
- **PC nps: OPEN.** All 5 fastchess slots are busy, so no clean ABBA pair vs ep10 was possible. The pre-gate bench nps under load was about 1.98–2.17M and is not usable.

## Gate 13b (queued, not started) — RE-ORDERED 2026-10-24 04:14 Vienna (CEST): now runs right after Gate 14
- h256_e12 (456743D9…FDFA) vs 5101c252 (`bin\forge_5101c252.exe` 770447EED3862E02275280DAC7C4D648CCD383B99D17B6A2BB229127D0947EC0, matches the gate1b and Gate 8 RUN_INFO). 1000-game cap, frozen gate1b settings, concurrency 5, start=20001, srand 20261111, folder `gate13b_h256e12_vs_5101c252`.
- Runner: `forge_push\chain_gates23.ps1`, PID 6480, BelowNormal; log `D:\grok-pc-data\forge_push\chain_gates23.log`. It waits for chain_gates10 (Gate 14, fastchess 5700) to exit, then for no fastchess, then a 20 s settle, then re-checks for fastchess. Then it runs the exact PreBench d11/13/20/22 = 308972/745494/11901452/31111774 and aborts on any mismatch. Its gate settings are byte-identical to chain_gates22; only the wait target and the log name changed.
- The end-of-queue runner chain_gates22 (PID 10884, waiting on Gate 25) was stopped while still waiting.
- Gate 15: the old chain_gates11 (PID 13960, waiting on chain_gates10) was replaced by a new chain_gates11.ps1, PID 7196. It waits on chain_gates23 (13b), then for no fastchess, then 20 s, then re-checks for fastchess. Gate 15's settings and srand 20261030 are unchanged. The old file is at `chain_gates11.ps1.bak_20261024_reorder13b`.
  - The new instance was started before the old one was stopped, so chain_gates12 never saw a gap.
  - Gates 16–25 runners are unchanged: they wait on their predecessor by script name, and chain_gates12's log now shows it waiting on PID 7196.
- Wait chain: G14 (10712/fastchess 5700) → 13b (chain_gates23, PID 6480) → G15 (chain_gates11, PID 7196) → G16 (chain_gates12) → … → G25 (chain_gates21).
- Driver: forge_gates.json has 13b right after 14 (runner chain_gates23), still DRIVER_HOLD (BLOCKED), because the driver cannot use the 5101c252 base or start=20001. Backup: `forge_gates.json.bak_20261024_0412`.
  - Dry run takeover order: G14 → G13b → G15 … G25, with 13b BLOCKED. "WOULD LAUNCH NOTHING NOW".
  - Caveat: if the runners die and the driver takes over, it skips 13b and runs G15 next. 13b would then need its runner relaunched by hand.

## SIMD/clamp checker on the PC g++ 15.2.0 znver5 objects (2026-10-24 ~04:20 Vienna, BelowNormal, read-only)
- Checkers:
  - v1 = `/workspace/forge-coder/fc_simdcheck_znver5_ep10/tools/check_nnue_simd.py` (CR_PASS_simdcheck_znver5_ep10, sha256 47c8c92e…).
  - v2 = `fc_simdcheck_znver5_v2_ep10` (NOT CR-reviewed, information only, sha256 0953cafd…).
- Both were run on the PC with PC objdump (GNU Binutils 2.46).

| object | sha256 | v1 | v2 (info) |
|---|---|---|---|
| nnue_cand\simd_check\nnue_ep10.o (ep10 H128, the object the old checker FAILed on) | BBE83A5F… | PASS (vcmpps+masked-zeroing) | PASS (vcmpps+masked-zeroing) |
| src_h256_e12\nnue_h256.o (h256_e12 build flags, old checker FAILed) | 9AD7AABE… | PASS (vcmpps+masked-zeroing) | PASS (vcmpps+masked-zeroing) |
| bin\forge_h256_e12.exe | 456743D9… | PASS (vcmpps+masked-zeroing) | PASS (vcmpps+masked-zeroing) |
| bin\forge_h256_e16h.exe (no separate .o exists) | D615ECE4… | PASS (vcmpps+masked-zeroing) | PASS (vcmpps+masked-zeroing) |

- The clamp sequence is the same in all four evaluate() bodies:
  - `vxorps %xmm5,%xmm5,%xmm5` zeroes ymm5, then `vmovaps %ymm5,%ymm2` makes ymm2 = 0.0.
  - `62 f1 7c 28 c2 ca 0e  vcmpgtps %ymm2,%ymm0,%k1`: imm 0x0e = GT_OS. AT&T order is (src2=zero, src1=x, dst=k1); Intel order is `vcmpps k1, ymm0, ymm2, 0x0e`. So k1 = **x > 0** (written as x>0, not 0<x; no swapped lt form).
  - `vmovaps %ymm0,%ymm1{%k1}{z}`: the cmp's own k1 and its own src1 (ymm0), giving max(0,x).
  - The same pattern appears for ymm4 → ymm0 (`vcmpgtps %ymm2,%ymm4,%k1` + `vmovaps %ymm4,%ymm0{%k1}{z}`). 4 cmp/mask pairs in total, no vblendmps, no vmaxps on ymm.
- Disassemblies: box `/workspace/forge-push-stage/simdchk/*.evaluate.dis.txt`.
- **CR LOW (a): is the compare's zero operand zeroed on every path? CONFIRMED for both nnue_h256.o (sha 9AD7AABE…) and nnue_ep10.o (BBE83A5F…).** Checked 2026-10-24 ~04:25 Vienna, read-only, from objdump -dr of each object (h256 on the box, ep10 on the PC at BelowNormal).
  - The clamp is inlined into `forge::nnue::evaluate(Board const&, Accumulator const&)`. There is no separate clamp routine.
  - All 4 compares use **%ymm2** as the zero operand, including the second pair (`vcmpgtps %ymm2,%ymm4,%k1`).
    - h256: 176b, 1778, 17be, 17cb. ep10: 124b, 1258, 129e, 12ab.
  - ymm2 has exactly one write before the compares: `vxorps %xmm5,%xmm5,%xmm5` (VEX form, so all of ymm5 is zeroed), then `vmovaps %ymm5,%ymm2` (h256 at 1731/173b, ep10 at 1211/121b).
    - This straight-line prologue comes after the only call (`weights()` at 1710/11f0) and before the loop head (1760/1240).
    - ymm16 (the other accumulator) is also copied from ymm5 here.
  - Control flow inside the function:
    - the only branch is the loop back-edge `jne 1760` / `jne 1240`, which targets the loop head after the zeroing;
    - besides that there is one call (before the zeroing) and one ret.
    - No other instruction in the object branches into the function body, and no relocation points at evaluate+offset. 0 found in each object.
  - Inside the loop nothing writes ymm2. Its next write is `vmovss …,%xmm2` after the loop (182e/130e), where it is reused for the final scalar clamp.
  - ymm5 itself does not stay zero: it is the second accumulator (`vaddps %ymm0,%ymm5,%ymm5`). The compares never read it; they read only the ymm2 copy, which stays 0.0.
  - So every path to every vcmpgtps runs the vxorps/vmovaps zeroing first.

## Remaining lock items
1. Gate 13b verdict (vs 5101c252; now right after Gate 14).
2. WAC300 game-time tactics result from Coder (in progress; no regression vs ep10 so far).
3. Profiler box nps (14 ABBA pairs); PC nps stays open until the slots are free.
4. Trainer/net provenance confirmed by Couns.
5. Lock rule: forge_tests 13/14 with only the 4 known lines (met), plus the CR's other lock-rule items.

## Game-time tactics, QA ruling (04:10 Vienna, 2026-10-24)
Coder's WAC300 run, h256_e12 vs ep10: at 1000 ms 283 vs 286 (2 solved only by h256_e12 vs 5 only by ep10, sign test p≈0.45); at 100 ms 256 vs 257 (13 vs 14, p≈1.0). There is no significant drop at either time control, so the "not worse" item counts as met (within noise). It is NOT evidence that the tactics are equal or better. Raw counts are lower by 3 and 1, and that is recorded here. Source: fc_nnue_h256_e12_ep12_ep10base/artifacts/tactics_wac300/summary.txt

## Box nps (Agent Profiler, 04:25 Vienna 2026-10-24)
h256_e12 vs ep10, measured on the box with 14 ABBA pairs at bench 20, T1 H16, on one pinned core. The median nps ratio is 0.826 (range 0.774 to 0.853), and h256_e12 was faster in 0 of 14 pairs. A/A noise SD is 3.7%. Time to depth 20 is about 15% longer for h256_e12. Files are in research/prof_forge_h256e12_20261024. This is recorded only. It is not a blocker, because Gate 13 reached H1 at game time. The comparison against 6.4.24 and the PC nps figure are still open; the PC figure belongs to QA once a slot is free. Box and PC numbers are not pooled.

## LOCK DECISION (2026-10-24 09:46 Vienna)
Couns delegated the decision to a crew vote ("swap it for the h256 build but ask everyone"). Tally 8-0 YES: h256_e12 is LOCKED as the new baseline. Net md5 6d22f612c855e17c62d396d32da99ea4, .inc sha256 74c4009d86b7d3a5ae9e6119d0890e5b923508f4063161bb4bc1539aab275b1b, PC exe C:\Users\Administrator\grok-pc\forge_push\bin\forge_h256_e12.exe sha256 456743D9C065D2DEC2D9A52EF23992F36908EFC1243B6916EDAB9A8AB3C7FDFA, float inference only (no int16). Evidence: Gate 13 H1 vs ep10 and Gate 13b H1 (194 g, LLR 2.96, TL 0, crash 0). Previous baseline: ep10 (42D387C6…0B5B). Recorded in PC forge_gates.json top-level "lock" object.
- PC nps PENDING after Gate 17: chain_gates24.ps1 (PID 11000) runs fixed-depth bench d20 T1 H16, 4 ABBA rounds per pair, pinned to CPU 2 at Normal priority, h256_e12 vs 6.4.24 (forge_1ab50b2d.exe BC5A6AE2…4A28) and vs ep10, once Gate 17 has ended and before Gate 26. Load is NOT isolated: NNUE GPU training and selfplay keep running (not touched); CPU load is sampled per run. Output D:\grok-pc-data\forge_push\nps_h256e12_lock\NPS.md + nps.csv. Box and PC numbers are not pooled.
