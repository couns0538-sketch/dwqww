# Forge handoff: continue strengthening the Forge C++ chess engine

You are picking up work on **Forge**, a C++20 UCI chess engine (classical alpha-beta search, HCE plus a small residual NNUE). A zip is attached to this message: **forge_handoff_20261025_0406.zip**. Everything you need is in it; start with `README_CONTENTS.md` and this file. You have no access to our machines or match farm. You write code, build, run local tests and benches, and hand back patches. We run the matches.

## 1. Current state
- **Lock (current best) = "h256_e12"** = engine commit 1ab50b2d (Forge 6.4.24) + NNUE net md5 `6d22f612c855e17c62d396d32da99ea4`, hidden size 256, float inference.
  - Windows exe sha256 `456743D9C065D2DEC2D9A52EF23992F36908EFC1243B6916EDAB9A8AB3C7FDFA` (znver5, Zen 5 only).
  - It won Gate 13 vs the previous lock: +37.95 +/-15.18 Elo, 478 games, LLR 2.95 (H1).
- Full source with the net embedded: `01_lock/forge_final_h256_e12/source/h256_e12_src.zip`. Per-file hashes are in `h256_e12_sources.sha256`. **All your patches are -p1 against this tree.**
- Status docs: `02_status/LOCK_CHECK_h256_e12.md`, `02_status/QUEUE_PENDING.md` (long log; read the tail), `02_status/GATE_MANIFEST_SNAPSHOT.md` (about 100 queued gates, so don't re-propose what is already there), `02_status/FORGE_KNOWN_TEST_FAILURES.md`, `02_status/NNUE_STATUS.md` and `02_status/SOL_WORK_AUDIT_20261024.md`.
- Ideas: `03_ideas/FORGE_IDEA_BOARD.md` (P1–P29 with status and lessons) and `03_ideas/FORGE_IDEA_BOARD_P22_P23.md`.
- The CR (code review) format we expect: `04_cr/*.txt` and `06_sol_next/CR_PASS_nnue_e16m.txt`.
- **New since the 02:02 handoff:** lock unchanged. Gate 100 (net e32f003, 32 epochs, blend-end 0.6) capped at 1500 games with no decision: +8.3 +/-8.5 Elo, LLR 1.54, clean. That is the closest any net has come to H1, but nothing is claimed and it goes on the rework list. Gate 102 (net e24f005) is running (at 560 games: -6.8 +/-14.9). Net f014 (e20, own data, lowest e20 holdout loss) passed review and is queued as G112; nets f006-f014 now fill G104-G112 (manifest 103 gates, ~212 h). A daily prune keeps at most two blend-end 0.6 nets per epoch count. Because about a dozen near-identical nets are being gated, the first net that reaches H1 gets one fresh confirm run before any lock. Speed patch `speedmp2` (+4.3-4.6% nps, bench identical) is still queued as G101; don't redo it (see `04_cr/CR_PASS_fc_speedmp2_h256e12.txt`).
- Lessons so far:
  - The net is the biggest lever.
  - Time-management tweaks sit below our ~+10 Elo detection limit.
  - Small search tweaks need bundling to show up in a 1000–1500-game gate.
  - Lower teacher loss has *not* meant stronger nets (blend-end 0.6 = lock, 0.7 −4.2, 0.8 −11.1, 0.9 −44.5).

## 2. Hard rules (a patch that breaks any of these is rejected)
1. **Ideas only, never copied code.** Do not copy code, constants or tables from any other engine (Stockfish, etc.). Write your own implementation. For every idea, add an `IDEA_SOURCE.md` entry: the idea, where it came from (paper, wiki, engine name) and the statement "idea only, own implementation".
2. **One OFF-by-default UCI option per behaviour change.** It is exposed as a tunable (built with `-DFORGE_EXPOSE_TUNABLES=1`, or `FORGE_EXPOSE_TUNABLES=ON` in cmake). With the option at its default the engine must behave exactly like the lock.
3. **Bench must match the lock** at Threads 1, Hash 16, OwnBook false, everything at default: **d11 308972, d13 745494, d16 2460422, d20 11901452, d22 31111774**. Bit-exact node counts. The only exception is a change that alters eval or search *by design* with its option ON, or a net swap. Then report the new bench numbers for every option set too.
   - d11 precondition: before measuring anything on a new build, run `bench 11` with everything OFF. If it isn't 308972, stop and fix that first.
4. **Perft:** startpos perft 5 = **4865609**, kiwipete perft 5 = **193690690**.
5. **No FMA, no fast-math:** always `-ffp-contract=off -fno-fast-math`. The float NNUE must give identical results on every build. objdump of `forge::nnue::evaluate` must show 0 `vfmadd*` (`05_tools/check_nnue_simd_v2.py` checks this).
6. **Tests:** ctest is 13/14 on the lock. The only failing test is `forge_tests`, with exactly 4 known FAIL lines:
   - `WAC 001 expected g3g6 got f6h5`
   - `WAC 001 score 661 below 31997`
   - 2× `unrestricted search chooses the winning rook underpromotion over stalemating queen promotion`

   No new FAIL lines are allowed, and existing tests must never be edited or deleted. Adding new test files is welcome. Print the exact FAIL lines, not just a count.
7. Never claim Elo. You can't run matches; we gate every candidate with SPRT [0,10] vs h256_e12.
8. No giant files: no datasets or oracle dumps. Hashes and summaries instead.

## 3. Build, test, bench
Unzip `h256_e12_src.zip` to `forge/`.

**Linux / box (cmake, g++ ≥ 13):**
```
cmake -S forge -B build_release -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_CXX_FLAGS="-march=x86-64-v3 -mtune=znver5 -fno-fast-math -ffp-contract=off -DFORGE_NNUE_HIDDEN=256"
cmake --build build_release -j
ctest --test-dir build_release --output-on-failure      # expect 13/14, the 4 known FAIL lines
```
- Dev/tunables build: add `-DFORGE_EXPOSE_TUNABLES=ON`.
- Sanitizer build: add `-DFORGE_ENABLE_SANITIZERS=ON` (ASan+UBSan), Debug or RelWithDebInfo.
- `-DFORGE_NNUE_HIDDEN=256` is mandatory. Without it the build fails loudly.

**PC release line (Windows, g++ 15.2 MSYS2, Zen 5), the exact lock recipe** from LOCK_CHECK, run inside the source dir:
```
g++ -std=c++20 -O3 -DNDEBUG -DFORGE_NNUE_HIDDEN=256 -ffp-contract=off -fno-fast-math -march=znver5 -static -pthread -Iinclude src/bitboard.cpp src/board.cpp src/book.cpp src/eval.cpp src/eval_params.cpp src/nnue.cpp src/search.cpp src/uci.cpp -o forge.exe
```
Add `-DFORGE_EXPOSE_TUNABLES=1` for option builds. The full script is `01_lock/pc_build/build_h256_e12.ps1`, with its log.

**Bench and perft over UCI stdin** (verified on the lock):
```
printf 'uci\nsetoption name Threads value 1\nsetoption name Hash value 16\nsetoption name OwnBook value false\nisready\nbench 11\nbench 13\nbench 16\nbench 20\nbench 22\nquit\n' | ./build_release/forge
#  -> info string bench depth 11 nodes 308972 ...   depth 13 nodes 745494 ...
(printf 'uci\nposition startpos\ngo perft 5\n'; sleep 20; \
 printf 'position fen r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1\ngo perft 5\n'; sleep 60; echo quit) | ./build_release/forge | grep '^nodes'
#  -> nodes 4865609  then  nodes 193690690   (perft runs async, so keep stdin open until it prints)
```
For option-ON benches, send `setoption name <Opt> value <v>` before `bench`.

## 4. Tasks, in priority order (stop after what fits; quality over quantity)

### Task A: bad-capture buffer overflow, defensive fix (do first, about 45 min)
- **The bug.** In `src/search.cpp` line 361 the MovePicker does `bad_captures_[bad_count_++] = move;`, which writes into `std::array<Move, 64> bad_captures_` (line 453) with no bounds check. The capture list feeding it holds up to 256 entries (`moves_`, MoveList capacity 256), and line 398 reads from the buffer back.
- **ASan cannot see this overflow.** It stays inside the MovePicker object (the next member is `bad_count_`). Detect it instead with a `-O1 -g -D_GLIBCXX_ASSERTIONS` build, where std::array `operator[]` aborts on out-of-range.
- **Step 1, try to trigger it.** Write a small unit-test harness linked against `forge_core` that counts captures and promotions with `!see_ge(move, -threshold)` for the side to move. Search or construct FENs with more than 64 SEE-losing captures, then run `go depth 3` on them.
- **Step 2, fix it.** Size the array to the move-list capacity (256) or add a bound check. This is a correctness fix, **not** an option.
- **Acceptance criteria:**
  - Bench identical at all 5 depths.
  - Perft unchanged.
  - New ctest case using the densest FEN you found.
  - ctest is otherwise unchanged (13/14, 4 known lines).
  - Full ctest plus `bench 13` under ASan+UBSan and under `_GLIBCXX_ASSERTIONS` are clean.
  - Report plainly either "confirmed overflow with FEN …" or "not reachable with the FENs tried, fixed defensively".
- **Deliverable:** `buffer_fix.patch`.

### Task B: int16 H256 NNUE inference behind an OFF-default `NnueInt16` (main task)
- **Context.** Float H256 inference costs about 14% nps compared with the older H128 net. The existing int16 path (`06_sol_next/fc_int16_ep10_src.tar.gz` + `CR_PASS_int16_ep10.txt`) is H128-only and compile-time. It aborts on H256 because the output bound exceeds 2^31.
- **Design** (your own; options include int32 accumulators, int16 weights, per-layer scaling and saturation analysis):
  - It must be a runtime UCI option `NnueInt16` (default 0 = float path, byte-for-byte lock behaviour), or a compile-time flag whose OFF build is byte-identical. Say which, and why.
  - Quantise the embedded net at startup or in a generator script. Do not change the net file.
- **Acceptance criteria:**
  - With the option OFF: bench equals the lock at all 5 depths, and perft is OK.
  - Parity of int16 vs float static eval on **100k FENs** (generate them by random playouts or extract them from your own self-play; say how): **mean |diff| ≤ 2 cp, max |diff| ≤ 30 cp**. Report the histogram and the worst 10 FENs.
  - FMA count 0 in all nnue code.
  - ASan+UBSan clean with the option ON (bench 13 + ctest).
  - Speed: nps of bench 20 OFF vs ON, as alternating pairs (ABAB, at least 8 pairs, median ratio). Report the CPU and machine load. `06_sol_next/nps_abba_bc.ps1` is our template.
  - Report the new bench node counts with the option ON. They will differ, because eval changes.
- **Stop rule.** If parity isn't met after reasonable effort, don't hand it off as a candidate. Hand back a write-up of where the error comes from instead.

### Task C: PGO release build, node-identical speed (about 2 hours; idea board ranking #2)
- **The idea.** A two-stage profile-guided build (`-fprofile-generate`, run a training workload, then `-fprofile-use -fprofile-partial-training` or plain `-fprofile-use`) on top of the exact lock recipe. It changes no search or eval code, so node counts must be identical; the only goal is nps. An older archive PGO build was bench-exact but its speed was never measured validly.
- **Do:**
  - Write a build script (bash for g++ on Linux, plus a PowerShell/MSYS2 version mirroring `01_lock/pc_build/build_h256_e12.ps1` for the PC's g++ 15.2 znver5 line). Keep `-ffp-contract=off -fno-fast-math` in both stages.
  - Training workload: `bench 16` plus a few fixed-depth searches on varied FENs (say which). Do not train on anything that needs extra data files.
  - No source changes and no new UCI option.
- **Acceptance criteria:**
  - Bench identical to the lock at all 5 depths, perft5 and kiwipete5 OK, ctest 13/14 with the 4 known FAIL lines.
  - FMA count 0 in `forge::nnue::evaluate` (`05_tools/check_nnue_simd_v2.py`).
  - nps of `bench 20`, PGO vs non-PGO built from the same tree with the same flags, as alternating pairs (ABAB, at least 8 pairs, median ratio), with CPU and load reported. Below +3% means drop it: report it and don't hand it off as a candidate.
- **Backup** if PGO is blocked: idea board P29 proposal 3, a result-consistency skip filter in `07_nnue/train_resid_v3b.py` (the current trainer; keep v3b's RAM fix intact) (own implementation, OFF by default via a CLI flag; with the flag off, training on a fixed seed must produce byte-identical outputs). Hand back the patch and a short design note; we train and gate it.

## 5. What to return
For each task:
1. `<task>.patch`: unified diff, `patch -p1` against the h256_e12 source tree, no fuzz. Also include the full changed files.
2. `sha256` of the patch, of every changed file and of any binary you built (say which compiler, flags and OS).
3. `IDEA_SOURCE.md` entries, in your own words.
4. A results file with:
   - bench at d11/13/16/20/22 for OFF and each option set
   - perft5 and kiwipete5
   - the ctest summary plus the exact FAIL lines
   - sanitizer results
   - parity and nps tables (Task B)
   - anything you could not verify, marked UNVERIFIED
5. A short `HANDOFF_REPORT.md`: what was done, what wasn't, known risks and suggested gate options (option name = value). No Elo claims.

Package everything as one zip: `forge_return_<yourname>_<date>.zip`.
