#include <concepts>
#include <span>
#include <array>
static_assert(__cplusplus >= 202002L);
consteval int answer(){return 42;}
template<std::integral T> constexpr T id(T x){return x;}
int main(){std::array<int,2> a{20,22};std::span<int> s(a);return id(s[0]+s[1]) == answer() ? 0 : 1;}
