import hashlib, json, os, pathlib, queue, subprocess, threading, time
root=pathlib.Path('/workspace/.cloud-setup/tt-investigation/baseline-full-engine-race-attempt1');root.mkdir()
engine=pathlib.Path('/workspace/.cloud-setup/forge-tt-baseline-tsan/forge')
env=dict(os.environ,TSAN_OPTIONS='halt_on_error=1:exitcode=66')
commands=[];q=queue.Queue();stdout=open(root/'stdout.bin','wb');stderr=open(root/'stderr.bin','wb')
p=subprocess.Popen([str(engine)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=stderr,env=env)
def read():
    for line in iter(p.stdout.readline,b''):
        stdout.write(line);stdout.flush();q.put(line.decode('utf-8',errors='replace').rstrip())
    q.put(None)
t=threading.Thread(target=read,daemon=True);t.start()
def send(s):
    commands.append({'monotonic_ns':time.monotonic_ns(),'line':s});p.stdin.write((s+'\n').encode());p.stdin.flush()
def until(prefix,timeout=60):
    end=time.monotonic()+timeout
    while True:
        v=q.get(timeout=max(.001,end-time.monotonic()))
        if v is None:raise RuntimeError('engine closed stdout before '+prefix)
        if v.startswith(prefix):return v
        if time.monotonic()>end:raise TimeoutError(prefix)
error=None;started=time.time()
try:
    send('uci');until('uciok');send('setoption name Threads value 4');send('setoption name Hash value 1');send('setoption name OwnBook value false');send('isready');until('readyok');send('position startpos');send('go nodes 200000');until('bestmove');send('quit');p.wait(timeout=15)
except Exception as e:
    error=repr(e)
    try:p.wait(timeout=3)
    except subprocess.TimeoutExpired:p.kill();p.wait()
finally:
    t.join(timeout=3);stdout.close();stderr.close()
    (root/'stdin.json').write_text(json.dumps(commands,indent=2)+'\n');(root/'stdin.bin').write_bytes(('\n'.join(x['line'] for x in commands)+'\n').encode())
    report=(root/'stderr.bin').read_bytes();r={'engine':str(engine),'engine_sha256':hashlib.sha256(engine.read_bytes()).hexdigest(),'exit_code':p.returncode,'TSAN_OPTIONS':env['TSAN_OPTIONS'],'elapsed_s':time.time()-started,'error':error,'actual_data_race_reported':b'WARNING: ThreadSanitizer: data race' in report,'completed_search':error is None};(root/'result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));print(report.decode(errors='replace')[:13000])
