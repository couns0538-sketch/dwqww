# Independent review of refined opaque-slot TT proposal

UPDATE: The two findings below were approved for external-proposal hardening and are now addressed: private full-key provenance rejects mismatched stores, and resize allocates before publishing state. Historical findings remain for rationale. Current revision and new standalone regression test remain uncompiled/unrun.

Reviewed current f6f0a00 production lifecycle plus the external proposal. This is a static review: no source edits, build, sanitizer, benchmark or game was performed for this review. Earlier syntax logs belong to the superseded reselection proposal and must not validate this revision.

## Conclusion

No blocking race, deadlock or replacement-policy defect found for the documented production use: a single outer Searcher::search at a time, read/store/hashfull concurrent during search, and every lifecycle operation after all TT users are quiescent. The opaque probe destination preserves the old eventual-store slot, including when recursive search has changed its contents. Add explicit key/handle mismatch rejection before declaring the new public API hardened; current production call sites are correctly paired, so this is an API integrity gap rather than a demonstrated current search regression.

## Findings and limits by priority

### P2: store accepts a handle paired with an unrelated full key

Proposal store validates table owner, epoch, cluster bounds and slot bounds, but never associates the passed `key` with the key used by probe. A valid handle from cluster A can therefore store a key mapping to cluster B into A. The result is unreachable through probe(B), and an unrelated A entry is overwritten. This existed as raw-pointer API misuse too; it is not exercised by the two production probes/four stores, which use the same restored board key. It remains a meaningful missing safety property of the new opaque handle.

Minimal policy: privately retain probe's full key and reject a store with a different full key, or remove store's public key parameter and derive it from private handle metadata. A cluster-only check blocks cross-cluster misuse but leaves same-cluster mismatches ambiguous. Full-key rejection is clearer and preserves all valid production calls, even with ordinary verification-tag collisions. Do not use snapshot.entry.key32 as provenance: it belongs to a replacement victim on misses, not the probed key. No whole-table search or store-time replacement reselection is needed.

Regression: take probe(A), attempt BoundExact store(B) with B mapping elsewhere; assert neither A's existing entry nor B changes. Repeat with a distinct same-cluster B, and with equal 32-bit verification tags where possible. A default/foreign/lifecycle-stale handle must also cause no mutation. Tests should inspect through fresh snapshots, not expose mutable private slots.

### P2 inherited: resize publishes cluster_count before allocation succeeds

Proposal retains baseline `cluster_count_ = new_count; clusters_ = make_unique...`. If allocation throws and a caller catches the exception, the old allocation remains while indexing uses the new count. This can cause out-of-bounds access on recovery. Current UCI does not catch bad_alloc and terminates, so it is not a newly demonstrated normal-path regression. Safe narrow hardening is allocate new storage into a local first, then publish count/storage/generation/epoch while quiescent. It does not alter successful single-thread replacement behavior. A targeted allocation-failure test is preferable to attempting huge real allocations.

### Contract precision: quiescence includes diagnostic readers

Epoch and count reads before the stripe lock are safe only because concurrent clear/resize/new_search are prohibited. Locks do not make lifecycle operations safe. Wording should require *all TT accessors*, including external hashfull/generation/prefetch readers, to be quiescent; joining search workers alone does not stop an arbitrary external monitoring thread. Current UCI satisfies the stronger condition. Keep private epoch ordinary only under this contract. Handle lifetime ends at table destruction, including destruction/reconstruction at the same address; owner pointer is not a cross-lifetime capability.

## Race/coherence audit

- Probe selects matching/first-empty/minimum depth-age under the same stripe mutex that all stores to that cluster use. Copy of entry plus hit/owner/slot/epoch completes before the local lock_guard is destroyed. No live TTEntry pointer/reference escapes.
- Search's `const TTEntry& tte` refers to the local TTProbe.entry, not shared storage. The old snapshot is stable across recursive calls. Current old-code score/depth/eval/move/PV reads occur before recursion, so taking one coherent snapshot introduces no intended single-thread semantic change.
- Store reopens the exact probe-selected slot under lock. It tests *current shared slot contents* for same_position and uses original move/payload/depth/generation admission rules. Using old snapshot values here instead would be a policy bug.
- An ordinary intervening overwrite must NOT invalidate a handle. It is expected to overwrite/reject based on the same destination/current payload as the old pointer. Epoch only changes for quiescent lifecycle transitions.
- Hashfull reads all sampled fields under their matching stripe mutex. Its aggregate need not be globally instantaneous; it is informational. Generation is stable through a search and updated before workers spawn.
- Prefetch computes an address into stable storage and does not read entry fields in C++ source. It remains covered by the lifecycle exclusion.
- Table metadata is non-atomic and unguarded during lifecycle operations. Concurrent external resize/clear/new_search, two simultaneous Searcher::search calls on the same instance, or concurrent destruction remain unsupported and racy; epoch checks do not cure them.
- Distinct stripes can share no entry; repeated cluster indices share the same stripe by index modulo1024. False contention affects throughput, not memory safety. Lock array lifetime covers cluster storage replacement.

## Deadlock audit

Probe/store/hashfull acquire one stripe at a time. Probe's snapshot lambda does not reacquire. Store has no callbacks, recursion, output or joins while locked. Hashfull's lock guard ends each cluster iteration, even where stripes repeat. There is no multi-stripe lock order and no table lock held while searching children or joining workers.

UCI emits progress under uci_output_mutex and calls hashfull, giving output->stripe ordering. No reviewed TT critical section acquires output_mutex, so there is no reverse edge. Preserve that property if adding debug tracing. stop_search releases stop_mutex before joining the outer worker.

## Actual lifecycle evidence (current source)

- src/uci.cpp:144–153: stop flag + stop notification, release stop_mutex, join outer worker.
- :186–191: ucinewgame and every setoption first stop_search; thus Clear Hash (:219), UseNNUE clear (:269), Hash resize (:277), Threads changes (:279), and tuning-table changes occur after join.
- :284–288: position and replacement go stop/join first; bench handler also calls stop_search. :417–424: stop, quit and EOF all join before stack-owned Searcher destruction.
- src/search.cpp:1376–1382: new_search happens before spawning helpers. :1384–1389: main search returns, shared stop requests helpers to end, every helper is joined before Searcher::search returns.
- Searcher::resize_hash/clear_hash/clear/set_threads/destructor themselves do NOT synchronize against another thread's search. The UCI caller provides the exclusion; a library client must follow the same contract.

## Replacement/parity regression plan

1. Run a compact deterministic reference model of the ORIGINAL table and proposed API through the same sequential operation trace. Include probe tokens retained across arbitrary intervening stores. Compare fresh probe hits, every payload field, hashfull and eviction behavior after each step. Use immutable retained baseline-style slot tokens, not a reference model that reselects at store.
2. Empty-slot delayed-store discriminator: probe X on empty table (slot0), separately probe/store colliding Y (slot0), then exact-store X through its earlier handle. Y must miss and X must hit. Reselection or invalidating ordinary overwrites fails this test.
3. Full-cluster discriminator: freeze a victim via miss probe, change another slot's depth/generation so it becomes a more attractive victim, then store using old probe. Only the frozen original slot may change.
4. Search-match-first before empty selection; first empty and tie priority; generation wrap31->0; same-key absent-move retention; a supplied new move despite rejected shallow payload; generation mismatch payload admission; score/eval clamping and depth saturation must all match baseline.
5. Snapshot immutability across overwrite, clear and resize (snapshot values remain readable; handles become invalid only on lifecycle transitions). Mutating public snapshot/hit fields must not alter the private destination or table state.
6. Default/foreign/key-mismatched/epoch-stale handle rejection. Clear, resize-small, resize-large and new_search should invalidate old handles, while newly obtained handles work. Do these operations sequentially after joining all readers.
7. Concurrent coherence tuples: writers publish score/eval/move/depth as correlated complete states with BoundExact. Readers must observe only one published tuple per snapshot, never a mixed tuple. Add same-cluster different-key collisions and concurrent hashfull. TSan must instrument actual forge_core and the probe, not just the external driver.
8. Actual Forge Threads2/4 TSan UCI searches plus repeated go infinite->stop->Hash resize->Threads change->Clear Hash->ucinewgame->go nodes cycles, then quit and EOF. Avoid timed-game evidence here. Recheck illegal/garbage hash moves remain filtered by MovePicker and Board legality.
9. Fixed-depth and fixed-node Threads1 tactical corpus/bench exact parity is the intended gate. Wall-clock searches may complete different depths due added mutex/metadata costs even when fixed-work trees match; do not confuse this with a replacement regression. SMP output equality is not required.

The exported patch still requires test/tool API ports before a full build. No passing sanitizer, full-engine behavior, throughput or strength claim follows from this review.

Reviewed proposal SHA256 header=660d3d9a09f16a639c4b8593796f58002c95a9e0fa27cf44bc0a70bb882c020b source=4d31265474f0b89e757199b7af5faf218a0f766a16f88c40fcedbeea76d7d7df.
