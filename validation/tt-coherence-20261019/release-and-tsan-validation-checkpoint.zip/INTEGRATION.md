# Opaque-slot coherent TT proposal (revised; NOT compiled or validated)

Base: f6f0a00b2f98a7a9f117790e2c8f19a340b6769f. Accepted reference remains 9108d012526be80c6d163f7cab684e6acd9abf8d. No repository files changed.

## Evidence identity

The fetched fdb9f33 branch adds only STATUS.md; 21:30 testing reports model results without publishing model code. 21:15 research refers to an archived handoff not found in the fetched trees or local search. `tt_thread_tsan.cpp` is the authentic 439f210 real-TT race driver. Status/research/provenance are exported alongside it.

`proposed-snapshot-striped.patch` is a NEW reconstructed proposal. Current full files are under proposed/. `tt_snapshot_tsan.cpp` adapts the real-TT driver to this proposal. The old store-time-reselection variant is retained as `superseded-store-reselect.patch`; old syntax logs are explicitly renamed `superseded-*syntax.log` and DO NOT validate this revised API. No compilation, full build, sanitizer, game or benchmark has been run on the revision.

## Interface and locking

`TTProbe probe(key) const` returns a PUBLIC `entry` value snapshot and `hit` boolean. PRIVATE metadata stores owner table, cluster index, slot index and lifecycle epoch. It contains no address of a shared entry. Search consumes a const local probe/snapshot. Calling store with a modified public snapshot does not change the destination or admission policy.

`store(const TTProbe&, key, ...)` locks the chosen cluster's stripe and accesses exactly the slot selected by the earlier probe. It does NOT look up the key again or choose another replacement. The current slot contents determine `same_position`, move preservation and the original exact/depth/generation overwrite policy. Snapshot copying and all entry reads/writes are protected by the same one-of-1024 cache-line-aligned mutexes. Hashfull locks each sampled cluster. Locks never span recursive search, worker joins or lifecycle operations.

Probe retains the original two-stage policy exactly: search all four entries for an occupied matching verification tag; otherwise choose the first empty slot; otherwise minimize depth - 4*relative_age, preserving the first slot on ties. Empty/full slot selection is frozen in the handle, just as the old raw pointer was frozen. If recursion or another worker changes its contents, eventual store applies the original policy to those CURRENT contents at that SAME destination. This isolates synchronization from the earlier proposed replacement-policy change and is intended to preserve exact Threads=1 behavior.

## Lifecycle and ownership

Clear, resize, new_search and destruction require all workers joined. Current UCI stop_search joins the outer search before setoption (Hash/Threads/Clear Hash), ucinewgame, go/position replacement and quit; Searcher joins helpers before returning. new_search runs before spawning them. Preserve these contracts; concurrent external lifecycle mutation is NOT supported by striped entry locks.

Clear/resize/new_search increment a private 64-bit epoch; default, foreign or lifecycle-stale handles are rejected by store as a no-op before accessing storage. A probe overwritten by ordinary stores is NOT lifecycle-stale and remains usable: rejecting that case would change the old policy. Handles must not outlive their table. Epoch is ordinary non-atomic data because lifecycle mutations require quiescence; do not claim arbitrary concurrent resize safety. Fixed mutex stripes outlive storage replacement. Prefetch only forms stable cluster addresses during active searches.

## Call sites and replacement regression plan

Production qsearch/main search are ported in the exported patch: `const TTProbe tt_probe = tt.probe(key); bool tt_hit = tt_probe.hit; const TTEntry& tte = tt_probe.entry;` and `tt.store(tt_probe,key,...)`. All reads are from the snapshot; no shared pointer escapes. Tests/audit code still need API ports before full build: hold TTProbe values, inspect `.hit`/`.entry`, and re-probe to inspect stores.

Targeted RED/GREEN assertions:

1. Snapshot coherence/immutability: probe occupied key, overwrite same slot, verify earlier entry copy retains every field and fresh probe sees the new complete tuple.
2. Frozen destination after intervening recursion: find same-cluster keys X/Y. Probe X on empty table (miss, slot0); independently probe/store Y (occupies slot0); store X using OLD X handle with BoundExact. Y must now miss and X hit. Reselect-at-store would incorrectly retain Y and use slot1. Check old X snapshot stays empty.
3. Same-key retained move: store a deep exact entry/move, re-probe it, attempt shallow upper bound with Move::none; payload/depth/move remain according to original admission policy. A supplied nonempty move still updates as before even when score admission is rejected.
4. Full cluster replacement: fill four colliding keys with controlled depths and generations; compare expected first minimum-age/depth victim, first-empty priority and tie order to baseline. Take a miss handle, change another slot to become more replaceable, then ensure delayed store still uses its ORIGINAL slot.
5. Matching tag search precedes empty slot selection, including a match later in the cluster with an earlier empty slot.
6. Default and foreign-table handles cause no mutation. For each quiescent clear/resize/new_search, old handles cause no mutation; newly probed handles work. Resize small/large with old handles must not index freed storage. Distinguish these invalidated handles from ordinary overwritten but still-valid handles in tests.
7. Same-key and colliding-key concurrent store/probe stress checks whole-tuple coherence, while concurrent hashfull runs. The real Forge TSAN control must report no races; model results alone are insufficient.
8. Stop/join -> clear/hash resize/thread-count change/new_search -> restart across repeated UCI cycles. No locks during joins, no concurrent unsupported lifecycle calls.

Required validation: actual baseline Threads=2/4 TSAN reproduction; revised real-TT driver plus actual-engine TSAN; full CTest; single-thread exact output/node/signature comparison (preservation intended, investigate any divergence); only then bounded 1/2/4-thread overhead/quality checks. SMP nondeterminism alone is not a defect. Retain source/binary hashes and raw reports. No performance or strength result is claimed.

## Approved review hardening

The current proposal privately freezes the full probed key and rejects mismatched stores before accessing entries. Resize allocates new storage before publishing any count/storage/generation/epoch change; failed allocation preserves the old table and handles. The earlier review findings describe the prior reviewed version; these two changes are now in the external proposal but remain unbuilt/unvalidated.
