# Independent same-binary A/A audit

Audited attempt: `/workspace/.cloud-setup/tt-speed-aa-attempt1`. This audit reads retained evidence and writes reports only. No engines, builds or benchmarks were run, and no A/A file was modified.

**No measurement/accounting/reset bug was demonstrated. Stop the full A/B performance run and record overhead as inconclusive.** Preserve all blocks and the complete attempt; do not trim or extend the calibration after seeing results.

The attempt completed72 measured sessions/216 searches in 219.907733seconds: six ABBA/BAAB blocks for each of Threads1,2,4, three requested200000-node searches per session (43.2M requested units). Both labels executed exactly `/workspace/.cloud-setup/forge-underpromotions-build/forge`, SHA256 `b18ee2db5402c1fd22f11e25ffd44255709d499efbd5c4d61c4c5890c9507763`. Initial frozen input hashes, the recorded final hash check and an independent current recheck all agree.

## Evidence checked

- Every one of the216 stored CPU deltas exactly recomputes from retained `/proc/tgid/stat` fields14+15 at100Hz. All72 independent `wait4` user+system totals exceed their summed search-window CPU. Final cumulative proc CPU agrees with wait4 within 8.895–77.991ms, including shutdown.
- All216 go/bestmove endpoints match raw timestamped events and correctly bracket CPU samples. Maximum pre-go gap is1.708ms; maximum post-bestmove gap is14.566ms. These gaps and10ms CPU quantization cannot explain the observed factors.
- All72 raw stdin streams contain the exact frozen options and cold reset sequence. The24 one-thread sessions yield one identical normalized complete stdout transcript per position: same depth records, nodes, scores, PVs and bestmoves across all24 repeats. No visible workload/reset divergence was found.
- All72 launches have affinity0,1,2,3,4; all exit normally with empty stderr. All18 block wall and tick-CPU ratios independently recompute correctly.

The JSON report contains exact checked session paths/file hashes and an inventory/hash of every retained file in the entire attempt. Principal protocol records are:

- `/workspace/.cloud-setup/tt-speed-aa-attempt1/plan.json` — `46a4702f5c9da6056993040407dcb2020927e4d5583e5bd58570a571ccafb68c`
- `/workspace/.cloud-setup/tt-speed-aa-attempt1/inputs.json` — `12fccf195d2c57f8681ec73856a8b1ab5021c662b14165d6316edb3a0bd218b1`
- `/workspace/.cloud-setup/tt-speed-aa-attempt1/result.json` — `b4e689e0b9ec6d1227b9099ee68ae47de5513e061edbd8e9f8ac7510a8b70e6e`
- `/workspace/.cloud-setup/tt-speed-aa-attempt1/performance-raw.json` — `6f12742a563fa0ea38810eea13b77c531c6cb85aefe8d2f0c1df8c56124aecb2`
- `/workspace/.cloud-setup/tt-speed-aa-attempt1/status.json` — `fa479789b154f5faf6208b52ecd0feb63dba207e8f3bfe3cccd1dd881427d665`

## Independent timing example

Same one-thread middlegame, same depth14/197935-node completed report, score−24 and identical PV:

| Session | Engine elapsed | External wall | Process CPU |
|---|---:|---:|---:|
| `perf-t1-b00-s2-candidate` | 339ms | 342.763ms | 0.34s |
| `perf-t1-b00-s0-baseline` | 1730ms | 1740.695ms | 1.69s |

Thus the requested rounded example is339 versus1730ms inside the engine,343 versus1741ms external wall, and0.34 versus1.69seconds CPU. The variability is present inside the engine's independent clock, not solely in the driver's endpoint measurement.

One-thread block wall ratios span0.656634–1.470350; tick-CPU ratios span0.657941–1.405634. Overall geometric means near1 do not make this calibration capable of resolving a modest overhead. SMP also has variable trees/stopping overshoot, so its requested-budget rates do not establish fixed-quality work.

## Cause and next action

The evidence establishes execution-cost variability consistent with the shared environment; its precise cause is not isolated. The five-vCPU mask allows migrations/core effects, but no actual worker migration/frequency/cache trace was retained. Shared-cgroup counters likewise do not attribute activity to a particular process. Pinning a separately preregistered bounded one-thread prospective control could test one confounder; it is not an established repair and does not justify another full216-search run.

Keep TT correctness evidence separate from unresolved whole-engine overhead. Do not launch the full A/B comparison on this calibration. Preserve the entire A/A attempt for archival. The known stale-running `status.json` versus completed `result.json` is bookkeeping, not an explanation for the timing outcome.
