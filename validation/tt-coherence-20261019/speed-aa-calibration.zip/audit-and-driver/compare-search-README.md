# TT parity and performance diagnostic

`compare-search.py` is a Linux `/proc` + `wait4` driver. It is external to the
checkout. No engine was run while preparing it. AST and pure parser/schedule/
summary checks passed; these do not verify actual engine I/O.

Run only after builds, sanitizers and other benchmarks are idle, using a new
output directory:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 /workspace/.cloud-setup/tt-investigation/compare-search.py \
  --out /workspace/.cloud-setup/tt-comparison-attempt1
```

For exactness only, with throughput completely disabled:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 /workspace/.cloud-setup/tt-investigation/compare-search.py \
  --parity-only --out /workspace/.cloud-setup/tt-parity-attempt1
```

This still freezes inputs and checks the two bench11 node signatures; its timing
records are diagnostics only and it never marks performance complete. Use a
separate fresh output directory for a later complete idle-machine attempt.

Defaults compare frozen 6.4.2
`/workspace/.cloud-setup/forge-underpromotions-build/forge` against 6.4.3
`/workspace/.cloud-setup/forge-tt-coherent-release/forge`. Preflight requires
matching Release compiler/flags/options, preserved floating-point flags, and no
sanitizers. It freezes executable, driver and build-file hashes before spawning.
Source-to-binary provenance remains in the respective build/validation evidence;
this driver does not infer a source commit from an executable hash.

`--plan-only --out NEW_DIRECTORY` writes the complete preview without starting
any child. The preview does not freeze future binary hashes. A real attempt
always needs its own fresh directory and writes its definitive plan and inputs
before the first engine starts. The pure-check JSON is
`compare-search-selfcheck.json`.

## Fixed stopping rule and work

1. One-thread fixed-depth cold and warm repeats of start, Kiwipete, middlegame,
   endgame and both-color underpromotion positions. Cold uses `ucinewgame`; warm
   repeats preserve TT and histories. Compare every ordered search-output line
   after normalizing only time/nps/hashfull. Nodes, score/bounds, depth/seldepth,
   PV and bestmove must match. Underpromotion must select the searched rook at a
   positive score. Fixed-depth completion and real PV/child nodes are required.
2. Send **stdin** `bench 11` to each binary and require 419798 nodes each. Forge's
   bench command creates its own Hash16/Threads1 searcher; outer Hash32 does not
   override it. Benchmark elapsed time is recorded but is not the main estimand.
3. For Threads1,2,4: one separate 50000-node start-position warmup per engine,
   then six blocks. Even blocks use ABBA; odd blocks use BAAB. Each slot is a
   fresh engine process with three cold 200000-node searches, rotating the same
   three-position order within each block. Hash32, OwnBook=false, Ponder=false.
   There are exactly72 measured sessions/216 searches/43.2M requested node units,
   plus the six warmup searches, parity checks and two benchmark commands.
4. Default response bound30seconds, overall bound480seconds. Counts are fixed;
   errors, timeouts, parity/signature mismatches or changed inputs abort the
   attempt. No retries, replaced samples, trimmed failures or adaptive extension.
   SIGTERM/SIGINT trigger owned-child cleanup; existing output is never resumed.

## Measurements and interpretation

Raw stdin/stdout/stderr, timestamped protocol events, launch argv/affinity,
per-search CPU samples/results and per-session exit/rusage are retained.
Wall time runs from immediately before writing go through permanent-reader
observation of bestmove, excluding local command/raw-output logging from those
endpoint timestamps. Pipe transport and observer descheduling remain included.
Aggregate process CPU is `/proc/tgid/stat` utime+stime deltas before go and after
bestmove. This includes helper threads but has `SC_CLK_TCK` quantization and
sample-boundary uncertainty. `wait4` separately records high-resolution whole-
session user+system CPU, including handshake, hash clearing and shutdown.
Cgroup and load/affinity snapshots are diagnostics; shared-cgroup counters are
not engine-only usage.

The last UCI `info nodes` can omit unfinished final-iteration work, so it is
retained as a diagnostic, **not final node accounting**. Performance ratios use
equal **requested-budget units**, not invented exact-node NPS. For each of the
six blocks, aggregate both A sessions and both B sessions before forming
A-time/B-time. A ratio above1 favors the candidate. Report raw six block ratios,
median, geometric mean and range separately for wall, tick CPU and whole-session
CPU. Searches within a block are not independent samples. SMP trees and stopping
overshoot vary, so SMP ratios are conditional throughput for this request, not
fixed quality. No Elo, equal-clock strength or physical Ryzen claim follows.

For a separate A/A noise control, use the same executable as both `--baseline`
and `--candidate` in another fresh directory with the identical full protocol.
Warmups are not A/A. Do not describe small A/B differences as measured overhead
when calibration spread dominates them. Keep this diagnostic separate from
functional/TSan correctness, and do not start a new unlimited-clock A/B match.
