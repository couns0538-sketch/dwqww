"""Preserve the audit-qualified but native-blocked experiment; never accept it."""
import hashlib
import importlib.util
import json
import os
import subprocess
from pathlib import Path
from types import SimpleNamespace

h = Path('/workspace/forge-independent-teacher-20261023')
r = Path('/workspace/dwqww')
spec = importlib.util.spec_from_file_location('net_guard', h / 'guard_net_only_candidate.py')
guard = importlib.util.module_from_spec(spec); spec.loader.exec_module(guard)
approved = guard.check(SimpleNamespace(
    training_result=h/'exec-one-warmstart-training-02/result.json',
    freeze_result=h/'exec-freeze-selected-candidate-02/result.json',
    audit_result=h/'exec-once-final-audit-02/result.json'))
native = json.loads((h/'qualified-native-02/NATIVE-VALIDATION.json').read_text())
assert native['status'] == 'BLOCKED_NATIVE_ACCEPTANCE_ORIGINAL13OF14_CTESTS'
assert native['candidate_sha256'] == approved['candidate_sha256']
assert native['ctest_actual_exit'] == 8 and native['native_gate_expected_nonzero'] == 1
def git(*args, env=None, data=None):
    return subprocess.check_output(['git',*args], cwd=r, env=env, input=data)
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def state():
    return {'head':git('rev-parse','HEAD').decode().strip(),
            'index_sha256':sha(r/'.git/index'), 'net_sha256':sha(r/'src/nnue_weights.inc')}
before=state(); assert before['net_sha256']==guard.SHIPPED
out=h/'research-net-preservation-02';out.mkdir(exist_ok=False)
index=out/'private-index';env={**os.environ,'GIT_INDEX_FILE':str(index)}
git('read-tree',guard.BASE,env=env)
raw=(h/'selected-candidate-02/selected.inc').read_bytes()
assert hashlib.sha256(raw).hexdigest()==approved['candidate_sha256']
blob=git('hash-object','-w','--stdin',data=raw).decode().strip()
git('update-index','--add','--cacheinfo','100644',blob,'src/nnue_weights.inc',env=env)
tree=git('write-tree',env=env).decode().strip()
message=('RESEARCH ONLY: independent-teacher net; native promotion regression\n\n'
         'Preserve exact epoch7 experiment, not accepted engine or release.\n'
         'Frozen once-only audit qualifies: blended MSE0.03453693078846838 ->0.031588403018465105; '
         '95% whole-game bootstrap absolute improvementCI[0.0025928813212714543,0.0033175113598455327].\n'
         'Original CTest13/14; two fixed rook-underpromotion assertions fail. '
         'Selected winning kingmoves miss shipped mate2 atdepth8. '
         'Native acceptance guard correctly remains BLOCKED. No tests or runtime algorithm edits.\n'
         'C++ parity10000 exact; extendedperft/UCIpass. No matches, Elo unproven.\n'
         'Evidence: forge/independent-teacher-20261023 validation/independent-teacher-20261023/FINAL_REPORT.md\n')
commit=git('commit-tree',tree,'-p',guard.BASE,data=message.encode()).decode().strip()
assert git('diff','--name-only',guard.BASE,commit).decode().splitlines()==['src/nnue_weights.inc']
assert git('rev-list','--parents','-n','1',commit).decode().split()==[commit,guard.BASE]
assert git('show',commit+':src/nnue_weights.inc')==raw
assert state()==before
branch='forge/nnue-independent-teacher-RESEARCH-20261023-'+approved['candidate_sha256'][:12]
git('update-ref','refs/heads/'+branch,commit,'0'*40)
result={'status':'RESEARCH_FAILURE_CHECKPOINT_ONLY_NOT_ACCEPTED_NOT_PUSHED',
        'branch':branch,'commit':commit,'parent':guard.BASE,'only_changed_path':'src/nnue_weights.inc',
        'net_sha256':approved['candidate_sha256'],'audit_ci95_abs':approved['primary_ci95_abs'],
        'native_acceptance_gate':'BLOCKED_UNCHANGED','ctests':'13/14;2failedassertions',
        'accepted_checkout_before_after_equal':before,'native_receipt_sha256':sha(h/'qualified-native-02/NATIVE-VALIDATION.json'),
        'purpose':'Preserve exact failed experiment under user authorization; not a validated release.',
        'elo':'unproven','matches':0}
(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
