"""Archive exact closed audit and native-failure evidence; never evaluates a model."""
from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,stat
H=Path('/workspace/forge-independent-teacher-20261023');rows=[];compression=[]
def sha(p):
 d=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):d.update(b)
 return d.hexdigest()
def add(rel,group,large_gzip=True):
 p=H/rel;assert p.is_file() and not p.is_symlink(),str(p)
 assert not any(x in p.parts for x in ['source','private-index']) and p.suffix not in ('.pt','.inc','.bin','.tar','.a','.o','.exe','.zip'),str(p)
 # Original per-row NPZ is included verbatim; only text streams are losslessly packed.
 member=rel;original_sha=sha(p);original_bytes=p.stat().st_size
 if large_gzip and original_bytes>500_000 and p.suffix!='.npz':
  q=H/'source14-compressed'/Path(rel+'.gz');q.parent.mkdir(parents=True,exist_ok=True);assert not q.exists()
  raw=p.read_bytes()
  with q.open('xb') as f:f.write(gzip.compress(raw,compresslevel=6,mtime=0))
  assert gzip.decompress(q.read_bytes())==raw and sha(p)==original_sha
  compression.append({'original_path':str(p),'restore_member':member,'original_sha256':original_sha,'original_bytes':original_bytes,'gzip_source':str(q),'gzip_member':member+'.gz','gzip_sha256':sha(q),'gzip_bytes':q.stat().st_size,'verification':'PASS_EXACT_ORIGINAL_DECOMPRESSION_AND_SOURCE_SHA_READBACK'})
  p=q;member+='.gz'
 assert member not in {r['member'] for r in rows}
 rows.append({'source':str(p),'member':member,'sha256':sha(p),'bytes':p.stat().st_size,'mode':stat.S_IMODE(p.stat().st_mode),'group':group})
# Root confirmed all writers closed; retain true failures instead of accepting them.
assert sha(H/'qualified-native-02/NATIVE-VALIDATION.json')=='0dd303e1d872f0da177391832cdf6c82216e1912e987dcc4d619babe2fd20a6c'
validation=json.loads((H/'qualified-native-02/NATIVE-VALIDATION.json').read_bytes());assert validation['status']=='BLOCKED_NATIVE_ACCEPTANCE_ORIGINAL13OF14_CTESTS'
for name in ['command.json','stdout','stderr','result.json']:add('exec-once-final-audit-02/'+name,'once_only_closed_audit')
assert json.loads((H/'exec-once-final-audit-02/result.json').read_bytes())['actual_exit']==0
for name in ['AUDIT_STARTED-02.json','final-audit-02/metrics.json','final-audit-02/per-row-losses.npz','final-audit-02/REPORT.md']:add(name,'once_only_closed_audit')
for name in ['AUDIT-GUARD.json','SOURCE.json','NATIVE_STEPS_STARTED.json','DIAGNOSTICS_AFTER_FAILED_CTEST_STARTED.json','native-commands.json','NATIVE-VALIDATION.json','bench.stdin','build/compile_commands.json','build/Testing/Temporary/LastTest.log','build/uci-regression.log','build/ownbook-regression.json','uci-regression.log','parity/RESULT.json']:
 add('qualified-native-02/'+name,'closed_native_source_identity_and_actual_results')
steps=['materialize','release-configure','release-build','ctest14','compile-probe','native-parity10000','extended-perft-uci','bench11'];exits={}
for step in steps:
 directory='qualified-native-02/steps/'+step
 result=json.loads((H/directory/'result.json').read_bytes());exits[step]=result['actual_exit'];assert result['closed_utc'];assert result['actual_exit']==(8 if step=='ctest14' else 0)
 for name in ['command.json','stdout','stderr','result.json']:
  if name in ('stdout','stderr'):assert sha(H/directory/name)==result[name+'_sha256']
  add(directory+'/'+name,'original_native_steps_including_failed_ctest')
for stem in ['actual-engine','hce-only','invalid-missing_king','invalid-extra_field','invalid-empty']:
 for ext in ['stdin','stdout','stderr','command.json']:add('qualified-native-02/parity/'+stem+'.'+ext,'actual_10000_native_parity_original_corpus_and_streams')
for name in ['run_native_steps_02.py','native-loop-02.stdout','native-loop-02.stderr','continue_native_diagnostics_02.py','native-diagnostics-02.stdout','native-diagnostics-02.stderr','reproduce_underpromotion_02.py','underpromotion-repro-02.stdout','underpromotion-repro-02.stderr','underpromotion-repro-02/RESULT.json','native-verification-attempt-02-spec.json']:
 add(name,'native_failed_loop_and_separate_closed_diagnostics')
for name in ['command.json','stdout','stderr','result.json']:add('exec-native-verification-blocked-02/'+name,'original_expected_failed_native_gate_invocation')
assert json.loads((H/'exec-native-verification-blocked-02/result.json').read_bytes())['actual_exit']==1
for name in ['PROMOTION-DIAGNOSTICS-CLOSED-02.json','PROMOTION-SEMANTIC-REVIEW-02.json','PROMOTION-REVIEW-HARNESS-CORRECTION-02.json','promotion-selectivity-diagnostics-02.py','promotion-selectivity-diagnostics-02.stdout','promotion-selectivity-diagnostics-02.stderr','promotion-semantic-review-02-before-oracle-order-fix.py','promotion-semantic-review-02.py']:
 add('trainer-agent/'+name,'independent_promotion_semantic_review_and_preserved_harness_failure')
for name in ['RESULT.json','original-uci-debug.log']+[f'case-{i:02d}-{kind}.json' for i in range(8) for kind in ['command','result']]:add('promotion-selectivity-diagnostics-02/'+name,'closed_actual_eight_position_diagnostics')
for name in ['preserve_research_net_02.py','research-net-preservation-02.stdout','research-net-preservation-02.stderr','research-net-preservation-02/RESULT.json','research-net-public-readback-02/RESULT.json','research-net-public-readback-02/nnue_weights.inc.http-receipt.json']:
 add(name,'research_only_net_preservation_and_public_byte_verification_no_model_payload')
for name in ['RESULT.json']+[x+'.http-receipt.json' for x in ['FINAL_REPORT.md','manifest.json','protocol.json','source-checks-13.zip']]:add('public-readback-b1f9c48/'+name,'source13_immutable_public_verification_no_response_duplication')
for name in ['source-checks-13-curation.json','source-checks-13.zip.json','checks-13-files.json','checks-14-files-pending-before-ctest-failure-3d7b1ceae98c.json','checks-14-files-pending.json','curate_source_checks_14.py']:add(name,'preserved_curation_receipts_and_original_pending_assumption')
cp=H/'source-checks-14-curation.json';assert not cp.exists()
curation={'schema_version':1,'utc':datetime.now(timezone.utc).isoformat(),'status':'CLOSED_ONCE_AUDIT_PASS_NATIVE_GATE_BLOCKED_RESEARCH_ONLY_EVIDENCE','native_step_actual_exits':exits,'native_acceptance_status':validation['status'],'ctests':'13/14,originalexit8,twoassertionsfailed','audit_status':'Actual once-only audit exit0; numericalauditpass does notoverridenativefailure orproveElo. No audit rescored.','research_publication':'Exactnet2b3038f5f1ec61c72f580d4036fda3cda1af97c2 publiclyverified; preservationreceipt originalNOT_PUSHED status retained, laterHTTPproof establishespublication. Research-only, unaccepted.','recorded_parity':'Actual10000positions exactintegerCP and features pass, originalcorpus/probestreams retained. No CSV invented.','root_writer_closure_authority':'Root explicit allnative/diagnosticsCLOSED before thiscuration; eachactualnative/resultclosedUtc rechecked.','source_or_model_changes_by_curator':False,'models_scoring_builds_matches_git_operations_by_curator':False,'raw_per_row_npz_verbatim':{'sha256':sha(H/'final-audit-02/per-row-losses.npz'),'bytes':(H/'final-audit-02/per-row-losses.npz').stat().st_size},'lossless_compressed_original_text_streams':compression,'excluded':['Sourcearchive andcopiedC++sourcetree','ALL modelweight/checkpointpayloads even researchpublicresponse.inc','ALL buildobjects/libraries/enginebinaries','PrivateGitindex','Oldarchives/publicZIPresponses/dataarchivepayloads','RUNNINGSTATE','UnexecutedWindowsrelease orPASS claims'],'known_limitations':['Originalsemanticreview harness failedassertion terminalstderr is represented by originalfailedsource and correctionreceipt; no missingrawstderr fabricated.','Originalresearchpreservationreceipt hasprepushNOT_PUSHED status; immutablepublicreadback proves subsequentpublication withoutrewritinghistory.'],'source_count_before_curation':len(rows),'raw_bytes_before_curation':sum(r['bytes'] for r in rows),'declarations':rows}
cp.write_text(json.dumps(curation,indent=2)+'\n');add(cp.name,'final_curation_receipt')
for r in rows:assert sha(Path(r['source']))==r['sha256']
p=H/'checks-14-files.json';assert not p.exists();p.write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps({'declarations':str(p),'files':len(rows),'raw_payload_bytes':sum(r['bytes'] for r in rows),'curation_sha256':sha(cp),'lossless_gzip_files':len(compression),'ctest':'BLOCKED13/14','models_scored':0}))
