# Forge fixed-held-out network comparison

302225 eligible positions from 10781 represented held-out games (11104 listed game IDs). Every source-line recipe, feature set, score and STM result replayed; prepared arrays and original source/network hashes remained unchanged. HCE values are bound by the prepared NPZ/native-probe provenance and were not reexecuted here.

Primary target: 0.6 × teacher probability + 0.4 × STM game result. The same fixed target determines every primary loss and interval below. Pure teacher is diagnostic.

| Evaluator | Fixed-target probability MSE | Pure-teacher probability MSE |
|---|---:|---:|
| HCE only | 0.0349583583 | 0.0177389344 |
| Shipped HCE + residual | 0.0345369308 | 0.0170719473 |
| Candidate HCE + residual | 0.031588403 | 0.017036364 |
| Shipped residual term only | 0.123364187 | 0.142553179 |
| Candidate residual term only | 0.191849369 | 0.22010352 |

Prior baseline comparison: not supplied; this report does not authenticate an earlier holdout.

Candidate versus HCE: absolute reduction 0.00336995524, 95% CI [0.00300213757, 0.00374623305]; relative 9.640%, 95% CI [8.650%, 10.636%].

Candidate versus shipped: absolute reduction 0.00294852777, 95% CI [0.00259288132, 0.00331751136]; relative 8.537%, 95% CI [7.555%, 9.540%].

Intervals use 10000 paired whole-game resamples, seed2026102303, with ratio(sum loss / sum rows) and linear percentile endpoints. Positive reduction means lower loss; no per-position independence is assumed. Empty eligible games are not represented clusters. Full per-row losses and game IDs are retained in `per-row-losses.npz`, SHA256 `08e56d2713271eecee1c631e1895a2c0c6e448603d0d14055763c8b96a34198f`. Full aggregate metrics agree with the trainer within1e-12.

These are conditional held-out loss comparisons, not Elo or independent confirmation after model selection on this holdout. Residual-term-only is diagnostic; the engine deploys HCE plus residual. Search and the shipped network were not modified.
