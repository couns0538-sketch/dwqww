"""Run the reviewed native plan once, preserving each actual subprocess receipt."""
import hashlib
import json
import subprocess
import sys
from pathlib import Path

h = Path('/workspace/forge-independent-teacher-20261023')
out = h / 'qualified-native-02'
plan = out / 'native-commands.json'
raw = plan.read_bytes()
digest = hashlib.sha256(raw).hexdigest()
commands = json.loads(raw)['commands']
with (out / 'NATIVE_STEPS_STARTED.json').open('x') as stream:
    json.dump({'plan_sha256': digest, 'steps': [c['name'] for c in commands]}, stream)
for command in commands:
    assert hashlib.sha256(plan.read_bytes()).hexdigest() == digest
    name = command['name']
    argv = [sys.executable, '-B', str(h / 'run_recorded_step.py'), '--spec', str(plan),
            '--step', name, '--out', str(out / 'steps' / name)]
    print('START_NATIVE_STEP', name, flush=True)
    result = subprocess.run(argv, check=False)
    if result.returncode:
        raise SystemExit(result.returncode)
print('ALL_NATIVE_STEPS_CLOSED_ZERO', flush=True)
