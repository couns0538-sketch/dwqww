"""Reproduce the original fixed-depth assertion against exact shipped/selected binaries."""
import hashlib
import json
import subprocess
from pathlib import Path
import chess
import chess.engine

h = Path('/workspace/forge-independent-teacher-20261023')
out = h / 'underpromotion-repro-02'
out.mkdir(exist_ok=False)
engines = {
    'shipped': Path('/workspace/.cloud-setup/nnue-pipeline-20261023-baseline-build/forge'),
    'selected': h / 'qualified-native-02/build/forge',
}
board = chess.Board('8/k1P5/2K5/8/8/8/8/8 w - - 0 1')
rows = []
for name, binary in engines.items():
    for mirrored, original in [(False, board), (True, board.mirror())]:
        for depth in [1, 3, 8]:
            with chess.engine.SimpleEngine.popen_uci(str(binary), timeout=30) as engine:
                engine.configure({'Threads': 1, 'Hash': 1, 'OwnBook': False})
                info = engine.analyse(original, chess.engine.Limit(depth=depth))
            move = info['pv'][0]
            after = original.copy(); after.push(move)
            row = {'engine': name, 'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
                   'fen': original.fen(), 'mirror': mirrored, 'depth': depth, 'bestmove': move.uci(),
                   'score_stm_cp': info['score'].pov(original.turn).score(mate_score=32000),
                   'pv': [m.uci() for m in info['pv']], 'legal': move in original.legal_moves,
                   'resulting_fen': after.fen(), 'immediate_stalemate': after.is_stalemate(),
                   'immediate_checkmate': after.is_checkmate()}
            rows.append(row)
            print(json.dumps(row), flush=True)
(out / 'RESULT.json').write_text(json.dumps({'rows': rows, 'scope': 'Position regression only; no matches or Elo.'}, indent=2)+'\n')
