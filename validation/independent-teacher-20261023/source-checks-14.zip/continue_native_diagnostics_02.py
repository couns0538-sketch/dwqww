"""Complete diagnostic steps after original CTest failure; never changes its result."""
import json
import subprocess
import sys
from pathlib import Path
h = Path('/workspace/forge-independent-teacher-20261023')
out = h / 'qualified-native-02'
plan = out / 'native-commands.json'
failed = json.loads((out / 'steps/ctest14/result.json').read_text())
assert failed['actual_exit'] == 8
with (out / 'DIAGNOSTICS_AFTER_FAILED_CTEST_STARTED.json').open('x') as stream:
    json.dump({'reason': 'Original core underpromotion fixed-move assertions failed; diagnostic continuation only, native gate remains blocked.'}, stream)
names = ['compile-probe', 'native-parity10000', 'extended-perft-uci', 'bench11']
for name in names:
    print('DIAGNOSTIC_STEP', name, flush=True)
    result = subprocess.run([sys.executable, '-B', str(h / 'run_recorded_step.py'),
        '--spec', str(plan), '--step', name, '--out', str(out / 'steps' / name)])
    if result.returncode: raise SystemExit(result.returncode)
print('DIAGNOSTICS_CLOSED_ZERO_ORIGINAL_CTEST_STILL_FAILED', flush=True)
