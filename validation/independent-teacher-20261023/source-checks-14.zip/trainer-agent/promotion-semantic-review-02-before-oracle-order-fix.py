#!/usr/bin/env python3
"""Original finite chess-rule proofs only. No engines, tablebases or matches."""
from pathlib import Path
import hashlib,json
from datetime import datetime,timezone
import chess
H=Path('/workspace/forge-independent-teacher-20261023')
S=H/'qualified-native-02/source'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def move_for(text,mirror):
 m=chess.Move.from_uci(text)
 return chess.Move(chess.square_mirror(m.from_square),chess.square_mirror(m.to_square),m.promotion) if mirror else m

def advance(b,m,route):
 assert b.is_valid() and m in b.legal_moves,(b.fen(),m.uci())
 c=b.copy();c.push(m)
 assert c.is_valid(),c.fen()
 return c,route+[m.uci()]

def leaf(b,route,promoted,winning):
 assert b.turn!=winning and b.is_valid()
 assert b.piece_at(promoted)==chess.Piece(chess.QUEEN,winning)
 assert sorted(p.piece_type for p in b.piece_map().values())==[chess.KING,chess.KING,chess.QUEEN]
 assert not b.is_stalemate() and not b.is_insufficient_material()
 assert b.halfmove_clock==0
 capture=[m.uci() for m in b.legal_moves if m.to_square==promoted and b.is_capture(m)]
 assert not capture
 return {'line':route,'fen':b.fen(),'queen_not_capturable':True,'not_stalemate':True,'halfmove_clock':0,'classification':'Won KQK by standard elementary-endgame theorem, not a tablebase query.'}

proof=[]
for mirror in [False,True]:
 original=chess.Board('8/k1P5/2K5/8/8/8/8/8 w - - 0 1')
 b=original.mirror() if mirror else original
 winning=b.turn
 roots={}
 for strategy in ['c6d7','c6d6']:
  first,route=advance(b,move_for(strategy,mirror),[])
  leaves=[]
  for reply in list(first.legal_moves):
   second,route2=advance(first,reply,route)
   if strategy=='c6d6':
    third,route3=advance(second,move_for('d6d7',mirror),route2)
    assert not third.is_game_over(claim_draw=True)
    continuations=[advance(third,r,route3) for r in list(third.legal_moves)]
   else:continuations=[(second,route2)]
   for before,route4 in continuations:
    promotion=move_for('c7c8q',mirror)
    after,route5=advance(before,promotion,route4)
    leaves.append(leaf(after,route5,promotion.to_square,winning))
  roots[move_for(strategy,mirror).uci()]={'all_defender_branches_enumerated':True,'winning_strategy':'After rootKd6 playKd7 after every firstdefenderreply; thenQpromote after every nextdefenderreply. After rootKd7 immediatelyQpromote after everyreply.','leaves':leaves}
 rook,rr=advance(b,move_for('c7c8r',mirror),[])
 replies=list(rook.legal_moves)
 assert len(replies)==1
 middle,rr=advance(rook,replies[0],rr)
 mate,rr=advance(middle,move_for('c8a8',mirror),rr)
 assert mate.is_checkmate()
 queen,qr=advance(b,move_for('c7c8q',mirror),[])
 assert queen.is_stalemate()
 proof.append({'mirror':mirror,'root_fen':b.fen(),'legal_root_moves':[m.uci() for m in b.legal_moves],'queen_promotion_stalemates':qr,'rook_forced_mate_in_two':rr,'winning_king_alternatives':roots})
repro=H/'underpromotion-repro-02/RESULT.json'
result={'utc':datetime.now(timezone.utc).isoformat(),'status':'FINITE_RULE_PROOF_PASS_NOT_AN_ENGINE_ACCEPTANCE','python_chess_version':chess.__version__,'proofs':proof,
 'source_sha256':{str(p):sha(p) for p in [Path(__file__),S/'tests/tests.cpp',S/'src/search.cpp',S/'src/board.cpp',S/'src/eval.cpp',S/'src/nnue_weights.inc',H/'qualified-native-02/steps/ctest14/stdout',repro]},
 'observed_engine_evidence':'Root-generated UCI receipt is hashed, not replayed here. Shipped chooses forcedmate2 rook atdepth3/8; selected chooses rule-proven winning kingmoves atdepth1/3/8 but misses the immediate forcedmate2.',
 'semantic_conclusions':['The unrestricteddepth1 fixture checks exactrookranking, not uniqueness of winningplay. Kingc6d6 andc6d7 also force a win; their mirrored moves do too.','There is no demonstrated illegal move or stalemating choice in these recorded candidate outputs.','Actual missedforcedmate2 atdepth8 is a tactical/search regression against shipped; lowerauditloss does not negate it.','The existing14CTestgate stillfails. Do not relabel13/14aspassing or altertestexpectation afterseeingcandidate just to publish.'],
 'source_review':{'verified':'Allpromotions originate in MovePicker capturestage; promotions excludedquietclassification. Rootshallowmovepruning guarded!root. Losingbarekinghas_non_pawn_materialfalse suppresseslatermovepruning andnullmove, but not nonPV TT/RFP/razoring.','hypothesis':'NNUEchangedranking/rootTTmove changes nonPV nullwindow alpha; evaluation-dependent RFP or cachedbound may suppress rookline. Sourceinspectionalone doesnotidentifyactual cutoff responsible.','causal_validation_needed':'Compare existingselectedbinary restrictedrook depth3/8 vsunrestricted; inspect actual pernodecutofftrace only in a separatelyauthorized sourcefix experiment; do not edit search in this mainnet-only job.'},
 'publication_recommendation':'Auditcriterion qualified only; native14CTest contractualgate remains blocked. Preserve unpublishedcandidate+failedoriginalevidence privately/recoverably as permitted; publish dataset/trainer/manifest/honestloss+testresults. Do not create net-onlyref using currentstricthelper and do not bypassit. A future explicit testcontract revision needs independent preselection justification and a robust promotion-choice regression, not silent weakening.',
 'scope':'No engineexecution, build, tables, sourcechanges, retraining, audits, or matches; only Pythonlegalruleenumeration and elementaryKQK theorem.'}
out=H/'trainer-agent/PROMOTION-SEMANTIC-REVIEW-02.json'
with out.open('x') as s:json.dump(result,s,indent=2);s.write('\n')
print(json.dumps({'receipt':str(out),'sha256':sha(out),'bytes':out.stat().st_size,'leaf_counts':[ {k:len(v['leaves']) for k,v in p['winning_king_alternatives'].items()} for p in proof]}))
