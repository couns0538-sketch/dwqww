"""Existing-binary position diagnostics. No matches, builds, or source changes."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,logging,time
import chess,chess.engine
h=Path('/workspace/forge-independent-teacher-20261023');out=h/'promotion-selectivity-diagnostics-02'
out.mkdir(exist_ok=False)
logging.basicConfig(filename=str(out/'original-uci-debug.log'),filemode='x',level=logging.DEBUG,format='%(asctime)s %(name)s %(levelname)s %(message)s')
binary=h/'qualified-native-02/build/forge'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
identity=sha(binary);rows=[]
board=chess.Board('8/k1P5/2K5/8/8/8/8/8 w - - 0 1')
start=datetime.now(timezone.utc).isoformat()
for mirror,original in [(False,board),(True,board.mirror())]:
 promotions=[m for m in original.legal_moves if m.promotion]
 rook=[m for m in promotions if m.promotion==chess.ROOK]
 for mode,depth,root in [('rook-only',3,rook),('all-four-promotions',3,promotions),('unrestricted',12,None),('unrestricted',16,None)]:
  config={'Threads':1,'Hash':1,'OwnBook':False}
  command={'binary':str(binary),'binary_sha256':identity,'options':config,'fresh_process':True,'fen':original.fen(),'root_moves':None if root is None else [m.uci() for m in root],'requested_depth':depth,'mode':mode,'mirror':mirror,'utc':datetime.now(timezone.utc).isoformat()}
  number=len(rows);(out/('case-%02d-command.json'%number)).write_text(json.dumps(command,indent=2)+'\n')
  begin=time.monotonic()
  with chess.engine.SimpleEngine.popen_uci(str(binary),timeout=30) as engine:
   engine.configure(config)
   info=engine.analyse(original,chess.engine.Limit(depth=depth),root_moves=root)
  elapsed=time.monotonic()-begin
  assert sha(binary)==identity
  pv=info.get('pv',[]);pov=info['score'].pov(original.turn)
  row={**command,'actual_depth':info.get('depth'),'seldepth':info.get('seldepth'),'nodes':info.get('nodes'),'elapsed_seconds':elapsed,'score_cp':pov.score(),'score_mate':pov.mate(),'pv':[m.uci() for m in pv],'bestmove':pv[0].uci() if pv else None,'legal':bool(pv) and pv[0] in original.legal_moves}
  replay=original.copy()
  for m in pv:assert m in replay.legal_moves;replay.push(m)
  row['pv_all_legal']=True
  rows.append(row);print(json.dumps(row),flush=True)
  (out/('case-%02d-result.json'%number)).write_text(json.dumps(row,indent=2)+'\n')
result={'status':'COMPLETED_POSITION_DIAGNOSTICS_NOT_ELO','started_utc':start,'closed_utc':datetime.now(timezone.utc).isoformat(),'script_sha256':sha(__file__),'binary_sha256':identity,'rows':rows,'scope':'Freshprocess percase,existingselectedbinary only,rootmoves specified as logged; no matches or sourcechanges.'}
(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
