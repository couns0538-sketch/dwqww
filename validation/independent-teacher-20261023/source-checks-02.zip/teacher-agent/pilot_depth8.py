import gzip,hashlib,json,os,random,selectors,subprocess,time
from pathlib import Path
import chess
out=Path('/workspace/forge-independent-teacher-20261023/teacher-agent'); binary=Path('/workspace/.cloud-setup/stockfish/stockfish/stockfish-linux-x86-64-universal')
rng=random.Random(20261023); fens=[]
while len(fens)<256:
 b=chess.Board()
 for ply in range(160):
  if b.is_game_over(): break
  legal=list(b.legal_moves); b.push(rng.choice(legal))
  if ply>=11 and ply%4==3 and not b.is_check() and not b.is_game_over(): fens.append(b.fen())
  if len(fens)==256: break
(out/'pilot_fens.json').write_text(json.dumps(fens)+'\n')
p=subprocess.Popen([str(binary)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,start_new_session=True,bufsize=0)
sel=selectors.DefaultSelector();sel.register(p.stdout,selectors.EVENT_READ);buf=b'';t0=time.monotonic(); transcript=gzip.open(out/'pilot_depth8_uci.jsonl.gz','wt',compresslevel=1)
def log(d,line): transcript.write(json.dumps({'direction':d,'line':line},separators=(',',':'))+'\n')
def send(x):log('in',x);p.stdin.write((x+'\n').encode());p.stdin.flush()
def line():
 global buf
 end=time.monotonic()+60
 while b'\n' not in buf:
  if not sel.select(max(0,end-time.monotonic())):raise RuntimeError('timeout')
  data=os.read(p.stdout.fileno(),65536)
  if not data:raise RuntimeError('EOF')
  buf+=data
 x,buf=buf.split(b'\n',1);s=x.decode().strip();log('out',s);return s
try:
 send('uci');uci=[]
 while True:
  s=line();uci.append(s)
  if s=='uciok':break
 opts={'Threads':'1','Hash':'16','MultiPV':'1','Ponder':'false','Skill Level':'20','UCI_LimitStrength':'false','UCI_Chess960':'false','SyzygyPath':'<empty>'}
 for k,v in opts.items():send('setoption name '+k+' value '+v)
 send('isready')
 while line()!='readyok':pass
 rows=[];search0=time.monotonic()
 for i,fen in enumerate(fens):
  send('setoption name Clear Hash');send('isready')
  while line()!='readyok':pass
  send('position fen '+fen);t=time.monotonic();send('go depth 8');last=None
  while True:
   s=line()
   if s.startswith('info depth ') and ' score ' in s:last=s
   if s.startswith('bestmove '):break
  rows.append({'fen':fen,'last_info':last,'bestmove':s,'wall_ms':(time.monotonic()-t)*1000})
  if (i+1)%32==0:print(json.dumps({'positions':i+1,'elapsed_s':time.monotonic()-search0}),flush=True)
 elapsed=time.monotonic()-search0
 send('quit');p.wait(timeout=5);transcript.close()
 summary={'engine_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'engine_bytes':binary.stat().st_size,'uci':uci,'options':opts,'cold_hash_per_fen':True,'requested_depth':8,'positions':len(rows),'search_wall_s':elapsed,'total_wall_s':time.monotonic()-t0,'positions_per_s':len(rows)/elapsed,'estimated_5M_hours_3workers':5000000/(len(rows)/elapsed)/3/3600,'rows':rows}
 (out/'pilot_depth8.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k not in ('uci','rows')}),flush=True)
finally:
 if p.poll() is None:p.kill();p.wait()
 transcript.close();sel.close()
