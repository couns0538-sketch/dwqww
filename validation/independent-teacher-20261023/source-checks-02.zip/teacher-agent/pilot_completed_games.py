import gzip,json,sys,time,statistics
from pathlib import Path
sys.path.insert(0,'/workspace/dwqww/tools/nnue')
import label_teacher_games as t
out=Path('/workspace/forge-independent-teacher-20261023/teacher-agent')
source=Path('/workspace/forge-independent-teacher-20261023/generation-agent/screen-256-mixed-n64/chunks/games-000000.jsonl.gz')
games=[];remaining=256
with gzip.open(source,'rt') as handle:
 for line in handle:
  game=json.loads(line)
  if not game['samples']:continue
  game['samples']=game['samples'][:remaining]
  remaining-=len(game['samples']);games.append(game)
  if not remaining:break
for depth in (6,4):
 trace=t.Transcript(out/('pilot-completed-games-d%d-transcript'%depth))
 teacher=t.Teacher(['/workspace/.cloud-setup/stockfish/stockfish/stockfish-linux-x86-64-universal'],trace,0,depth,60)
 started=time.monotonic();counts={};labelled=[]
 try:
  for game in games:
   item,delta=t.label_game(game,teacher);labelled.append(item)
   for key,value in delta.items():counts[key]=counts.get(key,0)+value
  elapsed=time.monotonic()-started
 finally:teacher.close();trace.close()
 rows=[sample for game in labelled for sample in game['samples']]
 summary={'pilot_only':True,'teacher_depth':depth,'games':len(games),'input_positions':256-remaining,'elapsed_s':elapsed,'search_positions_per_s':counts['searched_positions']/elapsed,'accepted_positions_per_s':counts['accepted']/elapsed,'estimated_5M_accepted_hours_3workers':5e6/(counts['accepted']/elapsed)/3/3600,'counts':counts,'teacher':teacher.identity,'networks':sorted(teacher.network_messages),'source_path':str(source),'source_sha256':t.sha256(source),'tool_sha256':t.sha256(Path(t.__file__)),'median_accepted_wall_ms':statistics.median([row['teacher_wall_ms'] for row in rows]),'transcript':trace.manifest()}
 with gzip.open(out/('pilot-completed-games-d%d-labels.jsonl.gz'%depth),'wt',compresslevel=1) as stream:
  for item in labelled:stream.write(json.dumps(item,separators=(',',':'))+'\n')
 (out/('pilot-completed-games-d%d.json'%depth)).write_text(json.dumps(summary,indent=2)+'\n')
 print(json.dumps(summary),flush=True)
