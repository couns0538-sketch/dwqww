from pathlib import Path
import json,hashlib,subprocess,os
from datetime import datetime,timezone
h=Path('/workspace/forge-independent-teacher-20261023'); root=Path('/workspace/dwqww'); rows=[]
def sha(p):
 d=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''): d.update(b)
 return d.hexdigest()
for name in ('initial','increment04','increment05'):
 proof=h/('dataset-'+name+'-public-readback/RESULT.json'); data=json.loads(proof.read_text())
 assert data['status']=='PASS_ALL_PUBLIC_DATASET_ARTIFACTS_BYTE_HASH_SIZE_VERIFIED'
 for row in data['checks']:
  if not Path(row['path']).name.startswith('dataset.zip.'): continue
  expected_bytes=row.get('bytes',row.get('expected_bytes')); expected_sha=row.get('sha256',row.get('expected_sha256'))
  assert expected_bytes==row['actual_bytes'] and expected_sha==row['actual_sha256'] and row['http_status']==200
  p=h/('dataset-publication-'+name)/Path(row['path']).name
  assert p.is_file() and not p.is_symlink() and p.stat().st_size==expected_bytes and sha(p)==expected_sha
  reader=subprocess.Popen(['git','cat-file','blob',data['commit']+':'+row['path']],cwd=root,stdout=subprocess.PIPE)
  d=hashlib.sha256(); n=0
  for b in iter(lambda:reader.stdout.read(1<<20),b''): d.update(b); n+=len(b)
  reader.stdout.close(); assert reader.wait()==0 and n==expected_bytes and d.hexdigest()==expected_sha
  rows.append({'path':str(p),'bytes':n,'sha256':d.hexdigest(),'commit':data['commit'],'git_path':row['path'],'public_verification_receipt_sha256':sha(proof)})
receipt={'status':'VERIFIED_TEMPORARY_ARCHIVE_PART_CACHES_ONLY','utc':datetime.now(timezone.utc).isoformat(),'all_source_inputs_and_git_objects_retained':True,'public_and_local_git_bytes_verified':True,'parts':rows,'free_bytes_before':os.statvfs(h).f_bavail*os.statvfs(h).f_frsize}
pre=h/'TEMP-PART-CACHE-PRUNE-PREFLIGHT.json'; assert not pre.exists(); pre.write_text(json.dumps(receipt,indent=2)+'\n')
for row in rows:
 p=Path(row['path']); assert sha(p)==row['sha256']; p.unlink()
receipt['status']='PASS_ONLY_VERIFIED_REDUNDANT_TEMP_PART_COPIES_REMOVED'; receipt['free_bytes_after']=os.statvfs(h).f_bavail*os.statvfs(h).f_frsize
receipt['logical_bytes_removed']=sum(x['bytes'] for x in rows); receipt['preflight_sha256']=sha(pre)
(h/'TEMP-PART-CACHE-PRUNE-RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(receipt['status'],len(rows),receipt['logical_bytes_removed'],receipt['free_bytes_after'])
