#!/usr/bin/env python3
"""Curate closed checks12 records and immutable INCOMPLETEPREFIX log snapshots."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,stat,time,zlib
H=Path('/workspace/forge-independent-teacher-20261023');REPO=Path('/workspace/dwqww');SUP=H/'checks-12-support-attempt2';SUP.mkdir(exist_ok=False)

def utc():return datetime.now(timezone.utc).isoformat()
def sha_bytes(b):return hashlib.sha256(b).hexdigest()
def raw(p):return Path(p).read_bytes()
def sha(p):return sha_bytes(raw(p))
def read(p):return json.loads(raw(p))
def new(p,b):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb')as f:f.write(b);f.flush();os.fsync(f.fileno())
def proc(pid):
 text=(Path('/proc')/str(pid)/'stat').read_text();f=text.rsplit(') ',1)[1].split();return{'pid':pid,'proc_start_ticks':int(f[19]),'state':f[0]}
def stable(p):
 p=Path(p);assert p.is_file()and not p.is_symlink();a=p.stat();b=raw(p);c=p.stat();assert(a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns,a.st_ctime_ns)==(c.st_dev,c.st_ino,c.st_size,c.st_mtime_ns,c.st_ctime_ns)and len(b)==c.st_size;assert raw(p)==b
 return b,{'sha256':sha_bytes(b),'bytes':len(b),'mode':stat.S_IMODE(c.st_mode),'mtime_ns':c.st_mtime_ns}

def main():
 started=utc();entries=[];identities={};groups={};copies=[]
 def add(path,group,member=None):
  p=Path(path);b,d=stable(p);member=member or str(p.relative_to(H));assert not member.startswith('/')and'..'not in Path(member).parts and member not in identities
  assert not any(x in p.parts for x in('checkpoints','exports'))and p.suffix not in('.pt','.bin','.inc','.npz')and not p.name.startswith('dataset.zip.')and'RUNNING-STATE'not in p.name
  assert p not in(REPO/'validation/independent-teacher-20261023/manifest.json',REPO/'validation/independent-teacher-20261023/FINAL_REPORT.md')
  entry={'source':str(p),'member':member,**{k:d[k]for k in('sha256','bytes','mode')},'group':group};entries.append(entry);identities[member]=d;groups[group]=groups.get(group,0)+1;return b
 def addrel(name,group):return add(H/name,group)
 for group,dirname in(('closed_global_seal','global-seal-exec-02'),('closed_global_pack','global-pack-exec-02'),('closed_global_dataref','global-data-ref-exec-02'),('closed_original_validation_baseline','exec-original-validation-baseline-02')):
  d=read(H/dirname/'result.json');assert d['status']=='COMPLETED'and d['actual_exit']==0
  for stream in('stdout','stderr'):assert sha(H/dirname/stream)==d[stream+'_sha256']and(H/dirname/stream).stat().st_size==d[stream+'_bytes']
  for name in('command.json','result.json','stdout','stderr'):addrel(dirname+'/'+name,group)
 for name in('global-seal-command-02.json','global-pack-command-02.json','downstream_commands.json'):addrel(name,'closed_actual_command_specs')
 push=read(H/'GLOBAL-DATA-PUSH-RESULT.json');assert push['status']=='PASS_ACTUAL_GIT_PUSH_COMPLETED'and push['commit']=='442d5647612591a2d5a387c0513f5b482c07d6e8'and push['tool_result']['exit_code']==0;addrel('GLOBAL-DATA-PUSH-RESULT.json','closed_data442_publication')
 public=read(H/'dataset-global02-public-readback/RESULT.json');assert public['status']=='PASS_ALL_PUBLIC_DATASET_ARTIFACTS_BYTE_HASH_SIZE_VERIFIED'and public['commit']==push['commit']and len(public['checks'])==27
 for row in public['checks']:assert row['http_status']==200 and row['bytes']==row['actual_bytes']and row['sha256']==row['actual_sha256']
 assert sum(row['bytes']for row in public['checks'])==723367402
 for name in('dataset-global02-public-readback/RESULT.json','dataset-global02-public-readback/checks.json','verify_dataset_publication.py'):addrel(name,'closed_data442_publication')
 for name in('commands.json','RESULT.json','PUBLICATION-MANIFEST.json','recovery-verify.stdout','recovery-verify.stderr'):addrel('dataset-git-global02/'+name,'closed_global_dataref_metadata')
 for name in('CLOSED-GLOBAL-INPUTS.json','CI-DEPENDENCIES.json','SOURCE-IDENTITIES.json','QUALIFICATION.json','RESTORE.md'):addrel('global-publication-02/'+name,'closed_global_restore_metadata')
 for n in range(4):addrel('global-publication-02/ci-final/shard-'+str(n)+'/STATUS.json','closed_global_restore_metadata')
 addrel('dataset-publication-global02/RECOVERY-MANIFEST.json','closed_global_restore_metadata')
 actual=H/'trainer-agent/ACTUAL-GLOBAL-BASELINE-TRAINING-PREFLIGHT-08.json';assert sha(actual)=='04674836a38be2ac8d3d707d4740aa8fc880846f21c6c8c70b7eeba32bd3d35e';add(actual,'actual_global_preflight0467')
 for name in('prune_verified_temp_parts.py','preparer-agent/prune_verified_temp_parts-before-cli-1843dda813b5.py','preparer-agent/prune-explicit-cli-guard-check.json','TEMP-PART-CACHE-PRUNE-GLOBAL02-RECEIPT-PREFLIGHT.json','TEMP-PART-CACHE-PRUNE-GLOBAL02-RECEIPT.json'):addrel(name,'closed_global02_staging_prune')
 pruned=read(H/'TEMP-PART-CACHE-PRUNE-GLOBAL02-RECEIPT.json');assert pruned['removed_parts']==23 and not pruned['errors']and pruned['logical_bytes_removed']==723304258
 baseline=read(H/'original-validation-baseline-02/summary.json');assert baseline['status']=='baseline_only'and baseline['epochs_completed']==0 and baseline['best']is None
 for name in('summary.json','initial-report.json','protocol.json'):addrel('original-validation-baseline-02/'+name,'closed_original_validation_baseline')
 marker=read(H/'TRAINING_STARTED-02.json');addrel('TRAINING_STARTED-02.json','one_active_training_run_marker')
 protocol_sha=sha(REPO/'validation/independent-teacher-20261023/protocol.json');assert marker['protocol_sha256']==protocol_sha=='245bf6dd4bcea66d0666e2443ff24602d036bffd76c7c0b5fa2a89c57f2b6b53'
 sources={}
 for relative,want in marker['source_sha256'].items():
  p=REPO/relative;b,d=stable(p);assert d['sha256']==want;dest=SUP/'frozen-tools'/relative;new(dest,b);assert raw(dest)==b;add(dest,'frozen_training_source_code');sources[relative]={'original_source':str(p),'snapshot':str(dest),'sha256':want,'bytes':len(b)}
 source_record={'status':'PASS_CURRENT_CODE_BYTE_IDENTICAL_TO_ACTUAL_TRAINING_STARTED_PINS','utc':utc(),'protocol_sha256':protocol_sha,'source_sha256':sources,'shipped_weight_SHA_reference_only_no_weight_payload':marker['shipped_sha256']};new(SUP/'TRAINING-SOURCE-IDENTITIES.json',(json.dumps(source_record,indent=2)+'\n').encode());add(SUP/'TRAINING-SOURCE-IDENTITIES.json','frozen_training_source_code')
 epoch_records=[]
 for n in(1,2):
  p=H/'training-run-02'/('epoch-'+str(n).zfill(4)+'-report.json');b,d=stable(p);e=json.loads(b);assert e['epochs_completed']==n and len(e['epochs'])==n and e['epochs'][-1]['epoch']==n and e['config']['baseline_only']is False and e['config']['fixed_result_weight']==.4 and e['config']['selection_include_initial']is False and e['config']['protocol']['sha256']==protocol_sha
  assert e['manifest_sha256']==marker['prepared_manifest_sha256'];add(p,'immutable_completed_epoch_reports');epoch_records.append({'epoch':n,'path':str(p),**d,'target_mse_combined':e['epochs'][-1]['target_mse_combined'],'status_scope':'Immutable completed epoch report; overall training status remains running, best field is provisional before epochs1..8 finish and audit'})
 assert epoch_records[1]['target_mse_combined']==.031849118953087376
 active=H/'exec-one-warmstart-training-02';command_raw,command_meta=stable(active/'command.json');command=json.loads(command_raw);assert command['actual_exit']is None and not(active/'result.json').exists();pid=command['pid'];before=proc(pid);assert before['proc_start_ticks']==int(command['proc_start_ticks'])and before['state']!='Z'
 command_copy=SUP/'training'/'exec-command.INCOMPLETE-RUN.snapshot.json';new(command_copy,command_raw);add(command_copy,'active_training_input_command_snapshot');copies.append({'source':str(active/'command.json'),'snapshot':str(command_copy),'sha256':command_meta['sha256'],'source_bytes_equal_snapshot':raw(active/'command.json')==raw(command_copy)})
 prefix_records=[]
 for stream in('stdout','stderr'):
  source=active/stream;dest=SUP/'training'/(stream+'.INCOMPLETEPREFIX');capture_start=utc();fd=os.open(source,os.O_RDONLY|os.O_NOFOLLOW|getattr(os,'O_NOATIME',0))
  with os.fdopen(fd,'rb')as f:
   original=os.fstat(f.fileno());count=original.st_size;content=f.read(count);assert len(content)==count;new(dest,content);f.seek(0);again=f.read(count);after_stat=os.fstat(f.fileno());path_stat=source.stat();assert again==content and after_stat.st_size>=count and(original.st_dev,original.st_ino)==(after_stat.st_dev,after_stat.st_ino)==(path_stat.st_dev,path_stat.st_ino)
  record={'status':'INCOMPLETEPREFIX_ACTIVE_TRAINING_LOG_NOT_CLOSED','source':str(source),'snapshot':str(dest),'utc_capture_started':capture_start,'utc_capture_finished':utc(),'pid':pid,'proc_start_ticks':command['proc_start_ticks'],'prefix_bytes':count,'prefix_sha256':sha_bytes(content),'source_size_before':original.st_size,'source_size_after_prefix_validation':after_stat.st_size,'source_dev':original.st_dev,'source_inode':original.st_ino,'source_prefix_reopened_or_rewound_and_byte_verified':True,'snapshot_full_SHA_verified':sha(dest)==sha_bytes(content),'scope':'Exact source prefix at recorded size; source may append later. No training-completion, final epoch selection, audit decision or candidate publication claimed.'};prefix_records.append(record);add(dest,'active_training_incomplete_log_prefix')
 after=proc(pid);assert before['proc_start_ticks']==after['proc_start_ticks']and after['state']!='Z'and not(active/'result.json').exists()
 snapshot_record={'schema':'forge-active-training-incomplete-prefix-snapshot-v1','status':'INCOMPLETEPREFIX_ONLY_ONE_TRAINING_RUN_STILL_ACTIVE','utc':utc(),'source_command':str(active/'command.json'),'source_command_sha256':command_meta['sha256'],'command_snapshot':str(command_copy),'process_before':before,'process_after':after,'actual_closed_result_absent_at_capture':True,'prefixes':prefix_records,'input_command_copies':copies,'immutable_epoch_reports_included':[1,2],'later_epoch_report_names_observed_but_not_included':[p.name for p in(H/'training-run-02').glob('epoch-*-report.json')if p.name not in('epoch-0001-report.json','epoch-0002-report.json')],'training_closed':False,'model_checkpoint_export_weight_payload_included':False};new(SUP/'TRAINING-INCOMPLETEPREFIX-SNAPSHOT.json',(json.dumps(snapshot_record,indent=2)+'\n').encode());add(SUP/'TRAINING-INCOMPLETEPREFIX-SNAPSHOT.json','active_training_incomplete_log_prefix')
 source_public=read(H/'public-readback-75447f9/RESULT.json');assert source_public['source_commit']=='75447f94755f230c98492481e4761a2b5c137c06'and len(source_public['checks'])==5 and all(c['pass']for c in source_public['checks'])
 for p in sorted((H/'public-readback-75447f9').iterdir()):
  if p.is_file()and p.suffix=='.json':add(p,'closed_source754_public_readback')
 addrel('package_closed_evidence.py','closed_packaging_helper');add(Path(__file__),'checks12_curation_source')
 # Rehash every explicit source again; only stable snapshots of the active logs/command are declared.
 for e in entries:assert sha(e['source'])==e['sha256']and Path(e['source']).stat().st_size==e['bytes']
 uncompressed=sum(e['bytes']for e in entries);estimated=sum(len(zlib.compress(raw(e['source']),6))for e in entries)
 curated={'schema':'forge-source-checks12-progress-curation-v1','status':'PASS_CLOSED_RECORDS_AND_EXPLICIT_ACTIVE_LOG_PREFIXES_DECLARED','utc_started':started,'utc_finished':utc(),'files_excludes_curation_receipt_itself':True,'files':len(entries),'uncompressed_bytes':uncompressed,'estimated_zip_deflate6_bytes':estimated,'groups':groups,'actual_global_preflight_sha256':sha(actual),'data_commit':push['commit'],'public_data_files_verified':27,'public_data_bytes_verified':723367402,'baseline_actual_exit':0,'baseline_original_validation_target_mse_combined':baseline['initial']['target_mse_combined'],'baseline_summary_status':'baseline_only','training_state':'ONE_RUN_ACTIVE_INCOMPLETEPREFIX_ONLY','training_pid':pid,'training_proc_start_ticks':command['proc_start_ticks'],'immutable_epoch_reports':epoch_records,'training_closed':False,'training_final_selection_or_audit_or_candidate_publication_claimed':False,'active_log_prefix_snapshot':{'path':str(SUP/'TRAINING-INCOMPLETEPREFIX-SNAPSHOT.json'),'sha256':sha(SUP/'TRAINING-INCOMPLETEPREFIX-SNAPSHOT.json')},'all_explicit_sources_two_read_sha_size_stable':True,'omissions':{'published_raw_dataset_parts_npz_recipes':'Already published at data442 plus transitive CI dependencies; no payload duplicated','baseline_input_manifest':'Same published prepared manifest SHA '+marker['prepared_manifest_sha256']+'; omitted duplicate9720377-byte body','models':'All checkpoints, exports, .pt/.bin/.inc weights and candidate publication artifacts omitted','active_state':'No live RUNNING-STATE, live training summary/result or direct live log source is declared','circular_current_repo':'Current repo FINAL_REPORT/manifest omitted; only closed source754 public HTTP verification metadata included','older_preflight':'Use actual closed04674836 global preflight, not earlier speculative/fixture preflight from archive11','ongoing_conditional_net_helper':'Excluded unfinished owner helper'},'files_identity':entries}
 curation=H/'source-checks-12-curation.json';new(curation,(json.dumps(curated,indent=2)+'\n').encode());add(curation,'checks12_curation_receipt');declaration=H/'checks-12-files.json';new(declaration,(json.dumps(entries,indent=2)+'\n').encode())
 print(json.dumps({'status':curated['status'],'declarations':str(declaration),'declarations_sha256':sha(declaration),'files':len(entries),'uncompressed_bytes_with_curation':sum(e['bytes']for e in entries),'estimated_zip_bytes':estimated+len(zlib.compress(raw(curation),6)),'curation':str(curation),'curation_sha256':sha(curation),'training_active_pid':pid,'epoch_reports':[1,2],'log_prefix_bytes':[r['prefix_bytes']for r in prefix_records]}))

if __name__=='__main__':main()
