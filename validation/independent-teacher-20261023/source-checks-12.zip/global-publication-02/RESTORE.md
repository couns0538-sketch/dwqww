This global group requires the four public CI dependency indexes in CI-DEPENDENCIES.json.
The global archive intentionally does not repeat their raw games, labels, arrays, binaries or source trees.
Use the actual 40-character immutable commits; STATUS.published_commit is not the final data-branch head.

Current loaders bind absolute Linux paths. Restore /workspace/dwqww, the global dataset at
/workspace/forge-independent-teacher-20261023/dataset-02 and the original recovery tree at
/workspace/forge-independent-teacher-20261023/ci-recovery-r1-01 exactly. Keep all source-map bytes,
both manifest roles, all recipes and all twelve selection streams unchanged. A different extraction
directory alone will not satisfy these bindings. Native Windows replay is unsupported/unproven;
use Linux, WSL or a Linux container exposing these canonical paths and executable Linux probes.

On a fresh isolated Linux environment, download this group's exact RECOVERY-MANIFEST and all parts,
verify the externally pinned manifest SHA with recover.py verify, then restore to a fresh staging
directory to obtain these instructions and support scripts. Do not overwrite an existing corpus.
Run global_dataset_publication.py restore-dependencies with this CI-DEPENDENCIES.json, its staged
helper directory, and an independently obtained exact-SHA external Stockfish binary. The wrapper
keeps private recovery e7d bytes unchanged and uses immutable raw/<commit>/ URLs, authenticating
all STATUS, archive and part SHA values. Its recovery root must be fresh or owned by the same pins.
Stockfish payload is not distributed here; its exact hash/path recipe remains an external requirement.

Then run restore-global with the public manifest, exact manifest SHA, helper directory, a fresh
owned staging path and proof output. It uses the existing no-overwrite verified restore_group
operation into /workspace. Existing files are accepted only if bytes, size and mode match; source
conflicts fail closed. First recreate/authenticate the frozen canonical tools tree, not a different
runtime checkout. The routine's /workspace/.ci-recovery registry is only a restoration proof.

Before any model, optimizer or loss evaluation: verify every global sources[] binding, array and
recipe hash, freeze-to-manifest identities, all four complete original CI source trees, executable
native probes and the >=5M qualification. Run the frozen loaders and original held-out native
HCE-only provenance replay for both prepared roles without neural models or loss scoring. Preserve
the actual commands/exits/proofs and publish independent public byte readback. Only then execute
the separately preregistered downstream commands. Byte restoration alone is not replay or training
authorization. Do not regenerate the global merge as a substitute for restoring its original bytes.
