#!/usr/bin/env python3
"""Stream every isolated dataset publication artifact from its immutable GitHub commit."""
import argparse,concurrent.futures,hashlib,json,re,time,urllib.request,urllib.parse
from pathlib import Path
from datetime import datetime,timezone
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--result',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
r=json.loads(a.result.read_bytes());assert re.fullmatch('[0-9a-f]{40}',r['commit']);a.out.mkdir(parents=True,exist_ok=False)
publication=a.result.parent/'PUBLICATION-MANIFEST.json'
rows=r['artifacts']+[{'path':r['publication_path'],'sha256':r['publication_manifest_sha256'],'bytes':publication.stat().st_size}]
def fetch(row):
 start=time.monotonic();d=hashlib.sha256();n=0
 assert row['path'].startswith('datasets/independent-teacher-20261023/') and '..' not in Path(row['path']).parts
 url='https://raw.githubusercontent.com/couns0538-sketch/dwqww/'+r['commit']+'/'+urllib.parse.quote(row['path'],safe='/')
 with urllib.request.urlopen(url,timeout=90) as stream:
  code=stream.status
  for b in iter(lambda:stream.read(1<<20),b''):d.update(b);n+=len(b)
 result={**row,'url':url,'http_status':code,'actual_bytes':n,'actual_sha256':d.hexdigest(),'elapsed_seconds':time.monotonic()-start}
 if code!=200 or n!=row['bytes'] or d.hexdigest()!=row['sha256']:raise ValueError(result)
 return result
checks=[];errors=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 futures={pool.submit(fetch,row):row['path'] for row in rows}
 for future in concurrent.futures.as_completed(futures):
  try:
   row=future.result();checks.append(row);print('VERIFIED',row['path'],row['actual_bytes'],flush=True)
  except Exception as error:errors.append({'path':futures[future],'error':repr(error)})
  (a.out/'checks.json').write_text(json.dumps({'checks':checks,'errors':errors},indent=2)+'\n')
result={'status':'PASS_ALL_PUBLIC_DATASET_ARTIFACTS_BYTE_HASH_SIZE_VERIFIED' if not errors and len(checks)==len(rows) else 'FAILED_PUBLIC_READBACK_OR_HASH_CHECK','commit':r['commit'],'branch':r['branch'],'utc':datetime.now(timezone.utc).isoformat(),'input_result_sha256':hashlib.sha256(a.result.read_bytes()).hexdigest(),'checks':sorted(checks,key=lambda x:x['path']),'errors':errors,'files':len(checks),'total_bytes':sum(x['bytes'] for x in checks),'source_originals_preserved':True}
(a.out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(result['status'],result['files'],result['total_bytes'],flush=True)
raise SystemExit(bool(errors) or len(checks)!=len(rows))
