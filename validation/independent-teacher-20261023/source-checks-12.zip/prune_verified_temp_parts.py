#!/usr/bin/env python3
"""Prune only explicitly selected, publicly verified temporary archive copies."""
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,os,re,stat,subprocess,sys,time
from datetime import datetime,timezone
H=Path('/workspace/forge-independent-teacher-20261023')
ROOT=Path('/workspace/dwqww')

def sha(path):
 d=hashlib.sha256();fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|getattr(os,'O_NOATIME',0))
 with os.fdopen(fd,'rb')as f:
  for block in iter(lambda:f.read(1<<20),b''):d.update(block)
 return d.hexdigest()

def metadata(path):
 s=path.lstat()
 if not stat.S_ISREG(s.st_mode):raise ValueError('Require regular non-symlink staging part: '+str(path))
 return {'dev':s.st_dev,'ino':s.st_ino,'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'bytes':s.st_size,'blocks':s.st_blocks,'nlink':s.st_nlink,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns}

def write_new(path,value):
 with path.open('x')as f:
  json.dump(value,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())

def local_git_blob(commit,path):
 env=dict(os.environ,GIT_OPTIONAL_LOCKS='0',GIT_NO_LAZY_FETCH='1')
 reader=subprocess.Popen(['git','cat-file','blob',commit+':'+path],cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 d=hashlib.sha256();n=0
 try:
  for block in iter(lambda:reader.stdout.read(1<<20),b''):d.update(block);n+=len(block)
  reader.stdout.close();error=reader.stderr.read();reader.stderr.close();code=reader.wait()
  if code:raise ValueError('Local Git blob read failed: '+error[:1000].decode(errors='replace'))
 finally:
  if reader.poll()is None:reader.kill();reader.wait()
 return n,d.hexdigest()

def main(argv=None):
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--group',action='append',required=True,help='Explicit publication group, e.g. global02; repeat for several groups')
 parser.add_argument('--receipt',type=Path,required=True,help='Fresh JSON receipt below the evidence root; never overwritten')
 parser.add_argument('--expected-parts',type=int,help='Fail closed unless exactly this many part copies are verified')
 parser.add_argument('--expected-commit',help='Require this exact full commit SHA in each public readback receipt')
 args=parser.parse_args(argv);started=time.monotonic()
 if len(set(args.group))!=len(args.group)or any(re.fullmatch('[A-Za-z0-9][A-Za-z0-9_-]*',g)is None for g in args.group):parser.error('Require unique simple explicit group names')
 if args.expected_parts is not None and args.expected_parts<1:parser.error('Positive --expected-parts required')
 if args.expected_commit is not None and re.fullmatch('[0-9a-f]{40}',args.expected_commit)is None:parser.error('Require a full lowercase commit SHA')
 receipt_path=args.receipt.resolve();preflight=receipt_path.with_name(receipt_path.stem+'-PREFLIGHT.json')
 if not receipt_path.is_relative_to(H)or not receipt_path.parent.is_dir():parser.error('Receipt must have an existing parent below '+str(H))
 if receipt_path.exists()or preflight.exists():parser.error('Refuse to overwrite any prior receipt or preflight')
 rows=[];proofs=[];stages={};seen=set()
 for group in args.group:
  proof=H/('dataset-'+group+'-public-readback/RESULT.json');data=json.loads(proof.read_text());proof_sha=sha(proof)
  if data['status']!='PASS_ALL_PUBLIC_DATASET_ARTIFACTS_BYTE_HASH_SIZE_VERIFIED':raise ValueError('Public receipt is not PASS')
  commit=data['commit']
  if re.fullmatch('[0-9a-f]{40}',commit)is None or(args.expected_commit is not None and commit!=args.expected_commit):raise ValueError('Public commit identity differs')
  stage=H/('dataset-publication-'+group)
  if stage.is_symlink()or not stage.is_dir()or stage.resolve()!=stage:raise ValueError('Require canonical non-symlink staging directory')
  stages[str(stage)]={'before_names':sorted(p.name for p in stage.iterdir()),'retained_files':{p.name:sha(p)for p in stage.iterdir()if p.is_file()and not p.is_symlink()and not p.name.startswith('dataset.zip.')}}
  group_rows=0
  for row in data['checks']:
   git_path=PurePosixPath(row['path']);name=git_path.name
   if not name.startswith('dataset.zip.'):continue
   if re.fullmatch(r'dataset\.zip\.[0-9]{4}',name)is None or git_path.is_absolute()or'..'in git_path.parts:raise ValueError('Unsafe archive part path')
   expected_bytes=row.get('bytes',row.get('expected_bytes'));expected_sha=row.get('sha256',row.get('expected_sha256'))
   if type(expected_bytes)is not int or expected_bytes<1 or re.fullmatch('[0-9a-f]{64}',expected_sha or'')is None:raise ValueError('Invalid public part byte/hash binding')
   if expected_bytes!=row['actual_bytes']or expected_sha!=row['actual_sha256']or row['http_status']!=200:raise ValueError('Public part hash/size verification differs')
   p=stage/name
   if str(p)in seen:raise ValueError('Duplicate staging target')
   seen.add(str(p));before=metadata(p)
   if before['bytes']!=expected_bytes or sha(p)!=expected_sha:raise ValueError('Staging part hash/size differs: '+str(p))
   n,digest=local_git_blob(commit,str(git_path))
   if n!=expected_bytes or digest!=expected_sha or metadata(p)!=before:raise ValueError('Git/staging part bytes changed or differ: '+str(p))
   rows.append({'group':group,'path':str(p),'bytes':n,'sha256':digest,'commit':commit,'git_path':str(git_path),'public_verification_receipt_sha256':proof_sha,'before_metadata':before,'public_and_local_git_bytes_verified':True});group_rows+=1
  if group_rows==0:raise ValueError('Explicit group has no verified archive parts')
  proofs.append({'path':str(proof),'sha256':proof_sha,'commit':commit,'parts':group_rows})
 if args.expected_parts is not None and len(rows)!=args.expected_parts:raise ValueError('Verified part count differs from explicit expectation')
 for proof in proofs:
  if sha(proof['path'])!=proof['sha256']:raise ValueError('Public receipt changed during verification')
 receipt={'status':'VERIFIED_TEMPORARY_ARCHIVE_PART_CACHES_ONLY','utc':datetime.now(timezone.utc).isoformat(),'argv':sys.argv,'groups':args.group,'helper_source_sha256':sha(Path(__file__)),'all_source_inputs_and_git_objects_retained':True,'git_access':'Read-only git cat-file blob streams; optional locks and lazy fetch disabled; no Git mutation','public_and_local_git_bytes_verified':True,'public_receipts':proofs,'parts':rows,'staging_inventory':stages,'free_bytes_before':os.statvfs(H).f_bavail*os.statvfs(H).f_frsize}
 write_new(preflight,receipt);removed=[];errors=[]
 try:
  for row in rows:
   p=Path(row['path'])
   if metadata(p)!=row['before_metadata']or sha(p)!=row['sha256']:raise ValueError('Staging part changed before removal: '+str(p))
   p.unlink();removed.append(row)
 except Exception as e:errors.append(str(e))
 for stage,record in stages.items():
  path=Path(stage);record['after_names']=sorted(p.name for p in path.iterdir());expected=set(record['before_names'])-{Path(row['path']).name for row in removed if str(Path(row['path']).parent)==stage}
  if set(record['after_names'])!=expected:errors.append('Unexpected staging inventory change: '+stage)
  for name,digest in record['retained_files'].items():
   if sha(path/name)!=digest:errors.append('Retained staging metadata changed: '+str(path/name))
 receipt.update(status='PASS_ONLY_VERIFIED_REDUNDANT_TEMP_PART_COPIES_REMOVED'if not errors and len(removed)==len(rows)else'PARTIAL_OR_FAILED_TEMP_PART_PRUNE',free_bytes_after=os.statvfs(H).f_bavail*os.statvfs(H).f_frsize,logical_bytes_removed=sum(x['bytes']for x in removed),allocated_blocks_of_unlinked_single_link_files=sum(x['before_metadata']['blocks']*512 for x in removed if x['before_metadata']['nlink']==1),removed_parts=len(removed),preflight_path=str(preflight),preflight_sha256=sha(preflight),elapsed_seconds=time.monotonic()-started,errors=errors)
 receipt['filesystem_available_delta_bytes']=receipt['free_bytes_after']-receipt['free_bytes_before'];receipt['filesystem_delta_scope']='Shared filesystem with concurrent baseline/native validation and other work. Logical removed bytes are exact; df delta can include concurrent writes, block rounding, and new receipt files. No baseline inputs, models, original dataset/source maps/manifests/recovery proofs or Git objects were removed.'
 write_new(receipt_path,receipt)
 print(json.dumps({k:receipt[k]for k in('status','removed_parts','logical_bytes_removed','allocated_blocks_of_unlinked_single_link_files','filesystem_available_delta_bytes','free_bytes_after','elapsed_seconds','errors')}));print('receipt_sha256 '+sha(receipt_path))
 return 0 if not errors and len(removed)==len(rows)else 2

if __name__=='__main__':raise SystemExit(main())
