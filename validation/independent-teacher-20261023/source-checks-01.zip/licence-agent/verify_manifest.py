"""Check existing manifest entries relative to the NNUE tools directory."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import sys


def inspect(base, filename):
    entries, errors, seen, resolved_seen = [], [], set(), set()
    for line_number, line in enumerate((base / filename).read_text().splitlines(), 1):
        match = re.fullmatch(r"([0-9a-f]{64})  ([^\r\n]+)", line)
        if not match:
            errors.append({"line": line_number, "reason": "invalid manifest row"})
            continue
        expected, name = match.groups()
        path = PurePosixPath(name)
        target = base / name
        if (path.is_absolute() or path.as_posix() != name
                or any(part in {".", ".."} for part in path.parts)
                or "\\" in name or name in seen or target.is_symlink()
                or target.resolve() in resolved_seen
                or not target.resolve().is_relative_to(base.resolve())):
            errors.append({"line": line_number, "path": name,
                           "reason": "duplicate or ambiguous path"})
        seen.add(name)
        resolved_seen.add(target.resolve())
        actual = hashlib.sha256(target.read_bytes()).hexdigest() if target.is_file() else None
        row = {"line": line_number, "path": name, "expected": expected,
               "actual": actual, "ok": actual == expected}
        entries.append(row)
        if not row["ok"]:
            errors.append(row)
    return {"manifest": filename, "base": str(base.resolve()),
            "entries": entries, "errors": errors, "ok": not errors}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    result = {name: inspect(args.base, name) for name in
              ("SHA256SUMS.txt", "CURRENT_SHA256SUMS.txt")}
    args.out.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({name: {"entries": len(value["entries"]),
                             "errors": len(value["errors"]), "ok": value["ok"]}
                      for name, value in result.items()}))
    return 0 if all(value["ok"] for value in result.values()) else 1


if __name__ == "__main__":
    sys.exit(main())
