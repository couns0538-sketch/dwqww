#!/usr/bin/env python3
import concurrent.futures,hashlib,json,urllib.request
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path('/workspace/forge-independent-teacher-20261023/teacher-agent/ci-hosted-monitor-r1/followup-30min')
SUMMARY=json.loads((ROOT/'summary.json').read_bytes())
EXPECTED=json.loads((ROOT/'command.json').read_bytes())['expected_sources']
def digest(body):return hashlib.sha256(body).hexdigest()
def sha(path):
    d=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):d.update(b)
    return d.hexdigest()
requests=[];statuses={}
for key,s in SUMMARY['verified_shards'].items():
    body=Path(s['status_path']).read_bytes();assert digest(body)==s['status_sha256'];doc=json.loads(body);statuses[key]=doc
    assert doc['source_commit']=='5111164ae0e86ff49804cdd3a3289fcae00d8cd5' and str(doc['run_id'])=='40023070082'
    assert doc['status']=='SHARD_PREPARED_NOT_GLOBAL_QUALIFIED' and doc['training_permitted'] is False and not doc.get('error')
    assert doc['prepared_retained']>=1400000
    for name in ('build','empty-initial','generator','teacher'):assert doc['children'][name]['actual_exit']==0
    assert doc['children']['prepare']['actual_exit']==2
    for item in doc['archives']:requests.append((key,s,item))
def fetch(request):
    key,s,item=request;target=ROOT/('recovery-'+item['sha256']+'.json')
    if target.exists():body=target.read_bytes()
    else:
        url=f'https://raw.githubusercontent.com/couns0538-sketch/dwqww/{s["ref_commit"]}/{item["path"]}'
        req=urllib.request.Request(url,headers={'User-Agent':'Forge-read-only-hosted-checkpoint-review/1'})
        with urllib.request.urlopen(req,timeout=20) as source:body=source.read(8*1024*1024+1)
        assert len(body)<=8*1024*1024
        target.write_bytes(body)
    assert digest(body)==item['sha256'];doc=json.loads(body)
    assert len(doc['parts'])==item['parts']
    assert all(part['bytes']<=31*1024*1024 for part in doc['parts'])
    source_pins={}
    for member in doc['members']+doc.get('aliases',[]):
        source=member.get('source','/'+member['path'])
        assert not source.endswith('/build/bin/stockfish') and '/build/external/' not in source
        if source in EXPECTED:
            assert member['sha256']==EXPECTED[source];source_pins[source]=member['sha256']
    return key,{'path':item['path'],'sha256':item['sha256'],'metadata_file':str(target),'members':len(doc['members']),'aliases':len(doc.get('aliases',[])),'parts':len(doc['parts']),'declared_part_bytes':sum(p['bytes'] for p in doc['parts']),'source_pins':source_pins}
verified={key:[] for key in statuses}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    for key,row in pool.map(fetch,requests):verified[key].append(row)
rows=[]
for key,s in sorted(SUMMARY['verified_shards'].items(),key=lambda item:int(item[0])):
    d=statuses[key];pins={k:v for archive in verified[key] for k,v in archive['source_pins'].items()}
    assert pins==EXPECTED
    rows.append({'shard':int(key),'ref_commit':s['ref_commit'],'status':d['status'],'source_commit':d['source_commit'],'run_id':d['run_id'],'status_path':s['status_path'],'status_sha256':s['status_sha256'],'observed_utc':s['observed_utc'],'prepared_retained':d['prepared_retained'],'accepted_rows':d['accepted_rows'],'within_shard_unique':d['unique_first4_fen'],'games':d.get('games'),'training_permitted':d['training_permitted'],'children':d['children'],'recovery_manifests':verified[key],'verified_source_pins':pins,'error':d.get('error')})
events=[json.loads(line) for line in (ROOT/'events.jsonl').read_text().splitlines()]
closed=next(event for event in reversed(events) if event['kind']=='monitor_closed')
record={'schema':'forge-teacher-r1-final-shard-monitor-review-v1','utc':datetime.now(timezone.utc).isoformat(),'status':'PASS_ALL_FOUR_SHARDS_PREPARED_EXPLICITLY_NOT_GLOBAL_QUALIFIED','run_id':'40023070082','run_url':'https://github.com/couns0538-sketch/dwqww/actions/runs/40023070082','source_commit':'5111164ae0e86ff49804cdd3a3289fcae00d8cd5','monitor_actual_exit':0,'monitor_closed_utc':closed['utc'],'monitor_elapsed_seconds':closed['elapsed_seconds'],'shards':rows,'prepared_retained_sum_before_global_dedup':sum(r['prepared_retained'] for r in rows),'accepted_rows_sum':sum(r['accepted_rows'] for r in rows),'global_dedup_or_minimum5M_qualification':'NOT_PERFORMED; no global training permission or qualified dataset claim','training_permitted':False,'all_recovery_manifest_sha256_checks_passed':len(requests),'all_eight_source_sha256_pins_verified_for_each_shard':True,'external_teacher_payload_exclusion':'All declared members/aliases checked: no build/bin/stockfish or build/external payload. Metadata declaration audit only; payload bytes not downloaded by monitor.','actual_cpu_cgroup':'Not present in readable small STATUS/recovery JSON; protocol file metadata binds content hashes but no payload values read. No resource count inferred.','dataset_parts_fetched':0,'git_fetch_ref_index_or_source_changes':False,'review_scope':'Read-only ls-remote/exact-SHA raw small STATUS+recovery manifests and public HTML. Root separately restores and verifies payloads before global preparation/training.','local_control_pipeline_receipt':{'path':'/workspace/forge-independent-teacher-20261023/generation-agent/ci-empty-initial-live128/result.json','sha256':'c01ba13bc971af3a3db3b8007468d5af6886c3b874b54305a5f6287a0eb3ba4b'},'evidence_bindings':[{'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(ROOT.rglob('*')) if p.is_file() and p.name!='final-review.json']}
path=ROOT/'final-review.json';path.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'path':str(path),'sha256':sha(path),'prepared_retained_sum_before_global_dedup':record['prepared_retained_sum_before_global_dedup'],'recovery_manifests_verified':len(requests),'declared_payload_parts':sum(a['parts'] for group in verified.values() for a in group),'declared_payload_bytes_not_fetched':sum(a['declared_part_bytes'] for group in verified.values() for a in group)},indent=2))
