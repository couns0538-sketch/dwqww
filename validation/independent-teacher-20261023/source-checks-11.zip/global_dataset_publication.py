#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Declare a closed global corpus and restore its pinned public dependencies.

This helper never packages, publishes, runs an engine, or loads a model.
Existing multipart_dataset.py and private recover_ci_archives.py remain unchanged.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import stat
import sys
import tempfile
import urllib.parse
import urllib.request

H = Path('/workspace/forge-independent-teacher-20261023')
REPO = Path('/workspace/dwqww')
RECOVERY = H / 'ci-recovery-r1-01'
PROTOCOL = REPO / 'validation/independent-teacher-20261023/protocol.json'
PROTOCOL_SHA = '245bf6dd4bcea66d0666e2443ff24602d036bffd76c7c0b5fa2a89c57f2b6b53'
COMMAND_SHA = '1a72e5c374e335c0ea8230f205a8f13001862207e1d53a4eb84f534c5edba297'
RECOVERY_SHA = 'e7d9a29603a60484cbc80f59663efa28455e1b579dd060e4281c41449e358c83'
TEST_SHA = 'b4aa4a4af46b60014c0e623e626e5a0bc7ca98890414c5ec5cc22a4479cc61e3'
MULTIPART_SHA = 'd008cc2e55b057e7144ea6e7acb45b2455c0158dcb42e332ab5be5dab1cd62ae'
SF_SHA = '0f83d24cc46d2c66c60f16001af5444873bc112b7d028594513426894c12da19'
CI_SOURCE = '5111164ae0e86ff49804cdd3a3289fcae00d8cd5'
CI_RUN = '40023070082'

def require(value, message):
    if not value:
        raise ValueError(message)

def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            digest.update(block)
    return digest.hexdigest()

def regular(path):
    path = Path(path).absolute()
    require(not any(p.is_symlink() for p in (path, *path.parents)), 'Symlink: ' + str(path))
    require(stat.S_ISREG(path.stat().st_mode), 'Not regular: ' + str(path))
    return path

def read(path):
    return json.loads(regular(path).read_bytes())

def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())

def identity(path):
    path = regular(path)
    before = path.stat()
    digest = sha(path)
    after = path.stat()
    require((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_mode)
            == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_mode),
            'File changed during hashing: ' + str(path))
    return {'path': str(path), 'sha256': digest, 'bytes': after.st_size,
            'mode': stat.S_IMODE(after.st_mode)}

def pinned_url(commit, path, repository='couns0538-sketch/dwqww'):
    require(re.fullmatch('[0-9a-f]{40}', commit), 'Actual immutable Git commit required')
    require(re.fullmatch('[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+', repository), 'Unsafe repository')
    require(not path.startswith('/') and '..' not in Path(path).parts, 'Unsafe public path')
    return 'https://raw.githubusercontent.com/' + repository + '/' + commit + '/' + urllib.parse.quote(path, safe='/')

def fetch_status(url, expected_sha):
    with urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent': 'Forge-global-publication/1'}), timeout=60) as stream:
        raw = stream.read((8 << 20) + 1)
    require(len(raw) <= 8 << 20 and hashlib.sha256(raw).hexdigest() == expected_sha,
            'Immutable public STATUS bytes differ')
    return raw

def modules(directory):
    directory = Path(directory)
    require(sha(directory / 'recover_ci_archives.py') == RECOVERY_SHA, 'Private recovery e7d bytes changed')
    require(sha(directory / 'multipart_dataset.py') == MULTIPART_SHA, 'Fixed multipart parser bytes changed')
    sys.path.insert(0, str(directory))
    spec = importlib.util.spec_from_file_location('global_pinned_recovery', directory / 'recover_ci_archives.py')
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value

def validate_final(status):
    require(status.get('status') == 'SHARD_PREPARED_NOT_GLOBAL_QUALIFIED', 'CI shard is not final')
    require(str(status.get('run_id')) == CI_RUN and status.get('source_commit') == CI_SOURCE,
            'Wrong CI attempt/source')
    children = status.get('children', {})
    expected = {'build': 0, 'empty-initial': 0, 'generator': 0, 'teacher': 0, 'prepare': 2}
    require(all(children.get(name, {}).get('actual_exit') == code for name, code in expected.items()),
            'CI parents are not closed with authentic expected exits')
    require(status.get('archives'), 'Final CI archive index is empty')

def qualified_dataset(dataset):
    require(dataset == H / 'dataset-02', 'Canonical global dataset path required')
    freeze = read(dataset / 'freeze.json')
    require(freeze.get('status') == 'QUALIFIED_FROZEN' and freeze.get('training_permitted') is True,
            'Global merge is not qualified/frozen')
    require(type(freeze.get('total')) is int and freeze['total'] >= max(5000000, freeze['minimum_positions'])
            and sum(freeze['retained'].values()) == freeze['total'], 'Global minimum/counts differ')
    require(freeze['protocol_sha256'] == PROTOCOL_SHA, 'Global protocol differs')
    manifests = []
    for role, key, dataset_role in [('prepared', 'prepared_manifest_sha256', 'training_and_selection'),
                                    ('audit-prepared', 'audit_manifest_sha256', 'final_audit_only')]:
        path = dataset / role / 'manifest.json'
        require(sha(path) == freeze[key], 'Global frozen manifest differs')
        manifest = read(path)
        require(manifest.get('status') == 'QUALIFIED_FROZEN' and manifest.get('training_permitted') is True
                and manifest.get('provenance_layout') == 'multi_shard_v1'
                and manifest['dataset_role'] == dataset_role and manifest['protocol_sha256'] == PROTOCOL_SHA
                and manifest['retained_total_positions'] == freeze['total'], 'Global role/count/protocol differs')
        require([s['id'] for s in manifest['merge']['shards']] == list(range(4)), 'All four CI shards required')
        for name, record in {**manifest['files'], **manifest['artifacts']}.items():
            require(sha(dataset / role / name) == record['sha256'], 'Global array/recipe bytes differ: ' + name)
        manifests.append(manifest)
    return freeze, manifests

def seal(args):
    dataset = Path(args.dataset).absolute()
    # Every gate precedes creating an output or declaring any corpus bytes closed.
    require(re.fullmatch('[0-9a-f]{40}', args.source_commit), 'Actual source commit required')
    require(sha(PROTOCOL) == PROTOCOL_SHA and read(PROTOCOL).get('revision') == 8, 'Protocol8 changed')
    require(sha(H / 'downstream_commands.json') == COMMAND_SHA, 'Preregistered downstream commands changed')
    require(sha(H / 'recover_ci_archives.py') == RECOVERY_SHA and sha(H / 'test_recover_ci_archives.py') == TEST_SHA,
            'Private recovery source/tests changed')
    require(sha(H / 'multipart_dataset.py') == MULTIPART_SHA, 'Fixed multipart parser changed')
    merge_result = read(args.merge_result)
    require(merge_result.get('actual_exit') == 0, 'An actual closed merge exit0 receipt is required')
    merge_argv = merge_result.get('argv', [])
    require(str(REPO / 'tools/nnue/merge_teacher_prepared.py') in merge_argv
            and '--out' in merge_argv and merge_argv[merge_argv.index('--out') + 1] == str(dataset),
            'Actual merge receipt does not bind the canonical output command')
    recovery_result_path = H / 'trainer-agent/r1-recovery-final.json'
    recovery_result = read(recovery_result_path)
    require(recovery_result.get('actual_watch_exit') == 0 and recovery_result.get('total_groups') == 48
            and recovery_result.get('maps_are_frozen_after_watch_exit') is True,
            'All four recovery inputs must have a closed authenticated receipt')
    heads_proof = recovery_result['actual_final_heads_proof']
    require(sha(heads_proof['path']) == heads_proof['sha256'], 'Actual immutable final-head proof changed')
    freeze, manifests = qualified_dataset(dataset)
    require(not (dataset / '.memmaps').exists(), 'Active merge scratch still exists')
    finals = {}
    for item in args.ci_final:
        number, value = item.split('=', 1)
        commit, status_path = value.split(',', 1)
        number = int(number)
        require(number in range(4) and number not in finals, 'Distinct four CI final identities required')
        record = identity(status_path)
        status = read(status_path)
        validate_final(status)
        require(status['shard'] == number, 'Final shard ID differs')
        recovered = [row for row in recovery_result['rows'] if row['shard'] == number]
        require(len(recovered) == 1 and recovered[0]['actual_data_head_sha'] == commit
                and recovered[0]['status_sha256'] == record['sha256'],
                'Immutable final identities differ from actual closed recovery')
        fetch_status(pinned_url(commit, 'STATUS.json'), record['sha256'])
        archives = []
        for entry in status['archives']:
            relative = entry['path']
            require(re.fullmatch(r'archive-\d+/RECOVERY-MANIFEST.json', relative), 'Unsafe archive path')
            local = RECOVERY / '.ci-recovery' / f'shard-{number}' / 'cache' / relative
            require(sha(local) == entry['sha256'], 'Recovered archive manifest differs')
            archive = read(local)
            archives.append({'path': relative, 'sha256': entry['sha256'], 'url': pinned_url(commit, relative),
                             'archive': archive['archive'], 'parts': archive['parts'],
                             'members': len(archive['members']), 'aliases': len(archive.get('aliases', []))})
        branch = f'data/independent-teacher-ci-{CI_RUN}-1-shard-{number}'
        require(status.get('publication_branch') == branch, 'Final publication branch differs')
        finals[number] = {'shard': number, 'branch': branch, 'immutable_commit': commit, 'status': record,
                          'status_url': pinned_url(commit, 'STATUS.json'), 'archives': archives}
    require(set(finals) == set(range(4)), 'All four actual immutable final refs required')
    # Authenticate direct transitive bindings without loading arrays into a model.
    bindings = {}
    for manifest in manifests:
        for record in manifest['sources']:
            require(Path(record['path']).is_absolute(), 'Unexpected relative merged source binding')
            prior = bindings.setdefault(record['path'], record['sha256'])
            require(prior == record['sha256'], 'Conflicting merged source binding')
    for name, digest in bindings.items():
        require(sha(name) == digest, 'Canonical transitive source differs: ' + name)
    sources = {}
    for name, digest in read(PROTOCOL)['producer_source_sha256'].items():
        require(sha(REPO / name) == digest, 'Frozen producer source changed: ' + name)
        sources[name] = identity(REPO / name)
    downstream = read(H / 'trainer-agent/DOWNSTREAM-PREFLIGHT-08.json')
    for name, digest in downstream['downstream_sources'].items():
        require(sha(REPO / name) == digest, 'Reviewed downstream source changed')
        sources[name] = identity(REPO / name)
    output = Path(args.out).absolute()
    require(not output.exists(), 'Never overwrite an earlier publication recipe')
    output.mkdir(parents=True)
    for number, final in finals.items():
        source = Path(final['status']['path'])
        destination = output / 'ci-final' / f'shard-{number}' / 'STATUS.json'
        destination.parent.mkdir(parents=True)
        destination.write_bytes(source.read_bytes())
        final['status']['published_copy'] = str(destination)
    dependencies = {'schema': 'forge-global-public-ci-dependencies-v1', 'repository': 'couns0538-sketch/dwqww',
        'source_commit': CI_SOURCE, 'run_id': CI_RUN, 'canonical_workspace': '/workspace',
        'canonical_repository': str(REPO), 'canonical_global_dataset': str(dataset),
        'canonical_ci_recovery': str(RECOVERY), 'private_recovery_sha256': RECOVERY_SHA,
        'external_stockfish_sha256': SF_SHA,
        'dependency_policy': 'All original CI inputs are transitive public dependencies, not repeated in this global group. Restore all indexed archive members and hydrate the external teacher before source proof/training.',
        'source_maps': [identity(RECOVERY / '.ci-recovery' / f'shard-{n}' / 'source-map.json') for n in range(4)],
        'shards': [finals[n] for n in range(4)]}
    write(output / 'CI-DEPENDENCIES.json', dependencies)
    write(output / 'SOURCE-IDENTITIES.json', sources)
    write(output / 'QUALIFICATION.json', {'schema': 'forge-global-dataset-publication-qualification-v1',
        'status': 'QUALIFIED_FROZEN_GLOBAL_DATASET_TRANSITIVE_CI_DEPENDENCIES_REQUIRED',
        'training_permitted_by_publication_alone': False, 'global_freeze': freeze,
        'protocol_sha256': PROTOCOL_SHA, 'downstream_commands_sha256': COMMAND_SHA,
        'source_commit': args.source_commit, 'merge_result': identity(args.merge_result),
        'closed_recovery_result': identity(recovery_result_path),
        'ci_dependencies_sha256': sha(output / 'CI-DEPENDENCIES.json'),
        'before_training': 'Publish and independently read back this group plus all four pinned CI indexes; restore canonical paths; verify all bindings and replay original held-out native provenance without model/optimizer/loss scoring.'})
    (output / 'RESTORE.md').write_text(RESTORE_TEXT)
    payload = set(p for p in dataset.rglob('*') if p.is_file())
    payload.update([PROTOCOL, H / 'downstream_commands.json', H / 'recover_ci_archives.py',
                    H / 'test_recover_ci_archives.py', H / 'multipart_dataset.py',
                    Path(__file__).absolute(), Path(args.merge_result).absolute(),
                    recovery_result_path, Path(heads_proof['path'])])
    for name in ['command.json', 'stdout', 'stderr']:
        path = Path(args.merge_result).parent / name
        require(path.is_file(), 'Closed raw merge command/log missing: ' + name)
        payload.add(path.absolute())
    require(sha(merge_result['spec_path']) == merge_result['spec_sha256'], 'Executed merge command spec changed')
    payload.add(Path(merge_result['spec_path']))
    payload.update(REPO / name for name in sources)
    for name in bindings:
        p = Path(name)
        if not p.is_relative_to(RECOVERY) or p.name == 'source-map.json':
            payload.add(p)
    payload.update(p for p in output.rglob('*') if p.is_file())
    files = []; aliases = []; seen = {}; frozen = []
    for path in sorted(payload):
        record = identity(path)
        require(record['sha256'] != SF_SHA and 'stockfish' not in path.name.lower()
                and path.suffix.lower() not in ['.tar', '.tgz', '.xz'], 'External payload forbidden')
        member = str(path.relative_to('/workspace'))
        row = {'source': str(path), 'member': member, 'sha256': record['sha256'], 'bytes': record['bytes']}
        key = (record['sha256'], record['bytes'], record['mode'])
        if key in seen:
            aliases.append({'source': str(path), 'member': member, 'target': seen[key]})
        else:
            seen[key] = member; files.append(row)
        frozen.append(record)
    declaration = {'status': 'CLOSED_INPUTS_FROZEN', 'files': files, 'aliases': aliases,
        'canonical_restore_root': '/workspace', 'transitive_dependencies': str(output / 'CI-DEPENDENCIES.json')}
    write(output / 'CLOSED-GLOBAL-INPUTS.json', declaration)
    for record in frozen:
        require(sha(record['path']) == record['sha256'], 'Source changed before declaration commit')
    print(json.dumps({'status': 'CLOSED_DECLARATIONS_READY_NOT_PACKAGED_OR_PUBLISHED',
        'declaration': str(output / 'CLOSED-GLOBAL-INPUTS.json'),
        'sha256': sha(output / 'CLOSED-GLOBAL-INPUTS.json'), 'members': len(files), 'aliases': len(aliases),
        'unique_payload_bytes': sum(x['bytes'] for x in files), 'retained': freeze['total']}))

def restore_dependencies(args):
    dependencies = read(args.dependencies)
    require(dependencies['canonical_ci_recovery'] == str(RECOVERY), 'Canonical recovery path differs')
    recovery = modules(args.helper_directory)
    originals = recovery.download
    pins = {entry['status_url']: entry['status']['sha256'] for entry in dependencies['shards']}
    def pinned_download(url, target, expected_sha=None, **kwargs):
        if url in pins:
            require(expected_sha in (None, pins[url]), 'Conflicting STATUS pin')
            expected_sha = pins[url]
        return originals(url, target, expected_sha=expected_sha, **kwargs)
    recovery.download = pinned_download
    commits = {entry['branch']: entry['immutable_commit'] for entry in dependencies['shards']}
    class PinnedRecovery(recovery.Recovery):
        def url(self, branch, path):
            require(branch in commits, 'Unpinned recovery branch identity')
            return pinned_url(commits[branch], path, dependencies['repository'])
    # Keep original state branch labels; only the download URL uses immutable commits.
    shards = {entry['shard']: entry['branch'] for entry in dependencies['shards']}
    require(set(shards) == set(range(4)), 'Four pinned source shards required')
    worker = PinnedRecovery(RECOVERY, dependencies['repository'], shards, args.external_stockfish)
    require(worker.poll(), 'Pinned four-shard recovery incomplete')
    for record in dependencies['source_maps']:
        require(sha(record['path']) == record['sha256'], 'Canonical source-map bytes changed after restoration')
    print(json.dumps({'status': 'PINNED_PUBLIC_DEPENDENCIES_RECOVERED_NOT_TRAINING_AUTHORIZATION',
                      'recovery_root': str(RECOVERY), 'groups': len(worker.state['groups'])}))

def restore_global(args):
    recovery = modules(args.helper_directory)
    manifest = read(args.manifest)
    require(all(not x['path'].startswith('workspace/') for x in manifest['members'] + manifest.get('aliases', [])),
            'Global members must be relative to canonical /workspace')
    # Reuse the established collision-checked/no-overwrite merge operation.
    stage = Path(args.staging)
    require(not stage.exists(), 'Fresh exclusively owned staging path required')
    proof = recovery.restore_group(Path(args.manifest), args.sha256, Path('/workspace'), stage)
    write(args.proof, proof)
    print(json.dumps({'status': 'GLOBAL_BYTES_RESTORED_CANONICAL_NO_MODEL_OR_REPLAY', 'proof': str(args.proof)}))

RESTORE_TEXT = '''This global group requires the four public CI dependency indexes in CI-DEPENDENCIES.json.
The global archive intentionally does not repeat their raw games, labels, arrays, binaries or source trees.
Use the actual 40-character immutable commits; STATUS.published_commit is not the final data-branch head.

Current loaders bind absolute Linux paths. Restore /workspace/dwqww, the global dataset at
/workspace/forge-independent-teacher-20261023/dataset-02 and the original recovery tree at
/workspace/forge-independent-teacher-20261023/ci-recovery-r1-01 exactly. Keep all source-map bytes,
both manifest roles, all recipes and all twelve selection streams unchanged. A different extraction
directory alone will not satisfy these bindings. Native Windows replay is unsupported/unproven;
use Linux, WSL or a Linux container exposing these canonical paths and executable Linux probes.

On a fresh isolated Linux environment, download this group's exact RECOVERY-MANIFEST and all parts,
verify the externally pinned manifest SHA with recover.py verify, then restore to a fresh staging
directory to obtain these instructions and support scripts. Do not overwrite an existing corpus.
Run global_dataset_publication.py restore-dependencies with this CI-DEPENDENCIES.json, its staged
helper directory, and an independently obtained exact-SHA external Stockfish binary. The wrapper
keeps private recovery e7d bytes unchanged and uses immutable raw/<commit>/ URLs, authenticating
all STATUS, archive and part SHA values. Its recovery root must be fresh or owned by the same pins.
Stockfish payload is not distributed here; its exact hash/path recipe remains an external requirement.

Then run restore-global with the public manifest, exact manifest SHA, helper directory, a fresh
owned staging path and proof output. It uses the existing no-overwrite verified restore_group
operation into /workspace. Existing files are accepted only if bytes, size and mode match; source
conflicts fail closed. First recreate/authenticate the frozen canonical tools tree, not a different
runtime checkout. The routine's /workspace/.ci-recovery registry is only a restoration proof.

Before any model, optimizer or loss evaluation: verify every global sources[] binding, array and
recipe hash, freeze-to-manifest identities, all four complete original CI source trees, executable
native probes and the >=5M qualification. Run the frozen loaders and original held-out native
HCE-only provenance replay for both prepared roles without neural models or loss scoring. Preserve
the actual commands/exits/proofs and publish independent public byte readback. Only then execute
the separately preregistered downstream commands. Byte restoration alone is not replay or training
authorization. Do not regenerate the global merge as a substitute for restoring its original bytes.
'''

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    p = sub.add_parser('seal')
    p.add_argument('--dataset', type=Path, default=H / 'dataset-02')
    p.add_argument('--merge-result', type=Path, required=True)
    p.add_argument('--ci-final', action='append', required=True, help='N=actual_immutable_commit,closed_STATUS_path')
    p.add_argument('--source-commit', required=True)
    p.add_argument('--out', type=Path, required=True)
    p = sub.add_parser('restore-dependencies')
    p.add_argument('--dependencies', type=Path, required=True)
    p.add_argument('--helper-directory', type=Path, required=True)
    p.add_argument('--external-stockfish', type=Path, required=True)
    p = sub.add_parser('restore-global')
    p.add_argument('--manifest', type=Path, required=True)
    p.add_argument('--sha256', required=True)
    p.add_argument('--helper-directory', type=Path, required=True)
    p.add_argument('--staging', type=Path, required=True)
    p.add_argument('--proof', type=Path, required=True)
    args = parser.parse_args()
    {'seal': seal, 'restore-dependencies': restore_dependencies, 'restore-global': restore_global}[args.command](args)

if __name__ == '__main__':
    main()
