import pathlib,os,stat,hashlib,json,gzip,time,collections
start=time.monotonic();base=pathlib.Path('/workspace/.cloud-setup');h=pathlib.Path('/workspace/forge-independent-teacher-20261023');denied=('nnue-pipeline','venv','wine','toolchain','stockfish','font-cache','apt','fastchess','windows-native-deps','baseline','working','probe','reference','forge-original','forge-6.4-build','forge-6.4-source','dwqww');roots=[]
for p in base.iterdir():
 if not p.is_dir()or p.is_symlink()or any(x in p.name for x in denied):continue
 # Closed historical evidence/results/builds only, no work trees or current source trees.
 if any(x in p.name for x in('complete','evidence','result-','recovered','observation','recovery','native-release','native-asan','native-tsan','green-build','-build','-release','-asan','-tsan','audit-'))and not any(x in p.name for x in('-source','public-archive','public-7')):roots.append(p)
files=[];skips=collections.Counter();sizes=collections.defaultdict(list)
for root in sorted(roots):
 for d,dirs,names in os.walk(root,followlinks=False):
  dirs[:]=[x for x in dirs if x!='.git'and not(pathlib.Path(d)/x).is_symlink()]
  for n in names:
   p=pathlib.Path(d)/n;s=p.lstat()
   if not stat.S_ISREG(s.st_mode):skips['not_regular']+=1;continue
   if s.st_size<1_000_000:skips['under1MB']+=1;continue
   archive=any(n.endswith(x)for x in('.zip','.tar','.tar.gz','.tgz','.gz','.xz','.bz2','.zst','.7z'))or'.zip.part'in n
   if archive:skips['archive_files_excluded']+=1;continue
   sizes[s.st_size].append(p)
def meta(p):
 s=p.lstat();return{'dev':s.st_dev,'ino':s.st_ino,'size':s.st_size,'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns,'links':s.st_nlink,'blocks':s.st_blocks}
def sha(p):
 h=hashlib.sha256();fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|getattr(os,'O_NOATIME',0))
 with os.fdopen(fd,'rb')as f:
  for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
 return h.hexdigest()
def byteeq(a,b):
 with open(a,'rb')as x,open(b,'rb')as y:
  while True:
   u,v=x.read(4*1024*1024),y.read(4*1024*1024)
   if u!=v:return False
   if not u:return True
byhash=collections.defaultdict(list);inodes={};hashed=0
for size,paths in sizes.items():
 if len({(p.stat().st_dev,p.stat().st_ino)for p in paths})<2:continue
 for p in paths:
  m=meta(p);ident=(m['dev'],m['ino']);attrs={x:os.getxattr(p,x).hex()for x in os.listxattr(p)}
  digest=inodes.get(ident)
  if digest is None:digest=sha(p);inodes[ident]=digest;hashed+=1
  if meta(p)!=m:raise RuntimeError('Changed during read-only scan '+str(p))
  key=(m['size'],m['mode'],m['uid'],m['gid'],json.dumps(attrs,sort_keys=True),digest)
  byhash[key].append({'path':str(p),'metadata':m,'sha256':digest,'xattrs':attrs})
groups=[]
for key,entries in byhash.items():
 uniq=collections.defaultdict(list)
 for e in entries:uniq[(e['metadata']['dev'],e['metadata']['ino'])].append(e)
 if len(uniq)<2:continue
 representatives=[sorted(es,key=lambda z:z['path'])[0]for es in uniq.values()];representatives.sort(key=lambda z:('complete'not in z['path']and'evidence'not in z['path'],z['path']));donor=representatives[0]
 targets=[]
 for e in representatives[1:]:
  if not byteeq(donor['path'],e['path']):raise RuntimeError('SameSHA but byte mismatch')
  targets.append({'representative':e,'all_scoped_paths_of_inode':[z['path']for z in uniq[(e['metadata']['dev'],e['metadata']['ino'])]],'outside_scanned_inode_links':e['metadata']['links']-len(uniq[(e['metadata']['dev'],e['metadata']['ino'])]),'full_byte_comparison':True})
 groups.append({'source':donor,'source_existing_aliases':[z['path']for z in uniq[(donor['metadata']['dev'],donor['metadata']['ino'])]],'targets':targets,'possible_reclaimed_bytes_if_all_inode_links_in_scope':sum(z['representative']['metadata']['blocks']*512 for z in targets if z['outside_scanned_inode_links']==0)})
groups.sort(key=lambda z:z['possible_reclaimed_bytes_if_all_inode_links_in_scope'],reverse=True)
out={'status':'READ_ONLY_PROPOSAL_NOT_AUTHORIZED_TO_MUTATE','created_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'scope_roots':[str(p)for p in sorted(roots)],'excluded_name_substrings':denied,'minimum_file_bytes':1000000,'all_archives_excluded':True,'git_source_toolchain_current_runtime_paths_excluded':True,'unique_inodes_hashed':hashed,'groups':groups,'possible_reclaimed_bytes':sum(z['possible_reclaimed_bytes_if_all_inode_links_in_scope']for z in groups),'pending_before_any_action':['Root review/authorization of exact path set','Fresh full inventory/SHA/byte/xattr/mode checks and process writable-FD/cwd/exe inactivity check','Only replace all scoped aliases for a duplicate inode when nlink accounting proves allocated inode released','Preserve every original pathname/content and before/after metadata receipts; never touch compressed archives/.git/active runtime/source paths'],'skips':dict(skips),'elapsed_seconds':time.monotonic()-start}
p=h/'CACHE-DEDUP-PROPOSAL-02.json.gz'
with gzip.open(p,'xt')as f:json.dump(out,f,separators=(',',':'))
summary={'proposal_path':str(p),'proposal_sha256':sha(p),'groups':len(groups),'possible_reclaimed_bytes':out['possible_reclaimed_bytes'],'unique_inodes_hashed':hashed,'elapsed_seconds':out['elapsed_seconds'],'largest_groups':[{'bytes':g['possible_reclaimed_bytes_if_all_inode_links_in_scope'],'source':g['source']['path'],'target_inodes':len(g['targets']),'targets':[z['representative']['path']for z in g['targets']][:5]}for g in groups[:8]]}
with(h/'CACHE-DEDUP-PROPOSAL-02-SUMMARY.json').open('x')as f:json.dump(summary,f,indent=2);f.write('\n')
print(json.dumps(summary))
