#!/usr/bin/env python3
"""Read-only frozen merged-data hashes/schema and bounded source-row checks."""
from pathlib import Path
import argparse,gzip,hashlib,json,os,random,re,sys,time,traceback
import numpy as np
sys.path.insert(0,'/workspace/dwqww/tools/nnue')
from prepare_teacher_data import RECIPE_KEYS,SourceResolver,position_key,split_for_game
from residual_train import load_protocol,verify_prepared_protocol,verify_training_qualification
H=Path('/workspace/forge-independent-teacher-20261023');OUT=H/'dataset-02';START=time.monotonic();SEED=2026102317

def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
 return h.hexdigest()
def read(p):return json.loads(Path(p).read_text())
def bound(p,want):
 assert re.fullmatch('[0-9a-f]{64}',want),('invalid SHA',str(p))
 assert sha(p)==want,('SHA mismatch',str(p))
def stream(p):
 return(gzip.open(p,'rb')if str(p).endswith('.gz')else Path(p).open('rb'))
def array_read(p,count):
 with np.load(p,allow_pickle=False)as archive:
  assert set(archive.files)=={'features','hce','score','result_stm'}
  a={name:archive[name]for name in archive.files}
 for name in('hce','score'):assert a[name].dtype==np.int32 and a[name].shape==(count,)
 assert a['features'].dtype==np.int16 and a['features'].shape==(count,2,32)
 assert a['result_stm'].dtype==np.float32 and a['result_stm'].shape==(count,)
 return a

def run():
 result_path=H/'global-merge-exec-02/result.json'
 if not result_path.is_file():raise RuntimeError('WAIT_FOR_ACTUAL_CLOSED_RESULT: no result receipt; no output manifests read')
 process=read(result_path);exitcode=process.get('actual_exit',process.get('returncode'))
 if exitcode not in(0,2):raise RuntimeError('Merge is not closed successfully/incompletely: '+str(exitcode))
 pre=read(H/'preparer-agent/global-merge-protocol8-preflight.json');admiss=read(H/'preparer-agent/global-merge-protocol8-all4-admissibility.json')
 protocol_path=Path(pre['global_protocol']['path']);bound(protocol_path,pre['global_protocol']['sha256']);protocol=read(protocol_path);assert protocol['revision']==8
 _,protocol_binding=load_protocol(protocol_path,.4,epochs=8,include_initial=False)
 freeze=read(OUT/'freeze.json');normal=read(OUT/'prepared/manifest.json');audit=read(OUT/'audit-prepared/manifest.json');plan=read(OUT/'merge-plan.json')
 bound(OUT/'prepared/manifest.json',freeze['prepared_manifest_sha256']);bound(OUT/'audit-prepared/manifest.json',freeze['audit_manifest_sha256'])
 for m,role in((normal,'training_and_selection'),(audit,'final_audit_only')):
  assert m['schema_version']==1 and m['hidden_size']==128 and m['provenance_format']=='independent_teacher_v1'and m['provenance_layout']=='multi_shard_v1'
  assert m['score_pov']==m['result_pov']=='side_to_move'and m['dataset_role']==role
  verify_prepared_protocol(m,protocol_binding);assert m['target']==protocol['target']and m['teacher']==protocol['teacher']
  assert m['split']['seed']==protocol['dataset']['whole_game_split_seed']and m['split']['legacy_training_game_ids_unknown']is False
  assert m['merge']['native_arrays_recomputed']is False and m['audit_isolation']['frozen_before_training']is True and m['audit_isolation']['audit_used_for_optimization_or_epoch_selection']is False
 assert normal['sources']==audit['sources']and normal['merge']==audit['merge']and normal['statistics']==audit['statistics']
 assert normal['files']['train.npz']==audit['files']['train.npz'];st0=(OUT/'prepared/train.npz').stat();st1=(OUT/'audit-prepared/train.npz').stat();assert(st0.st_dev,st0.st_ino)==(st1.st_dev,st1.st_ino)
 assert plan['protocol_sha256']==freeze['protocol_sha256']==protocol_binding['sha256']
 assert plan['shards']==normal['merge']['shards']and normal['split']['heldout_partition']=='validation'and audit['split']['heldout_partition']=='audit'
 sources={};originals={};expected={p:[]for p in('train','validation','audit')};original_counts={p:0 for p in expected};sample_original_arrays={}
 assert[s['id']for s in plan['shards']]==[0,1,2,3]
 for s in plan['shards']:
  n=s['id'];assert s['generation_seed']==protocol['dataset']['generation_seed']+n
  prior=next(z for z in admiss['shards']if z['id']==n);assert s['manifests']==prior['manifest_bindings']
  for p,role in(('validation','prepared'),('audit','audit-prepared')):
   entry=s['manifests'][p];bound(entry['path'],entry['sha256']);originals[(n,p)]=read(entry['path'])
  a,b=originals[(n,'validation')],originals[(n,'audit')];assert a['generation_configuration']['seed']==s['generation_seed'];assert a['target']==normal['target']
  for p,games in(('train',a['split']['train_game_ids']),('validation',a['split']['validation_game_ids']),('audit',b['split']['validation_game_ids'])):
   for gid in games:assert split_for_game(gid,protocol['dataset']['whole_game_split_seed'],.05,.05)==p
   expected[p]+=games
  for p,num in prior['counts'].items():original_counts[p]+=num
  source_map_path=next(z['source_map']for z in pre['shards']if z['id']==n);map_expected=next(z['source_map_sha256']for z in pre['shards']if z['id']==n);bound(source_map_path,map_expected);assert read(source_map_path)==s['source_mappings']
  sources[n]={'record':s,'resolver':SourceResolver(s['source_mappings'])}
 sets={p:set(ids)for p,ids in expected.items()};assert all(len(v)==len(expected[p])for p,v in sets.items());assert not(sets['train']&sets['validation']or sets['train']&sets['audit']or sets['validation']&sets['audit'])
 assert normal['split']['train_game_ids']==audit['split']['train_game_ids']==expected['train'];assert normal['split']['validation_game_ids']==expected['validation'];assert audit['split']['validation_game_ids']==expected['audit'];assert normal['audit_isolation']['audit_game_ids']==audit['audit_isolation']['audit_game_ids']==expected['audit']
 for e in normal['sources']:bound(e['path'],e['sha256'])
 artifact_records={};partspec={'train':(OUT/'prepared','train.npz','train-provenance.jsonl.gz',normal),'validation':(OUT/'prepared','validation.npz','validation-provenance.jsonl',normal),'audit':(OUT/'audit-prepared','validation.npz','validation-provenance.jsonl',audit)}
 spots=[];counts={};recipe_counts={};observed_shards={}
 tail=re.compile(rb',"shard_id":([0-9]+),"source_row":([0-9]+)}\n$')
 for partition,(directory,npz,recipe,manifest)in partspec.items():
  rec=manifest['files'][npz];count=rec['rows'];counts[partition]=count;bound(directory/npz,rec['sha256']);bound(directory/recipe,manifest['artifacts'][recipe]['sha256']);assert manifest['artifacts'][recipe]['rows']==count
  arrays=array_read(directory/npz,count)
  assert(np.abs(arrays['score'].astype(np.int64))<=manifest['filters']['max_abs_score']).all();assert np.isin(arrays['result_stm'],[0,.5,1]).all()
  selected={};first={};last={};rng=random.Random(SEED+('train','validation','audit').index(partition));indices={0,count//2,count-1,*[rng.randrange(count)for _ in range(12)]};linecount=0
  with stream(directory/recipe)as f:
   for i,line in enumerate(f):
    match=tail.search(line[-128:]);assert match is not None and line.endswith(b'\n');n=int(match[1]);assert n in sources
    if n not in first:first[n]=(i,line)
    last[n]=(i,line)
    if i in indices:selected[i]=line
    linecount+=1
  assert linecount==count;recipe_counts[partition]=linecount;observed_shards[partition]=sorted(first)
  for i,line in list(first.values())+list(last.values()):selected[i]=line
  for i,line in sorted(selected.items()):
   row=json.loads(line);assert set(row)==RECIPE_KEYS|{'shard_id','source_row'};assert row['game_id']in sets[partition]
   spot={'partition':partition,'merged_array_row':i,'shard_id':row['shard_id'],'original_array_row':row['source_row'],'recipe':row,'features':arrays['features'][i].copy(),'hce':int(arrays['hce'][i]),'score':int(arrays['score'][i]),'result_stm':float(arrays['result_stm'][i])};spots.append(spot)
  artifact_records[partition]={'path':str(directory/npz),'sha256':rec['sha256'],'rows':count,'arrays':{k:{'dtype':str(v.dtype),'shape':list(v.shape)}for k,v in arrays.items()},'recipe_path':str(directory/recipe),'recipe_sha256':manifest['artifacts'][recipe]['sha256'],'recipe_rows_counted':linecount};del arrays
 # Compare only the deterministic bounded samples to original arrays and original recipes.
 for n in range(4):
  for partition in partspec:
   wanted=[s for s in spots if s['shard_id']==n and s['partition']==partition]
   if not wanted:continue
   role='audit'if partition=='audit'else'validation';original=originals[(n,role)];directory=Path(sources[n]['record']['manifests'][role]['path']).parent;npz='train.npz'if partition=='train'else'validation.npz';recipe='train-provenance.jsonl.gz'if partition=='train'else'validation-provenance.jsonl';rec=original['files'][npz];bound(directory/npz,rec['sha256']);bound(directory/recipe,original['artifacts'][recipe]['sha256']);arrays=array_read(directory/npz,rec['rows']);wanted_by_row={s['original_array_row']:s for s in wanted};found=set()
   with stream(directory/recipe)as f:
    for i,line in enumerate(f):
     if i not in wanted_by_row:continue
     spot=wanted_by_row[i];row=json.loads(line);assert row=={k:spot['recipe'][k]for k in RECIPE_KEYS};assert np.array_equal(arrays['features'][i],spot['features'])
     for key in('hce','score','result_stm'):assert arrays[key][i]==spot[key]
     spot['original_native_array_and_recipe_exact_match']=True;spot['original_array_path']=str(directory/npz);spot['original_recipe_path']=str(directory/recipe);found.add(i)
     if len(found)==len(wanted_by_row):break
   assert found==set(wanted_by_row);del arrays
 # Bounded raw teacher row identity/score/outcome readback, without native/model recomputation.
 raw_requests={}
 for spot in spots:
  row=spot['recipe'];p=sources[spot['shard_id']]['resolver'](row['source_path']);raw_requests.setdefault(p,{}).setdefault(row['source_line'],[]).append(spot)
 actual_raw_lines=actual_raw_decoded=0
 for p,lines in raw_requests.items():
  found=set()
  with gzip.open(p,'rt')as f:
   for line_number,line in enumerate(f,1):
    actual_raw_lines+=1
    if line_number not in lines:continue
    game=json.loads(line);actual_raw_decoded+=1
    for spot in lines[line_number]:
     row=spot['recipe'];sample=game['samples'][row['sample_index']];assert game['game_id']==row['game_id']and sample['game_id']==row['game_id']and sample['fen']==row['fen']and sample['ply']==row['ply'];assert sample['source_sample_index']==row['source_sample_index'];assert sample['teacher_cp_stm']==sample['score_cp_stm']==spot['score'];assert sample['teacher_depth']==protocol['teacher']['depth']and sample['teacher_kind']=='cp';allowed_engines={e['sha256']for e in originals[(spot['shard_id'],'validation')]['generation_configuration']['engines']};assert game['engine_white_sha256']in allowed_engines and game['engine_black_sha256']in allowed_engines;assert sample['engine_sha256']==game['engine_white_sha256'if row['fen'].split()[1]=='w'else'engine_black_sha256'];rw=game['result_white'];assert(rw if row['fen'].split()[1]=='w'else 1-rw)==spot['result_stm'];spot['raw_teacher_row_exact_match']=True;spot['actual_game_engine_white_sha256']=game['engine_white_sha256'];spot['actual_game_engine_black_sha256']=game['engine_black_sha256']
    found.add(line_number)
    if found==set(lines):break
  assert found==set(lines)
 assert freeze['retained']==counts and freeze['total']==sum(counts.values());assert normal['statistics']['original_rows']==original_counts and normal['statistics']['retained_by_split']==counts
 for p in counts:assert normal['statistics']['excluded_by_split'][p]==original_counts[p]-counts[p]>=0
 assert freeze['minimum_positions']==normal['minimum_positions']==audit['minimum_positions']>=5000000;assert normal['retained_total_positions']==audit['retained_total_positions']==freeze['total'];qualified=freeze['total']>=freeze['minimum_positions'];assert freeze['training_permitted']==normal['training_permitted']==audit['training_permitted']==qualified;assert exitcode==(0 if qualified else 2)
 expectedstatus='QUALIFIED_FROZEN'if qualified else'INCOMPLETE_BELOW_MINIMUM_DO_NOT_TRAIN_OR_PROMOTE';assert freeze['status']==normal['status']==audit['status']==expectedstatus
 guard={}
 for label,m in(('training',normal),('audit',audit)):
  try:verify_training_qualification(m);guard[label]='ALLOWED'
  except ValueError as e:guard[label]='REJECTED: '+str(e)
 assert(guard['training']=='ALLOWED')==qualified and guard['audit'].startswith('REJECTED:')
 for spot in spots:spot['features_sha256']=hashlib.sha256(spot.pop('features').tobytes()).hexdigest();spot['position_key']=position_key(spot['recipe']['fen'])
 assert sha(OUT/'prepared/manifest.json')==freeze['prepared_manifest_sha256']and sha(OUT/'audit-prepared/manifest.json')==freeze['audit_manifest_sha256']
 return {'status':'PASS_QUALIFIED_FROZEN_SCHEMA_HASH_AND_BOUNDED_COPY_SPOTCHECKS'if qualified else'PASS_INCOMPLETE_FROZEN_OPTIMIZER_BLOCKED','actual_closed_process_result':process,'actual_result_sha256':sha(result_path),'freeze':freeze,'freeze_sha256':sha(OUT/'freeze.json'),'normal_manifest_sha256':sha(OUT/'prepared/manifest.json'),'audit_manifest_sha256':sha(OUT/'audit-prepared/manifest.json'),'protocol_sha256':protocol_binding['sha256'],'source_bindings_rehashed':len(normal['sources']),'whole_game_partition_counts':{p:len(v)for p,v in expected.items()},'whole_game_id_partitions_all_verified_disjoint':True,'all_four_original_shard_manifest_and_map_identities_verified':True,'array_schema_and_full_hash_checks':artifact_records,'deterministic_sampling':{'seed':SEED,'selection':'Each partition first/last global row, midpoint,12 seeded random global rows, plus first/last represented row of each shard; duplicates collapsed','spots':len(spots),'source_shards_seen_by_partition':observed_shards,'full_recipe_line_count_scan':recipe_counts},'spotchecks':spots,'actual_raw_teacher_jsonl_lines_read':actual_raw_lines,'actual_raw_teacher_jsonl_games_decoded':actual_raw_decoded,'training_guard':guard,'manifest_asserted_crosssplit_position_overlap':normal['exact_first4fen_crosssplit_overlap'],'global_dedup_independently_reconstructed':False,'scope_limit':'Full file hashes, NPZ array names/dtypes/shapes, declared row counts and all whole-game identity partitions checked. Bounded deterministic rows match original arrays/recipes and raw external-teacher rows. Exact global first4FEN deduplication was NOT independently recomputed; no new native features/HCE, NNUE/model scoring, optimizer or audit loss.','elapsed_seconds':time.monotonic()-START,'checker_source_sha256':sha(__file__)}

if __name__=='__main__':
 p=H/'preparer-agent/global-merge-final-independent-check.json'
 try:result=run();code=0
 except Exception as e:result={'status':'FAIL_OR_NOT_READY','error':str(e),'traceback':traceback.format_exc(),'scope':'No merge or model scoring executed','elapsed_seconds':time.monotonic()-START,'checker_source_sha256':sha(__file__)};code=1
 with p.open('x')as f:json.dump(result,f,indent=2);f.write('\n')
 print(json.dumps({k:result.get(k)for k in('status','error','freeze','training_guard','deterministic_sampling','elapsed_seconds')}));print('receipt_sha256 '+sha(p));raise SystemExit(code)
