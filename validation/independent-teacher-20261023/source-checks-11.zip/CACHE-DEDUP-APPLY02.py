import pathlib,os,stat,json,gzip,time,hashlib,collections,traceback,shutil
H=pathlib.Path('/workspace/forge-independent-teacher-20261023');BASE=pathlib.Path('/workspace/.cloud-setup');plan=json.load(gzip.open('/tmp/cache-dedup-authorized02-plan.json.gz','rt'));proc=json.loads(pathlib.Path('/tmp/cache-dedup-proc02.json').read_text());start=time.monotonic();central=BASE/'IMMUTABLE-HARDLINKED-EVIDENCE-20261023.json';receipt=H/'CACHE-DEDUP-RECEIPT-02.json';journal=H/'CACHE-DEDUP-DETAILS-02.jsonl.gz';inventory=H/'CACHE-DEDUP-INVENTORY-02.json.gz'
if time.time()-proc['utc_epoch']>300 or any(proc[k]for k in('writable_fds','shared_writable_maps','active_cwd_or_exe','errors')):raise RuntimeError('Fresh process check required')
for p in(central,receipt,journal,inventory):
 if p.exists():raise RuntimeError('Refuse overwrite '+str(p))
def m(p):
 s=pathlib.Path(p).lstat();return{'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'size':s.st_size,'dev':s.st_dev,'ino':s.st_ino,'nlink':s.st_nlink,'blocks':s.st_blocks,'mtime_ns':s.st_mtime_ns,'atime_ns':s.st_atime_ns,'ctime_ns':s.st_ctime_ns}
def fopen(p):return os.fdopen(os.open(p,os.O_RDONLY|os.O_NOFOLLOW|getattr(os,'O_NOATIME',0)),'rb')
def sha(p):
 h=hashlib.sha256()
 with fopen(p)as f:
  for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
 return h.hexdigest()
def eq(a,b):
 with fopen(a)as x,fopen(b)as y:
  while True:
   u,v=x.read(4*1024*1024),y.read(4*1024*1024)
   if u!=v:return False
   if not u:return True
def attrs(p):return{k:os.getxattr(p,k).hex()for k in os.listxattr(p)}
paths={};roots=set();archivehash={}
for g in plan['groups']:
 entries=[(g['source'],g['source_aliases'])]+[(t['representative'],t['all_paths'])for t in g['targets']]
 for e,aliases in entries:
  if e['metadata']['links']!=len(aliases):raise RuntimeError('Unknown inode alias')
  fresh=m(e['path'])
  for k in('mode','uid','gid','size','dev','ino','mtime_ns','ctime_ns','blocks'):
   if fresh[k]!=e['metadata'][k]:raise RuntimeError('Changed since proposal '+e['path'])
  if sha(e['path'])!=e['sha256']or attrs(e['path'])!=e['xattrs']:raise RuntimeError('Fresh SHA/xattrs mismatch')
  for p in aliases:
   if'accepted-ownbook-candidate-release'in pathlib.Path(p).parts or'.git'in pathlib.Path(p).parts:raise RuntimeError('Forbidden reference/Git alias')
   pm=m(p)
   if(pm['dev'],pm['ino'])!=(fresh['dev'],fresh['ino']):raise RuntimeError('Alias inode mismatch')
   paths[p]={'sha256':e['sha256'],'before':pm,'xattrs':e['xattrs']};roots.add(str(BASE/pathlib.Path(p).relative_to(BASE).parts[0]))
 for t in g['targets']:
  if not eq(g['source']['path'],t['representative']['path']):raise RuntimeError('Fresh full byte mismatch')
roots=sorted(roots)
def snapshot():
 entries={};dirs={};inodes={}
 for root in roots:
  for directory,subdirs,names in os.walk(root,followlinks=False):
   dirs[directory]=m(directory)
   for n in subdirs+names:
    p=pathlib.Path(directory)/n;s=p.lstat();entries[str(p)]={'type':stat.S_IFMT(s.st_mode),'size':s.st_size,'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'symlink':os.readlink(p)if stat.S_ISLNK(s.st_mode)else None}
    if stat.S_ISREG(s.st_mode):inodes[(s.st_dev,s.st_ino)]=s.st_blocks*512
 return entries,dirs,inodes
before_entries,before_dirs,before_inodes=snapshot()
for p,e in before_entries.items():
 n=pathlib.Path(p).name
 if e['type']==stat.S_IFREG and(any(n.endswith(x)for x in('.zip','.tar','.tar.gz','.tgz','.gz','.xz','.bz2','.zst','.7z'))or'.zip.part'in n):archivehash[p]=sha(p)
reference=BASE/'accepted-ownbook-candidate-release';referencehash={str(p):sha(p)for p in reference.rglob('*')if p.is_file()and not p.is_symlink()}
frozen={'schema':'immutable_historical_hardlink_snapshots_v1','status':'FROZEN_BEFORE_AUTHORIZED_HARDLINK_STORAGE_DEDUPLICATION','created_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'rule':'Every listed original historical path is now an immutable snapshot. Never compile/rebuild/write in place; all future builds must use fresh directories. Preserve byte identities and all paths. This is a declared preservation contract, not filesystem-enforced read-only mode.','excluded_reference_root':str(reference),'no_unknown_inode_aliases':True,'source_proposal_sha256':plan['proposal_sha256'],'scope_roots':roots,'paths':paths,'metadata_note':'Mode, owner and xattrs match before linking. Distinct original timestamps/inodes/link counts retained here; shared-inode timestamp/ctime/nlink differences will be declared in the external receipt.'}
with central.open('x')as f:json.dump(frozen,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
free_before=os.statvfs(H).f_bavail*os.statvfs(H).f_frsize;completed=0;errors=[];changed_mtime=0
try:
 with gzip.open(journal,'wt')as out:
  for g in plan['groups']:
   src=g['source']['path'];digest=g['source']['sha256']
   if sha(src)!=digest:raise RuntimeError('Donor changed before linking')
   for target in g['targets']:
    for dst in target['all_paths']:
     bm=m(dst);sm=m(src)
     if sha(dst)!=digest or attrs(src)!=paths[src]['xattrs']or attrs(dst)!=paths[dst]['xattrs']:raise RuntimeError('Pre-link SHA/xattrs failed')
     if any(sm[k]!=bm[k]for k in('mode','uid','gid','size'))or not eq(src,dst):raise RuntimeError('Pre-link metadata/bytes failed')
     temp=pathlib.Path(dst).parent/('.cache-dedup-02-'+str(os.getpid())+'-'+str(completed)+'.tmp')
     try:os.link(src,temp,follow_symlinks=False);os.replace(temp,dst)
     finally:
      if temp.exists():temp.unlink()
     am=m(dst)
     if(am['dev'],am['ino'])!=(m(src)['dev'],m(src)['ino'])or sha(dst)!=digest or not eq(src,dst):raise RuntimeError('Post-link inode/SHA/bytes failed')
     changed_mtime+=bm['mtime_ns']!=am['mtime_ns'];completed+=1
     out.write(json.dumps({'source':src,'target':dst,'sha256':digest,'target_before':paths[dst]['before'],'source_before':paths[src]['before'],'target_after':am,'source_after':m(src),'mode_owner_xattrs_matched':True,'full_byte_comparison':True},separators=(',',':'))+'\n')
except Exception as e:errors.append({'error':str(e),'traceback':traceback.format_exc()})
# Read back every frozen original path and compressed archive plus the excluded live reference.
all_path_shas=all(sha(p)==e['sha256']for p,e in paths.items());all_archives=all(sha(p)==v for p,v in archivehash.items());reference_ok=all(sha(p)==v for p,v in referencehash.items())
for p,d in before_dirs.items():os.utime(p,ns=(d['atime_ns'],d['mtime_ns']),follow_symlinks=False)
after_entries,after_dirs,after_inodes=snapshot();same_inventory=before_entries==after_entries
with gzip.open(inventory,'wt')as f:json.dump({'before_path_inventory':before_entries,'after_path_inventory':after_entries,'before_directories':before_dirs,'after_directories':after_dirs,'selected_file_metadata_after':{p:m(p)for p in paths}},f,separators=(',',':'))
free_after=os.statvfs(H).f_bavail*os.statvfs(H).f_frsize
out={'status':'PASS'if not errors and all_path_shas and all_archives and reference_ok and same_inventory else'FAILED_OR_PARTIAL','scope_roots':roots,'groups':len(plan['groups']),'completed_targets':completed,'selected_paths_hash_readback':len(paths),'all_selected_original_path_SHA256_readback_passed':all_path_shas,'all_pre_post_target_full_byte_checks_passed':not errors,'all_mode_owner_xattrs_checks_passed':not errors,'full_path_type_size_mode_owner_symlink_inventory_unchanged':same_inventory,'archives_untouched_and_hash_reverified':len(archivehash),'all_archive_hashes_passed':all_archives,'excluded_accepted_reference_files_reverified':len(referencehash),'excluded_reference_all_SHA_unchanged':reference_ok,'no_unknown_source_or_target_inode_aliases':True,'declared_immutable_snapshot_manifest':{'path':str(central),'sha256':sha(central)},'filesystem_read_only_enforced':False,'future_build_rule':'Root authorized preservation contract; all listed historical build/evidence paths are immutable snapshots and must never be rebuilt in place. Future compilation uses fresh directories. No file modes were changed.','allocated_unique_inode_reduction_bytes':sum(before_inodes.values())-sum(after_inodes.values()),'filesystem_available_before_bytes':free_before,'filesystem_available_after_bytes':free_after,'filesystem_available_delta_bytes':free_after-free_before,'space_measurement_scope':'Shared filesystem; concurrent live recovery and receipt writes affect df delta. Unique-inode allocated reduction measures this operation.','original_mtimes_differing_after_sharing':changed_mtime,'directory_atime_mtime_restored':True,'timestamp_metadata_scope':'Every selected original file timestamp retained in central snapshot; after timestamps/inode/link counts retained in external inventory. Hardlink sharing can replace distinct target timestamps and changes ctime/nlink.','proc_check':proc,'proc_limitations':'Two known Docker infrastructure daemons remain inaccessible; all accessible live processes checked for selected inode writers/shared writable maps and affected-root cwd/exe; no hits. Zombie processes have released descriptors.','errors':errors,'elapsed_seconds':time.monotonic()-start,'source_scripts':{str(p):sha(p)for p in map(pathlib.Path,('/tmp/cache_dedup_proc02.py','/tmp/cache_dedup_apply02.py'))},'evidence':{str(p):sha(p)for p in(journal,inventory,H/'CACHE-DEDUP-PROPOSAL-02.json.gz')}}
with receipt.open('x')as f:json.dump(out,f,indent=2);f.write('\n')
for n in('proc02','apply02'):
 src=pathlib.Path('/tmp/cache_dedup_'+n+'.py');dst=H/('CACHE-DEDUP-'+n.upper()+'.py')
 with dst.open('xb')as f:f.write(src.read_bytes())
print(json.dumps({k:out[k]for k in('status','groups','completed_targets','selected_paths_hash_readback','allocated_unique_inode_reduction_bytes','filesystem_available_before_bytes','filesystem_available_after_bytes','filesystem_available_delta_bytes','all_selected_original_path_SHA256_readback_passed','all_archive_hashes_passed','excluded_reference_all_SHA_unchanged','full_path_type_size_mode_owner_symlink_inventory_unchanged','elapsed_seconds','errors')}));print('receipt_sha256 '+sha(receipt));print('central_manifest_sha256 '+sha(central))
