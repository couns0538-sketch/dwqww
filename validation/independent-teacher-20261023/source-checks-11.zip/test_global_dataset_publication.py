"""Small real-file recovery contract checks; no engines, models, or Git."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest import mock

H = Path('/workspace/forge-independent-teacher-20261023')
spec = importlib.util.spec_from_file_location('publication', H / 'global_dataset_publication.py')
publication = importlib.util.module_from_spec(spec)
spec.loader.exec_module(publication)
recovery = publication.modules(H)
multipart = recovery.multipart

class PublicationContractTests(unittest.TestCase):
    def test_actual_final_status_and_running_parent_rejected(self):
        status = publication.read(H / 'teacher-agent/global-publication-review/ci-final-shard0-STATUS.json')
        publication.validate_final(status)
        changed = copy.deepcopy(status)
        changed['children']['generator']['actual_exit'] = None
        with self.assertRaisesRegex(ValueError, 'parents'):
            publication.validate_final(changed)

    def test_immutable_url_never_uses_branch_or_published_commit(self):
        commit = 'a' * 40
        self.assertEqual(publication.pinned_url(commit, 'STATUS.json'),
                         'https://raw.githubusercontent.com/couns0538-sketch/dwqww/' + commit + '/STATUS.json')
        with self.assertRaisesRegex(ValueError, 'immutable'):
            publication.pinned_url('data/live-branch', 'STATUS.json')

    def test_unclosed_real_merge_receipt_refused_before_output(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            result = root / 'result.json'
            result.write_text(json.dumps({'actual_exit': None}))
            args = SimpleNamespace(dataset=H / 'dataset-02', source_commit='a' * 40,
                                   merge_result=result, ci_final=[], out=root / 'out')
            with self.assertRaisesRegex(ValueError, 'closed merge'):
                publication.seal(args)
            self.assertFalse(args.out.exists())

    def test_global_restore_rejects_duplicate_workspace_prefix_before_delegating(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            manifest = root / 'manifest.json'
            manifest.write_text(json.dumps({'members': [{'path': 'workspace/wrong-prefix'}]}))
            delegate = mock.Mock()
            args = SimpleNamespace(helper_directory=H, manifest=manifest, sha256='a' * 64,
                                   staging=root / 'stage', proof=root / 'proof.json')
            with mock.patch.object(publication, 'modules', return_value=SimpleNamespace(restore_group=delegate)):
                with self.assertRaisesRegex(ValueError, 'relative to canonical'):
                    publication.restore_global(args)
            delegate.assert_not_called()

    def fixture(self, root):
        remote = root / 'remote'
        destination = root / 'canonical-recovery'
        shards = []
        maps = []
        for number in range(4):
            directory = remote / str(number)
            directory.mkdir(parents=True)
            source = root / f'original-{number}'
            source.write_bytes(('authentic-' + str(number)).encode())
            declaration = root / f'declaration-{number}.json'
            declaration.write_text(json.dumps({'status': 'CLOSED_INPUTS_FROZEN', 'files': [{
                'source': str(source), 'member': f'workspace/evidence/shard-{number}.txt',
                'sha256': publication.sha(source), 'bytes': source.stat().st_size}]}))
            archive = directory / 'archive-0000'
            multipart.pack(declaration, archive, part_bytes=113)
            status = {'status': 'SHARD_PREPARED_NOT_GLOBAL_QUALIFIED', 'shard': number,
                      'archives': [{'path': 'archive-0000/RECOVERY-MANIFEST.json',
                                    'sha256': publication.sha(archive / 'RECOVERY-MANIFEST.json')}]}
            status_path = directory / 'STATUS.json'
            status_path.write_text(json.dumps(status))
            branch = f'data/frozen-shard-{number}'
            shards.append({'shard': number, 'branch': branch, 'immutable_commit': str(number + 1) * 40,
                           'status_url': status_path.as_uri(), 'status': {'sha256': publication.sha(status_path)}})
            mapping = [{'from': f'/workspace/forge-independent-teacher-20261023/ci-shard-{number}',
                        'to': str(destination / f'workspace/forge-independent-teacher-20261023/ci-shard-{number}')},
                       {'from': '/workspace/dwqww', 'to': str(destination / 'workspace/dwqww')}]
            raw = (json.dumps(mapping, indent=2) + '\n').encode()
            maps.append({'path': str(destination / f'.ci-recovery/shard-{number}/source-map.json'),
                         'sha256': hashlib.sha256(raw).hexdigest()})
        dependency = root / 'dependencies.json'
        dependency.write_text(json.dumps({'canonical_ci_recovery': str(destination),
            'repository': 'owner/repository', 'shards': shards, 'source_maps': maps}))
        return remote, destination, dependency

    def test_real_tiny_pinned_recovery_preserves_branches_and_map_bytes(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            remote, destination, dependency = self.fixture(root)
            def local_url(commit, path, repository):
                return (remote / str(int(commit[0]) - 1) / path).as_uri()
            args = SimpleNamespace(dependencies=dependency, helper_directory=H,
                                   external_stockfish=root / 'unused-external-tool')
            with mock.patch.object(publication, 'RECOVERY', destination), \
                    mock.patch.object(publication, 'pinned_url', side_effect=local_url):
                publication.restore_dependencies(args)
            state = publication.read(destination / '.ci-recovery/state.json')
            self.assertEqual(state['shards'], {str(n): f'data/frozen-shard-{n}' for n in range(4)})
            for number in range(4):
                self.assertEqual((destination / f'workspace/evidence/shard-{number}.txt').read_bytes(),
                                 ('authentic-' + str(number)).encode())
            self.assertEqual(len(state['groups']), 4)

    def test_corrupt_pinned_status_refused_before_source_member_restore(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            remote, destination, dependency = self.fixture(root)
            (remote / '0/STATUS.json').write_bytes(b'corrupt status')
            def local_url(commit, path, repository):
                return (remote / str(int(commit[0]) - 1) / path).as_uri()
            args = SimpleNamespace(dependencies=dependency, helper_directory=H,
                                   external_stockfish=root / 'unused-external-tool')
            with mock.patch.object(publication, 'RECOVERY', destination), \
                    mock.patch.object(publication, 'pinned_url', side_effect=local_url):
                with self.assertRaisesRegex(ValueError, 'SHA256'):
                    publication.restore_dependencies(args)
            self.assertFalse((destination / 'workspace/evidence/shard-0.txt').exists())

if __name__ == '__main__':
    unittest.main(verbosity=2)
