import os,pathlib,json,gzip,time
p=json.load(gzip.open('/tmp/cache-dedup-authorized02-plan.json.gz','rt'));files=[s for g in p['groups']for s in g['source_aliases']+[s for t in g['targets']for s in t['all_paths']]];roots=sorted({str(pathlib.Path('/workspace/.cloud-setup')/pathlib.Path(s).relative_to('/workspace/.cloud-setup').parts[0])+'/'for s in files});inodes={(os.stat(s).st_dev,os.stat(s).st_ino)for s in files};out={'utc_epoch':time.time(),'live_processes_checked':0,'zombies':0,'writable_fds':[],'shared_writable_maps':[],'active_cwd_or_exe':[],'inaccessible_infrastructure':[],'errors':[]}
for pr in pathlib.Path('/proc').iterdir():
 if not pr.name.isdigit():continue
 try:
  st=(pr/'status').read_text();state=next(x.split()[1]for x in st.splitlines()if x.startswith('State:'))
  if state=='Z':out['zombies']+=1;continue
  uid=int(next(x.split()[1]for x in st.splitlines()if x.startswith('Uid:')));name=next(x.split()[1]for x in st.splitlines()if x.startswith('Name:'))
  try:
   for k in('cwd','exe'):
    try:
     s=os.readlink(pr/k)
     if any(s.startswith(r)for r in roots):out['active_cwd_or_exe'].append({'pid':pr.name,'kind':k,'path':s})
    except FileNotFoundError:pass
   for fd in(pr/'fd').iterdir():
    try:
     info=fd.stat()
     if(info.st_dev,info.st_ino)not in inodes:continue
     flag=int(next(x.split()[1]for x in(pr/'fdinfo'/fd.name).read_text().splitlines()if x.startswith('flags:')),8)
     if(flag&os.O_ACCMODE)in(os.O_WRONLY,os.O_RDWR):out['writable_fds'].append({'pid':pr.name,'fd':fd.name,'path':os.readlink(fd),'flags':oct(flag)})
    except FileNotFoundError:pass
   for line in(pr/'maps').read_text().splitlines():
    f=line.split(None,5)
    if len(f)==6 and f[1][1]=='w'and f[1][3]=='s'and any(f[5].startswith(r)for r in roots):out['shared_writable_maps'].append({'pid':pr.name,'map':line})
   out['live_processes_checked']+=1
  except PermissionError as e:
   entry={'pid':pr.name,'uid':uid,'name':name,'error':str(e)}
   (out['inaccessible_infrastructure']if name in('dockerd','containerd') and ((pr/'cmdline').read_bytes().replace(bytes([0]),b' ').startswith(b'/usr/local/bin/dockerd ') or (pr/'cmdline').read_bytes().replace(bytes([0]),b' ').startswith(b'containerd --config /run/codex-docker/'))else out['errors']).append(entry)
 except(FileNotFoundError,ProcessLookupError):pass
pathlib.Path('/tmp/cache-dedup-proc02.json').write_text(json.dumps(out));print(json.dumps(out))
if any(out[k]for k in('writable_fds','shared_writable_maps','active_cwd_or_exe','errors')):raise SystemExit(2)
