import os,stat,json,hashlib,time,gzip,pathlib,collections
BASE=pathlib.Path('/workspace/.cloud-setup'); H=pathlib.Path('/workspace/forge-independent-teacher-20261023'); start=time.monotonic()
roots=sorted(p for p in BASE.iterdir() if p.is_dir() and not p.is_symlink() and ('complete-evidence-stage' in p.name or p.name in ('forge-tt-refresh-1d3ed25-recovery-scratch-attempt1','forge20-recovery-check-attempt1','nnue-strength-final-audit-39348571407') or 'complete-stage' in p.name))
def meta(p):
 s=p.lstat();return {'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'size':s.st_size,'dev':s.st_dev,'ino':s.st_ino,'nlink':s.st_nlink,'blocks':s.st_blocks,'mtime_ns':s.st_mtime_ns,'atime_ns':s.st_atime_ns,'ctime_ns':s.st_ctime_ns}
def sha(p):
 h=hashlib.sha256();fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|getattr(os,'O_NOATIME',0))
 with os.fdopen(fd,'rb') as f:
  for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
 return h.hexdigest()
files=[];inv=[];skips=collections.Counter()
for root in roots:
 for directory,dirs,names in os.walk(root,followlinks=False):
  dirs[:]=[x for x in dirs if x!='.git' and not (pathlib.Path(directory)/x).is_symlink()]
  for n in names:
   p=pathlib.Path(directory)/n;s=p.lstat();rel=str(p.relative_to(root));r={'root':str(root),'relative_path':rel,'metadata':meta(p)}
   if not stat.S_ISREG(s.st_mode):r['type']='symlink' if stat.S_ISLNK(s.st_mode) else 'other';r['target']=os.readlink(p) if p.is_symlink() else None;skips[r['type']]+=1
   else:
    r['type']='regular'
    if any(x=='.git' for x in p.parts):r['skip']='git'
    elif any(n.endswith(x) for x in ('.zip','.tar','.tar.gz','.tgz','.gz','.xz','.bz2','.zst','.7z')) or '.zip.part' in n:r['skip']='archive_untouched'
    elif s.st_size==0:r['skip']='zero_bytes'
    else:files.append(p)
    if 'skip'in r:skips[r['skip']]+=1
   inv.append(r)
# Inventory comparison of the two full extracted pairs (archives included read-only).
def fullmap(root):
 d={}
 for directory,dirs,names in os.walk(root,followlinks=False):
  for n in names:
   p=pathlib.Path(directory)/n
   if p.is_file() and not p.is_symlink():d[str(p.relative_to(root))]=(p.stat().st_size,stat.S_IMODE(p.stat().st_mode),sha(p))
 return d
pairs=[]
for an,bn in [('forge-tt-refresh-1d3ed25-recovery-scratch-attempt1','forge-tt-refresh-1d3ed25-complete-evidence-stage'),('forge20-recovery-check-attempt1','forge-pawn-span-fc23918-complete-evidence-stage')]:
 a,b=fullmap(BASE/an/'files'),fullmap(BASE/bn);pairs.append({'a':str(BASE/an/'files'),'b':str(BASE/bn),'files_a':len(a),'files_b':len(b),'full_relative_paths_identical':set(a)==set(b),'all_size_mode_sha_identical':a==b,'a_only':sorted(set(a)-set(b))[:10],'b_only':sorted(set(b)-set(a))[:10]})
by_size=collections.defaultdict(list)
for p in files:by_size[p.stat().st_size].append(p)
groups=collections.defaultdict(list);hashed=0
for size,paths in by_size.items():
 if len(paths)<2:continue
 for p in paths:
  m=meta(p);xattrs={k:os.getxattr(p,k).hex() for k in os.listxattr(p)};digest=sha(p);hashed+=1
  if meta(p)!=m:raise RuntimeError('File changed during hashing '+str(p))
  groups[(size,m['mode'],m['uid'],m['gid'],json.dumps(xattrs,sort_keys=True),digest)].append({'path':str(p),'before':m,'sha256':digest,'xattrs':xattrs})
plan=[]
for key,entries in groups.items():
 if len(entries)<2:continue
 entries.sort(key=lambda e:e['path']);source=entries[0]
 for target in entries[1:]:
  if (source['before']['dev'],source['before']['ino'])!=(target['before']['dev'],target['before']['ino']):plan.append({'source':source,'target':target})
# no writable descriptor and no processes executing/from cwd within closed roots.
rootstr=[str(p)+'/' for p in roots];writable=[];active=[];denied=[];scanned=0
for pr in pathlib.Path('/proc').iterdir():
 if not pr.name.isdigit():continue
 try:
  for label in ('cwd','exe'):
   try:
    link=os.readlink(pr/label)
    if any(link.startswith(r) for r in rootstr):active.append({'pid':pr.name,'kind':label,'path':link})
   except FileNotFoundError:pass
  for fd in (pr/'fd').iterdir():
   try:
    link=os.readlink(fd)
    if not any(link.startswith(r) for r in rootstr):continue
    data=(pr/'fdinfo'/fd.name).read_text();flag=int(next(z.split()[1] for z in data.splitlines() if z.startswith('flags:')),8)
    if flag&os.O_ACCMODE in (os.O_WRONLY,os.O_RDWR):writable.append({'pid':pr.name,'fd':fd.name,'path':link,'flags_octal':oct(flag)})
   except FileNotFoundError:pass
  scanned+=1
 except (PermissionError,ProcessLookupError) as e:denied.append({'pid':pr.name,'error':str(e)})
payload={'roots':[str(p) for p in roots],'inventory':inv,'plan':plan,'normalized_full_pairs':pairs,'proc':{'processes_scanned':scanned,'writable_fds':writable,'active_cwd_or_exe':active,'denied':denied},'files_hashed':hashed,'skips':dict(skips),'elapsed_scan_seconds':time.monotonic()-start}
with gzip.open('/tmp/cache-dedup-plan.json.gz','wt')as f:json.dump(payload,f,separators=(',',':'))
print(json.dumps({'roots':len(roots),'inventory_entries':len(inv),'files_hashed':hashed,'dedup_targets':len(plan),'dedup_logical_bytes':sum(z['target']['before']['size'] for z in plan),'dedup_block_bytes_if_nlink1':sum(z['target']['before']['blocks']*512 for z in plan if z['target']['before']['nlink']==1),'pairs':pairs,'proc':payload['proc'],'skips':payload['skips'],'elapsed':payload['elapsed_scan_seconds']}))
