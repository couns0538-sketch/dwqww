#!/usr/bin/env python3
"""Bounded read-only Git ref and small raw JSON watcher; never fetch datasets."""
import hashlib,json,re,subprocess,time,urllib.request
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path('/workspace/forge-independent-teacher-20261023/teacher-agent/ci-hosted-monitor-r1')
REPO=Path('/workspace/dwqww')
EXPECTED='5111164ae0e86ff49804cdd3a3289fcae00d8cd5'
DURATION=900
BEGIN=time.monotonic()
EXPECTED_FILES={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [REPO/'tools/nnue'/n for n in ('run_teacher_ci_shard.py','build_teacher_ci.py','generate_teacher_games.py','label_teacher_games.py','coordinate_teacher_shards.py','native_game_driver.cpp','prepare_teacher_data.py','multipart_dataset.py')]}
last={};shards={};manifest_cache={};round_index=0

def utc():return datetime.now(timezone.utc).isoformat()
def sha(data):return hashlib.sha256(data).hexdigest()
def atomic(path,doc):
    tmp=path.with_suffix('.pending');tmp.write_text(json.dumps(doc,indent=2)+'\n');tmp.replace(path)
def event(kind,**fields):
    row={'utc':utc(),'elapsed_seconds':round(time.monotonic()-BEGIN,3),'kind':kind,**fields}
    with (ROOT/'events.jsonl').open('a') as out:out.write(json.dumps(row)+'\n')
    print(json.dumps(row),flush=True)
def raw(commit,member):
    url=f'https://raw.githubusercontent.com/couns0538-sketch/dwqww/{commit}/{member}'
    req=urllib.request.Request(url,headers={'User-Agent':'Forge-read-only-hosted-checkpoint-review/1'})
    with urllib.request.urlopen(req,timeout=20) as f:
        body=f.read(8*1024*1024+1)
    if len(body)>8*1024*1024:raise ValueError('Small JSON bound exceeded')
    return body,url
atomic(ROOT/'command.json',{'started_utc':utc(),'expected_source_commit':EXPECTED,'duration_seconds':DURATION,'interval_seconds':30,'command':['git','ls-remote','origin','refs/heads/data/independent-teacher-ci-*'],'raw_url_rule':'https://raw.githubusercontent.com/couns0538-sketch/dwqww/EXACT_REF_SHA/STATUS.json','read_only':True,'dataset_objects_fetched':False,'expected_sources':EXPECTED_FILES})
while time.monotonic()-BEGIN<DURATION:
    stamp=ROOT/f'poll-{round_index:03d}';stamp.mkdir(exist_ok=False)
    command=['git','ls-remote','origin','refs/heads/data/independent-teacher-ci-*']
    started=utc()
    try:
        result=subprocess.run(command,cwd=REPO,text=True,capture_output=True,timeout=30)
        (stamp/'ls-remote.stdout').write_text(result.stdout);(stamp/'ls-remote.stderr').write_text(result.stderr)
        atomic(stamp/'command.json',{'argv':command,'started_utc':started,'ended_utc':utc(),'actual_exit':result.returncode})
        if result.returncode:raise RuntimeError('ls-remote exit '+str(result.returncode))
        refs=[]
        for line in result.stdout.splitlines():
            commit,ref=line.split()
            match=re.fullmatch(r'refs/heads/data/independent-teacher-ci-(\d+)-(\d+)-shard-([0-3])',ref)
            if match and match.group(1)!='40021324995':refs.append((commit,ref,match.groups()))
        event('poll',round=round_index,refs=len(refs))
        for commit,ref,(run_id,attempt,shard_text) in refs:
            if last.get(ref)==commit:continue
            shard=int(shard_text);base=stamp/f'shard-{shard}';base.mkdir(exist_ok=True)
            try:
                body,url=raw(commit,'STATUS.json');(base/'STATUS.json').write_bytes(body);doc=json.loads(body)
                if doc.get('source_commit')!=EXPECTED:raise ValueError('Unexpected source_commit '+str(doc.get('source_commit')))
                if str(doc.get('run_id'))!=run_id or doc.get('shard')!=shard:raise ValueError('Run/shard identity mismatch')
                verified=[]
                archives=doc.get('archives',[])
                selected=archives[:1]+(archives[-1:] if len(archives)>1 else [])
                source_hashes={}
                for number,entry in enumerate(selected):
                    key=entry['sha256']
                    if key not in manifest_cache:
                        data,manifest_url=raw(commit,entry['path'])
                        if sha(data)!=entry['sha256']:raise ValueError('Recovery manifest SHA mismatch')
                        cached=ROOT/('recovery-'+key+'.json');cached.write_bytes(data)
                        manifest_cache[key]={'body':json.loads(data),'file':str(cached),'url':manifest_url}
                    cached=manifest_cache[key];manifest=cached['body']
                    for item in manifest.get('members',[])+manifest.get('aliases',[]):
                        source=item.get('source','/'+item.get('path',''))
                        if source in EXPECTED_FILES:
                            if item['sha256']!=EXPECTED_FILES[source]:raise ValueError('Published source SHA differs: '+source)
                            source_hashes[source]=item['sha256']
                    verified.append({'path':entry['path'],'sha256':key,'cached_path':cached['file'],'members':len(manifest.get('members',[])),'parts':len(manifest.get('parts',[]))})
                if not archives:raise ValueError('No completed recovery archive in STARTED status')
                for required in ('run_teacher_ci_shard.py','build_teacher_ci.py','generate_teacher_games.py','label_teacher_games.py','coordinate_teacher_shards.py','native_game_driver.cpp','prepare_teacher_data.py'):
                    key=str(REPO/'tools/nnue'/required)
                    if key not in source_hashes:raise ValueError('Source binding absent from first/latest recovery manifests: '+required)
                item={'shard':shard,'run_id':run_id,'attempt':attempt,'branch':ref,'ref_commit':commit,'source_commit':doc['source_commit'],'status':doc.get('status'),'status_sha256':sha(body),'status_path':str(base/'STATUS.json'),'status_url':url,'observed_utc':utc(),'verified_recovery_manifests':verified,'verified_source_count':len(source_hashes),'children':doc.get('children',{}),'error':doc.get('error'),'accepted_rows':doc.get('accepted_rows'),'unique_first4_fen':doc.get('unique_first4_fen'),'prepared_retained':doc.get('prepared_retained'),'training_permitted':doc.get('training_permitted')}
                atomic(base/'verified-review.json',item);shards[str(shard)]=item;last[ref]=commit
                event('verified_checkpoint',**item)
            except Exception as error:
                atomic(base/'read-error.json',{'utc':utc(),'ref_commit':commit,'branch':ref,'error':repr(error)})
                event('checkpoint_error',branch=ref,ref_commit=commit,error=repr(error))
        status={'utc':utc(),'expected_source_commit':EXPECTED,'elapsed_seconds':round(time.monotonic()-BEGIN,3),'verified_shards':shards,'all_four_started':len(shards)==4,'all_four_collecting_nonzero':len(shards)==4 and all(s['status']=='COLLECTING_FRESH_WHOLE_GAMES' and (s.get('accepted_rows') or 0)>0 for s in shards.values()),'dataset_objects_fetched':False}
        atomic(ROOT/'summary.json',status)
        if len(shards)==4:
            states=[s['status'] for s in shards.values()]
            if any('FAILED' in str(s) for s in states):event('terminal',reason='hosted failure observed');break
            if all(s['status']=='COLLECTING_FRESH_WHOLE_GAMES' and (s.get('accepted_rows') or 0)>0 for s in shards.values()):event('terminal',reason='all four hosted shards actually collecting nonzero teacher rows');break
    except Exception as error:event('poll_error',round=round_index,error=repr(error))
    round_index+=1
    remaining=DURATION-(time.monotonic()-BEGIN)
    if remaining>0:time.sleep(min(30,remaining))
event('monitor_closed',verified_shards=len(shards),dataset_objects_fetched=False)
