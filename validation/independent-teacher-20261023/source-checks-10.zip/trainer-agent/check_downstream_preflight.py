import ast,hashlib,json,math,tempfile
from pathlib import Path
BASE=Path('/workspace/forge-independent-teacher-20261023')
data=json.loads((BASE/'downstream_commands.json').read_bytes())

def assigned(node,name):
 return isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in node.targets)

def execute_prefix(command,paths,stop):
 nodes=[]
 for node in ast.parse(command['argv'][2]).body:
  if assigned(node,stop):break
  if assigned(node,'P'):node.value=ast.parse(repr(paths),mode='eval').body
  nodes.append(node)
 exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),'<guard-only>','exec'),{})

checks=[]
with tempfile.TemporaryDirectory() as directory:
 root=Path(directory);bad=root/'bad-protocol.json';bad.write_text('{"revision":7}')
 for command in data['commands']:
  compile(command['argv'][2],command['name'],'exec')
  try:execute_prefix(command,{**data['paths'],'protocol':str(bad)},'frozen_data')
  except ValueError as error:assert 'protocol08' in str(error)
  else:raise AssertionError('Changed protocol accepted')
  checks.append(command['name']+':changed_protocol_rejected_before_data')
 protocol=Path(data['paths']['protocol']);protocol_raw=protocol.read_bytes();protocol_sha=hashlib.sha256(protocol_raw).hexdigest();p=json.loads(protocol_raw)
 prepared=root/'prepared';audit=root/'audit';prepared.mkdir();audit.mkdir();manifest_shas={}
 for target,role,key in ((prepared,'training_and_selection','prepared_manifest_sha256'),(audit,'final_audit_only','audit_manifest_sha256')):
  m={'dataset_role':role,'protocol_sha256':protocol_sha,'training_permitted':True,'provenance_format':'independent_teacher_v1','status':'QUALIFIED_FROZEN','target':p['target'],'retained_total_positions':5000000,'minimum_positions':5000000}
  raw=json.dumps(m).encode();(target/'manifest.json').write_bytes(raw);manifest_shas[key]=hashlib.sha256(raw).hexdigest()
 freeze=root/'freeze.json';freeze.write_text(json.dumps({'status':'QUALIFIED_FROZEN','training_permitted':True,'minimum_positions':5000000,'total':5000000,'retained':{'train':4500000,'validation':250000,'audit':250000},'protocol_sha256':protocol_sha,**manifest_shas}))
 for command in data['commands']:
  paths={**data['paths'],'data':str(prepared),'audit_data':str(audit),'data_freeze':str(freeze),'shipped':str(root/'MUST_NOT_READ_MODEL.inc')}
  try:execute_prefix(command,paths,'source_files')
  except ValueError as error:assert 'merged independent-teacher' in str(error)
  else:raise AssertionError('Old single-source provenance accepted')
  checks.append(command['name']+':single_source_rejected_before_model_read')

freeze=next(c for c in data['commands'] if c['name']=='freeze_selected_quantized_candidate')
tree=ast.parse(freeze['argv'][2]);selection=[];collect=False
for node in tree.body:
 if assigned(node,'records'):collect=True
 if collect and assigned(node,'baseline'):break
 if collect:selection.append(node)
records=[{'epoch':i,'result_weight':.4,'target_mse_combined':value} for i,value in enumerate([.8,.3,.5,.4,.3,.7,.6,.9],1)]
def require(condition,message):
 if not condition:raise ValueError(message)
for best_epoch in (2,5):
 namespace={'summary':{'epochs':records,'best':{'epoch':best_epoch,'stem':'epoch-%04d'%best_epoch,'selection_metric':'target_mse_combined','selection_mse':.3}},'require':require,'math':math}
 try:exec(compile(ast.Module(body=selection,type_ignores=[]),'<synthetic-earliest-tie>','exec'),namespace)
 except ValueError:assert best_epoch==5
 else:assert best_epoch==2 and namespace['chosen']['epoch']==2
checks.append('actual_selection_guard:earliest_trained_epoch_tie_enforced')
for command in data['commands']:
 argv=command.get('underlying_cli_argv')
 if argv is None:continue
 tree=ast.parse(Path(argv[1]).read_text());known={arg.value for node in ast.walk(tree) if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and node.func.attr=='add_argument' for arg in node.args if isinstance(arg,ast.Constant) and isinstance(arg.value,str)}
 assert all(value in known for value in argv[2:] if value.startswith('--'))
 checks.append(command['name']+':CLI_flags_match_actual_source')
print(json.dumps({'status':'PASS_GUARD_ONLY_NO_MODEL_OR_OPTIMIZER','checks':checks,'count':len(checks)}))
