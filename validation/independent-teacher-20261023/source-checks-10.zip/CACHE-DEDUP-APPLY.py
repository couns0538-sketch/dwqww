import os,stat,json,hashlib,time,gzip,pathlib,shutil,collections,traceback
H=pathlib.Path('/workspace/forge-independent-teacher-20261023'); plan=json.load(gzip.open('/tmp/cache-dedup-plan.json.gz','rt')); start=time.monotonic(); receipt=H/'CACHE-DEDUP-RECEIPT.json'; details=H/'CACHE-DEDUP-DETAILS.jsonl.gz'; preflight=H/'CACHE-DEDUP-PREFLIGHT.json.gz'
for p in (receipt,details,preflight):
 if p.exists():raise RuntimeError('Refuse overwrite '+str(p))
shutil.copyfile('/tmp/cache-dedup-plan.json.gz',preflight)
def sha(p):
 h=hashlib.sha256();fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|getattr(os,'O_NOATIME',0))
 with os.fdopen(fd,'rb')as f:
  for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
 return h.hexdigest()
def meta(p):
 s=pathlib.Path(p).lstat();return {'mode':stat.S_IMODE(s.st_mode),'uid':s.st_uid,'gid':s.st_gid,'size':s.st_size,'dev':s.st_dev,'ino':s.st_ino,'nlink':s.st_nlink,'blocks':s.st_blocks,'mtime_ns':s.st_mtime_ns,'atime_ns':s.st_atime_ns,'ctime_ns':s.st_ctime_ns}
def samebytes(a,b):
 with open(a,'rb')as x,open(b,'rb')as y:
  while True:
   u,v=x.read(4*1024*1024),y.read(4*1024*1024)
   if u!=v:return False
   if not u:return True
def snapshot():
 inv={};dirs={};inodes={}
 for root in plan['roots']:
  for directory,subdirs,names in os.walk(root,followlinks=False):
   dirs[directory]=meta(directory)
   for n in subdirs+names:
    p=pathlib.Path(directory)/n;s=p.lstat();inv[str(p)]={'type':stat.S_IFMT(s.st_mode),'size':s.st_size,'mode':stat.S_IMODE(s.st_mode),'target':os.readlink(p)if stat.S_ISLNK(s.st_mode)else None}
    if stat.S_ISREG(s.st_mode):inodes[(s.st_dev,s.st_ino)]=s.st_blocks*512
 return inv,dirs,inodes
# Reject any changed candidate before the first mutation.
for item in plan['plan']:
 for name in ('source','target'):
  e=item[name]
  if meta(e['path'])!=e['before']:raise RuntimeError('Candidate changed since preflight '+e['path'])
before_inventory,before_dirs,before_inodes=snapshot();free_before=os.statvfs(H).f_bavail*os.statvfs(H).f_frsize
archive_hashes={}
for e in plan['inventory']:
 if e.get('skip')=='archive_untouched':
  p=str(pathlib.Path(e['root'])/e['relative_path']);archive_hashes[p]=sha(p)
completed=0;logical=0;errors=[];verified_source=set();changed_times=0
try:
 with gzip.open(details,'wt')as journal:
  for item in plan['plan']:
   a,b=item['source'],item['target'];ap,bp=pathlib.Path(a['path']),pathlib.Path(b['path']);am,bm=meta(ap),meta(bp)
   for x,want in ((am,a['before']),(bm,b['before'])):
    if any(x[k]!=want[k]for k in ('mode','uid','gid','size','dev','ino','mtime_ns')):raise RuntimeError('Candidate changed during execution')
   if a['path'] not in verified_source:
    if sha(ap)!=a['sha256']:raise RuntimeError('Source SHA changed')
    verified_source.add(a['path'])
   if sha(bp)!=b['sha256'] or a['sha256']!=b['sha256']:raise RuntimeError('Target SHA mismatch')
   temp=bp.parent/('.cache-dedup-'+str(os.getpid())+'-'+str(completed)+'.tmp')
   try:
    os.link(ap,temp,follow_symlinks=False);os.replace(temp,bp)
   finally:
    if temp.exists():temp.unlink()
   if not samebytes(ap,bp)or sha(bp)!=a['sha256']:raise RuntimeError('Post-replacement byte/SHA verification failed')
   aa,bb=meta(ap),meta(bp)
   if (aa['dev'],aa['ino'])!=(bb['dev'],bb['ino']):raise RuntimeError('Replacement is not a hardlink')
   changed_times+=bm['mtime_ns']!=bb['mtime_ns'];completed+=1;logical+=bm['size']
   journal.write(json.dumps({'source_path':str(ap),'target_path':str(bp),'sha256':a['sha256'],'source_before':a['before'],'target_before':b['before'],'source_after':aa,'target_after':bb,'xattrs':a['xattrs'],'byte_comparison':True},separators=(',',':'))+'\n')
except Exception as e:errors.append({'error':str(e),'traceback':traceback.format_exc()})
after_inventory,after_dirs,after_inodes=snapshot();archive_ok=all(sha(p)==h for p,h in archive_hashes.items());paths_bytes_inventory_unchanged=before_inventory==after_inventory
# Directory timestamp changes and original differing file timestamps are retained in the receipt, never hidden.
with gzip.open(H/'CACHE-DEDUP-DIRECTORY-METADATA.json.gz','wt')as f:json.dump({'before':before_dirs,'after':after_dirs},f,separators=(',',':'))
free_after=os.statvfs(H).f_bavail*os.statvfs(H).f_frsize
out={'status':'PASS'if not errors and archive_ok and paths_bytes_inventory_unchanged else 'PARTIAL_OR_FAILED','operation':'Atomic os.link(temp)+os.replace; SHA256 before/after and full byte comparison; regular files only; no pathname removal','scope_roots':plan['roots'],'completed_hardlink_targets':completed,'verified_source_files':len(verified_source),'logical_duplicate_bytes':logical,'allocated_unique_inode_bytes_before':sum(before_inodes.values()),'allocated_unique_inode_bytes_after':sum(after_inodes.values()),'exact_unique_inode_allocated_reduction_bytes':sum(before_inodes.values())-sum(after_inodes.values()),'filesystem_available_before_bytes':free_before,'filesystem_available_after_bytes':free_after,'filesystem_available_delta_bytes':free_after-free_before,'filesystem_delta_scope':'Shared filesystem; concurrent unrelated jobs and new receipt bytes can affect this measurement','full_path_type_size_mode_symlink_inventory_unchanged':paths_bytes_inventory_unchanged,'public_and_compressed_archive_files_untouched':len(archive_hashes),'all_archive_hashes_reverified':archive_ok,'metadata_timestamps_differing_after_link':changed_times,'metadata_note':'Mode/uid/gid/xattrs match before linking. Original file timestamps/dev/inode/link counts/blocks are preserved in details; shared inode timestamps and ctime/link-count changes are declared. Full directory before/after timestamps retained separately.','normalized_full_pairs':plan['normalized_full_pairs'],'proc_check':json.loads(pathlib.Path('/tmp/cache-dedup-proc.json').read_text()),'proc_classification':json.loads(pathlib.Path('/tmp/cache-dedup-live-denied.json').read_text()),'proc_limitation':'Two inaccessible live UID65534 infrastructure daemons dockerd/containerd; all 1005 other denied entries zombies. All accessible live experiment/user processes had no target writable descriptors/cwd/exe; candidate files UID1000 and no group/other write.','elapsed_apply_seconds':time.monotonic()-start,'errors':errors,'scripts':{p:sha(p)for p in('/tmp/cache_dedup_scan.py','/tmp/cache_dedup_apply.py')},'evidence':{str(p):sha(p)for p in(preflight,details,H/'CACHE-DEDUP-DIRECTORY-METADATA.json.gz')}}
with open(receipt,'x')as f:json.dump(out,f,indent=2);f.write('\n')
print(json.dumps({k:out[k]for k in('status','completed_hardlink_targets','logical_duplicate_bytes','exact_unique_inode_allocated_reduction_bytes','filesystem_available_before_bytes','filesystem_available_after_bytes','filesystem_available_delta_bytes','full_path_type_size_mode_symlink_inventory_unchanged','all_archive_hashes_reverified','elapsed_apply_seconds','errors')}));print('receipt_sha256 '+sha(receipt))
