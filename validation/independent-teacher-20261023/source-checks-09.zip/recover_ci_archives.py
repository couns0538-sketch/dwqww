#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Recover authenticated raw-Git CI archives incrementally, without Git fetch.

Use a private fresh recovery root. Original absolute-minus-leading-slash paths
are preserved underneath it; source-map files bind those restored paths. Only
verified downloaded opaque part caches are reclaimed, after local SHA proof.
"""
from __future__ import annotations
import argparse
from datetime import datetime,timezone
import errno
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import time
import urllib.error
import urllib.parse
import urllib.request
import multipart_dataset as multipart

MIB=1024*1024
SF_SHA='0f83d24cc46d2c66c60f16001af5444873bc112b7d028594513426894c12da19'


def utc():return datetime.now(timezone.utc).isoformat()

def atomic(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    temporary=path.with_name(path.name+'.pending');temporary.write_text(json.dumps(value,indent=2)+'\n')
    os.replace(temporary,path)

def safe_target(root,name):
    name=multipart.safe_name(name)
    if name.split('/')[0]=='.ci-recovery':raise ValueError('Reserved recovery metadata namespace')
    target=Path(root)/name
    for parent in reversed(target.parents):
        if parent==root or root in parent.parents:
            if parent.is_symlink() or (parent.exists() and not parent.is_dir()):raise ValueError('Unsafe existing ancestor: '+str(parent))
    return target

def check_file(path,record):
    try:info=path.lstat()
    except FileNotFoundError:return False
    if (not stat.S_ISREG(info.st_mode) or info.st_size!=record['bytes']
        or stat.S_IMODE(info.st_mode)!=record['mode'] or multipart.sha(path)!=record['sha256']):
        raise ValueError('Existing path collision differs: '+str(path))
    return True


def restore_group(manifest_path,expected_sha,root,staging):
    """Verify one group, preflight all paths, then merge using no-replace links."""
    root=Path(root).absolute();staging=Path(staging)
    manifest,verified=multipart.verified_snapshot(manifest_path,expected_sha)
    multipart.restore(manifest_path,expected_sha,staging)
    records=manifest['members']+manifest.get('aliases',[])
    registry_path=root/'.ci-recovery/members.json'
    registry=json.loads(registry_path.read_bytes()) if registry_path.exists() else {}
    combined=dict(registry);folded={name.casefold():name for name in registry}
    existing=0
    for record in records:
        name=record['path'];target=safe_target(root,name)
        old=folded.get(name.casefold())
        if old is not None and old!=name:raise ValueError('Cross-group casefold collision: '+name)
        folded[name.casefold()]=name
        prior=combined.get(name)
        identity={key:record[key] for key in ('bytes','sha256','mode')}
        if prior is not None and prior!=identity:raise ValueError('Cross-group member collision: '+name)
        combined[name]=identity
        if check_file(target,record):existing+=1
    components={}
    for name in combined:
        fields=name.split('/')
        for n in range(1,len(fields)+1):
            prefix='/'.join(fields[:n]);prior=components.setdefault(prefix.casefold(),prefix)
            if prior!=prefix:raise ValueError('Cross-group directory casefold collision: '+prefix)
    # Check namespace for file/ancestor conflicts across every group and alias.
    all_names=set(folded)
    for name in all_names:
        if any('/'.join(name.split('/')[:n]) in all_names for n in range(1,len(name.split('/')))):
            raise ValueError('Cross-group file/ancestor collision: '+name)
    created=[]
    for record in records:
        target=safe_target(root,record['path']);source=staging/record['path']
        target.parent.mkdir(parents=True,exist_ok=True)
        try:os.link(source,target,follow_symlinks=False);created.append(record['path'])
        except FileExistsError:check_file(target,record)
        check_file(target,record)
    proof={'status':'RESTORED_VERIFIED','utc':utc(),'manifest_sha256':expected_sha,
        'archive_sha256':manifest['archive']['sha256'],'parts':manifest['parts'],
        'local_members':[{'path':record['path'],**combined[record['path']]} for record in records],
        'created_files':len(created),'existing_verified':existing,'verification':verified}
    atomic(registry_path,combined)
    # Remove staging only; original restored files remain linked and untouched.
    shutil.rmtree(staging)
    return proof


def download(url,target,expected_sha=None,expected_bytes=None,cap=16*MIB):
    target=Path(target)
    if target.exists():
        if expected_sha and multipart.sha(target)==expected_sha and (expected_bytes is None or target.stat().st_size==expected_bytes):return
        raise ValueError('Existing downloaded evidence differs: '+str(target))
    target.parent.mkdir(parents=True,exist_ok=True);temporary=target.with_name(target.name+'.partial-'+str(time.time_ns()))
    digest=hashlib.sha256();count=0
    request=urllib.request.Request(url,headers={'User-Agent':'Forge-CI-recovery/1'})
    with urllib.request.urlopen(request,timeout=90) as incoming,temporary.open('xb') as outgoing:
        for block in iter(lambda:incoming.read(MIB),b''):
            count+=len(block)
            if count>cap or (expected_bytes is not None and count>expected_bytes):raise ValueError('Download exceeded declared byte bound')
            digest.update(block);outgoing.write(block)
        outgoing.flush();os.fsync(outgoing.fileno())
    if expected_bytes is not None and count!=expected_bytes:raise ValueError('Download byte count differs')
    if expected_sha is not None and digest.hexdigest()!=expected_sha:raise ValueError('Downloaded SHA256 differs')
    os.link(temporary,target);temporary.unlink()


class Recovery:
    def __init__(self,root,repo,shards,stockfish):
        self.root=Path(root).absolute();self.meta=self.root/'.ci-recovery';self.repo=repo;self.shards=shards;self.stockfish=Path(stockfish)
        if self.root.is_symlink():raise ValueError('Recovery root must be a private real directory')
        self.state_path=self.meta/'state.json'
        if self.root.exists():
            if not self.state_path.is_file():raise ValueError('Existing recovery root lacks ownership receipt')
            self.state=json.loads(self.state_path.read_bytes())
            supplied={str(k):v for k,v in shards.items()}
            if self.state['repo']!=repo or any(supplied.get(k)!=v for k,v in self.state['shards'].items()):raise ValueError('Recovery source identity changed')
            self.state['shards']=supplied;atomic(self.state_path,self.state)
        else:
            self.root.mkdir(parents=True,mode=0o700);self.meta.mkdir()
            self.state={'schema':'forge-ci-incremental-recovery-v1','created_utc':utc(),'repo':repo,
                'shards':{str(k):v for k,v in shards.items()},'groups':{},'hydrated':{},'status':'PARTIAL_RECOVERY'}
            atomic(self.state_path,self.state)

    def url(self,branch,path):
        return 'https://raw.githubusercontent.com/'+self.repo+'/refs/heads/'+urllib.parse.quote(branch,safe='/')+'/'+urllib.parse.quote(path,safe='/')

    def hydrate(self):
        for shard in self.shards:
            requirement=self.root/f'workspace/forge-independent-teacher-20261023/ci-shard-{shard}/external-tools-required.json'
            if not requirement.exists():continue
            for record in json.loads(requirement.read_bytes())['tools']:
                if record['sha256']!=SF_SHA or not re.fullmatch(r'/workspace/forge-independent-teacher-20261023/ci-shard-[0-3]/build/bin/stockfish',record['path']):raise ValueError('External tool hydration contract differs')
                destination=safe_target(self.root,record['path'].lstrip('/'))
                identity={'sha256':SF_SHA,'bytes':record['bytes'],'mode':0o755}
                if not check_file(destination,identity):
                    if not self.stockfish.is_file() or multipart.sha(self.stockfish)!=SF_SHA:raise ValueError('Trusted external Stockfish missing or SHA differs')
                    destination.parent.mkdir(parents=True,exist_ok=True)
                    if stat.S_IMODE(self.stockfish.stat().st_mode)==0o755:
                        try:os.link(self.stockfish,destination)
                        except OSError as error:
                            if error.errno!=errno.EXDEV:raise
                            with self.stockfish.open('rb') as incoming,destination.open('xb') as outgoing:shutil.copyfileobj(incoming,outgoing,MIB)
                            destination.chmod(0o755)
                    else:
                        with self.stockfish.open('rb') as incoming,destination.open('xb') as outgoing:shutil.copyfileobj(incoming,outgoing,MIB)
                        destination.chmod(0o755)
                check_file(destination,identity)
                self.state['hydrated'][record['path']]={'sha256':SF_SHA,'source':str(self.stockfish),'utc':utc(),'from_git':False}
        atomic(self.state_path,self.state)

    def poll(self):
        statuses={};new_groups=0
        for shard,branch in self.shards.items():
            directory=self.meta/f'shard-{shard}';status_path=directory/'statuses'/f'{time.time_ns()}.json'
            try:download(self.url(branch,'STATUS.json'),status_path,cap=8*MIB)
            except urllib.error.HTTPError as error:
                if error.code==404:statuses[str(shard)]='NOT_YET_PUBLISHED';continue
                raise
            status=json.loads(status_path.read_bytes());statuses[str(shard)]=status['status']
            if status['shard']!=shard:raise ValueError('Remote STATUS shard differs')
            for item in status['archives']:
                name=item['path'];digest=item['sha256'];key=f'{shard}:{name}'
                if not re.fullmatch(r'archive-\d+/RECOVERY-MANIFEST.json',name) or not re.fullmatch('[0-9a-f]{64}',digest):raise ValueError('Unsafe remote archive declaration')
                old=self.state['groups'].get(key)
                if old:
                    if old['manifest_sha256']!=digest:raise ValueError('Published archive identity changed')
                    proof_path=Path(old['local_proof'])
                    if not proof_path.is_relative_to(self.meta):raise ValueError('Pinned local recovery proof path differs')
                    proof_raw=proof_path.read_bytes()
                    if hashlib.sha256(proof_raw).hexdigest()!=old['proof_sha256']:
                        raise ValueError('Pinned local recovery proof differs')
                    proof=json.loads(proof_raw)
                    for record in proof['local_members']:
                        if not check_file(safe_target(self.root,record['path']),record):
                            raise ValueError('Previously restored member missing: '+record['path'])
                    continue
                cache=directory/'cache'/name.split('/')[0];manifest_path=cache/'RECOVERY-MANIFEST.json'
                download(self.url(branch,name),manifest_path,expected_sha=digest)
                manifest=json.loads(manifest_path.read_bytes())
                needed=sum(p['bytes'] for p in manifest['parts'])+manifest['archive']['bytes']+300*MIB
                if shutil.disk_usage(self.root).free<needed:raise RuntimeError('Disk bound insufficient for one download+fresh restore group')
                tracked=[]
                for part in manifest['parts']:
                    if not re.fullmatch(r'dataset\.zip\.\d+',part['name']) or not 0<part['bytes']<=31*MIB:raise ValueError('Unsafe opaque part declaration')
                    path=cache/part['name'];download(self.url(branch,name.rsplit('/',1)[0]+'/'+part['name']),path,
                        expected_sha=part['sha256'],expected_bytes=part['bytes'],cap=31*MIB);tracked.append(path)
                staging=directory/'staging'/f'{name.split("/")[0]}-{time.time_ns()}'
                proof=restore_group(manifest_path,digest,self.root,staging)
                proof.update(remote_branch=branch,remote_status_sha256=multipart.sha(status_path),remote_manifest_path=name)
                proof_path=directory/'proofs'/(name.split('/')[0]+'.json');atomic(proof_path,proof)
                self.state['groups'][key]={'manifest_sha256':digest,'local_proof':str(proof_path),'proof_sha256':multipart.sha(proof_path),'utc':utc()}
                atomic(self.state_path,self.state)
                # Reclaim exclusively the tracked, hash-verified cache parts.
                for path,part in zip(tracked,manifest['parts']):
                    if path.parent!=cache or multipart.sha(path)!=part['sha256']:raise ValueError('Cache changed before reclamation')
                    path.unlink()
                new_groups+=1
            mapping=[{'from':f'/workspace/forge-independent-teacher-20261023/ci-shard-{shard}',
                      'to':str(self.root/f'workspace/forge-independent-teacher-20261023/ci-shard-{shard}')},
                     {'from':'/workspace/dwqww','to':str(self.root/'workspace/dwqww')}]
            atomic(directory/'source-map.json',mapping)
        self.hydrate();complete=bool(statuses) and all(v=='SHARD_PREPARED_NOT_GLOBAL_QUALIFIED' for v in statuses.values())
        self.state.update(last_poll_utc=utc(),remote_statuses=statuses,status='ALL_DECLARED_SHARDS_RECOVERED_NOT_GLOBAL_QUALIFIED' if complete else 'PARTIAL_RECOVERY')
        atomic(self.state_path,self.state)
        result={'utc':utc(),'status':self.state['status'],'remote_statuses':statuses,'new_groups':new_groups,
            'total_groups':len(self.state['groups']),'disk_free_bytes':shutil.disk_usage(self.root).free}
        print(json.dumps(result),flush=True);return complete


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--repo',default='couns0538-sketch/dwqww')
    parser.add_argument('--shard',action='append',required=True,help='N=published_data_branch')
    parser.add_argument('--recovery-root',type=Path,required=True);parser.add_argument('--watch',action='store_true')
    parser.add_argument('--poll-seconds',type=float,default=60)
    parser.add_argument('--external-stockfish',type=Path,default=Path('/workspace/.cloud-setup/stockfish/stockfish/stockfish-linux-x86-64-universal'))
    args=parser.parse_args();shards={}
    for value in args.shard:
        index,branch=value.split('=',1);index=int(index)
        if index not in range(4) or index in shards:parser.error('Distinct shard numbers 0..3 required')
        shards[index]=branch
    if not re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+',args.repo) or not 1<=args.poll_seconds<=60:parser.error('Invalid repository/poll bound')
    recovery=Recovery(args.recovery_root,args.repo,shards,args.external_stockfish)
    try:
        while True:
            complete=recovery.poll()
            if complete:return 0
            if not args.watch:return 2
            time.sleep(args.poll_seconds)
    except BaseException as error:
        recovery.state.update(status='FAILED_PARTIAL_EVIDENCE_PRESERVED',error=repr(error),failed_utc=utc());atomic(recovery.state_path,recovery.state)
        raise

if __name__=='__main__':raise SystemExit(main())
