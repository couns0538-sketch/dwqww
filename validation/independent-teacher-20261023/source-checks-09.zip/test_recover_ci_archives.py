import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

BASE=Path(__file__).resolve().parent

def module(name):
    spec=importlib.util.spec_from_file_location(name,BASE/(name+'.py'))
    value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value

class RecoveryTests(unittest.TestCase):
    def setUp(self):
        self.temporary=tempfile.TemporaryDirectory();self.root=Path(self.temporary.name)
        self.parts=module('multipart_dataset')
        try:self.recovery=module('recover_ci_archives')
        except FileNotFoundError:self.fail('Incremental verified recovery helper is missing')
    def tearDown(self):self.temporary.cleanup()
    def pack(self,name,contents,aliases=None):
        files=[]
        for member,data in contents.items():
            path=self.root/(name+'-'+str(len(files)));path.write_bytes(data)
            files.append({'source':str(path),'member':member,'sha256':self.parts.sha(path),'bytes':len(data)})
        declaration=self.root/(name+'.json')
        alias_records=[{'source':next(f['source'] for f in files if f['member']==target),'member':name,'target':target} for name,target in (aliases or {}).items()]
        declaration.write_text(json.dumps({'status':'CLOSED_INPUTS_FROZEN','files':files,'aliases':alias_records}))
        destination=self.root/name;self.parts.pack(declaration,destination,part_bytes=113)
        return destination/'RECOVERY-MANIFEST.json'
    def test_incremental_exact_collision_and_alias(self):
        first=self.pack('one',{'workspace/shard/a':b'first'})
        second=self.pack('two',{'workspace/shard/a':b'first','workspace/shard/b':b'second'},{'workspace/shard/c':'workspace/shard/b'})
        destination=self.root/'recovered';destination.mkdir()
        self.recovery.restore_group(first,self.parts.sha(first),destination,self.root/'stage1')
        before=(destination/'workspace/shard/a').stat()
        result=self.recovery.restore_group(second,self.parts.sha(second),destination,self.root/'stage2')
        self.assertEqual((destination/'workspace/shard/a').read_bytes(),b'first')
        self.assertEqual((destination/'workspace/shard/a').stat().st_ino,before.st_ino)
        self.assertEqual((destination/'workspace/shard/b').read_bytes(),b'second')
        self.assertEqual(result['existing_verified'],1)
        self.assertEqual((destination/'workspace/shard/b').stat().st_ino,(destination/'workspace/shard/c').stat().st_ino)
    def test_conflict_preflight_preserves_all_existing_files(self):
        manifest=self.pack('conflict',{'workspace/a':b'new','workspace/z':b'expected'})
        destination=self.root/'recovered';(destination/'workspace').mkdir(parents=True)
        (destination/'workspace/z').write_bytes(b'original evidence')
        with self.assertRaisesRegex(ValueError,'collision'):
            self.recovery.restore_group(manifest,self.parts.sha(manifest),destination,self.root/'stage')
        self.assertFalse((destination/'workspace/a').exists())
        self.assertEqual((destination/'workspace/z').read_bytes(),b'original evidence')
    def test_cross_group_directory_case_collision_rejected(self):
        first=self.pack('first-case',{'workspace/Directory/a':b'one'})
        second=self.pack('second-case',{'workspace/directory/b':b'two'})
        destination=self.root/'recovered';destination.mkdir()
        self.recovery.restore_group(first,self.parts.sha(first),destination,self.root/'stage1')
        with self.assertRaisesRegex(ValueError,'casefold'):
            self.recovery.restore_group(second,self.parts.sha(second),destination,self.root/'stage2')
        self.assertFalse((destination/'workspace/directory/b').exists())
    def test_symlink_ancestor_never_writes_outside_recovery(self):
        manifest=self.pack('symlink',{'workspace/sub/a':b'payload'})
        destination=self.root/'recovered';destination.mkdir();outside=self.root/'outside';outside.mkdir()
        (destination/'workspace').symlink_to(outside,target_is_directory=True)
        with self.assertRaisesRegex(ValueError,'ancestor'):
            self.recovery.restore_group(manifest,self.parts.sha(manifest),destination,self.root/'stage')
        self.assertEqual(list(outside.iterdir()),[])
    def test_resume_rechecks_local_member_and_pinned_proof(self):
        import shutil
        manifest=self.pack('resume',{'workspace/shard/a':b'authentic'})
        remote=self.root/'remote';remote.mkdir();shutil.copytree(manifest.parent,remote/'archive-0000')
        status={'status':'SHARD_PREPARED_NOT_GLOBAL_QUALIFIED','shard':0,'archives':[{'path':'archive-0000/RECOVERY-MANIFEST.json','sha256':self.parts.sha(manifest)}]}
        (remote/'STATUS.json').write_text(json.dumps(status))
        recovery=self.recovery.Recovery(self.root/'recovered','owner/repo',{0:'branch'},self.root/'unused-stockfish')
        recovery.url=lambda branch,path:(remote/path).as_uri()
        self.assertTrue(recovery.poll())
        self.assertEqual(list((recovery.meta/'shard-0/cache').rglob('dataset.zip.*')),[])
        local=recovery.root/'workspace/shard/a';local.write_bytes(b'corrupt')
        with self.assertRaisesRegex(ValueError,'collision'):recovery.poll()
        local.write_bytes(b'authentic')
        proof=Path(next(iter(recovery.state['groups'].values()))['local_proof'])
        proof.write_bytes(proof.read_bytes()+b' ')
        with self.assertRaisesRegex(ValueError,'proof'):recovery.poll()
    def test_corrupt_part_rejected_before_merge(self):
        manifest=self.pack('corrupt',{'workspace/a':b'payload'})
        part=next(manifest.parent.glob('dataset.zip.*'));part.write_bytes(b'broken')
        destination=self.root/'recovered';destination.mkdir()
        with self.assertRaises((ValueError,AssertionError)):
            self.recovery.restore_group(manifest,self.parts.sha(manifest),destination,self.root/'stage')
        self.assertEqual(list(destination.iterdir()),[])

if __name__=='__main__':unittest.main(verbosity=2)
