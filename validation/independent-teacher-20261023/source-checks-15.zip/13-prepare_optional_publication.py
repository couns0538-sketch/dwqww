"""Prepare final optional handoff after closed Windows research validation."""
import argparse
import datetime
import hashlib
import json
import shutil
import zipfile
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('--package', type=Path, required=True)
p.add_argument('--package-validation', type=Path, required=True)
p.add_argument('--archive', type=Path, required=True)
p.add_argument('--archive-validation', type=Path, required=True)
a = p.parse_args()
h = Path('/workspace/forge-buckets8-20261023')
v = h / 'publication/validation/nnue-buckets8-20261023'

def identity(path):
    raw = Path(path).read_bytes()
    return {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}

for path in (a.package, a.archive):
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None
for path in (a.package_validation, a.archive_validation):
    receipt = json.loads(path.read_text())
    assert str(receipt.get('status', '')).startswith('PASS'), receipt.get('status')
bound = h / 'WINDOWS-BOUND-REPEAT-VALIDATION.json'
actual = h / 'WINDOWS-ACTUAL-VALIDATION-v2.json'
assert json.loads(bound.read_text())['status'].startswith('PASS')
assert json.loads(actual.read_text())['status'].startswith('PASS')

release_rel = 'releases/forge-6.4.24-buckets8-experimental-windows-zen5'
release_dir = h / 'publication' / release_rel
release_dir.mkdir(parents=True, exist_ok=False)
package_name = 'forge-6.4.24-buckets8-EXPERIMENTAL-NPS-UNRESOLVED-windows-zen5.zip'
shutil.copyfile(a.package, release_dir / package_name)
shutil.copyfile(a.archive, v / 'WINDOWS-EVIDENCE.zip')
assert identity(a.package) == identity(release_dir / package_name)
assert identity(a.archive) == identity(v / 'WINDOWS-EVIDENCE.zip')

manifest_path = v / 'manifest.json'
m = json.loads(manifest_path.read_text())
m['updated_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
m['source_commit'] = 'a1fcc36acbacc5f78a17ecfd5377068d738f9191'
m['windows_comparison_artifact'] = {
    'status': 'WINE_VALIDATED_RESEARCH_ONLY_NPS_UNRESOLVED',
    'artifact': release_rel + '/' + package_name, **identity(a.package),
    'compiler': 'LLVM-MinGW20261006ucrtClang23.1.3',
    'flags': '-march=znver5 -mtune=znver5 -fno-fast-math -ffp-contract=off -fno-lto',
    'runtime': 'Wine on Linux; NOT nativeWindows or Ryzen hardware',
    'regression_groups_passed': 15,
    'fresh_hash_bound_parity': '10000/10000exactintegerCP;maxerror0;feature0;all8buckets/bothSTM;equalshippedreference',
    'same_platform_bench11_nodes': 334752,
    'shipped_Windows_bench11_nodes': 334752,
    'Linux_bench11_nodes_separate': 292545,
    'actual_exe_sha256': 'e8fd5d45454ca8f52f77fac3c77d60ef0b7a66e3226ffc4c4f9c7e6a29ae0ec4',
    'included_baseline_exe_sha256': 'b58058055615e299ed49279929ee71fced5d505845d8049dabaeed57aa07269c',
    'actual_validation': identity(actual), 'fresh_bound_repeat': identity(bound),
    'package_verification': identity(a.package_validation),
    'network': 'EightduplicatedSHIPPEDheads;NOTlearnedepoch7',
    'PC_helper': 'stdlib-only;counterbalanced20pairs;8benchcalls/process;originalrawstreams;fake-subprocessunittestsONLYhere',
    'PC_helper_metric': 'Process-wallcomparisonclearlylabelleddiagnostic;doesNOTautomaticallyqualifyexistinginternalbench-NPSgate',
    'speed_gate': 'UNPROVEN', 'matches': 0, 'elo': 'unproven', 'accepted': False,
}
m['artifacts']['WINDOWS-EVIDENCE.zip'] = {
    **identity(a.archive), 'validation_receipt': identity(a.archive_validation),
    'scope': 'AlloriginalWindows/Wineruns,raw10kcorpora/parity,strictsource/PE/compilebindings,before-afterhash-boundrepeat,oldhelperlabeldraftandcorrectedhelpertests/packageverification.',
}
m['artifacts'][release_rel + '/' + package_name] = identity(a.package)
m['limitations'].append('PChelperprocess-wallthresholdisdiagnosticanddoesnotaccepttheexistinginternalbench-NPSgate;nativeWindowshelpernotrunhere.')
manifest_path.write_text(json.dumps(m, indent=2) + '\n')

report_path = v / 'FINAL_REPORT.md'
old = report_path.read_text()
old_tail = old.index('A Windows research comparison artifact is being built')
report = old[:old_tail] + (
    'The Windows Zen5 research comparison package passes **15 regression groups**\n'
    'and **10,000-position exact C++ parity under Wine**. A fresh repeat binds\n'
    'the actual PE, probe, core, sources and tools before/after execution. Windows\n'
    'bench repeats the shipped Windows **334,752-node** signature; Linux\n'
    '292,545 is a separate compiler/platform signature. Strict arithmetic, imports\n'
    'and actual NNUE SIMD code pass inspection. The package includes the exact\n'
    'accepted Windows baseline and a raw-evidence comparison helper. Its process-wall\n'
    'diagnostic cannot automatically accept the existing internal bench-NPS gate;\n'
    'the original misleading label/draft and corrected unit tests are preserved.\n\n'
    '**Native Windows/Ryzen speed, ≤5% overhead and Elo remain unproven.**\n'
    'This is an explicitly experimental comparison artifact, not an accepted release.\n'
    'The accepted engine remains unchanged. No matches ran. Next: measure the\n'
    'unchanged bench-NPS gate on stable target hardware, then preregister any\n'
    'future bucket training and apply the user PC game gate. `WINDOWS-EVIDENCE.zip`\n'
    'and the manifest retain the original proof and every artifact checksum.\n'
)
assert len(report.split()) < 650
report_path.write_text(report)
receipt = {'status': 'PASS_FINAL_OPTIONAL_PUBLICATION_STAGED_NOT_YET_COMMITTED',
    'package': {'path': str(release_dir / package_name), **identity(a.package)},
    'windows_evidence': {'path': str(v / 'WINDOWS-EVIDENCE.zip'), **identity(a.archive)},
    'report_words': len(report.split()), 'source_commit': m['source_commit'],
    'unchanged_gate': m['performance_gate'], 'elo': 'unproven'}
(h / 'OPTIONAL-PUBLICATION-STAGING.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
