"""Close the main handoff after immutable optional-artifact public readback."""
import argparse
import datetime
import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--optional-public-result', type=Path, required=True)
args = parser.parse_args()
repo = Path('/workspace/dwqww')
home = Path('/workspace/forge-independent-teacher-20261023')
optional = Path('/workspace/forge-buckets8-20261023')
target = repo / 'validation/independent-teacher-20261023'

def identity(path):
    data = Path(path).read_bytes()
    return {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}

publication = json.loads((optional / 'git-windows-checkpoint/RESULT.json').read_text())
public = json.loads(args.optional_public_result.read_text())
assert public['source_commit'] == publication['commit']
assert public['status'].startswith('PASS')
optional_manifest_path = optional / 'publication/validation/nnue-buckets8-20261023/manifest.json'
optional_manifest = json.loads(optional_manifest_path.read_text())
assert optional_manifest['windows_comparison_artifact']['status'] == 'WINE_VALIDATED_RESEARCH_ONLY_NPS_UNRESOLVED'
now = datetime.datetime.now(datetime.timezone.utc).isoformat()
skill = repo / '.agents/skills/validating-chess-simd/SKILL.md'
assert identity(skill)['sha256'] == '73516c049078521648ce94276b3284459fc820af65a1de11d2ddca2947e16c4a'
unchanged = subprocess.run(['git', 'diff', '--exit-code',
    '1ab50b2dd64d9b2f752f7f1285f6968cad2fd792', '--', 'src', 'include'],
    cwd=repo, capture_output=True)
assert unchanged.returncode == 0, unchanged.stdout.decode()
assert identity(repo / 'src/nnue_weights.inc')['sha256'] == '41487f328ff51f27417564df45b6f3139d038b7e940dedb121340bd61be9a4d3'
preservation = optional / 'FINAL-CHECKOUT-PRESERVATION.json'
preservation.write_text(json.dumps({
    'status': 'PASS_ROOT_SRC_INCLUDE_AND_SHIPPED_NET_UNCHANGED',
    'compared_source': '1ab50b2dd64d9b2f752f7f1285f6968cad2fd792',
    'git_diff_actual_exit': unchanged.returncode,
    'root_head_before_final_documentation_commit': subprocess.check_output(
        ['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip(),
    'root_status_before_final_documentation_commit': subprocess.check_output(
        ['git', 'status', '--porcelain'], cwd=repo).decode().splitlines(),
    'shipped_weights': identity(repo / 'src/nnue_weights.inc'),
}, indent=2) + '\n')

continuation = {
    'utc': now,
    'status': 'ALL_CURRENT_WORK_CHECKPOINTED_NO_NEW_EXPERIMENTS',
    'accepted_engine': {'version': 'Forge6.4.24', 'source': '1ab50b2dd64d9b2f752f7f1285f6968cad2fd792',
                        'weights_sha256': '41487f328ff51f27417564df45b6f3139d038b7e940dedb121340bd61be9a4d3', 'unchanged': True},
    'main_branch': 'forge/independent-teacher-20261023',
    'main_previous_published_commit': 'e44e20fc001cca325eec0daa2ab42f4dc286634f',
    'data_commit': '442d5647612591a2d5a387c0513f5b482c07d6e8',
    'trained_net_research_commit': '2b3038f5f1ec61c72f580d4036fda3cda1af97c2',
    'trained_net_native_gate': 'BLOCKED:13/14originalgroups;2underpromotionassertions;no gate/test weakened',
    'training_runs': 1, 'audit_runs': 1, 'matches': 0, 'elo': 'unproven',
    'optional_branch': publication['branch'], 'optional_commit': publication['commit'],
    'optional_source_commit': publication['parent'],
    'optional_public_readback': identity(args.optional_public_result),
    'optional_speed_gate': 'UNPROVEN: both paired VM trials retained, no samples removed',
    'optional_windows': optional_manifest['windows_comparison_artifact'],
    'skill': {'path': str(skill.relative_to(repo)), **identity(skill), 'reused_existing': True,
              'new_duplicate_skills': 0, 'global_installation_claimed': False},
    'next_actions': [
        'Run the supplied counterbalanced Windows comparison on Ryzen7 9850X3D; preserve raw output. Evaluate the unchanged >=.95 bench-NPS ratio/95%lower gate separately from the helper process-wall diagnostic; no automatic gate pass.',
        'In a separate isolated source experiment, reproduce the selected-net delayed rook-mate discovery and isolate the suspected evaluation/search-selectivity interaction; root cause remains unproven.',
        'Only after correctness acceptance use the user PC1000-game paired SPRT gate. No playing-strength claim from loss, parity or NPS.',
        'Future real eight-bucket training requires a fresh preregistered protocol and previously unseen whole-game audit; no second training run was started here.',
    ],
    'environment': {'runtime': 'Linux; Windows tests under Wine', 'native_windows_ryzen_tested': False,
                    'skill_creator_callable': False, 'CodeRabbit_CLI_available': False,
                    'git_and_public_raw_access': True},
    'stop_new_work_utc': '2026-10-23T23:34:09+00:00',
    'hard_deadline_utc': '2026-10-24T00:04:09+00:00',
}
closed = optional / 'FINAL-CONTINUATION.json'
closed.write_text(json.dumps(continuation, indent=2) + '\n')

evidence = [
    closed, args.optional_public_result,
    optional / 'public-readback-a1fcc36/RESULT.json',
    optional / 'git-source-checkpoint/RESULT.json',
    optional / 'git-windows-checkpoint/RESULT.json',
    optional_manifest_path,
    optional / 'publication/validation/nnue-buckets8-20261023/FINAL_REPORT.md',
    optional / 'SKILL-MAINTENANCE-RESULT.json',
    optional / 'skill-before-buckets-de2a45a61789.md',
    skill, preservation, optional / 'publish_source_checkpoint.py', optional / 'publish_windows_checkpoint.py',
    optional / 'prepare_optional_publication.py', optional / 'OPTIONAL-PUBLICATION-STAGING.json',
    Path(__file__), home / 'public-readback-e44e20f/RESULT.json',
]
archive = target / 'source-checks-15.zip'
assert not archive.exists()
inventory = []
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for index, path in enumerate(evidence):
        data = path.read_bytes()
        name = f'{index:02d}-{path.name}'
        inventory.append({'source': str(path), 'member': name, **identity(path)})
        item = zipfile.ZipInfo(name)
        item.create_system = 3
        item.external_attr = (0o100644 << 16)
        item.compress_type = zipfile.ZIP_DEFLATED
        z.writestr(item, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    z.writestr('MANIFEST.json', json.dumps(inventory, indent=2) + '\n')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for item in inventory:
        raw = z.read(item['member'])
        assert hashlib.sha256(raw).hexdigest() == item['sha256']
        assert len(raw) == item['bytes']

manifest_path = target / 'manifest.json'
manifest = json.loads(manifest_path.read_text())
manifest['updated_utc'] = now
manifest['status'] = 'MAIN_COMPLETE_RESEARCH_NET_NATIVE_BLOCKED_OPTIONAL_IMPLEMENTED_SPEED_UNPROVEN'
manifest['optional_buckets8'] = {
    'status': 'PUBLISHED_EXPERIMENTAL_NOT_ACCEPTED', 'branch': publication['branch'],
    'source_commit': publication['parent'], 'artifact_commit': publication['commit'],
    'parent': '1ab50b2dd64d9b2f752f7f1285f6968cad2fd792',
    'network': 'All8headsduplicateSHIPPED;notlearnedepoch7', 'real_training_runs': 0,
    'release_ctest': '15/15PASS', 'asan_ubsan_ctest': '15/15PASS;leakdetectiondisabled',
    'linux_cpp_parity': '2x10000exactCP0andfeature0;all8/bothSTM/distinctheadscontrol',
    'performance_gate': 'UNPROVEN;pairedVMresultsinconclusive;thresholdunchanged/noexclusions',
    'windows_comparison': optional_manifest['windows_comparison_artifact'],
    'artifacts': optional_manifest['artifacts'], 'public_readback': identity(args.optional_public_result),
    'matches': 0, 'elo': 'unproven', 'accepted': False,
}
manifest['artifacts']['source-checks-15.zip'] = {**identity(archive), 'members': len(evidence) + 1,
    'status': 'PASS_ZIP_CRC_AND_ALL_MEMBER_SHA_READBACK',
    'scope': 'Closedoptionalpublications,exactGit/source/artifactlinks,reusedskillmaintenanceandconcisecontinuation;rawnative/Windowsarchivesremainonisolatedbranch.'}
manifest['skills']['current_actual_use']['skill_sha256'] = identity(skill)['sha256']
manifest['skills']['current_actual_use']['maintenance_receipt_sha256'] = identity(optional / 'SKILL-MAINTENANCE-RESULT.json')['sha256']
manifest['skills']['current_actual_use']['bucket_parity_and_native_gate_guidance_added'] = True
manifest['skills']['current_actual_use']['new_duplicate_skills'] = 0
manifest['next_action'] = continuation['next_actions']
manifest['continuation'] = continuation
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')

report_path = target / 'FINAL_REPORT.md'
report = report_path.read_text()
report += (
    '\n## Optional eight-output candidate\n\n'
    'The separate experimental branch now contains eight piece-count heads, a QAT\n'
    'trainer/exporter and regression tests. All heads duplicate the **shipped** net;\n'
    'this is not the learned epoch-7 candidate. Linux Release **15/15** and separate\n'
    '**ASan/UBSan 15/15** pass; two 10,000-position C++ parity runs match exactly,\n'
    'including a distinct-head control. The Windows comparison package passes\n'
    '**15 regression groups and 10,000-position exact parity under Wine**. Native\n'
    'Windows/Ryzen testing is pending. Both original 20-pair VM speed studies are\n'
    'inconclusive, so the ≤5% overhead gate remains **unproven**. Source, original\n'
    'raw evidence, exact baseline executable and a target-PC comparison helper are\n'
    f'published at `{publication["commit"]}`. The manifest links every artifact.\n'
    'No accepted-engine change, matches or Elo claim resulted.\n'
)
assert len(report.split()) <= 800
report_path.write_text(report)
for path in (home / 'RUNNING-STATE.json', optional / 'RUNNING_STATE.json'):
    old = json.loads(path.read_text())
    old['updated_utc'] = now
    old['phase'] = 'FINAL_HANDOFF_AND_PUBLICATION_NO_NEW_EXPERIMENTS'
    old['final_continuation'] = continuation
    old['next'] = continuation['next_actions']
    old['optional8_current_state'] = {
        'branch': publication['branch'], 'published_commit': publication['commit'],
        'code_commit': publication['parent'], 'speed_gate': 'UNPROVEN',
        'active_jobs': [], 'accepted': False,
    }
    if path.parent == optional:
        old['branch_not_yet_created'] = False
        old['branch'] = publication['branch']
        old['published_commit'] = publication['commit']
        old['active_performance'] = None
        old['windows_plan'] = 'CLOSED_WINE_VALIDATION_AND_RESEARCH_PACKAGE_PUBLISHED'
    path.write_text(json.dumps(old, indent=2) + '\n')
print(json.dumps({'archive': str(archive), **identity(archive),
                  'report_words': len(report.split()), 'optional_commit': publication['commit']}))
