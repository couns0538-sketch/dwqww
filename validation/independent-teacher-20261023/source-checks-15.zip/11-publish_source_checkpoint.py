"""Create an isolated, explicitly experimental code/evidence commit using a private index."""
import hashlib,json,os,subprocess
from pathlib import Path
h=Path('/workspace/forge-buckets8-20261023');s=h/'source';r=Path('/workspace/dwqww')
base='1ab50b2dd64d9b2f752f7f1285f6968cad2fd792'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(*args,env=None,data=None):return subprocess.check_output(['git',*args],cwd=r,env=env,input=data)
def root_state():return {'head':git('rev-parse','HEAD').decode().strip(),'index_sha256':sha(r/'.git/index'),'net_sha256':sha(r/'src/nnue_weights.inc'),'skill_sha256':sha(r/'.agents/skills/validating-chess-simd/SKILL.md')}
before=root_state();assert before['net_sha256']=='41487f328ff51f27417564df45b6f3139d038b7e940dedb121340bd61be9a4d3'
original=json.loads((h/'SOURCE-BASELINE.json').read_text())['files']
allowed={'CMakeLists.txt','src/nnue.cpp','src/nnue_weights.inc','include/forge/nnue.hpp'}
files={}
for path,record in original.items():
    p=s/path;assert p.is_file(),path
    if sha(p)!=record['sha256']:
        assert path in allowed,path
        files[path]=p
for p in s.rglob('*'):
    if not p.is_file() or '__pycache__' in p.parts:continue
    path=str(p.relative_to(s))
    if path not in original:
        assert path.startswith('tools/nnue/') or path=='tests/nnue_bucket_tests.cpp',path
        assert p.suffix in ('.py','.cpp','.json','.txt'),path
        files[path]=p
v=h/'publication/validation/nnue-buckets8-20261023'
for p in v.iterdir():
    assert p.name in ('manifest.json','FINAL_REPORT.md','NATIVE-EVIDENCE.zip')
    files['validation/nnue-buckets8-20261023/'+p.name]=p
out=h/'git-source-checkpoint';out.mkdir(exist_ok=False)
env={**os.environ,'GIT_INDEX_FILE':str(out/'private-index')};git('read-tree',base,env=env)
identities={}
for path,p in sorted(files.items()):
    raw=p.read_bytes();blob=git('hash-object','-w','--stdin',data=raw).decode().strip()
    git('update-index','--add','--cacheinfo','100644',blob,path,env=env)
    identities[path]={'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
tree=git('write-tree',env=env).decode().strip()
message=('EXPERIMENTAL: eight material output heads with trainer and parity evidence\n\n'
         'Initial heads replicate accepted Forge6.4.24 network. No new real-data training.\n'
         'Release15/15 and ASan/UBSan15/15 pass; two10000position C++ parity runs exact.\n'
         'Both paired NPS studies are inconclusive; <=5% overhead unproven. Not accepted engine.\n'
         'No matches or Elo claims. Original failures and all timing samples retained.\n')
commit=git('commit-tree',tree,'-p',base,data=message.encode()).decode().strip()
assert sorted(git('diff','--name-only',base,commit).decode().splitlines())==sorted(files)
assert git('rev-list','--parents','-n','1',commit).decode().split()==[commit,base]
for path,p in files.items():assert git('show',commit+':'+path)==p.read_bytes(),path
assert root_state()==before
branch='forge/nnue-buckets8-EXPERIMENTAL-20261023-0e1585e2'
git('update-ref','refs/heads/'+branch,commit,'0'*40)
result={'status':'LOCAL_EXPERIMENTAL_COMMIT_CREATED_NOT_PUSHED','branch':branch,'commit':commit,'parent':base,'files':identities,'root_before_after_equal':before,'performance_gate':'UNPROVEN','accepted':False,'elo':'unproven'}
(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='files'}))
