"""Publish only reviewed optional research artifacts, using an isolated Git index."""
import hashlib
import json
import os
import subprocess
from pathlib import Path

home = Path('/workspace/forge-buckets8-20261023')
repo = Path('/workspace/dwqww')
parent = 'a1fcc36acbacc5f78a17ecfd5377068d738f9191'
branch = 'forge/nnue-buckets8-EXPERIMENTAL-20261023-0e1585e2'

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def git(*args, env=None, data=None):
    return subprocess.check_output(['git', *args], cwd=repo, env=env, input=data)

def root_state():
    return {
        'head': git('rev-parse', 'HEAD').decode().strip(),
        'index_sha256': sha(repo / '.git/index'),
        'net_sha256': sha(repo / 'src/nnue_weights.inc'),
        'skill_sha256': sha(repo / '.agents/skills/validating-chess-simd/SKILL.md'),
    }

before = root_state()
assert before['net_sha256'] == '41487f328ff51f27417564df45b6f3139d038b7e940dedb121340bd61be9a4d3'
assert git('rev-parse', 'refs/heads/' + branch).decode().strip() == parent
allowed_roots = [
    'validation/nnue-buckets8-20261023',
    'releases/forge-6.4.24-buckets8-experimental-windows-zen5',
]
files = {}
for root in allowed_roots:
    for path in (home / 'publication' / root).rglob('*'):
        if path.is_file():
            files[str(path.relative_to(home / 'publication'))] = path
assert any(name.endswith('WINDOWS-EVIDENCE.zip') for name in files)
assert any(name.endswith('windows-zen5.zip') for name in files)
manifest = json.loads(files['validation/nnue-buckets8-20261023/manifest.json'].read_text())
assert manifest['windows_comparison_artifact']['status'] == 'WINE_VALIDATED_RESEARCH_ONLY_NPS_UNRESOLVED'
assert manifest['performance_gate'].startswith('UNPROVEN')
out = home / 'git-windows-checkpoint'
out.mkdir(exist_ok=False)
env = {**os.environ, 'GIT_INDEX_FILE': str(out / 'private-index')}
git('read-tree', parent, env=env)
identities = {}
for name, path in sorted(files.items()):
    raw = path.read_bytes()
    blob = git('hash-object', '-w', '--stdin', data=raw).decode().strip()
    git('update-index', '--add', '--cacheinfo', '100644', blob, name, env=env)
    identities[name] = {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}
tree = git('write-tree', env=env).decode().strip()
message = (
    'Preserve Wine-validated experimental Windows comparison and original evidence\n\n'
    'Eight duplicated shipped heads; not the learned independent-teacher net.\n'
    '15 regression groups and exact 10000-position Windows parity pass under Wine.\n'
    'Physical Ryzen NPS gate unresolved; no accepted-engine change or Elo claim.\n'
)
commit = git('commit-tree', tree, '-p', parent, data=message.encode()).decode().strip()
changed = git('diff', '--name-only', parent, commit).decode().splitlines()
assert changed and all(any(name.startswith(root + '/') for root in allowed_roots) for name in changed)
assert not git('diff', '--name-only', parent, commit, '--', 'src', 'include', 'CMakeLists.txt', 'tests', 'tools').strip()
for name, path in files.items():
    assert git('show', commit + ':' + name) == path.read_bytes(), name
assert root_state() == before
git('update-ref', 'refs/heads/' + branch, commit, parent)
result = {'status': 'LOCAL_COMMIT_CREATED_NOT_YET_PUSHED', 'branch': branch,
          'commit': commit, 'parent': parent, 'files': identities, 'changed': changed,
          'root_state_unchanged': before, 'accepted_engine_changed': False,
          'performance_gate': 'UNPROVEN', 'elo': 'unproven'}
(out / 'RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key not in ('files', 'changed')}))
