import gzip,hashlib,json,os,signal,subprocess,time
from pathlib import Path
root=Path('/workspace/forge-independent-teacher-20261023/generation-agent/contract-e2e-live-v2')
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
base=Path('/workspace/forge-independent-teacher-20261023/generation-agent')
gen=json.loads((base/'production-command.json').read_text())['argv']
for flag,value in [('--out',str(root/'games')),('--games','16'),('--chunk-games','256'),('--time-limit-seconds','60')]:gen[gen.index(flag)+1]=value
teacher=json.loads(Path('/workspace/forge-independent-teacher-20261023/collection-run-01/commands.json').read_text())['labeler']['argv']
for flag,value in [('--input-dir',str(root/'games')),('--output-dir',str(root/'labels')),('--idle-timeout','300'),('--stop-file',str(root/'labels'/'STOP_LABELING'))]:teacher[teacher.index(flag)+1]=value
pins={path:sha(path) for path in [gen[1],teacher[1],gen[gen.index('--engine')+1],gen[gen.index('--opponent')+1]]}
(root/'commands.json').write_text(json.dumps({'generator':gen,'labeler':teacher,'pins':pins},indent=2)+'\n')
processes=[];handles=[];paused=False;result={'status':'failed'}
try:
 for kind,command in [('generator',gen)]:
  out=(root/(kind+'.stdout')).open('wb');err=(root/(kind+'.stderr')).open('wb');handles += [out,err]
  producer=subprocess.Popen(command,stdout=out,stderr=err,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'});processes.append(producer)
 deadline=time.monotonic()+15
 while True:
  trace=root/'games'/'process-trace.jsonl.gz'
  if trace.exists() and trace.stat().st_size>0:
   os.kill(producer.pid,signal.SIGSTOP);paused=True;break
  if producer.poll() is not None:raise RuntimeError('producer exited before startup race could be exercised')
  if time.monotonic()>deadline:raise TimeoutError('producer never published genuine process trace')
  time.sleep(.001)
 assert not list((root/'games'/'chunks').glob('*.jsonl.gz'))
 with gzip.open(trace,'rt') as stream:startup_events=[json.loads(line) for line in stream]
 assert startup_events and all('game_id' not in event for event in startup_events)
 result['startup_state']={'real_producer_pid':producer.pid,'producer_paused':True,'canonical_chunks':0,'genuine_trace_events':len(startup_events),'trace_first_fields':list(startup_events[0])}
 out=(root/'labeler.stdout').open('wb');err=(root/'labeler.stderr').open('wb');handles += [out,err]
 follower=subprocess.Popen(teacher,stdout=out,stderr=err,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'});processes.append(follower)
 deadline=time.monotonic()+20
 while not (root/'labels'/'manifest.json').exists():
  if follower.poll() is not None:raise RuntimeError('teacher exited during empty-chunks startup')
  if time.monotonic()>deadline:raise TimeoutError('teacher never published running manifest')
  time.sleep(.02)
 time.sleep(1.2)
 assert follower.poll() is None,'teacher failed while canonical chunks empty and genuine trace visible'
 label_start=json.loads((root/'labels'/'manifest.json').read_text());assert label_start['status']=='running' and not label_start['chunks']
 result['empty_canonical_wait']='PASS'
 os.kill(producer.pid,signal.SIGCONT);paused=False
 result['generator_exit']=producer.wait(timeout=60)
 deadline=time.monotonic()+90
 while True:
  current=json.loads((root/'labels'/'manifest.json').read_text())
  if sum(chunk['games'] for chunk in current['chunks'])==16:
   (root/'labels'/'STOP_LABELING').touch();break
  if follower.poll() is not None:raise RuntimeError('teacher ended before all real generated games committed')
  if time.monotonic()>deadline:raise TimeoutError('teacher did not label all real generated games')
  time.sleep(.1)
 result['labeler_exit']=follower.wait(timeout=15)
 assert result['generator_exit']==0 and result['labeler_exit']==0
 gm=json.loads((root/'games'/'manifest.json').read_text());lm=json.loads((root/'labels'/'manifest.json').read_text())
 assert gm['status']=='PASS_COMPLETED_GAMES_OWNED_ENGINES_CLOSED' and lm['status']=='complete'
 assert gm['completed_games']==16 and sum(c['games'] for c in lm['chunks'])==16
 source_game_ids=set();label_game_ids=set();source_rows=label_rows=0
 for metadata in gm['chunks']:
  assert sha(root/'games'/metadata['path'])==metadata['sha256']
  for line in gzip.open(root/'games'/metadata['path'],'rt'):
   game=json.loads(line);source_game_ids.add(game['game_id']);source_rows+=len(game['samples'])
   assert all(row['game_id']==game['game_id'] for row in game['samples'])
 for metadata in lm['chunks']:
  path=root/'labels'/'chunks'/metadata['path'];assert sha(path)==metadata['sha256']
  assert Path(metadata['source_path']).parent.name=='chunks'
  for line in gzip.open(path,'rt'):
   game=json.loads(line);label_game_ids.add(game['game_id']);label_rows+=len(game['samples'])
   assert all(row['game_id']==game['game_id'] for row in game['samples'])
   assert all(row['teacher_kind']=='cp' and row['teacher_cp_stm']==row['score_cp_stm'] for row in game['samples'])
 assert source_game_ids==label_game_ids and label_rows>0
 assert pins=={path:sha(path) for path in pins},'source or adapter changed during contract check'
 result.update(status='PASS',complete_games=gm['completed_games'],generator_rows=source_rows,teacher_rows=label_rows,teacher_totals=lm['totals'],generator_manifest_sha256=sha(root/'games'/'manifest.json'),teacher_manifest_sha256=sha(root/'labels'/'manifest.json'),pins=pins)
finally:
 if paused and processes[0].poll() is None:os.kill(processes[0].pid,signal.SIGCONT)
 for process in processes:
  if process.poll() is None:
   process.terminate()
   try:process.wait(timeout=10)
   except subprocess.TimeoutExpired:process.kill();process.wait()
 for handle in handles:handle.close()
 result['owned_parent_exit_codes']=[process.returncode for process in processes]
 (root/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
