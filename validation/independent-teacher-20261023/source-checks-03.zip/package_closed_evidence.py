"""Pack explicitly closed evidence, verifying stable bytes and ZIP readback."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import stat
import zipfile


def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda: stream.read(1 << 20), b''):
            value.update(data)
    return value.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--files', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    assert not args.out.exists(), 'Never overwrite prior evidence'
    declarations = json.loads(args.files.read_text())
    records = {}
    for entry in declarations:
        source, name = Path(entry['source']), entry['member']
        assert not source.is_symlink() and source.is_file()
        assert name not in records and not name.startswith('/') and '..' not in Path(name).parts
        records[name] = {'source': str(source), 'sha256': digest(source),
                         'bytes': source.stat().st_size,
                         'mode': stat.S_IMODE(source.stat().st_mode)}
    temporary = args.out.with_suffix(args.out.suffix + '.tmp')
    with zipfile.ZipFile(temporary, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, record in sorted(records.items()):
            archive.write(record['source'], name)
        archive.writestr('ARCHIVE_MANIFEST.json', json.dumps(records, indent=2) + '\n')
    with zipfile.ZipFile(temporary) as archive:
        assert len(archive.namelist()) == len(records) + 1
        assert archive.testzip() is None
        for name, record in records.items():
            assert hashlib.sha256(archive.read(name)).hexdigest() == record['sha256']
            assert digest(Path(record['source'])) == record['sha256'], 'Source changed during archive'
            assert archive.getinfo(name).file_size == record['bytes']
            assert stat.S_IMODE(archive.getinfo(name).external_attr >> 16) == record['mode']
    with temporary.open('rb') as stream:
        os.fsync(stream.fileno())
    os.replace(temporary, args.out)
    result = {'path': str(args.out), 'sha256': digest(args.out), 'bytes': args.out.stat().st_size,
              'members': len(records) + 1, 'status': 'PASS_STABLE_SOURCE_ZIP_CRC_SHA_MODE_READBACK'}
    args.out.with_suffix(args.out.suffix + '.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
