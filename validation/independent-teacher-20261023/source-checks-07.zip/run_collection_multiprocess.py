#!/usr/bin/env python3
"""Bounded collection controller; launch only after the scientific protocol freezes."""
import argparse
from collections import Counter
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import tempfile
import time
import unittest

BASE = Path(__file__).resolve().parent
REPO = Path('/workspace/dwqww')


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1<<20),b''): digest.update(block)
    return digest.hexdigest()


def atomic(path, value):
    temporary = path.with_suffix(path.suffix+'.tmp')
    with temporary.open('w') as stream:
        json.dump(value,stream,indent=2,allow_nan=False);stream.write('\n');stream.flush();os.fsync(stream.fileno())
    os.replace(temporary,path)


def count_chunk(path, metadata, keys, game_ids, split_rows):
    if sha(path)!=metadata['sha256']: raise ValueError('committed label chunk hash mismatch: '+str(path))
    fresh_keys, fresh_ids, fresh_splits, rows = set(), [], Counter(), 0
    with gzip.open(path,'rt') as stream:
        for line in stream:
            if not line.endswith('\n'): raise ValueError('truncated committed game record')
            game=json.loads(line); identity=game['game_id']; split=game['split']
            if not isinstance(identity,str) or not identity or identity in game_ids or identity in fresh_ids:
                raise ValueError('invalid or repeated accepted game ID')
            if split not in ('train','validation','audit') or not isinstance(game['samples'],list):
                raise ValueError('invalid game split/samples')
            fresh_ids.append(identity)
            for sample in game['samples']:
                fen=sample['fen'].split()
                if len(fen)!=6 or sample.get('game_id')!=identity or sample.get('split',split)!=split:
                    raise ValueError('accepted sample identity/FEN mismatch')
                fresh_keys.add(' '.join(fen[:4]));fresh_splits[split]+=1;rows+=1
    if (rows!=metadata['accepted'] or len(fresh_ids)!=metadata['games'] or fresh_ids!=metadata['game_ids']
            or sha(path)!=metadata['sha256']): raise ValueError('committed chunk counts/IDs/hash changed')
    keys.update(fresh_keys);game_ids.update(fresh_ids);split_rows.update(fresh_splits)
    return rows


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--protocol',type=Path)
    parser.add_argument('--out',type=Path)
    parser.add_argument('--generation-command',type=Path,default=BASE/'generation-agent/production-command.json')
    parser.add_argument('--labels-out',type=Path,default=BASE/'production-labels')
    parser.add_argument('--initial-manifest',type=Path,required=False)
    parser.add_argument('--resume-generation-receipt',type=Path,required=False)
    parser.add_argument('--stop-at',default='2026-10-23T22:30:00Z')
    parser.add_argument('--self-test',action='store_true')
    args=parser.parse_args()
    if args.self_test: return self_test()
    if args.protocol is None or args.out is None: parser.error('--protocol and --out required')
    cutoff=datetime.fromisoformat(args.stop_at.replace('Z','+00:00'))
    if cutoff.tzinfo is None or cutoff<=datetime.now(timezone.utc): parser.error('--stop-at must be a future UTC instant')
    protocol_bytes=args.protocol.read_bytes();protocol=json.loads(protocol_bytes)
    command=json.loads(args.generation_command.read_text())
    generator=command['argv']; generated=Path(generator[generator.index('--out')+1])
    labels=args.labels_out.resolve(); stop_gen=Path(command['stop_file']);stop_labels=labels/'STOP_LABELING'
    if generator[generator.index('--workers')+1]!='1': raise ValueError('exact generator command must use one worker')
    if labels.exists(): raise ValueError('new aggregate label directory must be fresh')
    if generated.exists():
        if args.resume_generation_receipt is None: raise ValueError('existing generation requires a closed authenticated receipt')
        receipt=json.loads(args.resume_generation_receipt.read_text())
        retry = receipt['status']=='PASS_CLOSED_FAILED_SEGMENT_PRESERVED_BEFORE_ONE_UNCHANGED_RETRY'
        if not retry and receipt['status']!='PASS_CLOSED_SEGMENT_PRESERVED_BEFORE_AUTHENTIC_GENERATOR_RESUME': raise ValueError('invalid closed generation receipt')
        expected_resume_files={generated/'manifest.json',generated/'process-trace.jsonl.gz'}
        seen_resume_files=set()
        for record in receipt['files']:
            if Path(record['source']) in expected_resume_files:
                seen_resume_files.add(Path(record['source']))
                if sha(Path(record['source']))!=record['sha256'] or sha(Path(record['snapshot']))!=record['sha256']: raise ValueError('closed generation binding changed')
        if seen_resume_files!=expected_resume_files: raise ValueError('closed generation receipt omits manifest or trace')
        old=json.loads((generated/'manifest.json').read_text())
        if not all(session.get('owned_workers_reaped') for session in old['sessions']): raise ValueError('generator was not closed')
        if retry:
            last=old['sessions'][-1]
            allowed=["RuntimeError('UCI timeout waiting for gamejson')"]
            if old['status']!='INCOMPLETE_OR_FAILED' or last['errors']!=allowed:
                raise ValueError('one-time retry requires the exact diagnosed whole-game timeout')
            if receipt.get('next_game_index')!=14116 or receipt.get('timeout_seconds')!=15:
                raise ValueError('one-time retry context changed')
            if old.get('completed_games')!=14116 or old.get('configuration',{}).get('engine_timeout')!=15:
                raise ValueError('one-time retry committed game count changed')
            diagnosis=Path(receipt['diagnosis']['path'])
            if sha(diagnosis)!=receipt['diagnosis']['sha256']:
                raise ValueError('one-time retry diagnosis changed')
            if json.loads(diagnosis.read_text()).get('original_trace_sha256')!=sha(generated/'process-trace.jsonl.gz'):
                raise ValueError('one-time retry diagnosis belongs to another trace')
            if set(last.get('workers_observed',{}))!={'0'} or len(last['workers_observed']['0'].get('engines',[]))!=1:
                raise ValueError('one-time retry worker evidence missing')
            if any(not engine.get('reaped') or engine.get('forced_kill') or engine.get('returncode')!=0
                   or not engine.get('nested_opponent',{}).get('reaped')
                   or engine.get('nested_opponent',{}).get('returncode')!=0
                   for worker in last['workers_observed'].values() for engine in worker['engines']):
                raise ValueError('one-time retry requires clean actual engine exits')
        elif not old['status'].startswith('PASS'):
            raise ValueError('generator was not closed successfully')
        if stop_gen.exists(): raise ValueError('preserve/remove old generation stop flag explicitly before resuming')
    if args.initial_manifest is None or not args.initial_manifest.is_file(): raise ValueError('closed initial teacher manifest required')
    binary=Path('/workspace/.cloud-setup/stockfish/stockfish/stockfish-linux-x86-64-universal')
    teacher=[generator[0],str(REPO/'tools/nnue/coordinate_teacher_shards.py'),'--input-dir',str(generated),
             '--output-dir',str(labels),'--teacher',str(binary),'--depth',str(protocol['teacher']['depth']),
             '--workers',str(protocol['teacher']['workers']),'--follow','--idle-timeout','86400','--stop-file',str(stop_labels),
             '--teacher-network-sha256',protocol['teacher']['network_sha256'],'--initial-manifest',str(args.initial_manifest)]
    pins={args.protocol.resolve():hashlib.sha256(protocol_bytes).hexdigest(),args.generation_command.resolve():protocol['generation_command_prepared_sha256'],
          binary:protocol['teacher']['binary_sha256']}
    pins.update({REPO/name:digest for name,digest in protocol['producer_source_sha256'].items()})
    build=Path(generator[generator.index('--build-provenance')+1]);pins[build]=protocol['native_build_provenance_sha256']
    pins[args.initial_manifest.resolve()]=protocol['execution']['initial_teacher_manifest_sha256']
    pins[args.resume_generation_receipt.resolve()]=protocol['execution']['closed_generation_receipt_sha256']
    pins[Path(__file__).resolve()]=protocol['execution']['collection_controller_sha256']
    def check_pins():
        for path,digest in pins.items():
            if sha(path)!=digest: raise ValueError('frozen protocol/producer input changed: '+str(path))
    check_pins(); args.out.mkdir(parents=True,exist_ok=False)
    if generated.exists() and retry:
        with Path(receipt['one_time_consumption_marker']).open('x') as stream:
            json.dump({'receipt_sha256':sha(args.resume_generation_receipt),'protocol_sha256':pins[args.protocol.resolve()],
                       'utc':datetime.now(timezone.utc).isoformat(),'next_game_index':14116},stream)
            stream.write('\n');stream.flush();os.fsync(stream.fileno())
    keys, game_ids, split_rows, chunks, processes, handles = set(), set(), Counter(), {}, {}, []
    state={'status':'RUNNING','protocol_sha256':pins[args.protocol.resolve()], 'errors':[], 'rows':0,
           'controller_sha256':sha(Path(__file__)),
           'stop_at':cutoff.isoformat(),'target_unique_positions':5100000,'minimum_positions':5000000,
           'started_utc':datetime.now(timezone.utc).isoformat(),'children':{},'input_pins':{str(p):h for p,h in pins.items()}}
    stopping=None;forced=None;last_progress=0;last_check=0; interrupted=False
    def event(kind, **values):
        with (args.out/'events.jsonl').open('a') as stream:
            stream.write(json.dumps({'utc':datetime.now(timezone.utc).isoformat(),'event':kind,**values})+'\n');stream.flush()
    def stop(reason):
        nonlocal stopping
        if stopping is None:
            stopping=time.monotonic();state['stop_reason']=reason;event('drain_requested',reason=reason)
            for path in (stop_gen,stop_labels):path.parent.mkdir(parents=True,exist_ok=True);path.touch(exist_ok=True)
    def error(message):
        if message not in state['errors']:state['errors'].append(message);event('failure',error=message)
        stop('failure')
    def progress(final=False):
        state.update(unique_positions=len(keys),games=len(game_ids),split_rows=dict(split_rows),committed_label_chunks=len(chunks),
                     utc=datetime.now(timezone.utc).isoformat(),free_bytes=shutil.disk_usage(args.out).free)
        for name,process in processes.items():state['children'][name]['actual_exit']=process.poll()
        atomic(args.out/'progress.json',state)
        if final:atomic(args.out/'result.json',state);atomic(args.out/'commands.json',state['children'])
        event('final' if final else 'progress',status=state['status'],unique_positions=len(keys),rows=state['rows'],games=len(game_ids))
        print(json.dumps({key:state[key] for key in ('utc','status','unique_positions','rows','games')}),flush=True)
    def scan():
        manifest_path=labels/'manifest.json'
        if not manifest_path.exists():return
        manifest=json.loads(manifest_path.read_text());config=manifest['configuration']
        expected={'depth':protocol['teacher']['depth'],'teacher_sha256':protocol['teacher']['binary_sha256'],
                  'teacher_network_sha256':protocol['teacher']['network_sha256'],
                  'tool_sha256':protocol['producer_source_sha256']['tools/nnue/label_teacher_games.py'],
                  'options':protocol['teacher']['options'],'policy':protocol['teacher']['policy']}
        if any(config.get(key)!=value for key,value in expected.items()):raise ValueError('labeler configuration differs from frozen protocol')
        present=set()
        for metadata in manifest['chunks']:
            name=metadata['path'];present.add(name)
            if name in chunks:
                if chunks[name]!=metadata['sha256']:raise ValueError('committed label manifest binding changed')
                continue
            path=(labels/'chunks'/name).resolve()
            if not path.is_relative_to((labels/'chunks').resolve()):raise ValueError('label path escapes committed chunks')
            rows=count_chunk(path,metadata,keys,game_ids,split_rows);state['rows']+=rows;chunks[name]=metadata['sha256']
            event('verified_chunk',path=name,sha256=metadata['sha256'],rows=rows,games=metadata['games'])
        if set(chunks)-present:raise ValueError('committed label chunks disappeared from manifest')
        state['labeler_status']=manifest['status'];state['labeler_manifest_sha256']=sha(manifest_path)
    def halted(number,frame):
        nonlocal interrupted
        interrupted=True
    original_handlers={number:signal.signal(number,halted) for number in (signal.SIGINT,signal.SIGTERM)}
    try:
        for name,argv in (('generator',generator),('labeler',teacher)):
            stdout=(args.out/(name+'.stdout')).open('wb');stderr=(args.out/(name+'.stderr')).open('wb');handles.extend([stdout,stderr])
            process=subprocess.Popen(argv,cwd=REPO,env={**os.environ,**command.get('env',{}),'PYTHONDONTWRITEBYTECODE':'1'},
                                     stdout=stdout,stderr=stderr,start_new_session=True)
            processes[name]=process
            state['children'][name]={'argv':argv,'pid':process.pid,'actual_exit':None,'cwd':str(REPO),
                                     'env_overrides':{**command.get('env',{}),'PYTHONDONTWRITEBYTECODE':'1'},
                                     'stdout':stdout.name,'stderr':stderr.name}
            atomic(args.out/'commands.json',state['children'])
        while True:
            now=time.monotonic()
            try:
                scan()
                if now-last_check>=60:
                    check_pins();last_check=now
                    if shutil.disk_usage(args.out).free<700*(1<<20):raise ValueError('disk free below 700 MiB')
            except Exception as failure:error(repr(failure))
            if interrupted:error('controller interrupted by signal')
            for name,process in processes.items():
                if process.poll() not in (None,0):error(name+' failed with actual exit '+str(process.returncode))
            if len(keys)>=5100000:stop('unique_position_target')
            if datetime.now(timezone.utc)>=cutoff:stop('UTC_cutoff')
            if processes['labeler'].poll()==0 and processes['generator'].poll() is None:stop('labeler_finished')
            if all(process.poll() is not None for process in processes.values()):break
            if stopping is not None and now-stopping>=300 and forced is None:
                forced=now;error('300 second graceful drain exceeded; SIGTERM sent to owned parents')
                for process in processes.values():
                    if process.poll() is None:process.terminate()
            if forced is not None and now-forced>=30:break
            if now-last_progress>=60:progress();last_progress=now
            time.sleep(2)
    except BaseException as failure:
        error(repr(failure))
        deadline=time.monotonic()+300
        while any(process.poll() is None for process in processes.values()) and time.monotonic()<deadline:time.sleep(1)
        for process in processes.values():
            if process.poll() is None:process.terminate();forced=time.monotonic()
        deadline=time.monotonic()+30
        while any(process.poll() is None for process in processes.values()) and time.monotonic()<deadline:time.sleep(1)
    finally:
        try:scan();check_pins()
        except Exception as failure:error(repr(failure))
        for handle in handles:handle.close()
        for number,handler in original_handlers.items():signal.signal(number,handler)
    codes={name:process.poll() for name,process in processes.items()}
    try:
        generated_manifest=json.loads((generated/'manifest.json').read_text())
        state['generator_status']=generated_manifest.get('status')
        state['generator_manifest_sha256']=sha(generated/'manifest.json')
        if not str(state['generator_status']).startswith('PASS'):state['errors'].append('generator manifest is not PASS')
    except Exception as failure:state['errors'].append('final generator manifest: '+repr(failure))
    if state.get('labeler_status')!='complete':state['errors'].append('labeler manifest is not complete')
    state['status']=('FAILED' if state['errors'] or forced is not None or len(codes)!=2 or any(code!=0 for code in codes.values())
                     else 'PASS' if len(keys)>=5000000 else 'INCOMPLETE')
    state['training_permitted']=False;state['training_status']='requires authenticated preparation and final retained-row qualification'
    state['remaining_parent_pids']=[p.pid for p in processes.values() if p.poll() is None]
    with gzip.open(args.out/'game-ids.json.gz','wt',compresslevel=1) as stream:json.dump(sorted(game_ids),stream)
    progress(final=True)
    return 0 if state['status']=='PASS' else 1


def self_test():
    class CollectionTests(unittest.TestCase):
        def test_exact_unique_keys_and_hash_rejection(self):
            with tempfile.TemporaryDirectory() as directory:
                path = Path(directory) / 'labels.jsonl.gz'
                a = '8/8/8/8/8/8/4K3/7k w - - 0 1'
                b = '8/8/8/8/8/8/4K3/7k w - - 99 51'
                games = [{'game_id':'g1', 'split':'train', 'samples':[{'game_id':'g1','fen':a}]},
                         {'game_id':'g2', 'split':'audit', 'samples':[{'game_id':'g2','fen':b}]}]
                with gzip.open(path,'wt') as stream:
                    for game in games: stream.write(json.dumps(game)+'\n')
                digest = hashlib.sha256(path.read_bytes()).hexdigest()
                metadata = {'sha256':digest,'games':2,'accepted':2,'game_ids':['g1','g2']}
                try: consume = count_chunk
                except NameError: self.fail('Committed chunk counter is not implemented')
                keys, identities, splits = set(), set(), Counter()
                self.assertEqual(consume(path,metadata,keys,identities,splits),2)
                self.assertEqual(len(keys),1)
                self.assertEqual(identities,{'g1','g2'})
                self.assertEqual(dict(splits),{'train':1,'audit':1})
                with path.open('ab') as stream: stream.write(b'changed')
                with self.assertRaisesRegex(ValueError,'hash'):
                    consume(path,metadata,set(),set(),Counter())
    return 0 if unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(CollectionTests)).wasSuccessful() else 1


if __name__ == '__main__':
    raise SystemExit(main())
