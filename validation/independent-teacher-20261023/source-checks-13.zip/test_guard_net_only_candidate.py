"""Clearly synthetic gate-boundary tests; no models, Git, builds or engines."""
import copy
import importlib.util
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest import mock

H = Path('/workspace/forge-independent-teacher-20261023')
spec = importlib.util.spec_from_file_location('gate', H / 'guard_net_only_candidate.py')
gate = importlib.util.module_from_spec(spec); spec.loader.exec_module(gate)

def fixtures():
    summary = {'status': 'completed', 'input_integrity': 'passed', 'epochs_completed': 8,
        'config': {'epochs': 8, 'seed': 20261023, 'lr': .0003, 'min_lr': .000003,
                   'batch_size': 1024, 'threads': 4, 'fixed_result_weight': .4,
                   'selection_include_initial': False, 'selection_metric': 'target_mse_combined',
                   'selection_target': copy.deepcopy(gate.TARGET)},
        'epochs': [{'epoch': n, 'result_weight': .4, 'target_mse_combined': .1 if n in [2, 3] else .2} for n in range(1, 9)],
        'best': {'epoch': 2, 'stem': 'epoch-0002', 'selection_metric': 'target_mse_combined', 'selection_mse': .1}}
    changes = {'W1': 1, 'B1': 0, 'W2': 0, 'B2': 0}
    frozen = {'status': 'FROZEN_BEFORE_ANY_AUDIT_MODEL_LOSS', 'epoch': 2, 'selection_metric': 'target_mse_combined',
              'selection_mse': .1, 'numeric_quantized_changes': changes.copy(), 'selected_inc_sha256': 'c' * 64,
              'shipped_sha256': gate.SHIPPED, 'utc': '2026-10-23T22:00:00+00:00'}
    metrics = {'status': 'PASS_FIXED_HELDOUT_LOSS_COMPARISON_NOT_ELO', 'input_integrity': 'passed',
        'target': copy.deepcopy(gate.TARGET), 'protocol': {'sha256': gate.PROTOCOL}, 'manifest_sha256': 'a' * 64,
        'candidate_net': {'sha256': 'c' * 64}, 'shipped_net': {'sha256': gate.SHIPPED},
        'bootstrap_draws': 10000, 'seed': 2026102303, 'rows': 100, 'represented_games': 10,
        'comparisons': {'shipped_vs_candidate': {'rows': 100, 'games': 10, 'draws': 10000,
            'seed': 2026102303, 'ci95_abs': [.01, .03], 'reference_mse': .2, 'candidate_mse': .18,
            'improvement_abs': .02}},
        'loss_mse': {'shipped_hce_plus_net': .2, 'candidate_hce_plus_net': .18},
        'utc': '2026-10-23T22:02:00+00:00'}
    marker = {'candidate_freeze_sha256': 'f' * 64, 'utc': '2026-10-23T22:01:00+00:00'}
    return summary, frozen, metrics, marker, changes

class NetOnlyGateTests(unittest.TestCase):
    def test_synthetic_positive_primary_interval_and_earliest_tie(self):
        summary, frozen, metrics, marker, changes = fixtures()
        self.assertEqual(gate.selection_policy(summary, frozen, changes), 'epoch-0002')
        self.assertGreater(gate.audit_policy(metrics, frozen, marker, 'f' * 64, 'a' * 64, 100)['improvement_abs'], 0)

    def test_zero_negative_nonfinite_and_wrong_type_lower_bounds_rejected(self):
        for value in [0, -.01, float('nan'), float('inf'), '0.01', True]:
            _, frozen, metrics, marker, _ = fixtures()
            metrics['comparisons']['shipped_vs_candidate']['ci95_abs'][0] = value
            with self.subTest(value=value), self.assertRaises(ValueError):
                gate.audit_policy(metrics, frozen, marker, 'f' * 64, 'a' * 64, 100)

    def test_secondary_hce_teacher_or_relative_interval_cannot_substitute(self):
        _, frozen, metrics, marker, _ = fixtures()
        metrics['comparisons']['hce_vs_candidate'] = copy.deepcopy(metrics['comparisons']['shipped_vs_candidate'])
        metrics['comparisons']['shipped_vs_candidate']['ci95_abs'] = [0, .03]
        metrics['comparisons']['shipped_vs_candidate']['ci95_relative'] = [.1, .2]
        metrics['teacher_loss_mse'] = {'shipped_hce_plus_net': .2, 'candidate_hce_plus_net': .1}
        with self.assertRaises(ValueError): gate.audit_policy(metrics, frozen, marker, 'f' * 64, 'a' * 64, 100)

    def test_audit_identity_target_and_settings_mismatches_rejected(self):
        for field in ['manifest', 'candidate', 'shipped', 'marker', 'target', 'draws', 'seed', 'rows']:
            _, frozen, metrics, marker, _ = fixtures()
            if field == 'manifest': metrics['manifest_sha256'] = 'b' * 64
            elif field in ['candidate', 'shipped']: metrics[field + '_net']['sha256'] = 'b' * 64
            elif field == 'marker': marker['candidate_freeze_sha256'] = 'b' * 64
            elif field == 'target': metrics['target']['result_weight'] = .3
            elif field == 'draws': metrics['bootstrap_draws'] = 9999
            elif field == 'seed': metrics['seed'] = 1
            else: metrics['rows'] = 99
            with self.subTest(field=field), self.assertRaises(ValueError):
                gate.audit_policy(metrics, frozen, marker, 'f' * 64, 'a' * 64, 100)

    def test_initial_later_tie_and_malformed_numeric_changes_rejected(self):
        for field in ['initial', 'later_tie', 'zero', 'boolean', 'negative']:
            summary, frozen, _, _, changes = fixtures()
            if field == 'initial': summary['config']['selection_include_initial'] = True
            elif field == 'later_tie':
                summary['best'].update(epoch=3, stem='epoch-0003'); frozen['epoch'] = 3
            elif field == 'zero': changes['W1'] = 0; frozen['numeric_quantized_changes']['W1'] = 0
            elif field == 'boolean': frozen['numeric_quantized_changes']['W1'] = True
            else: changes['W1'] = -1; frozen['numeric_quantized_changes']['W1'] = -1
            with self.subTest(field=field), self.assertRaises(ValueError): gate.selection_policy(summary, frozen, changes)

    def test_numeric_parser_ignores_comment_only_changes_then_refuses_candidate(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / 'comment-only.inc'
            original = gate.R / 'src/nnue_weights.inc'
            path.write_bytes(original.read_bytes() + b'\n// clearly synthetic nonnumeric test change\n')
            changes = gate.quantized_changes(original, path)
            self.assertEqual(sum(changes.values()), 0)
            summary, frozen, _, _, _ = fixtures(); frozen['numeric_quantized_changes'] = changes.copy()
            with self.assertRaises(ValueError): gate.selection_policy(summary, frozen, changes)

    def test_unclosed_receipt_refuses_before_any_model_output_or_git_action(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / 'running.json'
            path.write_text(json.dumps({'status': 'RUNNING', 'actual_exit': None}))
            args = SimpleNamespace(training_result=path, freeze_result=path, audit_result=path)
            with mock.patch.object(gate, 'git', side_effect=AssertionError('Git must never run in check')) as command:
                with self.assertRaisesRegex(ValueError, 'closed preregistered'): gate.check(args)
            command.assert_not_called()

    def test_boolean_exit_and_changed_closed_stream_refused(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary); receipt = root / 'result.json'
            (root / 'stdout').write_bytes(b'closed output'); (root / 'stderr').write_bytes(b'')
            record = {'status': 'COMPLETED', 'actual_exit': False, 'closed_utc': '2026-10-23T22:00:00+00:00',
                      'argv': ['synthetic'], 'stdout_sha256': gate.sha(root / 'stdout'), 'stdout_bytes': 13,
                      'stderr_sha256': gate.sha(root / 'stderr'), 'stderr_bytes': 0}
            receipt.write_text(json.dumps(record))
            with self.assertRaisesRegex(ValueError, 'closed preregistered'):
                gate.closed_execution(receipt, ['synthetic'])
            record['actual_exit'] = 0; receipt.write_text(json.dumps(record))
            gate.closed_execution(receipt, ['synthetic'])
            (root / 'stdout').write_bytes(b'changed')
            with self.assertRaisesRegex(ValueError, 'stream changed'):
                gate.closed_execution(receipt, ['synthetic'])

if __name__ == '__main__': unittest.main(verbosity=2)
