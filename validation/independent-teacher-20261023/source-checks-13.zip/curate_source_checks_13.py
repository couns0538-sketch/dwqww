"""Explicit closed-only checkpoint13 curation; never opens audit or model files."""
from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,stat
H=Path('/workspace/forge-independent-teacher-20261023')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
rows=[]
def add(rel,group,member=None):
 p=H/rel
 assert p.is_file() and not p.is_symlink(),str(p)
 assert p.suffix not in ('.pt','.inc','.bin','.npz','.zip'),str(p)
 row={'source':str(p),'member':member or rel,'sha256':sha(p),'bytes':p.stat().st_size,'mode':stat.S_IMODE(p.stat().st_mode),'group':group}
 assert row['member'] not in {r['member'] for r in rows}
 rows.append(row)
# Closed process records establish writer closure before archival.
for directory in ['exec-one-warmstart-training-02','exec-freeze-selected-candidate-02']:
 result=json.loads((H/directory/'result.json').read_bytes());assert result['actual_exit']==0 and result['closed_utc']
 for name in ['command.json','result.json','stdout','stderr']:add(directory+'/'+name,'closed_actual_execution')
for name in ['TRAINING_STARTED-02.json','selected-candidate-02/freeze.json']:add(name,'single_run_and_pre_audit_freeze')
for name in ['summary.json','initial-report.json','protocol.json']+[f'epoch-{i:04d}-report.json' for i in range(1,9)]:add('training-run-02/'+name,'closed_training_metadata')
# Exact reversible storage for the 9.7MB authenticated input manifest.
source=H/'training-run-02/input-manifest.json';original=source.read_bytes();compressed=H/'training-run-02-input-manifest-closed.json.gz'
assert not compressed.exists()
with compressed.open('xb') as f:f.write(gzip.compress(original,compresslevel=6,mtime=0))
assert gzip.decompress(compressed.read_bytes())==original and sha(source)==hashlib.sha256(original).hexdigest()
compression={'status':'PASS_EXACT_GZIP_DECOMPRESSION_SHA_SIZE_READBACK','original_path':str(source),'original_sha256':hashlib.sha256(original).hexdigest(),'original_bytes':len(original),'compressed_path':str(compressed),'compressed_sha256':sha(compressed),'compressed_bytes':compressed.stat().st_size,'restore_member':'training-run-02/input-manifest.json','compression':'gzip,mTime0,level6; exact original bytes on decompression','reason':'Avoid >9MB raw evidence member while retaining entire original manifest, not a summary.'}
receipt=H/'training-input-manifest-closed-compression.json';assert not receipt.exists();receipt.write_text(json.dumps(compression,indent=2)+'\n')
add(compressed.name,'closed_training_input_manifest',member='training-run-02/input-manifest.json.gz');add(receipt.name,'closed_training_input_manifest')
# Numeric export metadata only; no weight or checkpoint payloads.
for name in ['initial.json']+[f'epoch-{i:04d}.json' for i in range(1,9)]:add('training-run-02/exports/'+name,'closed_export_hash_metadata_only')
for name in ['CLOSED-TRAINING-FREEZE-INDEPENDENT-REVIEW-02.json','closed-training-02-artifact-inventory.json','review_closed_training_02.py','closed-training-review-02.result.json','closed-training-review-02.stdout','closed-training-review-02.stderr']:
 add('trainer-agent/'+name,'independent_closed_training_freeze_review')
for name in ['guard_net_only_candidate.py','test_guard_net_only_candidate.py','net-only-gate-tests.stdout','net-only-gate-tests.stderr','net-only-gate-tests-reviewed.stdout','net-only-gate-tests-reviewed.stderr']:
 add(name,'conditional_net_gate')
for name in ['guard_net_only_candidate-before-cmake-fa510b328e1a.py','NET-GATE-NATIVE-PLAN-FINAL-REVIEW-02.json','test_net_guard_native_plan.py','test_net_guard_independent_review.py','net-guard-independent-test-inputs.json','red-native-plan-paths.stdout','red-native-plan-paths.stderr','green-native-plan-paths.stdout','green-native-plan-paths.stderr','green-native-plan-author-suite.stdout','green-native-plan-author-suite.stderr','green-native-plan-independent-suite.stdout','green-native-plan-independent-suite.stderr','red-net-guard-independent-review.stdout','red-net-guard-independent-review.stderr','green-net-guard-author-review.stdout','green-net-guard-author-review.stderr','green-net-guard-independent-review.stdout','green-net-guard-independent-review.stderr']:
 add('trainer-agent/'+name,'conditional_net_gate_red_green_review')
for name in ['windows-candidate-plan.json','windows-candidate-plan.md','windows-candidate-plan-original-529e655c51a95813.json','windows-candidate-plan-original-655d459d3d4eecdd.md','prepare_windows_support.py','test_windows_support.py','test_windows_support-before-fstring-normalization.py','windows-support-validation.json']:
 add(name,'windows_static_plan_and_inert_support')
for stem in ['windows-support-red','windows-support-prepare','windows-support-green','windows-support-green02','windows-support-final']:
 for suffix in ['stdout','stderr']:add(stem+'.'+suffix,'windows_static_plan_failed_and_completed_tests')
for name in ['PREPARATION.json','bench.stdin','forge-wine','forge-probe-wine','ownbook-path-only.diff','ownbook-wine-regression.py','original-ownbook-1ab.py.txt','original-run_windows_trial.py.txt']:
 add('windows-qualified-02/'+name,'windows_inert_support_not_engine_runtime')
for name in ['RESULT.json','CHECKSUM-CWD-CORRECTION-NOTE.json']+[x+'.http-receipt.json' for x in ['FINAL_REPORT.md','manifest.json','protocol.json','source-checks-12.zip']]:
 add('public-readback-8f91df1/'+name,'immutable_source12_public_verification_no_response_duplication')
for name in ['checksums-source12-primary.stdout','checksums-source12-current.stdout','checksums-source12-primary-corrected.stdout','checksums-source12-primary-corrected.stderr','checksums-source12-current-corrected.stdout','checksums-source12-current-corrected.stderr','checksums-source12-cwd-correction.json']:
 add(name,'preserved_wrong_cwd_attempt_and_corrected_56_checksum_passes')
add('curate_source_checks_13.py','archive_curation_source')
curation={'schema_version':1,'utc':datetime.now(timezone.utc).isoformat(),'status':'CURATED_EXPLICIT_NEW_CLOSED_EVIDENCE_ONLY','scope':'One closed8epochrun and frozenepoch7 metadata; actual commands/outputs; numeric hashes only; corrected conditionalnativeplan17synthetic tests; staticWindowsinert support and failures; source12public readback; cwdchecksumfailure and correction. No audit results read.','audit_scope':'Audit was active at task handoff. Audit command/logs/outputs and RUNNING-STATE excluded without reading or altering them; no scoring or acceptance assertion.','closed_processes':[{'directory':d,'actual_exit':json.loads((H/d/'result.json').read_bytes())['actual_exit']} for d in ['exec-one-warmstart-training-02','exec-freeze-selected-candidate-02']],'training_input_manifest_compression':compression,'excluded':['ALL model weights/checkpoints (.inc/.pt/.bin)','ALL data arrays (.npz)','SF binaries/networks/source/licence text','Audit outputs,logs,and command receipts','RUNNING-STATE','Old ZIPs/largepublished response bodies','Native engine tests/builds/runtime not yet executed in these static plans'],'known_evidence_limitations':['Wrong-cwd checksum attempt retained stdout and correctionreceipt; original terminal stderr was not a separately captured file and is not fabricated.','Native/Windows plan passes concern synthetic/static support only, not successful native or Wine runtime.'],'source_count_before_curation':len(rows),'raw_bytes_before_curation':sum(r['bytes'] for r in rows),'declarations':rows}
cp=H/'source-checks-13-curation.json';assert not cp.exists();cp.write_text(json.dumps(curation,indent=2)+'\n');add(cp.name,'archive_curation_receipt')
assert len(rows)<120
assert sum(r['bytes'] for r in rows)<5_000_000
for r in rows:assert sha(Path(r['source']))==r['sha256']
out=H/'checks-13-files.json';assert not out.exists();out.write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps({'declarations':str(out),'files':len(rows),'raw_bytes':sum(r['bytes'] for r in rows),'curation_sha256':sha(cp),'compression':compression}))
