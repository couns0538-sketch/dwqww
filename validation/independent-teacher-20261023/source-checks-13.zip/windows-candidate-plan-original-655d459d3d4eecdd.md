# Conditional Windows candidate plan

Static tool/hash checks pass: LLVM-MinGW 20261006 (preserved version evidence: clang 23.1.3), CMake, Wine loader and initialized prefix are available. No compiler, Wine, model, build, match or network was executed for this plan. All 11 existing pinned tool SHA256/size pairs match. Full argv, paths, environment and artifact hashes are in `windows-candidate-plan.json`.

Only proceed after the once-only audit qualifies and root `guard_net_only_candidate.py verify-native --out /workspace/forge-independent-teacher-20261023/qualified-native-02` succeeds. Cross-build that exact immutable `source/` in a fresh `/workspace/.cloud-setup/independent-teacher-windows-02/build`; preserve evidence in `/workspace/forge-independent-teacher-20261023/windows-qualified-02`. Keep baseline 1ab50b2d and only the selected include. Existing historical builds are immutable.

Run the plan in order with actual process receipts. Set LLVM_MINGW_ROOT and the exact Wine environment. Use Release C++20 Zen5 flags, no fast-math, FMA contraction, LTO or host-native target. After PE/import/disassembly checks, execute nine C++ suites through Wine and five Python suites with engine wrappers (the OwnBook test needs the previously audited path-only adapter). Do not run cross-CMake CTest blindly. Check 10,000 exact Windows C++/Python inference scores and repeated candidate bench signature; do not impose the shipped-network signature.

Prior full source+Windows build used 29,391,061 bytes; reserve 256 MiB for fresh build/evidence/package (estimate). This leaves ample nominal space under the current ~2.5 GB free, subject to other writers. The source/include identity must stay frozen throughout.

Deliver only the tested executable, hashes and concise provenance after gates pass. This proves Wine functional checks/parity, not physical Windows/Ryzen correctness, speed or Elo. Playing strength remains unproven and the user PC owns the 1,000-game gate.
