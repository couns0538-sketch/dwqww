#!/usr/bin/env python3
"""Static adapter and fake-loader checks; never launch real Wine/engine."""
import ast,json,os,pathlib,shlex,subprocess,tempfile,unittest
H=pathlib.Path('/workspace/forge-independent-teacher-20261023')
O=H/'windows-qualified-02'; S=H/'qualified-native-02/source'
W='/workspace/.cloud-setup/wine/usr/lib/wine/wine64'
B=pathlib.Path('/workspace/.cloud-setup/independent-teacher-windows-02/build')
R=pathlib.Path('/workspace/dwqww'); BASE='1ab50b2dd64d9b2f752f7f1285f6968cad2fd792'
class WindowsSupport(unittest.TestCase):
 def test_adapter_only_changes_source_root_and_book_path_representation(self):
  target=O/'ownbook-wine-regression.py';self.assertTrue(target.is_file(),'path-only OwnBook adapter is not prepared')
  old=subprocess.check_output(['git','show',BASE+':tools/ownbook_regression.py'],cwd=R).decode()
  new=target.read_text();compile(new,str(target),'exec')
  tree=ast.parse(new)
  class Normalize(ast.NodeTransformer):
   def visit_Assign(self,node):
    if len(node.targets)==1 and isinstance(node.targets[0],ast.Name):
     if node.targets[0].id=='ROOT':return ast.parse('ROOT = Path(__file__).resolve().parents[1]').body[0]
     if node.targets[0].id=='book_sent':return None
    return self.generic_visit(node)
   def visit_FormattedValue(self,node):
    if isinstance(node.value,ast.Name) and node.value.id=='book_sent':node.value=ast.Name(id='book',ctx=ast.Load());return node
    return self.generic_visit(node)
   def visit_Name(self,node):
    if node.id=='book_sent':return ast.copy_location(ast.Call(func=ast.Name(id='str',ctx=ast.Load()),args=[ast.Name(id='book',ctx=ast.Load())],keywords=[]),node)
    return node
  self.assertEqual(ast.dump(Normalize().visit(tree),include_attributes=False),ast.dump(ast.parse(old),include_attributes=False))
  self.assertIn('ROOT = Path('+repr(str(S))+')',new)
  self.assertEqual(new.count('book_sent = "Z:" + str(book).replace("/", chr(92))'),1)
  self.assertEqual(new.count(' + book_sent)'),2)
  self.assertEqual(new.count('{book_sent} with 1 entries'),2)
 def test_both_exact_wrappers_preserve_arguments_and_wine_environment(self):
  for name,exe in [('forge-wine','forge.exe'),('forge-probe-wine','forge_nnue_probe.exe')]:
   with self.subTest(wrapper=name):
    p=O/name;self.assertTrue(p.is_file(),'Wine wrapper is not prepared')
    self.assertTrue(os.access(p,os.X_OK))
    text=p.read_text();self.assertIn('exec '+shlex.quote(W)+' '+shlex.quote(str(B/exe))+' "$@"\n',text)
    self.assertEqual(text.count(W),1)
    with tempfile.TemporaryDirectory(prefix='forge-wrapper-args-') as tmp:
     d=pathlib.Path(tmp);fake=d/'fake loader.py'
     fake.write_text('#!/usr/bin/python3\nimport json,os,sys\nprint(json.dumps({"argv":sys.argv[1:],"environment":{k:os.environ[k] for k in ("WINEPREFIX","WINEDEBUG","XDG_CACHE_HOME")}}))\n');fake.chmod(0o755)
     inert=d/'wrapper';inert.write_text(text.replace('exec '+shlex.quote(W)+' ','exec '+shlex.quote(str(fake))+' ',1));inert.chmod(0o755)
     args=['one space','"quotes"',"'single'",'$(touch NOT_EXECUTED)','; touch NOT_EXECUTED','*','',r'Z:\\a folder\\file.txt']
     r=subprocess.run([str(inert),*args],cwd=d,check=True,capture_output=True,text=True)
     got=json.loads(r.stdout);self.assertEqual(got['argv'],[str(B/exe),*args])
     self.assertEqual(got['environment'],{'WINEPREFIX':'/workspace/.cloud-setup/wine-prefix-ready','WINEDEBUG':'-all','XDG_CACHE_HOME':'/workspace/.cloud-setup/font-cache'})
     self.assertFalse((d/'NOT_EXECUTED').exists())
 def test_adapter_matches_existing_audited_adapter_except_source_root(self):
  p=O/'ownbook-wine-regression.py';self.assertTrue(p.is_file(),'adapter not prepared')
  old=pathlib.Path('/workspace/forge-nnue-handoff-20261023/windows-final-net-trial-attempt1/ownbook-wine-regression.py').read_text()
  expected=old.replace("ROOT = Path('/workspace/.cloud-setup/nnue-final-windows-attempt1/source')",'ROOT = Path('+repr(str(S))+')')
  self.assertEqual(p.read_text(),expected)
if __name__=='__main__':unittest.main(verbosity=2)
