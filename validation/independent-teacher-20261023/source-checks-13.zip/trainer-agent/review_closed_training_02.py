#!/usr/bin/env python3
"""Inspect closed training artifacts; never execute a neural forward pass or audit."""
from pathlib import Path
import datetime
import hashlib
import json
import math
import re
import stat
import sys

H = Path('/workspace/forge-independent-teacher-20261023')
R = Path('/workspace/dwqww')
OUT = H / 'trainer-agent'
RUN = H / 'training-run-02'
PROTOCOL = '245bf6dd4bcea66d0666e2443ff24602d036bffd76c7c0b5fa2a89c57f2b6b53'
COMMANDS = '1a72e5c374e335c0ea8230f205a8f13001862207e1d53a4eb84f534c5edba297'
SHIPPED = '41487f328ff51f27417564df45b6f3139d038b7e940dedb121340bd61be9a4d3'
TARGET = {'kind': 'teacher_probability_game_result_blend', 'result_weight': .4,
          'sigmoid_k': 2.25, 'cp_scale': 400.0}
checks = []


def require(value, description):
    if not value:
        raise ValueError(description)
    checks.append(description)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            digest.update(block)
    return digest.hexdigest()


def load(path):
    return json.loads(Path(path).read_bytes())


def save_new(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def closed_receipt(directory, step, declared):
    path = H / directory
    receipt = load(path / 'result.json')
    require(receipt['status'] == 'COMPLETED' and type(receipt['actual_exit']) is int
            and receipt['actual_exit'] == 0, step + ': actual closed zero exit')
    require(receipt['step'] == step and receipt['argv'] == declared['argv']
            and receipt['spec_sha256'] == COMMANDS
            and Path(receipt['spec_path']) == H / 'downstream_commands.json',
            step + ': exact preregistered command and source specification')
    command = load(path / 'command.json')
    require(command['argv'] == receipt['argv'] and command['pid'] == receipt['pid']
            and command['proc_start_ticks'] == receipt['proc_start_ticks']
            and command['started_utc'] == receipt['started_utc'],
            step + ': original launch process identity binding')
    for name in ('stdout', 'stderr'):
        require(sha(path / name) == receipt[name + '_sha256']
                and (path / name).stat().st_size == receipt[name + '_bytes'],
                step + ': preserved original ' + name + ' bytes')
    start = datetime.datetime.fromisoformat(receipt['started_utc'])
    stop = datetime.datetime.fromisoformat(receipt['closed_utc'])
    require(start < stop and math.isfinite(receipt['elapsed_seconds'])
            and receipt['elapsed_seconds'] > 0, step + ': real temporal closure')
    return receipt


require(sha(R / 'validation/independent-teacher-20261023/protocol.json') == PROTOCOL,
        'frozen revision8 protocol exact byte SHA')
require(sha(H / 'downstream_commands.json') == COMMANDS,
        'frozen downstream command specification exact byte SHA')
protocol = load(R / 'validation/independent-teacher-20261023/protocol.json')
require(protocol['revision'] == 8 and protocol['target'] == TARGET,
        'predeclared revision8 fixed40percent blend')
require(protocol['training']['runs'] == 1 and protocol['training']['epochs'] == 8
        and protocol['training']['selection_metric'] == 'target_mse_combined'
        and protocol['training']['include_initial'] is False,
        'one run, eight epochs, earliest minimum fixed-blend selection excludes initial')
for name, digest in protocol['producer_source_sha256'].items():
    require(sha(R / name) == digest, 'frozen producer source: ' + name)
commands = {row['name']: row for row in load(H / 'downstream_commands.json')['commands']}
training = closed_receipt('exec-one-warmstart-training-02', 'one_warmstart_training_run',
                          commands['one_warmstart_training_run'])
freeze_exec = closed_receipt('exec-freeze-selected-candidate-02',
                            'freeze_selected_quantized_candidate',
                            commands['freeze_selected_quantized_candidate'])
baseline_exec = closed_receipt('exec-original-validation-baseline-02',
                              'original_validation_shipped_baseline',
                              commands['original_validation_shipped_baseline'])
summary = load(RUN / 'summary.json')
baseline = load(H / 'original-validation-baseline-02/summary.json')
frozen = load(H / 'selected-candidate-02/freeze.json')
launch = load(H / 'TRAINING_STARTED-02.json')
data_freeze = load(H / 'dataset-02/freeze.json')
require(summary['status'] == 'completed' and summary['epochs_completed'] == 8
        and summary['input_integrity'] == 'passed', 'closed eight-epoch trainer integrity passed')
require(baseline['status'] == 'baseline_only' and baseline['epochs_completed'] == 0
        and baseline['input_integrity'] == 'passed', 'independent shipped baseline closed and intact')
require(summary['initial'] == baseline['initial'], 'all initial validation metrics equal independent baseline exactly')
config = summary['config']
expected = {'epochs': 8, 'batch_size': 1024, 'threads': 4, 'lr': .0003, 'min_lr': .000003,
            'seed': 20261023, 'fixed_result_weight': .4, 'baseline_only': False,
            'hidden': 128, 'residual': True, 'selection_target': TARGET,
            'selection_metric': 'target_mse_combined', 'selection_include_initial': False,
            'exclude_initial_from_selection': True}
require(all(config[key] == value for key, value in expected.items()),
        'actual training configuration matches frozen architecture, optimizer and selection')
require(config['protocol']['sha256'] == PROTOCOL and config['initial_net']['sha256'] == SHIPPED
        and sha(R / 'src/nnue_weights.inc') == SHIPPED, 'actual warmstart uses exact shipped network')
require(sha(RUN / 'protocol.json') == PROTOCOL
        and sha(RUN / 'input-manifest.json') == summary['manifest_sha256']
        == data_freeze['prepared_manifest_sha256'], 'trainer snapshots bind exact frozen protocol and input manifest')
require(data_freeze['status'] == 'QUALIFIED_FROZEN' and data_freeze['training_permitted'] is True
        and data_freeze['total'] == 5988335
        and data_freeze['retained'] == {'train': 5390457, 'validation': 295653, 'audit': 302225}
        and data_freeze['total'] >= data_freeze['minimum_positions'] >= 5000000,
        'globally qualified frozen partition counts')
require(summary['training_count'] == data_freeze['retained']['train']
        and summary['validation_count'] == data_freeze['retained']['validation'],
        'actual trainer row counts use training and original validation partitions')
for key, value in {'protocol_sha256': PROTOCOL, 'shipped_sha256': SHIPPED,
                   'prepared_manifest_sha256': data_freeze['prepared_manifest_sha256'],
                   'audit_manifest_sha256': data_freeze['audit_manifest_sha256']}.items():
    require(launch[key] == frozen[key] == value, 'launch and candidate immutable input binding: ' + key)
require(frozen['source_sha256'] == launch['source_sha256'], 'same downstream source bytes from launch through freeze')
for name, digest in frozen['source_sha256'].items():
    require(sha(R / name) == digest, 'frozen downstream source: ' + name)
records = summary['epochs']
require([row['epoch'] for row in records] == list(range(1, 9))
        and all(row['result_weight'] == .4 and row['count'] == 295653
                and math.isfinite(row['target_mse_combined']) for row in records),
        'all eight complete original-validation epoch metrics use fixed40percent blend')
for i, row in enumerate(records, 1):
    report = load(RUN / ('epoch-%04d-report.json' % i))
    require(report['epochs_completed'] == i and report['latest'] == row
            and report['epochs'] == records[:i] and report['config'] == config,
            'immutable epoch%02d report matches final summary history' % i)
    export = load(RUN / ('exports/epoch-%04d.json' % i))
    require(export['epoch'] == i and export['selection_target'] == TARGET
            and export['protocol']['sha256'] == PROTOCOL
            and export['metrics']['target_mse_combined'] == row['target_mse_combined']
            and export['inc_sha256'] == sha(RUN / ('exports/epoch-%04d.inc' % i))
            and export['bin_sha256'] == sha(RUN / ('exports/epoch-%04d.bin' % i)),
            'epoch%02d export metrics and actual include/binary identities' % i)
chosen = min(records, key=lambda row: (row['target_mse_combined'], row['epoch']))
require(chosen['epoch'] == 7 and summary['best']['epoch'] == 7
        and summary['best']['selection_mse'] == chosen['target_mse_combined']
        and summary['best']['stem'] == 'epoch-0007'
        and frozen['epoch'] == 7 and frozen['selection_mse'] == chosen['target_mse_combined'],
        'epoch7 is exact earliest minimum trained fixed-blend validation epoch')
sys.path.insert(0, str(R / 'tools/nnue'))
from include_parser import load_include, _array
import numpy as np


def numeric(path):
    model = load_include(path, expected_hidden=128)
    require(model['hidden'] == 128 and model['residual'] is True,
            'fixed residual include format: ' + str(path.relative_to(path.parents[1])))
    text = path.read_text()
    arrays = {label: _array(text, symbol) for label, symbol in
              [('W1', 'NnueW1'), ('B1', 'NnueB1'), ('W2', 'NnueW2')]}
    biases = re.findall(r'\bstatic\s+const\s+std::int16_t\s+NnueB2\s*=\s*([+-]?\d+)\s*;', text)
    require(len(biases) == 1, 'one int16 output bias')
    arrays['B2'] = np.asarray([int(biases[0])], dtype=np.int16)
    return arrays


old = numeric(R / 'src/nnue_weights.inc')
initial = numeric(RUN / 'exports/initial.inc')
candidate = numeric(H / 'selected-candidate-02/selected.inc')
require(all(np.array_equal(old[key], initial[key]) for key in old),
        'numeric initial exported quantized arrays exactly reproduce shipped network')
changes = {key: int(np.count_nonzero(old[key] != candidate[key])) for key in old}
require(changes == frozen['numeric_quantized_changes'] ==
        {'W1': 94122, 'B1': 128, 'W2': 256, 'B2': 1},
        'independently parsed numeric int16 change counts equal candidate freeze')
for selected, original, digest_key in [('selected.inc', 'exports/epoch-0007.inc', 'selected_inc_sha256'),
                                       ('selected.bin', 'exports/epoch-0007.bin', 'selected_bin_sha256'),
                                       ('selected.pt', 'checkpoints/epoch-0007.pt', 'selected_checkpoint_sha256')]:
    selected_path = H / 'selected-candidate-02' / selected
    require(sha(selected_path) == sha(RUN / original) == frozen[digest_key],
            'selected exact epoch7 artifact: ' + selected)
require(sha(RUN / 'summary.json') == frozen['training_summary_sha256']
        and sha(H / 'dataset-02/freeze.json') == frozen['data_freeze_sha256'],
        'candidate freezes closed training and global data hashes')
freeze_time = datetime.datetime.fromisoformat(frozen['utc'])
train_end = datetime.datetime.fromisoformat(training['closed_utc'])
require(train_end < freeze_time < datetime.datetime.fromisoformat(freeze_exec['closed_utc']),
        'candidate freeze temporally follows actual completed training')

inventory = []
for path in sorted(RUN.rglob('*')):
    require(not path.is_symlink(), 'training artifact has no symlink: ' + str(path.relative_to(RUN)))
    if not path.is_file():
        continue
    before = path.stat()
    digest = sha(path)
    after = path.stat()
    require((before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns)
            and digest == sha(path), 'closed training artifact stable double-read: ' + str(path.relative_to(RUN)))
    inventory.append({'relative_path': str(path.relative_to(RUN)), 'bytes': after.st_size,
                      'sha256': digest, 'mode': stat.S_IMODE(after.st_mode),
                      'contains_model_weights': path.suffix in ('.pt', '.inc', '.bin'),
                      'copy_into_public_evidence_zip': path.suffix not in ('.pt', '.inc', '.bin')})
inventory_path = OUT / 'closed-training-02-artifact-inventory.json'
save_new(inventory_path, {'status': 'PASS_CLOSED_TRAINING_ARTIFACTS_STABLE_DOUBLE_READ',
                         'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                         'root': str(RUN), 'files': inventory, 'file_count': len(inventory),
                         'total_bytes': sum(row['bytes'] for row in inventory),
                         'private_model_artifacts_not_copied': True})
inputs = [R / 'validation/independent-teacher-20261023/protocol.json', H / 'downstream_commands.json',
          H / 'TRAINING_STARTED-02.json', H / 'dataset-02/freeze.json',
          H / 'selected-candidate-02/freeze.json', H / 'original-validation-baseline-02/summary.json',
          RUN / 'summary.json', Path(__file__)]
for directory in ('exec-one-warmstart-training-02', 'exec-freeze-selected-candidate-02',
                  'exec-original-validation-baseline-02'):
    inputs.extend(H / directory / name for name in ('command.json', 'result.json', 'stdout', 'stderr'))
report = {'status': 'PASS_INDEPENDENT_CLOSED_TRAINING_AND_QUANTIZED_FREEZE_REVIEW_NO_NEURAL_SCORING',
          'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'checks': checks, 'check_count': len(checks), 'selected_epoch': 7,
          'selected_include_sha256': frozen['selected_inc_sha256'], 'numeric_quantized_changes': changes,
          'training_actual_exit': training['actual_exit'], 'training_elapsed_seconds': training['elapsed_seconds'],
          'baseline_fixedblend_validation_mse': baseline['initial']['target_mse_combined'],
          'selected_fixedblend_validation_mse': chosen['target_mse_combined'],
          'baseline_teacher_only_validation_mse': baseline['initial']['teacher_mse_combined'],
          'selected_teacher_only_validation_mse': chosen['teacher_mse_combined'],
          'artifact_inventory_sha256': sha(inventory_path),
          'input_sha256': {str(path): sha(path) for path in inputs},
          'limitations': ['No model forward pass, training, audit scoring, build or match was executed.',
                          'No active/partial final-audit outputs were opened.',
                          'The fixed40percent-result blended target selects epoch7; its teacher-only validation MSE is worse than shipped.',
                          'Lower held-out loss does not establish speed or playing strength. Elo remains unproven.',
                          'This verifies exact frozen metadata and output bytes, not an independent retraining or complete dataset reconstruction.',
                          'The evidence-contract skill reference was unavailable; root skill guidance was read.'],
          'audit_results_read': False, 'model_forward_passes': 0, 'matches_run': 0,
          'repo_source_changed': False, 'git_or_index_operations': 0}
report_path = OUT / 'CLOSED-TRAINING-FREEZE-INDEPENDENT-REVIEW-02.json'
save_new(report_path, report)
print(json.dumps({'status': report['status'], 'checks': len(checks), 'inventory_files': len(inventory),
                  'inventory_bytes': sum(row['bytes'] for row in inventory),
                  'inventory_sha256': sha(inventory_path), 'review_sha256': sha(report_path)}))
