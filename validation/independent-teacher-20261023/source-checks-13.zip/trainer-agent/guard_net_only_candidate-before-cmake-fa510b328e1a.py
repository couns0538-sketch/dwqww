#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Conditional net-only handoff. check/prepare never run Git, engines or models.

The materialize and publish-root-only actions are for explicit later root use.
They are never called by check, prepare, or the tests of the decision policy.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import shlex
import subprocess
import sys
import tarfile
from types import SimpleNamespace

H = Path('/workspace/forge-independent-teacher-20261023')
R = Path('/workspace/dwqww')
BASE = '1ab50b2dd64d9b2f752f7f1285f6968cad2fd792'
SHIPPED = '41487f328ff51f27417564df45b6f3139d038b7e940dedb121340bd61be9a4d3'
PROTOCOL = '245bf6dd4bcea66d0666e2443ff24602d036bffd76c7c0b5fa2a89c57f2b6b53'
COMMANDS = '1a72e5c374e335c0ea8230f205a8f13001862207e1d53a4eb84f534c5edba297'
PARSER = '48cc169f506e9975c239001bbe3ef5fd220d68c0e0ecc68b16dc4145d3f0d32b'
TARGET = {'kind': 'teacher_probability_game_result_blend', 'result_weight': .4,
          'sigmoid_k': 2.25, 'cp_scale': 400.0}
PYTHON = '/workspace/.cloud-setup/nnue-pipeline-20261023-venv/bin/python'
SELECTED = H / 'selected-candidate-02'
TRAIN = H / 'training-run-02'
AUDIT = H / 'final-audit-02'
NATIVE_TOOLS = {
    'tools/nnue/engine_probe.cpp': 'a4d584955d9cdf1185b6bec6efe884d90babf1a7bbcb79de1b0c40f69b647629',
    'tools/nnue/tests/test_engine_parity.py': 'e2107a375c39dfd83ef276b3018f5f5665dfdb7b7835b772ca820d7dd3510d3a',
    'tools/nnue/train_nnue.py': '65555913c8047058d090e6b12a2eda76d2945d713da38afc1f43f493af44c898',
    'tools/nnue/include_parser.py': PARSER,
    'tools/nnue/examples/forge_sample.txt': 'ab429836ee5920e92a61bfb09cf29c15318a7b0e3d63643cf176d1d0962ee0bb',
}

def require(value, message):
    if not value:
        raise ValueError(message)

def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            digest.update(block)
    return digest.hexdigest()

def load(path):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), 'Missing/unsafe closed input: ' + str(path))
    return json.loads(path.read_bytes())

def write(path, value):
    path = Path(path)
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())

def finite(value):
    return type(value) in (int, float) and math.isfinite(value)

def selection_policy(summary, frozen, changes):
    require(summary['status'] == 'completed' and summary['input_integrity'] == 'passed'
            and summary['epochs_completed'] == 8, 'Actual eight-epoch training incomplete')
    config = summary['config']
    expected = {'epochs': 8, 'seed': 20261023, 'lr': .0003, 'min_lr': .000003,
                'batch_size': 1024, 'threads': 4, 'fixed_result_weight': .4,
                'selection_include_initial': False, 'selection_metric': 'target_mse_combined',
                'selection_target': TARGET}
    require(all(config.get(k) == v for k, v in expected.items()), 'Preregistered training/selection changed')
    require(config['selection_include_initial'] is False, 'Initial network cannot enter epoch selection')
    records = summary['epochs']
    require(len(records) == 8 and all(type(r['epoch']) is int for r in records)
            and [r['epoch'] for r in records] == list(range(1, 9))
            and all(r['result_weight'] == .4 and finite(r['target_mse_combined']) for r in records),
            'Invalid trained epoch records')
    chosen = min(records, key=lambda row: (row['target_mse_combined'], row['epoch']))
    best = summary['best']
    stem = 'epoch-%04d' % chosen['epoch']
    require(best['epoch'] == chosen['epoch'] and best['stem'] == stem
            and best['selection_metric'] == 'target_mse_combined'
            and best['selection_mse'] == chosen['target_mse_combined'], 'Earliest minimum trained epoch differs')
    require(frozen['status'] == 'FROZEN_BEFORE_ANY_AUDIT_MODEL_LOSS'
            and frozen['epoch'] == chosen['epoch'] and frozen['selection_metric'] == 'target_mse_combined'
            and frozen['selection_mse'] == chosen['target_mse_combined'], 'Candidate freeze selection differs')
    require(set(changes) == {'W1', 'B1', 'W2', 'B2'}
            and all(type(x) is int and x >= 0 for x in changes.values())
            and sum(changes.values()) > 0, 'No genuine numeric quantized change')
    require(set(frozen['numeric_quantized_changes']) == set(changes)
            and all(type(x) is int and x >= 0 for x in frozen['numeric_quantized_changes'].values())
            and frozen['numeric_quantized_changes'] == changes, 'Frozen numeric change counts differ')
    return stem

def audit_policy(metrics, frozen, marker, freeze_sha, audit_manifest_sha, audit_rows):
    require(metrics['status'] == 'PASS_FIXED_HELDOUT_LOSS_COMPARISON_NOT_ELO'
            and metrics['input_integrity'] == 'passed', 'Actual final audit incomplete')
    require(metrics['target'] == TARGET and metrics['protocol']['sha256'] == PROTOCOL
            and metrics['manifest_sha256'] == audit_manifest_sha, 'Audit target/protocol/partition differs')
    require(metrics['candidate_net']['sha256'] == frozen['selected_inc_sha256']
            and metrics['shipped_net']['sha256'] == frozen['shipped_sha256'] == SHIPPED,
            'Audit network identities differ')
    require(marker['candidate_freeze_sha256'] == freeze_sha, 'Audit did not bind this candidate freeze')
    require(metrics['bootstrap_draws'] == 10000 and metrics['seed'] == 2026102303
            and type(metrics['bootstrap_draws']) is int and type(metrics['seed']) is int
            and metrics['rows'] == audit_rows and type(metrics['represented_games']) is int
            and metrics['represented_games'] >= 2, 'Audit bootstrap/row/game settings differ')
    comparison = metrics['comparisons']['shipped_vs_candidate']
    require(comparison['rows'] == audit_rows and comparison['games'] == metrics['represented_games']
            and comparison['draws'] == 10000 and comparison['seed'] == 2026102303,
            'Primary comparison bootstrap identity differs')
    lo, hi = comparison['ci95_abs']
    require(finite(lo) and finite(hi) and 0 < lo <= hi,
            'Primary shipped-minus-candidate 95% absolute lower bound must be strictly positive')
    old = metrics['loss_mse']['shipped_hce_plus_net']
    new = metrics['loss_mse']['candidate_hce_plus_net']
    require(finite(old) and finite(new) and 0 <= new < old
            and comparison['reference_mse'] == old and comparison['candidate_mse'] == new
            and finite(comparison['improvement_abs'])
            and math.isclose(comparison['improvement_abs'], old - new, abs_tol=1e-12, rel_tol=1e-12),
            'Primary deployed fixed-target loss comparison differs')
    before = datetime.fromisoformat(frozen['utc'])
    started = datetime.fromisoformat(marker['utc'])
    ended = datetime.fromisoformat(metrics['utc'])
    require(before < started <= ended, 'Candidate was not frozen before the one audit')
    return {'primary_ci95_abs': [lo, hi], 'shipped_mse': old, 'candidate_mse': new,
            'improvement_abs': old - new}

def quantized_changes(old_path, new_path):
    require(sha(R / 'tools/nnue/include_parser.py') == PARSER, 'Fixed numeric include parser changed')
    sys.path.insert(0, str(R / 'tools/nnue'))
    from include_parser import load_include, _array
    import numpy as np
    require(load_include(old_path, expected_hidden=128)['residual'] is True
            and load_include(new_path, expected_hidden=128)['residual'] is True, 'Residual/H128 architecture differs')
    def numbers(path):
        text = Path(path).read_text(encoding='ascii')
        arrays = {key: _array(text, name) for key, name in [('W1', 'NnueW1'), ('B1', 'NnueB1'), ('W2', 'NnueW2')]}
        scalar = re.findall(r'\bstatic\s+const\s+std::int16_t\s+NnueB2\s*=\s*([+-]?\d+)\s*;', text)
        require(len(scalar) == 1, 'Invalid numeric B2')
        arrays['B2'] = np.asarray([int(scalar[0])], dtype=np.int16)
        return arrays
    old, new = numbers(old_path), numbers(new_path)
    return {name: int(np.count_nonzero(old[name] != new[name])) for name in old}

def closed_execution(path, expected_argv):
    receipt = load(path)
    require(type(receipt.get('actual_exit')) is int and receipt.get('actual_exit') == 0 and receipt.get('status') == 'COMPLETED'
            and receipt.get('closed_utc') and receipt.get('argv') == expected_argv,
            'Actual closed preregistered execution missing: ' + str(path))
    for name in ['stdout', 'stderr']:
        stream = Path(path).parent / name
        require(sha(stream) == receipt[name + '_sha256'] and stream.stat().st_size == receipt[name + '_bytes'],
                'Original closed execution stream changed: ' + str(stream))
    return receipt

def check(args):
    require(sha(H / 'downstream_commands.json') == COMMANDS, 'Preregistered commands changed')
    commands = {c['name']: c for c in load(H / 'downstream_commands.json')['commands']}
    # Close/exit gates precede reading any potentially partial training/freeze/audit output.
    closed_execution(args.training_result, commands['one_warmstart_training_run']['argv'])
    closed_execution(args.freeze_result, commands['freeze_selected_quantized_candidate']['argv'])
    closed_execution(args.audit_result, commands['once_only_final_audit']['argv'])
    protocol_path = R / 'validation/independent-teacher-20261023/protocol.json'
    require(sha(protocol_path) == PROTOCOL and load(protocol_path)['revision'] == 8, 'Protocol8 differs')
    data_freeze = load(H / 'dataset-02/freeze.json')
    require(data_freeze['status'] == 'QUALIFIED_FROZEN' and data_freeze['training_permitted'] is True
            and data_freeze['total'] >= data_freeze['minimum_positions'] >= 5000000
            and sum(data_freeze['retained'].values()) == data_freeze['total']
            and data_freeze['protocol_sha256'] == PROTOCOL,
            'Global dataset is unqualified')
    frozen = load(SELECTED / 'freeze.json')
    summary = load(TRAIN / 'summary.json')
    marker = load(H / 'AUDIT_STARTED-02.json')
    launch = load(H / 'TRAINING_STARTED-02.json')
    metrics = load(AUDIT / 'metrics.json')
    baseline = load(H / 'original-validation-baseline-02/summary.json')
    require(marker['argv'] == commands['once_only_final_audit']['underlying_cli_argv'], 'One-audit command changed')
    snapshot = {'protocol_sha256': PROTOCOL, 'prepared_manifest_sha256': data_freeze['prepared_manifest_sha256'],
                'audit_manifest_sha256': data_freeze['audit_manifest_sha256'], 'shipped_sha256': SHIPPED}
    for key, value in snapshot.items():
        require(frozen[key] == launch[key] == value, 'Frozen launch/data identity differs: ' + key)
    require(frozen['source_sha256'] == launch['source_sha256'], 'Training/source identities differ')
    for name, digest in frozen['source_sha256'].items():
        require(sha(R / name) == digest, 'Frozen source changed: ' + name)
    require(sha(R / 'src/nnue_weights.inc') == SHIPPED, 'Accepted checkout network changed')
    for role, key in [('prepared', 'prepared_manifest_sha256'), ('audit-prepared', 'audit_manifest_sha256')]:
        require(sha(H / 'dataset-02' / role / 'manifest.json') == data_freeze[key], 'Frozen prepared manifest changed')
    identities = {SELECTED / 'selected.inc': frozen['selected_inc_sha256'],
                  SELECTED / 'selected.bin': frozen['selected_bin_sha256'],
                  SELECTED / 'selected.pt': frozen['selected_checkpoint_sha256'],
                  TRAIN / 'summary.json': frozen['training_summary_sha256'],
                  H / 'dataset-02/freeze.json': frozen['data_freeze_sha256']}
    for path, digest in identities.items():
        require(sha(path) == digest, 'Frozen candidate/export/data changed: ' + str(path))
    changes = quantized_changes(R / 'src/nnue_weights.inc', SELECTED / 'selected.inc')
    stem = selection_policy(summary, frozen, changes)
    require(summary['manifest_sha256'] == snapshot['prepared_manifest_sha256']
            and summary['config']['protocol']['sha256'] == PROTOCOL
            and summary['config']['initial_net']['sha256'] == SHIPPED, 'Training data/init differs')
    require(baseline['status'] == 'baseline_only' and baseline['input_integrity'] == 'passed'
            and baseline['manifest_sha256'] == snapshot['prepared_manifest_sha256']
            and baseline['config']['protocol']['sha256'] == PROTOCOL
            and baseline['config']['initial_net']['sha256'] == SHIPPED, 'Baseline incomplete or identity differs')
    for key in ['teacher_mse_hce', 'teacher_mse_combined', 'target_mse_hce', 'target_mse_combined']:
        require(math.isclose(baseline['initial'][key], summary['initial'][key], abs_tol=1e-12, rel_tol=1e-12),
                'Original-validation baseline changed')
    metadata = load(TRAIN / 'exports' / (stem + '.json'))
    require(metadata['epoch'] == frozen['epoch'] and metadata['inc_sha256'] == frozen['selected_inc_sha256']
            and metadata['bin_sha256'] == frozen['selected_bin_sha256'], 'Genuine trained export identity differs')
    for suffix, selected in [('inc', 'selected.inc'), ('bin', 'selected.bin')]:
        require(sha(TRAIN / 'exports' / (stem + '.' + suffix)) == sha(SELECTED / selected), 'Frozen export bytes differ')
    require(sha(TRAIN / 'checkpoints' / (stem + '.pt')) == frozen['selected_checkpoint_sha256'], 'Frozen checkpoint differs')
    audit_rows = data_freeze['retained']['audit']
    decision = audit_policy(metrics, frozen, marker, sha(SELECTED / 'freeze.json'),
                            snapshot['audit_manifest_sha256'], audit_rows)
    artifact = AUDIT / metrics['per_row_artifact']['path']
    require(metrics['per_row_artifact']['rows'] == audit_rows and sha(artifact) == metrics['per_row_artifact']['sha256'],
            'Original one-audit row artifact differs')
    inputs = [Path(args.training_result), Path(args.freeze_result), Path(args.audit_result), protocol_path,
              H / 'downstream_commands.json', H / 'TRAINING_STARTED-02.json', H / 'AUDIT_STARTED-02.json',
              SELECTED / 'freeze.json', AUDIT / 'metrics.json', artifact, *identities]
    return {'status': 'AUDIT_GATE_PASS_NATIVE_VALIDATION_REQUIRED_NO_GIT_AUTHORIZATION',
            'utc': datetime.now(timezone.utc).isoformat(), 'parent': BASE, 'only_changed_path': 'src/nnue_weights.inc',
            'candidate_sha256': frozen['selected_inc_sha256'], 'selected_path': str(SELECTED / 'selected.inc'),
            'numeric_quantized_changes': changes, 'epoch': frozen['epoch'], **decision,
            'inputs': {str(path): sha(path) for path in inputs}, 'audit_scoring_executed_by_guard': False,
            'guard_source_sha256': sha(__file__),
            'execution_receipts': {name: str(getattr(args, name)) for name in ['training_result', 'freeze_result', 'audit_result']},
            'strength': 'Held-out fixed-target loss qualification only; Elo unproven; no matches.'}

def frozen_guard(path):
    guard = load(path)
    require(guard['status'] == 'AUDIT_GATE_PASS_NATIVE_VALIDATION_REQUIRED_NO_GIT_AUTHORIZATION'
            and guard['parent'] == BASE and guard['only_changed_path'] == 'src/nnue_weights.inc', 'Invalid guard')
    for name, digest in guard['inputs'].items():
        require(sha(name) == digest, 'Approved audit input changed: ' + name)
    require(guard['primary_ci95_abs'][0] > 0 and sum(guard['numeric_quantized_changes'].values()) > 0,
            'Positive primary audit/numeric change gate missing')
    require(guard['guard_source_sha256'] == sha(__file__), 'Guard implementation changed after approval')
    actual = check(SimpleNamespace(**guard['execution_receipts']))
    for key in ['status', 'parent', 'candidate_sha256', 'numeric_quantized_changes', 'epoch',
                'primary_ci95_abs', 'shipped_mse', 'candidate_mse', 'inputs']:
        require(actual[key] == guard[key], 'Actual one-audit qualification changed: ' + key)
    return guard

def prepare(args):
    guard = check(args)
    for name, digest in NATIVE_TOOLS.items(): require(sha(R / name) == digest, 'Pinned native validation tool changed')
    out = Path(args.out).absolute(); out.mkdir(parents=True, exist_ok=False)
    write(out / 'AUDIT-GUARD.json', guard)
    source, build = out / 'source', out / 'build'
    helper = Path(__file__).absolute()
    flags = '-march=x86-64-v3 -mtune=znver5 -fno-fast-math -ffp-contract=off -fno-lto'
    commands = [
        {'name': 'materialize', 'argv': [PYTHON, '-B', str(helper), 'materialize', '--guard', str(out / 'AUDIT-GUARD.json'), '--out', str(out)]},
        {'name': 'release-configure', 'argv': ['cmake', '-S', str(source), '-B', str(build), '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_CXX_COMPILER=/usr/bin/g++-14', '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON', '-DCMAKE_INTERPROCEDURAL_OPTIMIZATION=OFF', '-DFORGE_NATIVE=OFF', '-DCMAKE_CXX_FLAGS=' + flags, '-DPython3_EXECUTABLE=' + PYTHON]},
        {'name': 'release-build', 'argv': ['cmake', '--build', str(build), '--parallel', '2']},
        {'name': 'ctest14', 'argv': ['ctest', '--test-dir', str(build), '--output-on-failure', '-j', '1']},
        {'name': 'compile-probe', 'argv': ['/usr/bin/g++-14', '-std=c++20', '-O3', '-DNDEBUG', *flags.split(), '-I' + str(source / 'include'), str(R / 'tools/nnue/engine_probe.cpp'), str(build / 'libforge_core.a'), '-pthread', '-o', str(build / 'forge_nnue_probe')]},
        {'name': 'native-parity10000', 'argv': [PYTHON, '-B', str(R / 'tools/nnue/tests/test_engine_parity.py'), '--probe', str(build / 'forge_nnue_probe'), '--weights', str(source / 'src/nnue_weights.inc'), '--trainer', str(R / 'tools/nnue/train_nnue.py'), '--sample', str(R / 'tools/nnue/examples/forge_sample.txt'), '--positions', '10000', '--seed', '20261023', '--out', str(out / 'parity')]},
        {'name': 'extended-perft-uci', 'argv': [PYTHON, '-B', str(source / 'tools/uci_regression.py'), str(build / 'forge'), '--extended-perft', '--log', str(out / 'uci-regression.log')]},
        {'name': 'bench11', 'argv': [PYTHON, '-c', "import pathlib,subprocess,sys;sys.exit(subprocess.run([sys.argv[1]],input=pathlib.Path(sys.argv[2]).read_bytes()).returncode)", str(build / 'forge'), str(out / 'bench.stdin')]},
    ]
    (out / 'bench.stdin').write_text('uci\nsetoption name Threads value 1\nsetoption name Hash value 16\nsetoption name OwnBook value false\nisready\nbench 11\nquit\n')
    tools = [R / p for p in ['tools/nnue/engine_probe.cpp', 'tools/nnue/tests/test_engine_parity.py',
                            'tools/nnue/train_nnue.py', 'tools/nnue/include_parser.py',
                            'tools/nnue/examples/forge_sample.txt']]
    write(out / 'native-commands.json', {'status': 'ROOT_EXECUTION_ONLY_NATIVE_VALIDATION_PENDING',
        'guard_sha256': sha(out / 'AUDIT-GUARD.json'), 'parent': BASE, 'commands': commands,
        'tool_sources_sha256': {str(p): sha(p) for p in tools},
        'run_each': [PYTHON, '-B', str(H / 'run_recorded_step.py'), '--spec', str(out / 'native-commands.json'),
                     '--step', '<STEP_NAME>', '--out', str(out / 'steps/<STEP_NAME>')],
        'bench_rule': 'Record candidate signature; the shipped-network292545 nodes is not an equality target. Investigate an identical signature for stale weights before publishing.',
        'no_source_algorithm_changes': True, 'no_models_or_builds_or_Git_executed_by_prepare': True})
    print(json.dumps({'status': guard['status'], 'plan': str(out / 'native-commands.json'), 'candidate_sha256': guard['candidate_sha256']}))

def git(*argv, env=None, data=None):
    return subprocess.check_output(['git', *argv], cwd=R, env=env, input=data)

def materialize(args):
    out = Path(args.out).absolute(); guard = frozen_guard(args.guard)
    source = out / 'source'; require(not source.exists(), 'Fresh source directory required')
    archive = out / 'source-1ab.tar'
    with archive.open('xb') as stream:
        subprocess.run(['git', 'archive', '--format=tar', BASE, 'CMakeLists.txt', 'LICENSE', 'src', 'include', 'tests', 'bench', 'tools'], cwd=R, stdout=stream, check=True)
    source.mkdir(); originals = {}
    with tarfile.open(archive) as tar:
        for item in tar:
            path = PurePosixPath(item.name)
            require(not path.is_absolute() and '..' not in path.parts and not item.issym() and not item.islnk(), 'Unsafe source archive')
            destination = source / path
            if item.isdir(): destination.mkdir(parents=True, exist_ok=True); continue
            require(item.isfile(), 'Unexpected archive file type')
            destination.parent.mkdir(parents=True, exist_ok=True)
            raw = tar.extractfile(item).read(); destination.write_bytes(raw); destination.chmod(item.mode & 0o777)
            originals[item.name] = hashlib.sha256(raw).hexdigest()
    require(originals['src/nnue_weights.inc'] == SHIPPED, 'Accepted1ab original network differs')
    (source / 'src/nnue_weights.inc').write_bytes(Path(guard['selected_path']).read_bytes())
    require(sha(source / 'src/nnue_weights.inc') == guard['candidate_sha256'], 'Selected source copy differs')
    for name, digest in originals.items():
        require(sha(source / name) == (guard['candidate_sha256'] if name == 'src/nnue_weights.inc' else digest), 'Only weights may differ from accepted1ab')
    write(out / 'SOURCE.json', {'status': 'EXACT_ACCEPTED_PARENT_PLUS_SELECTED_WEIGHTS', 'parent': BASE,
        'archive_sha256': sha(archive), 'guard_sha256': sha(args.guard), 'candidate_sha256': guard['candidate_sha256'],
        'original_source_sha256': originals, 'only_changed_path': 'src/nnue_weights.inc'})

def verify_native(out):
    out = Path(out).absolute(); guard = frozen_guard(out / 'AUDIT-GUARD.json'); plan = load(out / 'native-commands.json')
    require(plan['guard_sha256'] == sha(out / 'AUDIT-GUARD.json'), 'Native plan guard differs')
    for path, digest in plan['tool_sources_sha256'].items(): require(sha(path) == digest, 'Native tool changed')
    for name, digest in NATIVE_TOOLS.items(): require(sha(R / name) == digest, 'Pinned native tool changed')
    for command in plan['commands']:
        step = out / 'steps' / command['name']; receipt = load(step / 'result.json')
        require(type(receipt['actual_exit']) is int and receipt['actual_exit'] == 0 and receipt['argv'] == command['argv']
                and receipt['status'] == 'COMPLETED' and receipt['closed_utc']
                and receipt['spec_sha256'] == sha(out / 'native-commands.json'), 'Actual native step incomplete')
        for stream in ['stdout', 'stderr']:
            require(sha(step / stream) == receipt[stream + '_sha256']
                    and (step / stream).stat().st_size == receipt[stream + '_bytes'], 'Original native process stream changed')
    require('100% tests passed, 0 tests failed out of 14' in (out / 'steps/ctest14/stdout').read_text(), 'All14CTest pass required')
    compilation = load(out / 'build/compile_commands.json'); require(compilation, 'Actual compiler command inventory absent')
    strict = {'-march=x86-64-v3', '-mtune=znver5', '-fno-fast-math', '-ffp-contract=off', '-fno-lto'}
    for record in compilation:
        tokens = record.get('arguments') or shlex.split(record['command'])
        require(strict.issubset(tokens) and not {'-ffast-math', '-Ofast', '-march=native', '-ffp-contract=fast', '-flto'}.intersection(tokens),
                'Actual native floating-point/architecture flags differ')
    parity = load(out / 'parity/RESULT.json')
    require(parity['status'] == 'PASS' and parity['positions'] == 10000 and parity['seed'] == 20261023
            and parity['weights_sha256'] == guard['candidate_sha256'] and parity['hidden_size'] == 128
            and parity['residual_mode'] is True and parity['feature_mismatch_count'] == 0
            and parity['maximum_integer_cp_error'] <= 1 and not parity['changed_inputs']
            and parity['probe_sha256'] == sha(out / 'build/forge_nnue_probe'), 'Selected-network native parity failed')
    text = (out / 'steps/bench11/stdout').read_text()
    nodes = re.findall(r'bench depth 11 nodes (\d+)\b', text)
    require(len(nodes) == 1 and int(nodes[0]) > 0, 'Candidate benchmark record absent')
    require(int(nodes[0]) != 292545, 'Unexpected shipped-network signature; investigate stale compiled weights')
    source = load(out / 'SOURCE.json')
    require(source['parent'] == BASE and source['candidate_sha256'] == guard['candidate_sha256'], 'Native source identity differs')
    for name, digest in source['original_source_sha256'].items():
        require(sha(out / 'source' / name) == (guard['candidate_sha256'] if name == 'src/nnue_weights.inc' else digest), 'Native source changed')
    return {'status': 'PASS_SELECTED_NET_NATIVE_VALIDATION_NOT_ELO', 'parent': BASE,
        'candidate_sha256': guard['candidate_sha256'], 'guard_sha256': sha(out / 'AUDIT-GUARD.json'),
        'ctests': 14, 'parity_positions': 10000, 'bench11_nodes': int(nodes[0]),
        'engine_sha256': sha(out / 'build/forge'), 'core_sha256': sha(out / 'build/libforge_core.a'),
        'probe_sha256': sha(out / 'build/forge_nnue_probe'), 'parity_result_sha256': sha(out / 'parity/RESULT.json')}

def publish(args):
    require(args.root_authorized, 'Only root may explicitly execute publication')
    out = Path(args.out).absolute(); native = verify_native(out); guard = frozen_guard(out / 'AUDIT-GUARD.json')
    index_path = Path(git('rev-parse', '--git-path', 'index').decode().strip())
    if not index_path.is_absolute(): index_path = R / index_path
    before = {'head': git('rev-parse', 'HEAD').decode().strip(), 'tree': git('rev-parse', 'HEAD^{tree}').decode().strip(),
              'index_sha256': sha(index_path), 'checkout_net_sha256': sha(R / 'src/nnue_weights.inc')}
    require(before['checkout_net_sha256'] == SHIPPED and hashlib.sha256(git('show', BASE + ':src/nnue_weights.inc')).hexdigest() == SHIPPED, 'Accepted root changed')
    require(not (out / 'private-index').exists(), 'Fresh private index required')
    env = {**os.environ, 'GIT_INDEX_FILE': str(out / 'private-index')}
    git('read-tree', BASE, env=env)
    raw = Path(guard['selected_path']).read_bytes()
    blob = git('hash-object', '-w', '--stdin', data=raw).decode().strip()
    git('update-index', '--add', '--cacheinfo', '100644', blob, 'src/nnue_weights.inc', env=env)
    tree = git('write-tree', env=env).decode().strip()
    message = ('Forge independent-teacher residual network ' + guard['candidate_sha256'][:12]
        + '\n\nOnly replace src/nnue_weights.inc from accepted1ab. Fixed-target final held-out game-cluster95% interval lower bound '
        + repr(guard['primary_ci95_abs'][0]) + '; native14CTest/perft/UCI/10000position parity passed. No Elo or playing-strength acceptance.\n')
    commit = git('commit-tree', tree, '-p', BASE, data=message.encode()).decode().strip()
    require(git('diff', '--name-only', BASE, commit).decode().splitlines() == ['src/nnue_weights.inc'], 'Commit is not net-only')
    require(git('rev-list', '--parents', '-n', '1', commit).decode().split() == [commit, BASE], 'Wrong parent(s)')
    require(git('show', commit + ':src/nnue_weights.inc') == raw, 'Commit network differs')
    after = {'head': git('rev-parse', 'HEAD').decode().strip(), 'tree': git('rev-parse', 'HEAD^{tree}').decode().strip(),
             'index_sha256': sha(index_path), 'checkout_net_sha256': sha(R / 'src/nnue_weights.inc')}
    require(after == before, 'Accepted root HEAD/tree/index/working network changed')
    # Branch creation occurs only after authentic audit, native proof, and root preservation.
    frozen_guard(out / 'AUDIT-GUARD.json')
    branch = 'forge/nnue-independent-teacher-20261023-' + guard['candidate_sha256'][:12]
    git('update-ref', 'refs/heads/' + branch, commit, '0' * 40)
    write(out / 'NET-ONLY-SOURCE.json', {'status': 'ROOT_CREATED_NET_ONLY_COMMIT_NOT_PUSHED_NOT_ELO',
        'branch': branch, 'commit': commit, 'parent': BASE, 'only_changed_path': 'src/nnue_weights.inc',
        'candidate_sha256': guard['candidate_sha256'], 'native_validation': native,
        'accepted_root_before_after_equal': before, 'guard_sha256': sha(out / 'AUDIT-GUARD.json')})

def main():
    parser = argparse.ArgumentParser(description=__doc__); sub = parser.add_subparsers(dest='command', required=True)
    for name in ['check', 'prepare']:
        p = sub.add_parser(name)
        for arg in ['training-result', 'freeze-result', 'audit-result']: p.add_argument('--' + arg, type=Path, required=True)
        if name == 'prepare': p.add_argument('--out', type=Path, required=True)
    p = sub.add_parser('materialize'); p.add_argument('--guard', type=Path, required=True); p.add_argument('--out', type=Path, required=True)
    p = sub.add_parser('verify-native'); p.add_argument('--out', type=Path, required=True)
    p = sub.add_parser('publish-root-only'); p.add_argument('--out', type=Path, required=True); p.add_argument('--root-authorized', action='store_true')
    args = parser.parse_args()
    if args.command == 'check': print(json.dumps(check(args)))
    elif args.command == 'prepare': prepare(args)
    elif args.command == 'materialize': materialize(args)
    elif args.command == 'verify-native': write(Path(args.out) / 'NATIVE-VALIDATION.json', verify_native(args.out))
    else: publish(args)

if __name__ == '__main__':
    try: main()
    except (ValueError, OSError, KeyError, TypeError, IndexError) as error:
        print('REFUSED: ' + str(error), file=sys.stderr); raise SystemExit(1)
