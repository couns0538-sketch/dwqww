"""Plan-only synthetic check. No models, builds, engines, or Git run.

Catches a native plan that relies on PATH for CMake/CTest although installed
CMake tools are outside PATH in the current execution environment.
The check() boundary is stubbed because the real once-only audit is pending;
prepare(), plan serialization, installed executables and --version are real.
"""
import contextlib
import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import tempfile
from types import SimpleNamespace
import unittest
from unittest import mock

H = Path('/workspace/forge-independent-teacher-20261023')
spec=importlib.util.spec_from_file_location('native_plan_gate', H/'guard_net_only_candidate.py')
gate=importlib.util.module_from_spec(spec);spec.loader.exec_module(gate)

class NativePlanToolPaths(unittest.TestCase):
    def test_generated_native_plan_uses_installed_tools_without_path_lookup(self):
        synthetic={'status':'SYNTHETIC_PLAN_FIXTURE_NOT_AN_AUDIT_OR_CANDIDATE',
                   'candidate_sha256':'c'*64}
        with tempfile.TemporaryDirectory() as temporary:
            out=Path(temporary)/'synthetic-plan-only'
            with mock.patch.object(gate,'check',return_value=synthetic), contextlib.redirect_stdout(io.StringIO()):
                gate.prepare(SimpleNamespace(out=out))
            plan=json.loads((out/'native-commands.json').read_text())
            commands={c['name']:c['argv'] for c in plan['commands']}
            for name, banner in [('release-configure','cmake version'),('release-build','cmake version'),('ctest14','ctest version')]:
                executable=commands[name][0]
                with self.subTest(step=name):
                    self.assertTrue(Path(executable).is_absolute(), 'Native plan must run installed tool with PATH unavailable')
                    result=subprocess.run([executable,'--version'],env={**os.environ,'PATH':'/nonexistent-path-for-plan-test'},capture_output=True,text=True,check=False)
                    self.assertEqual(result.returncode,0,result.stderr)
                    self.assertIn(banner,result.stdout)

if __name__=='__main__':unittest.main(verbosity=2)
