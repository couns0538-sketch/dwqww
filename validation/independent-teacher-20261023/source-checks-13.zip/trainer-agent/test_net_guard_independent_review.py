"""Independent, clearly synthetic guard checks; never scores or launches models."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import tempfile
import unittest

H = Path('/workspace/forge-independent-teacher-20261023')
spec = importlib.util.spec_from_file_location('net_gate_author_fixtures', H / 'test_guard_net_only_candidate.py')
fixtures_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixtures_module)
gate = fixtures_module.gate
fixtures = fixtures_module.fixtures


class IndependentGuardChecks(unittest.TestCase):
    def execution_fixture(self, temporary):
        root = Path(temporary)
        for name in ('stdout', 'stderr'):
            (root / name).write_bytes(('clearly synthetic ' + name).encode())
        receipt = {'status': 'COMPLETED', 'actual_exit': 0,
                   'closed_utc': '2026-10-23T22:02:00+00:00', 'argv': ['synthetic-never-executed']}
        for name in ('stdout', 'stderr'):
            raw = (root / name).read_bytes()
            receipt[name + '_sha256'] = hashlib.sha256(raw).hexdigest()
            receipt[name + '_bytes'] = len(raw)
        path = root / 'result.json'
        path.write_text(json.dumps(receipt))
        return path, receipt

    def test_closed_receipt_positive_control_and_boolean_exit_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            path, receipt = self.execution_fixture(temporary)
            gate.closed_execution(path, receipt['argv'])
            receipt['actual_exit'] = False
            path.write_text(json.dumps(receipt))
            with self.assertRaises(ValueError): gate.closed_execution(path, receipt['argv'])

    def test_closed_receipt_original_stream_corruption_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            path, receipt = self.execution_fixture(temporary)
            path.with_name('stderr').write_bytes(b'changed synthetic bytes')
            with self.assertRaises(ValueError): gate.closed_execution(path, receipt['argv'])

    def test_closed_receipt_missing_stream_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            path, receipt = self.execution_fixture(temporary)
            path.with_name('stdout').unlink()
            with self.assertRaises((ValueError, OSError)): gate.closed_execution(path, receipt['argv'])

    def test_upper_interval_nonfinite_type_and_reversed_bounds_rejected(self):
        for upper in (float('nan'), float('inf'), True, '0.03', .005):
            _, frozen, metrics, marker, _ = fixtures()
            metrics['comparisons']['shipped_vs_candidate']['ci95_abs'][1] = upper
            with self.subTest(upper=upper), self.assertRaises(ValueError):
                gate.audit_policy(metrics, frozen, marker, 'f' * 64, 'a' * 64, 100)

    def test_protocol_primary_cluster_identity_and_freeze_order_rejected(self):
        for field in ('protocol', 'games', 'draws', 'seed', 'before_freeze', 'future_marker'):
            _, frozen, metrics, marker, _ = fixtures()
            comparison = metrics['comparisons']['shipped_vs_candidate']
            if field == 'protocol': metrics['protocol']['sha256'] = 'e' * 64
            elif field == 'games': comparison['games'] = 9
            elif field == 'draws': comparison['draws'] = 9999
            elif field == 'seed': comparison['seed'] = 2
            elif field == 'before_freeze': marker['utc'] = frozen['utc']
            else: marker['utc'] = '2026-10-23T22:03:00+00:00'
            with self.subTest(field=field), self.assertRaises(ValueError):
                gate.audit_policy(metrics, frozen, marker, 'f' * 64, 'a' * 64, 100)

    def test_missing_primary_comparison_cannot_use_secondary(self):
        _, frozen, metrics, marker, _ = fixtures()
        metrics['comparisons']['hce_vs_candidate'] = metrics['comparisons'].pop('shipped_vs_candidate')
        with self.assertRaises((KeyError, ValueError)):
            gate.audit_policy(metrics, frozen, marker, 'f' * 64, 'a' * 64, 100)

    def test_nonfinite_validation_and_incomplete_epoch_sequence_rejected(self):
        for field in ('nan', 'missing_epoch', 'epoch_zero', 'changed_target'):
            summary, frozen, _, _, changes = fixtures()
            if field == 'nan': summary['epochs'][0]['target_mse_combined'] = float('nan')
            elif field == 'missing_epoch': summary['epochs'].pop()
            elif field == 'epoch_zero': summary['epochs'][0]['epoch'] = 0
            else: summary['config']['selection_target']['result_weight'] = .3
            with self.subTest(field=field), self.assertRaises(ValueError):
                gate.selection_policy(summary, frozen, changes)

    def test_numeric_parser_observes_one_real_quantized_b2_change(self):
        with tempfile.TemporaryDirectory() as temporary:
            original = gate.R / 'src/nnue_weights.inc'
            text = original.read_text(encoding='ascii')
            pattern = r'(\bstatic\s+const\s+std::int16_t\s+NnueB2\s*=\s*)([+-]?\d+)(\s*;)'
            found = re.search(pattern, text)
            self.assertIsNotNone(found)
            value = int(found.group(2)); changed = value + (1 if value < 32767 else -1)
            edited = re.sub(pattern, lambda m: m.group(1) + str(changed) + m.group(3), text)
            path = Path(temporary) / 'clearly-synthetic-not-a-candidate.inc'
            path.write_text(edited, encoding='ascii')
            self.assertEqual(gate.quantized_changes(original, path), {'W1': 0, 'B1': 0, 'W2': 0, 'B2': 1})


if __name__ == '__main__': unittest.main(verbosity=2)
