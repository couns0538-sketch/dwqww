#!/usr/bin/env python3
"""Prepare inert path-only support. Never compile or launch Wine/engines."""
import pathlib,json,hashlib,subprocess,shlex,difflib,datetime
H=pathlib.Path('/workspace/forge-independent-teacher-20261023');R=pathlib.Path('/workspace/dwqww');O=H/'windows-qualified-02';S=H/'qualified-native-02/source';B=pathlib.Path('/workspace/.cloud-setup/independent-teacher-windows-02/build')
BASE='1ab50b2dd64d9b2f752f7f1285f6968cad2fd792';W='/workspace/.cloud-setup/wine/usr/lib/wine/wine64'
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
old_runner=pathlib.Path('/workspace/forge-nnue-handoff-20261023/windows-final-net-trial-attempt1/run_windows_trial.py')
assert sha(old_runner)=='01c2138057839da3d96fbb7a4bc8354367ffdae36e080b5518e887c3f8465f98', 'Prior runner changed; re-review required'
original=subprocess.check_output(['git','show',BASE+':tools/ownbook_regression.py'],cwd=R).decode()
assert (R/'tools/ownbook_regression.py').read_text()==original
assert original.count('str(book)')==2 and original.count('{book} with 1 entries')==2
new=original.replace('ROOT = Path(__file__).resolve().parents[1]','ROOT = Path('+repr(str(S))+')')
new=new.replace('            e.send("setoption name Book File value " + str(book))','            book_sent = "Z:" + str(book).replace("/", chr(92))\n            e.send("setoption name Book File value " + book_sent)',1)
new=new.replace(' + str(book))',' + book_sent)').replace('{book} with 1 entries','{book_sent} with 1 entries')
compile(new,'ownbook-wine-regression.py','exec')
old_adapter=pathlib.Path('/workspace/forge-nnue-handoff-20261023/windows-final-net-trial-attempt1/ownbook-wine-regression.py')
assert sha(old_adapter)=='52ec118b6673d5c95bd1d9ec408c913adc949a3984ac03f93a2e9e6d78ea9f03'
assert old_adapter.read_text().replace("ROOT = Path('/workspace/.cloud-setup/nnue-final-windows-attempt1/source')",'ROOT = Path('+repr(str(S))+')')==new
O.mkdir(exist_ok=False)
with (O/'ownbook-wine-regression.py').open('x') as f:f.write(new)
with (O/'ownbook-path-only.diff').open('x') as f:f.write(''.join(difflib.unified_diff(original.splitlines(True),new.splitlines(True),fromfile=BASE+':tools/ownbook_regression.py',tofile='windows-qualified-02/ownbook-wine-regression.py')))
env={'WINEPREFIX':'/workspace/.cloud-setup/wine-prefix-ready','WINEDEBUG':'-all','XDG_CACHE_HOME':'/workspace/.cloud-setup/font-cache'}
for name,exe in [('forge-wine','forge.exe'),('forge-probe-wine','forge_nnue_probe.exe')]:
 p=O/name
 with p.open('x') as f:f.write('#!/bin/bash\n'+''.join('export '+k+'='+shlex.quote(v)+'\n' for k,v in env.items())+'exec '+shlex.quote(W)+' '+shlex.quote(str(B/exe))+' "$@"\n')
 p.chmod(0o755)
with (O/'bench.stdin').open('x') as f:f.write('bench 11\nquit\n')
with (O/'original-run_windows_trial.py.txt').open('xb') as f:f.write(old_runner.read_bytes())
with (O/'original-ownbook-1ab.py.txt').open('x') as f:f.write(original)
records={p.name:{'sha256':sha(p),'bytes':p.stat().st_size,'mode':oct(p.stat().st_mode&0o777)} for p in O.iterdir() if p.is_file()}
receipt={'status':'INERT_SUPPORT_PREPARED_PENDING_STATIC_TESTS_NO_RUNTIME','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseline':BASE,'source_root':str(S),'windows_build':str(B),'files':records,'actual_windows_executables_exist':list(B.glob('*.exe'))!=[],'engine_or_wine_or_build_launched':False,'prior_runner_source_preserved_sha256':sha(O/'original-run_windows_trial.py.txt'),'original_ownbook_from_git_sha256':hashlib.sha256(original.encode()).hexdigest(),'transformation':'Only ROOT binding; str(book) sent/expected path representation -> book_sent Z:Windows path. All other AST structure must equalbaseline after inversepathnormalization.'}
with (O/'PREPARATION.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps(receipt,indent=2))
