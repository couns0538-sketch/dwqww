"use strict";
/** Time management v2 (UCI layer). Pure functions, no search.ts dependency.
 *  hard limit: enforced by a main-thread timer through the shared stop flag (precise, not 4096-node polling).
 *  soft limit: checked after each completed iteration (info callback); scaled by best-move stability and score drop. */
Object.defineProperty(exports, "__esModule", { value: true });
exports.SoftController = void 0;
exports.effectiveOverhead = effectiveOverhead;
exports.computeBudget = computeBudget;
const DEFAULT_MTG = 28;
/** Overhead per move: UCI option plus extra allowance at short time controls (process scheduling, pipe latency). */
function effectiveOverhead(time, moveOverhead) {
    const mo = Math.max(0, moveOverhead);
    if (time < 1500)
        return mo + 40;
    if (time < 5000)
        return mo + 25;
    if (time < 15000)
        return mo + 10;
    return mo;
}
function computeBudget(inp) {
    const time = Math.max(0, inp.time ?? 0);
    const inc = Math.max(0, inp.inc ?? 0);
    const ovh = effectiveOverhead(time, inp.moveOverhead);
    const mtgGiven = inp.movestogo !== undefined && inp.movestogo > 0;
    const mtg = mtgGiven ? Math.min(inp.movestogo, 60) : DEFAULT_MTG;
    const usable = Math.max(0, time - ovh);
    let soft = usable / mtg + inc * 0.75;
    // fraction of the clock we allow ourselves on hard: ~40%, rises as the control nears (last moves before time control)
    const frac = mtgGiven && mtg <= 2 ? (mtg === 1 ? 0.8 : 0.55) : 0.4;
    let hard = Math.min(soft * 3.2, usable * frac);
    // never spend more than the clock minus overhead (incl. the increment we get back only after moving)
    const ceiling = Math.max(0, usable - 5);
    soft = Math.min(soft, hard * 0.8, ceiling);
    hard = Math.min(hard, ceiling);
    // safe floors, but never exceeding what is left
    const floor = Math.min(15, Math.max(1, Math.floor(usable * 0.5)));
    if (hard < floor)
        hard = floor;
    if (soft < floor * 0.6)
        soft = floor * 0.6;
    if (soft > hard)
        soft = hard;
    return { soft: Math.floor(soft), hard: Math.floor(hard) };
}
/** Per-search dynamic soft-limit state. Feed it each completed iteration. */
class SoftController {
    constructor(budget) {
        this.budget = budget;
        this.prevMove = '';
        this.stable = 0;
        this.prevScore = 0;
        this.dropBonus = 1;
    }
    /** returns true if the search should stop now (after this completed iteration). */
    onIteration(depth, score, bestUci, elapsed) {
        if (bestUci === this.prevMove)
            this.stable++;
        else {
            this.stable = 0;
        }
        if (depth > 1 && score < this.prevScore - 25)
            this.dropBonus = Math.min(1.6, this.dropBonus + 0.25);
        else
            this.dropBonus = Math.max(1, this.dropBonus - 0.1);
        this.prevMove = bestUci;
        this.prevScore = score;
        if (depth < 4)
            return false;
        const stabFactor = [1.35, 1.15, 1.0, 0.9, 0.8, 0.72][Math.min(this.stable, 5)];
        const target = Math.min(this.budget.hard * 0.9, this.budget.soft * stabFactor * this.dropBonus);
        // next iteration typically costs ~2x: stop if we would not finish it within target
        return elapsed >= target * 0.55;
    }
}
exports.SoftController = SoftController;
//# sourceMappingURL=timeman.js.map