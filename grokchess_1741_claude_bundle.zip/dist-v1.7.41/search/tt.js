"use strict";
/** Transposition table — packed entries; optional SharedArrayBuffer for Lazy SMP */
Object.defineProperty(exports, "__esModule", { value: true });
exports.MATE_BOUND = exports.MATE_SCORE = exports.TranspositionTable = exports.TT_SIZE = void 0;
exports.createSharedTTBundle = createSharedTTBundle;
exports.packMove = packMove;
exports.unpackMove = unpackMove;
exports.scoreToTT = scoreToTT;
exports.scoreFromTT = scoreFromTT;
/** Default 4M entries; shared SMP uses same. */
exports.TT_SIZE = 1 << 22;
function createSharedTTBundle(size = exports.TT_SIZE) {
    const depthsSab = new SharedArrayBuffer(size);
    new Int8Array(depthsSab).fill(-1);
    return {
        size,
        keysHiSab: new SharedArrayBuffer(size * 4),
        keysLoSab: new SharedArrayBuffer(size * 4),
        depthsSab,
        scoresSab: new SharedArrayBuffer(size * 2),
        flagsSab: new SharedArrayBuffer(size),
        agesSab: new SharedArrayBuffer(size),
        movesSab: new SharedArrayBuffer(size * 4),
        metaSab: new SharedArrayBuffer(4),
    };
}
/** Pack from/to/promo; 0 = null. sameMove only needs these fields. */
function packMove(m) {
    if (!m)
        return 0;
    return (1 + m.from + (m.to << 6) + ((m.promo & 15) << 12)) >>> 0;
}
function unpackMove(code) {
    if (!code)
        return null;
    const v = (code - 1) >>> 0;
    return {
        from: v & 63,
        to: (v >>> 6) & 63,
        promo: (v >>> 12) & 15,
        piece: 0 /* Piece.None */,
        captured: 0 /* Piece.None */,
        flags: 0,
    };
}
class TranspositionTable {
    constructor(size = exports.TT_SIZE, bundle) {
        /** Optional object cache for local TT only (unused when shared). */
        this.moves = null;
        this.age = 0;
        this.sharedMeta = null;
        this.isShared = false;
        if (bundle) {
            this.size = bundle.size;
            this.keysHi = new Int32Array(bundle.keysHiSab);
            this.keysLo = new Int32Array(bundle.keysLoSab);
            this.depths = new Int8Array(bundle.depthsSab);
            this.scores = new Int16Array(bundle.scoresSab);
            this.flags = new Uint8Array(bundle.flagsSab);
            this.ages = new Uint8Array(bundle.agesSab);
            this.moveCodes = new Uint32Array(bundle.movesSab);
            this.sharedMeta = new Int32Array(bundle.metaSab);
            this.isShared = true;
            this.age = Atomics.load(this.sharedMeta, 0) & 255;
        }
        else {
            this.size = size;
            this.keysHi = new Int32Array(size);
            this.keysLo = new Int32Array(size);
            this.depths = new Int8Array(size);
            this.scores = new Int16Array(size);
            this.flags = new Uint8Array(size);
            this.ages = new Uint8Array(size);
            this.moveCodes = new Uint32Array(size);
            this.depths.fill(-1);
        }
    }
    clear() {
        this.depths.fill(-1);
        this.moveCodes.fill(0);
        this.keysHi.fill(0);
        this.keysLo.fill(0);
        this.scores.fill(0);
        this.flags.fill(0);
        this.ages.fill(0);
        this.age = 0;
        if (this.sharedMeta)
            Atomics.store(this.sharedMeta, 0, 0);
    }
    index(lo) {
        return lo & (this.size - 1);
    }
    probe(hi, lo) {
        const i = lo & (this.size - 1);
        if (this.keysLo[i] === lo && this.keysHi[i] === hi && this.depths[i] >= 0) {
            return {
                hi, lo,
                depth: this.depths[i],
                score: this.scores[i],
                flag: this.flags[i],
                bestMove: unpackMove(this.moveCodes[i]),
                age: this.ages[i],
            };
        }
        return null;
    }
    store(hi, lo, depth, score, flag, bestMove) {
        const i = lo & (this.size - 1);
        const curD = this.depths[i];
        const same = this.keysLo[i] === lo && this.keysHi[i] === hi && curD >= 0;
        if (same && depth < curD && flag !== 0 /* TTFlag.Exact */) {
            if (!this.moveCodes[i] && bestMove)
                this.moveCodes[i] = packMove(bestMove);
            return;
        }
        if (same && depth < curD) {
            if (!this.moveCodes[i] && bestMove)
                this.moveCodes[i] = packMove(bestMove);
            return;
        }
        // ttkeep: wrap-safe generation distance (age is 8-bit and now persists across go)
        if (!same && curD >= 0 && depth < curD && ((this.age - this.ages[i]) & 255) <= 2 && flag !== 0 /* TTFlag.Exact */) {
            return;
        }
        // Racy writes OK for Lazy SMP — last writer wins
        this.keysHi[i] = hi;
        this.keysLo[i] = lo;
        this.depths[i] = depth > 127 ? 127 : depth;
        this.scores[i] = score > 32767 ? 32767 : score < -32768 ? -32768 : score;
        this.flags[i] = flag;
        this.moveCodes[i] = packMove(bestMove);
        this.ages[i] = this.age & 255;
    }
    prefetchAge() {
        if (this.sharedMeta) {
            // Approximate age bump; races are fine for replacement policy
            let a = (Atomics.load(this.sharedMeta, 0) + 1) & 255;
            Atomics.store(this.sharedMeta, 0, a);
            this.age = a;
        }
        else {
            this.age = (this.age + 1) & 255;
        }
    }
}
exports.TranspositionTable = TranspositionTable;
exports.MATE_SCORE = 30000;
exports.MATE_BOUND = 29000;
function scoreToTT(score, ply) {
    if (score > exports.MATE_BOUND)
        return score + ply;
    if (score < -exports.MATE_BOUND)
        return score - ply;
    return score;
}
function scoreFromTT(score, ply) {
    if (score > exports.MATE_BOUND)
        return score - ply;
    if (score < -exports.MATE_BOUND)
        return score + ply;
    return score;
}
//# sourceMappingURL=tt.js.map