- 2026-10-14 18:40 PT | ttcuthist2-1735 (Coder; replaces ttcuthist-1735) | PASS CR (stm+pseudo-legal guards; search.js-only; js ef630d53) | UNPROVEN | research/cr_ttcuthist2_1735_review.md; handoff_1735 ACTIVE 14; lock 1.7.35 intact
- 2026-10-14 17:46 PT | texel-1735 / threats2-1735 / hmfade-1735 on lock 1.7.35 | texel READY js 39b62ba0 bench 242692/452851; threats2 HELD js 426b0a90; hmfade HAND-MERGED READY js f0d214d5 bench=lock; all gates PASS PARTIAL 0 new | UNPROVEN | research/cr1735/handoff_1735.txt ACTIVE
- 2026-10-14 17:40 PT | cr1735 ACTIVATE (was provisional) | 11 eval -1735 + building texel/threats2/hmfade | UNPROVEN | research/cr1735/handoff_1735.txt
- 2026-10-14 16:57 PT | cr1735 provisional→superseded by ACTIVE 17:46 on tteval | 11 eval -1735 built (hmfade CONFLICT skip) | UNPROVEN provisional→superseded by ACTIVE 17:46 | research/cr1735/handoff_1735.txt
- 2026-10-14 16:52 PT | kpk2-1734 | PASS CR (promo 0/25500, SF 0/400, lock-fail FOUND) | UNPROVEN | research/cr_kpk2_1734_review.md
- imbal-1733 (base 1.7.33, 2026-10-14): Kaufman pawn-count N/R imbalance, hand S(5,6)/S(10,12). dist-cand-imbal-1733 js-tree 8c37bd3c6f573d30e5bf61d24a69fe0b, patch cr_imbal_1733_ts.patch md5 bd6ee599f149bf6c2c8860b5b86af8df, bench d9 248698 / d10 379890. Gates PASS PARTIAL. UNPROVEN (post-push).
# Code Review: mainline experiment archive (1.7.x line, 48-game gates @100ms, Threads=1)
All results below are UNPROVEN, not dead: 48 games is about +-100 Elo at 95%. Source of truth with logs: /workspace/chess-engine/PROGRESS.md and results/gate_*.log; candidate binaries in /workspace/chess-engine/baseline/dist-candidate-*.

## Accepted (locked, QA signed off), score vs previous lock
- 1.7.12 follow-up move slot (quiet cutoff keyed 2 plies back, ordered 640000): 27.5/48
- 1.7.13 non-improving LMR +1: 27/48
- 1.7.14 null-move extra reduction when not improving: 28/48
- 1.7.15 follow-up LMR reduction: 27/48
- 1.7.16 singular depth floor 10: 28/48
- 1.7.17 check extension only at depth<=6: 30/48
- 1.7.18 recapture extension only depth<=3: 30/48
- 1.7.19 singular seExtend=2 (+ MAX_PLY guard QA required): 28.5/48
- 1.7.20 recapture extension only depth<=2: 28/48
- 1.7.21 LMR R+1 when TT move is a capture: 27.5/48
- 1.7.22 LMR R+1 when TT flag is Lower: 27.5/48
- 1.7.23 ProbCut only when improving: 27/48 (QA: mostly an endgame effect, near noise)

## Missed (retest only under real SPRT, after bugs)
- vs 1.7.11-1.7.15: killer LMR R=1 (23.5), razor depth 3 (26), negative-history quiet prune (26), qsearch quiet checks (19), SEE scratch alloc (23.5), follow-up futility exception (26), reverse futility depth 4 (26), tighter not-improving futility (20.5), losing-check ext skip (23), SEE-negative capture reduction (23.5), 7th-rank pawn ext (24), capture-history ordering tiebreak (25), PV singular ext (24)
- vs 1.7.15-1.7.18: recapture depth 6 (22.5), no-hash-move depth cut/IIR (22), one-reply ext (24), equal-trade qsearch SEE skip (24.5), qsearch quiet ordering (22.5), aspiration fail-high keep (24.5), quiet-check LMR (26), improving LMR bonus (22.5), aspiration window 80 (23.5), no double-null (22.5), ProbCut floor 7 (24.5), IID floor 8 (24), SEE prune -200*depth (24.5), qsearch delta 100 (26), singular margin 4*depth (25), private TT kept across moves (20), check-ext cap 4 (23.5), null base R=4 (26), ProbCut margin 220 (21.5)
- vs 1.7.20-1.7.22: singular floor 9 (22.5), history term in LMR (22.5), TT-Upper LMR R-1 (24.0, ~0 Elo), TT-Lower depth gate (25), null-move verification depth>=8 (23.5)
- earlier: LMR startup table (23.5)

## Eval / tuning history
- Old Texel attempts (190-900 positions, engine-search labels, stale eval cache/pawn hash after weight changes, no mobility bound) all overfit or were no-ops; never applied.
- Tuner v2 (scripts/tune/): extractor verified <1 cp vs evaluate(); 3M rows from /workspace/chess-tools/data/quiet-evals.csv (cp column is side-to-move POV); holdout MSE lock 0.013975, tuned1 0.013298, tuned2 0.012453, tuned3 0.012786, tuned3s 0.013100. SPRT results pending in CHANGELOG.md.
- Mainline-only unlocked note: lmrlate (R+1 for legalCount>8) scored 27/48 once but was never QA-signed or promoted.

## 1.7.33 eval builds (Code Review, 2026-10-14 11:00 PT), UNPROVEN, no games
- passer2-1733: passed-pawn stop square blocked/clear/safe x rank scale + unstoppable (rule of the square, opponent K+P only). js 83afef4c, bench 249423/450048. Queued for [0,10] vs 1.7.33.
- threats2-1733: typed minor/rook threats + hanging + safe-pawn threats, Forge 6.3 values 1:1. js a3302db6, bench 252848/372159. HELD for texel-1733 then refit (prior hand-set threats: hanging 24.5/48 on 1.7.4; bundles -24/-27 Elo).
- wbish-1733: wrong-bishop rook-pawn fortress eg scale 4/64 (strong = B+rook-file pawns only, bishop misses promo sq, weak K near corner). js 62acbe5c, patch ad8eb3e7, bench = lock 269586/467620. Gates PASS PARTIAL 0 new. UNPROVEN; QA [0,10] H64 vs 1.7.33.
- hmfade-1733: 50-move-rule eval fade, final score * (100-hm)/40 when hm > 60 (0 at 100), evaluate+evaluateQ, eval-cache key xor imul(hm) only when hm>60. js 63ec2044, patch f45a5417, bench = lock 269586/467620. Gates PASS PARTIAL 0 new. UNPROVEN; QA [0,10] H64 vs 1.7.33.

## 1.7.34 eval rebuilds (Code Review, 2026-10-14 15:03 PT), UNPROVEN, no games
- escale-1734: escale-1733 on 1.7.34 (evalfast). js fa2b528f, patch 94402fe5, bench 271203/515229 (= 1733 build). Eval identical to 1733 build. Gates PASS PARTIAL 0 new. UNPROVEN; QA [0,10] H64 vs 1.7.34.
- fewpawn-1734: fewpawn-1733 on 1.7.34. js 21d48de5, patch 312dd894, bench 264409/472657 (= 1733). Gates PASS PARTIAL 0 new. UNPROVEN.
- imbal-1734: imbal-1733 on 1.7.34. js b1205a1b, patch 07f956ad, bench 248698/379890 (= 1733). Gates PASS PARTIAL 0 new. UNPROVEN; refit if texel locks.
- wbish-1734: wbish-1733 on 1.7.34. js a01d0655, patch 9e2bd10b, bench = lock. Gates PASS PARTIAL 0 new. UNPROVEN.
- hmfade-1734: hmfade-1733 fade + TT guard (ttKeyHi salts TT hi key with hm only when hm>60) as one change. js 4929ea33, patch cf399d3f, bench = lock. Gates PASS PARTIAL 0 new, unit 45/45. UNPROVEN; supersedes hmfade-1733.
- threats2-1734: threats2-1733 on 1.7.34 (HELD for texel verdict). js bacc99d4, patch 2f84261f, bench 252848/372159 (= 1733). Gates PASS PARTIAL 0 new. UNPROVEN.

## 1.7.34 eval rebuilds batch B (Code Review, 2026-10-14 15:56 PT), UNPROVEN, no games
- texel-1734 js 4d23031c (weights/pst = texel-1733), bench 241188/424981. passer2-1734 js 93b5d935, bench 249423/450048. rookpass-1734 js 9b475268, bench 271484/465508. kpdist-1734 js a510a2c6, bench 273515/472567.
- longdiag2-1734 js cf78b2c9, bench 250246/405430 (supersedes longdiag). weakqueen-1734 js 28636498, bench 259126/513594. weakunopp-1734 js d701ee31, bench 235258/415959.
- All: eval == the 1733 build (0 mismatches), bench == the 1733 build, gates PASS PARTIAL 0 new. QA [0,10] H64 vs 1.7.34. Handoff research/cr1734/handoff_1734b.txt.
- mopup-1734 (parallel CR run, 38380cab, post-taper): KRK/KQK playout lock 6/8 mates in 556 plies vs cand 8/8 in 190.
