// Launch node --cpu-prof on inproc_nnue for one build at d10 (suite).
const {spawn}=require('child_process');
const [dist,tag,dep]=process.argv.slice(2);
const DEP=dep||'10';
const outDir=__dirname+'/prof';
const p=spawn('node',[
  '--cpu-prof','--cpu-prof-dir',outDir,'--cpu-prof-name',tag+'.cpuprofile',
  __dirname+'/inproc_nnue.js', dist, DEP
],{env:{...process.env,GROKCHESS_USE_NNUE:'1',TZ:'America/Los_Angeles'},stdio:['ignore','pipe','pipe']});
let o='',e='';
p.stdout.on('data',d=>o+=d);
p.stderr.on('data',d=>e+=d);
p.on('exit',c=>{console.log(o.trim()); if(e.trim())console.error(e.trim()); console.log(tag,'exit',c);});
