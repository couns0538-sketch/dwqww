# prof1740_cpu — lock 1.7.40 d10 CPU profile (2026-10-15 20:31 PT)
Source: copy of /workspace/chess-engine/baseline/dist-v1.7.40 in ./src (net md5 157e6b16, NNUE active, hid=64).
Method: same as prof1736_2317 (inproc_nnue.js, 6 positions, Threads=1 in-process, TT 1<<20 = Hash 16, d10), `nice -n 19 taskset -c 7 node --cpu-prof`, single run, load 4.27 at start.
Run: nodes=353610 cpu=2296ms nps=154032 (in-process 6-position sum; not the bench 350802 count). Profile: prof/L1740.cpuprofile; full tables: prof_L1740.txt (byfile.py).

NNUE self-time 15.6% = applyMove 8.1 + updateAccumulator 4.0 + nnueEvaluate (forward) 3.0 + load 0.5.
Accumulator upkeep (applyMove+updateAccumulator) 12.1%; inference ~3%.
Search 35.0% (negamax 20.3, orderMoves 8.6, qsearch 4.4) + SEE 3.1; movegen+magics 9.8; TT 9.7; board 7.6; evaluate.js wrapper 7.0; GC 5.6.
vs prof1736_2317 (N64d40, 1.7.37 build): NNUE 10.9% -> 15.6% (applyMove 6.9->8.1, updateAccumulator newly separate 4.0, nnueEvaluate 2.4->3.0); movegen 15.0->9.8; board 10.6->7.6. Single sample each, ~2.5s profiles: treat shifts of <1pt as noise.
total_ms 2768

## top25 functions (self)
  search.js:negamax                              20.3%   562ms
  search.js:orderMoves                            8.6%   238ms
  nnue.js:applyMove                               8.1%   223ms
  evaluate.js:evaluate                            6.9%   190ms
  (garbage collector)                             5.6%   154ms
  tt.js:TranspositionTable                        5.0%   139ms
  search.js:quiescence                            4.4%   122ms
  nnue.js:updateAccumulator                       4.0%   111ms
  movegen.js:emitTargets                          4.0%   111ms
  movegen.js:generateMoves                        3.4%    93ms
  see.js:seeClassic                               3.1%    86ms
  nnue.js:nnueEvaluate                            3.0%    82ms
  tt.js:store                                     2.9%    81ms
  board.js:makeMove                               1.9%    53ms
  board.js:isAttacked                             1.9%    53ms
  tt.js:probe                                     1.5%    41ms
  board.js:unmakeMove                             1.4%    38ms
  magics.js:(magics.js)                           1.3%    37ms
  realm:compileForInternalLoader                  1.1%    29ms
  board.js:removePiece                            1.1%    29ms
  magics.js:initMagics                            0.8%    22ms
  givescheck.js:givesCheckQuiet                   0.8%    21ms
  (idle)                                          0.5%    14ms
  board.js:putPiece                               0.5%    12ms
  board.js:makeNullMove                           0.4%    10ms

## top25 files (self)
  search.js                       35.0%   968ms
  nnue.js                         15.6%   430ms
  tt.js                            9.7%   267ms
  board.js                         7.6%   211ms
  movegen.js                       7.5%   206ms
  evaluate.js                      7.0%   192ms
  (garbage collector)              5.6%   154ms
  see.js                           3.1%    86ms
  magics.js                        2.4%    65ms
  realm                            1.2%    31ms
  bitboard.js                      1.0%    28ms
  loader                           0.9%    25ms
  givescheck.js                    0.9%    23ms
  (idle)                           0.5%    14ms
  node:fs                          0.3%     7ms
  zobrist.js                       0.3%     7ms
  node:path                        0.2%     6ms
  errors                           0.2%     5ms
  (program)                        0.1%     4ms
  inproc_nnue.js                   0.1%     3ms
  node                             0.1%     3ms
  attacks.js                       0.1%     2ms
  pre_execution                    0.1%     2ms
  node:buffer                      0.1%     2ms
  node:net                         0.1%     2ms

## categories
  search                        35.0%
  NNUE                          15.6%
  other/GC/runtime              12.3%
  movegen                        9.8%
  TT                             9.7%
  board make/unmake/attacks      7.6%
  eval wrapper                   7.0%
  search(SEE)                    3.1%
