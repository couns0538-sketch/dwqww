// in-process single-thread search (no worker), CPU time via process.cpuUsage
const D=process.argv[2],DEP=+process.argv[3]||9,which=process.argv[4]||'all';const E=require(D+'/index.js');
const P=[['startpos',E.START_FEN],['kiwipete','r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1'],['qgd-middle','r1bq1rk1/pp2bppp/2n1pn2/3p4/2PP4/2N1PN2/PP3PPP/R2QKB1R w KQ - 0 8'],['rook-endgame','8/5pk1/6p1/8/3R4/6P1/r4PK1/8 w - - 0 1'],['pos3-endgame','8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1'],['tactical-pos4','r3k2r/Pppp1ppp/1b3nbN/nP6/BBP1P3/q4N2/Pp1P2PP/R2Q1RK1 w kq - 0 1']];
const sel=which==='all'?P:P.filter(p=>which.split(',').includes(p[0]));
let info='';try{const N=require(D+'/eval/nnue.js');info=' nnue_active='+N.nnueActive()+' hid='+N.hiddenSize()+' ['+N.nnueInfo()+']';}catch(e){info=' nnue=none';}
let tn=0,tc=0;for(const [n,f] of sel){const b=new E.Board(f);const s=new E.Search(b);{const T=require(D+'/search/tt.js');s.tt=new T.TranspositionTable(1<<20);}/*Hash=16,T1*/const c0=process.cpuUsage();s.search({maxDepth:DEP});const c=process.cpuUsage(c0);tn+=s.nodes;tc+=(c.user+c.system)/1000;}
console.log(`INPROC ${require('path').basename(D)} d=${DEP} nodes=${tn} cpu=${tc.toFixed(0)}ms nps=${Math.round(tn*1000/tc)}${info}`);
