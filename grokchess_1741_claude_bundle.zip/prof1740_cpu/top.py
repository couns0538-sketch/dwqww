import json,sys,collections
for f in sys.argv[1:]:
  j=json.load(open(f));n={x['id']:x for x in j['nodes']};c=collections.Counter(j['samples'])
  dt=collections.Counter()
  for i,t in zip(j['samples'],j['timeDeltas']):dt[i]+=t
  agg=collections.Counter()
  for i,t in dt.items():cf=n[i]['callFrame'];agg[cf['functionName'] or '('+cf['url'].split('/')[-1]+')']+=t
  tot=sum(agg.values());print(f,'total ms',tot//1000)
  for k,v in agg.most_common(int(__import__("os").environ.get("N","14"))):print('  %-28s %6.1f%% %6dms'%(k,100*v/tot,v//1000))
