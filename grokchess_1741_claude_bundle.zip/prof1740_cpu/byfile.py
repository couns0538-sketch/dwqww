import json,sys,collections
j=json.load(open(sys.argv[1]));n={x['id']:x for x in j['nodes']}
dt=collections.Counter()
for i,t in zip(j['samples'],j['timeDeltas']):dt[i]+=t
fn=collections.Counter();fl=collections.Counter()
for i,t in dt.items():
  cf=n[i]['callFrame'];f=cf['url'].split('/')[-1];name=cf['functionName'] or '('+f+')'
  fn[(f+':' if f else '')+name]+=t;fl[f or name]+=t
tot=sum(fn.values());print('total_ms',tot//1000)
print('\n## top25 functions (self)');[print('  %-45s %5.1f%% %5dms'%(k,100*v/tot,v//1000)) for k,v in fn.most_common(25)]
print('\n## top25 files (self)');[print('  %-30s %5.1f%% %5dms'%(k,100*v/tot,v//1000)) for k,v in fl.most_common(25)]
cat=collections.Counter()
m={'nnue.js':'NNUE','search.js':'search','tt.js':'TT','movegen.js':'movegen','magics.js':'movegen','see.js':'search(SEE)','board.js':'board make/unmake/attacks','evaluate.js':'eval wrapper'}
for k,v in fl.items():cat[m.get(k,'other/GC/runtime')]+=v
print('\n## categories');[print('  %-28s %5.1f%%'%(k,100*v/tot)) for k,v in cat.most_common()]
